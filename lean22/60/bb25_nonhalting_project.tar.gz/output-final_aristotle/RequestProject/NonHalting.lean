import RequestProject.Walls
import RequestProject.LeftEnd
import RequestProject.RightEnd

/-!
# Non-halting of `1RB2LA3LB4LB---_0LA4LB3RA4LA0RB`

This file states the goal — that the machine started on the blank tape never halts — and
collects the elementary facts about halting.  The statement `never_halts` is **not yet
proved**; see `ANALYSIS.md` in the repository root for a detailed description of what has
been established (`Blocks.lean`, `Walls.lean`, `RightEnd.lean`) and what is missing.
-/

namespace BB25

/-! ### Elementary facts about halting -/

@[simp] lemma step_halt (p : ℤ) (T : ℤ → Sym) : step ⟨St.H, p, T⟩ = ⟨St.H, p, T⟩ := rfl

/-- The halting state is absorbing. -/
lemma halted_step {c : Cfg} (h : Halted c) : Halted (step c) := by
  obtain ⟨st, p, T⟩ := c
  cases st <;> simp_all [Halted, step]

/-- Once halted, always halted. -/
lemma halted_mono {m n : ℕ} (hmn : m ≤ n) (h : Halted (run m)) : Halted (run n) := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hmn
  clear hmn
  induction k with
  | zero => simpa using h
  | succ k ih =>
      have : run (m + (k + 1)) = step (run (m + k)) := by
        unfold run
        rw [show m + (k + 1) = (m + k) + 1 by ring, Function.iterate_succ_apply']
      rw [this]
      exact halted_step ih

/-- Consequently, checking a single configuration bounds the halting time from below. -/
lemma not_halted_of_not_halted_at {n : ℕ} (h : ¬ Halted (run n)) :
    ∀ m ≤ n, ¬ Halted (run m) := fun _ hm hc => h (halted_mono hm hc)

/-! ### A machine-checked finite run

This confirms that the transition function above really is the machine
`1RB2LA3LB4LB---_0LA4LB3RA4LA0RB`: after `500` steps it is in state `B` with the head at
position `-6`, exactly as the reference simulation says. -/

set_option maxRecDepth 20000 in
theorem run_500 : (run 500).st = St.B ∧ (run 500).pos = -6 := by decide

/-- The machine does not halt during its first `500` steps. -/
theorem not_halted_le_500 : ∀ m ≤ 500, ¬ Halted (run m) := by
  refine not_halted_of_not_halted_at ?_
  rw [Halted, run_500.1]
  exact fun h => St.noConfusion h

/-- Since halting is absorbing, it is enough to exhibit *arbitrarily late* configurations
that are not halted: this reduces `never_halts` to "the machine keeps reaching
recognisable configurations forever", which is the form the longitudinal argument takes. -/
theorem never_halts_of_unbounded (h : ∀ N : ℕ, ∃ n, N ≤ n ∧ ¬ Halted (run n)) :
    ∀ n : ℕ, ¬ Halted (run n) := by
  intro n hn
  obtain ⟨m, hm, hnh⟩ := h n
  exact hnh (halted_mono hm hn)

/-! ### The goal

This is the statement we want; a proof is not yet available.  Everything that *is* proved
about this machine lives in `Blocks.lean`, `Walls.lean` and `RightEnd.lean` (the original
bulk/wall/right-end analysis) and in `Words.lean`, `Chains.lean`, `Bounces.lean` and
`Excursion.lean` (the block description: every macro rule of the machine, for regions of
arbitrary size).  What is missing is the *global* bookkeeping — a description of which
sequences of blocks can occur which is closed under those rules; see `ANALYSIS.md`.

By `never_halts_of_unbounded` it would be enough to show that the machine keeps returning
to left-end configurations of the shape handled by `left_end_sweep`. -/
theorem never_halts : ∀ n : ℕ, ¬ Halted (run n) := by
  sorry

end BB25
