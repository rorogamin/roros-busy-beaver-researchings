import RequestProject.CarryP1

/-!
# A `4`-run is a piece of virtual blank tape

This file records, and machine-checks, the mechanism behind the self-similarity of the
space-time diagram of `1RB2LA3LB4LB---_0LA4LB3RA4LA0RB`.

All the left-end macro rules of this development (`rule_P2`, `rule_P1`, `rule_P3`,
`rule_P1_gen`, `rule_P3_gen`, `unfold_U4`, `unfold_U10`) are `Win` rules whose window
begins with exactly **three** cells `0 0 0` — the blank cells to the left of the leftmost
non-blank cell of the tape.  Being `Win` rules they are *local*: the head provably never
leaves the window, so everything outside it is arbitrary.  Consequently

> a left-end rule applies verbatim at any place where the tape happens to carry three
> `0`s followed by the pattern the rule asks for.

Now look at what a rightward sweep does to a token `U(a,1) = 0 4^a 2`: by `blockR` it
rewrites it as `1 0^a 3`.  The `4`-run has become a **run of `a` zeros**, i.e. a finite
piece of tape that is indistinguishable, for the machine, from the blank tape at the left
end.  So after the sweep the machine can — and does — perform its own left-end macro
steps inside the run, each of them consuming three cells of it.  A run of `3j+1` fours
therefore hosts `j` macro steps of the machine's own computation, which is exactly the
"fractal identity" of `ANALYSIS.md` §20: the token `U(3j+1,1)` unfolds into a copy of the
tape at the `j`-th `B`-event.

The two statements below are the two halves of that mechanism.  Composing them for a
*specific* `j` gives the unfolding rules `unfold_U4` and `unfold_U10` of `Carry.lean`;
composing them for *all* `j` at once is what a complete non-halting proof still needs,
and it requires knowing which tape words can follow the run.
-/

namespace BB25

/-! ### The `4`-run becomes a run of `0`s -/

/-- **A `4`-run becomes a run of `0`s.**  A rightward sweep in state `A` rewrites the token
`U(a,1) = 0 4^a 2` as `1 0^a 3` in exactly `a + 2` steps.  The `a` zeros it leaves behind
are the "virtual blank tape" on which the machine then runs a copy of its own left-end
computation. -/
theorem four_run_to_zero_run (a : ℕ) :
    SweepR St.A St.A
      ([0] ++ (List.replicate a 4 ++ [2]))
      ([1] ++ (List.replicate a 0 ++ [3])) (a + 2) :=
  blockR a

/-! ### A left-end rule applies inside a run of `0`s -/

/-- **A window rule that only needs three blank cells on its left applies inside any run
of `0`s.**  This is the formal content of "a `4`-run, once swept, is blank tape": the
left-end rules of `Cycle.lean`, `Carry.lean` and `CarryP1.lean` all have windows of the
form `[0,0,0] ++ l`, so each of them can be applied `k` cells inside a run of `k + 3`
zeros, the extra `k` zeros being untouched. -/
theorem Win.in_zero_run {q q' : St} {k' n : ℕ} {l l' : List Sym}
    (h : Win q q' 3 k' ([0, 0, 0] ++ l) l' n) (hlen : l'.length = 3 + l.length) (k : ℕ) :
    Win q q' (k + 3) (k + k')
      (List.replicate k 0 ++ ([0, 0, 0] ++ l))
      (List.replicate k 0 ++ l') n := by
  have h2 := h.embed (by simp; omega) (List.replicate k (0 : Sym)) []
  simpa using h2

/-- `rule_P2` inside a run of `k + 3` zeros. -/
theorem rule_P2_in_run (k : ℕ) :
    Win St.B St.B (k + 3) k
      (List.replicate k 0 ++ ([0, 0, 0] ++ (tokU 2 2 ++ [0])))
      (List.replicate k 0 ++ (tokU 2 2 ++ tokV 1 ++ [0])) 31 := by
  have h : Win St.B St.B 3 0 ([0, 0, 0] ++ (tokU 2 2 ++ [0]))
      (tokU 2 2 ++ tokV 1 ++ [0]) 31 := by
    simpa [List.append_assoc] using rule_P2
  simpa using h.in_zero_run (by simp [tokU, tokV]) k

/-- `rule_P1` inside a run of `k + 3` zeros. -/
theorem rule_P1_in_run (k m : ℕ) :
    Win St.B St.B (k + 3) k
      (List.replicate k 0 ++
        ([0, 0, 0] ++ (tokU 2 1 ++ tokU 4 1 ++ tokU 1 (2 * m + 2) ++ [0])))
      (List.replicate k 0 ++ (tokU 2 2 ++ tokU 1 1 ++ tokU 2 (2 * m + 6) ++ [0]))
      (79 + 20 * m) := by
  have h : Win St.B St.B 3 0
      ([0, 0, 0] ++ (tokU 2 1 ++ tokU 4 1 ++ tokU 1 (2 * m + 2) ++ [0]))
      (tokU 2 2 ++ tokU 1 1 ++ tokU 2 (2 * m + 6) ++ [0]) (79 + 20 * m) := by
    simpa [List.append_assoc] using rule_P1 m
  simpa using h.in_zero_run (by simp [tokU]; omega) k

/-- `rule_P3` inside a run of `k + 3` zeros. -/
theorem rule_P3_in_run (k m : ℕ) :
    Win St.B St.B (k + 3) k
      (List.replicate k 0 ++
        ([0, 0, 0] ++ (tokU 2 2 ++ tokV 1 ++ tokU 1 1 ++ tokU 1 (2 * m + 2) ++ [0])))
      (List.replicate k 0 ++ (tokU 2 1 ++ tokU 4 1 ++ tokU 1 (2 * m + 6) ++ [0]))
      (91 + 20 * m) := by
  have h : Win St.B St.B 3 0
      ([0, 0, 0] ++ (tokU 2 2 ++ tokV 1 ++ tokU 1 1 ++ tokU 1 (2 * m + 2) ++ [0]))
      (tokU 2 1 ++ tokU 4 1 ++ tokU 1 (2 * m + 6) ++ [0]) (91 + 20 * m) := by
    simpa [List.append_assoc] using rule_P3 m
  simpa using h.in_zero_run (by simp [tokU, tokV]; omega) k

end BB25
