import Mathlib

/-!
# The 2-state, 5-symbol Turing machine `1RB2LA3LB4LB---_0LA4LB3RA4LA0RB`

This file sets up the machine, its one-step transition function, the run from the
all-blank tape, and the statement "this machine never halts".

Transition table (states `A`, `B`; symbols `0,1,2,3,4`):

| state | 0     | 1     | 2     | 3     | 4     |
|-------|-------|-------|-------|-------|-------|
| `A`   | `1RB` | `2LA` | `3LB` | `4LB` | halt  |
| `B`   | `0LA` | `4LB` | `3RA` | `4LA` | `0RB` |

The only halting transition is `A` reading `4`.
-/

namespace BB25

/-- Machine states.  `H` is the (absorbing) halting state. -/
inductive St
  | A : St
  | B : St
  | H : St
  deriving DecidableEq, Repr

/-- Tape symbols. -/
abbrev Sym := Fin 5

/-- A configuration: current state, head position, tape contents. -/
structure Cfg where
  st : St
  pos : ℤ
  tape : ℤ → Sym

/-- Write `v` at position `p` of tape `T`. -/
def wr (T : ℤ → Sym) (p : ℤ) (v : Sym) : ℤ → Sym := fun i => if i = p then v else T i

@[simp] lemma wr_self (T : ℤ → Sym) (p : ℤ) (v : Sym) : wr T p v p = v := by
  simp [wr]

@[simp] lemma wr_of_ne (T : ℤ → Sym) (p : ℤ) (v : Sym) {i : ℤ} (h : i ≠ p) :
    wr T p v i = T i := by
  simp [wr, h]

/-- One step of the machine. -/
def step (c : Cfg) : Cfg :=
  match c.st, (c.tape c.pos).val with
  | .H, _ => c
  | .A, 0 => ⟨.B, c.pos + 1, wr c.tape c.pos 1⟩
  | .A, 1 => ⟨.A, c.pos - 1, wr c.tape c.pos 2⟩
  | .A, 2 => ⟨.B, c.pos - 1, wr c.tape c.pos 3⟩
  | .A, 3 => ⟨.B, c.pos - 1, wr c.tape c.pos 4⟩
  | .A, _ => ⟨.H, c.pos, c.tape⟩
  | .B, 0 => ⟨.A, c.pos - 1, c.tape⟩
  | .B, 1 => ⟨.B, c.pos - 1, wr c.tape c.pos 4⟩
  | .B, 2 => ⟨.A, c.pos + 1, wr c.tape c.pos 3⟩
  | .B, 3 => ⟨.A, c.pos - 1, wr c.tape c.pos 4⟩
  | .B, _ => ⟨.B, c.pos + 1, wr c.tape c.pos 0⟩

/-- The initial configuration: state `A`, head at `0`, blank (all `0`) tape. -/
def init : Cfg := ⟨.A, 0, fun _ => 0⟩

/-- The configuration after `n` steps. -/
def run (n : ℕ) : Cfg := step^[n] init

/-- The machine has halted in configuration `c`. -/
def Halted (c : Cfg) : Prop := c.st = St.H

/-! ### Basic step lemmas -/

section StepLemmas
variable (T : ℤ → Sym) (p : ℤ)

lemma step_A0 (h : T p = 0) : step ⟨St.A, p, T⟩ = ⟨St.B, p + 1, wr T p 1⟩ := by
  simp [step, h]

lemma step_A1 (h : T p = 1) : step ⟨St.A, p, T⟩ = ⟨St.A, p - 1, wr T p 2⟩ := by
  simp [step, h]

lemma step_A2 (h : T p = 2) : step ⟨St.A, p, T⟩ = ⟨St.B, p - 1, wr T p 3⟩ := by
  simp [step, h]

lemma step_A3 (h : T p = 3) : step ⟨St.A, p, T⟩ = ⟨St.B, p - 1, wr T p 4⟩ := by
  simp [step, h]

lemma step_A4 (h : T p = 4) : step ⟨St.A, p, T⟩ = ⟨St.H, p, T⟩ := by
  simp [step, h]

lemma step_B0 (h : T p = 0) : step ⟨St.B, p, T⟩ = ⟨St.A, p - 1, T⟩ := by
  simp [step, h]

lemma step_B1 (h : T p = 1) : step ⟨St.B, p, T⟩ = ⟨St.B, p - 1, wr T p 4⟩ := by
  simp [step, h]

lemma step_B2 (h : T p = 2) : step ⟨St.B, p, T⟩ = ⟨St.A, p + 1, wr T p 3⟩ := by
  simp [step, h]

lemma step_B3 (h : T p = 3) : step ⟨St.B, p, T⟩ = ⟨St.A, p - 1, wr T p 4⟩ := by
  simp [step, h]

lemma step_B4 (h : T p = 4) : step ⟨St.B, p, T⟩ = ⟨St.B, p + 1, wr T p 0⟩ := by
  simp [step, h]

end StepLemmas

end BB25
