# Original proof dependencies and provenance

All source locations below refer to the supplied Aristotle archive. No original
Lean declaration or definition has been changed. The new proof bypasses
`GapRatio` rather than redefining it or assuming it.

The bundled `project/` preserves the original project, with only three new
`RequestProject/Completion*.lean` files and `CheckCompletion.lean` added.
The simulator copy in `reference/` is byte-for-byte identical to the original.

## Archive

Original upload: `3dee1288-a30c-48af-a6fb-14f866162e4b-aristotle.tar.gz`

SHA-256: `14b1b1e1fe563afbc5b911958452211b9730c71240a84e771d655aba671f822f`

## Relevant source locations

### `RequestProject/Machine.lean`

Original Turing-machine transition table and configuration semantics.

SHA-256: `a6494baf77cd323a2b9d798d2eef85a9940ae8621b329c67579dc17904d0dafc`

### `RequestProject/Macro.lean`

Mixed-radix digits and increment relation, including the tape-level sweep correspondence.

SHA-256: `34074b52246af60f545e5dbe2f82d58f275e8a93ca2260c31b2a5ee8b0bd12d4`

Declarations: `Inc` at line 77.

### `RequestProject/Counter.lean`

Exact counter gap and increment/overflow equivalences.

SHA-256: `010e3cc1801f158b717e17b8f132895d02f3a6a49eab5d605e37313faa90919b`

Declarations: `gap` at line 39; `Inc.gap_eq` at line 53; `Inc.gap_pos` at line 61; `Inc.length_eq` at line 65; `inc_exists` at line 73; `ovf_exists` at line 97.

### `RequestProject/Fast.lean`

Executable reset, junction, normal phase, revolution, and correspondence with tape runs.

SHA-256: `733c9168984d175c01974780e9bbb128965d75fdb866e74eb20f74c675ffc6a8`

Declarations: `addT_four` at line 257; `ovfF` at line 283; `resetF` at line 360; `junctionF` at line 434; `normalF` at line 493; `revolutionF` at line 524; `revolutionF_spec` at line 528; `revIter` at line 554; `revIter_labels` at line 577.

### `RequestProject/Shape.lean`

Reset radix pattern and the inherited released-word shape.

SHA-256: `0660375c46239ccc5a85a7bc89d9f792e05731fc006af6230cc91733dc5f9a13`

Declarations: `patF_true` at line 77; `resetF_pat` at line 91; `revolutionF_shape` at line 267.

### `RequestProject/Success.lean`

Bulk increments, binary-head junction success, and nonhalting from all successful revolutions.

SHA-256: `397992900daf62c14ca0a00247b490dc8e318c40bd3dc73c4223f239329f990c`

Declarations: `addT_of_le_gap` at line 37; `normalF_isSome` at line 91; `junctionF_isSome` at line 107; `neverHalts_of_revIter` at line 196.

### `RequestProject/FirstPhase.lean`

The initial released block sequence reached from the blank tape.

SHA-256: `eb9c2c78b49f93af59eace8b7543995a849814c84e42a71b3d15a91a7d4d5a77`

Declarations: `firstBlocks` at line 27.

### `RequestProject/Trajectory.lean`

The previous sufficient capacity-growth condition, bypassed by this completion.

SHA-256: `b5d16a723703ca0d657a36a0afc08db9465e6180848a8d1568ee2e19e2e98897`

Declarations: `GapRatio` at line 190.

### `RequestProject/TrajectoryChecks.lean`

The previous conditional nonhalting endpoint and finite trajectory checks.

SHA-256: `0f293ad52715f253a4765e4103c6e64db3d9e7a3d37f0bfec3e07312e7cd627c`

Declarations: `neverHalts_of_gapRatio_eight` at line 93.

### `sim/macro_sim.py`

Unmodified executable reference simulator used for independent comparisons.

SHA-256: `bd6a20474ef9c12c647e05e773f247673f4cd1a2997164d0764280bf112d5a97`

### `lean-toolchain`

Original pinned Lean toolchain.

SHA-256: `db7bb24b756d745bbde83fe92718b51bd3625dae3701ba0f598d0eedcd3f3028`

### `lakefile.toml`

Original Lake project and mathlib requirement.

SHA-256: `b1481968ce2912f2b85288fc18aa05fb22750e4083f9e03f49f59a8814ba268a`

### `lake-manifest.json`

Original resolved dependency manifest.

SHA-256: `116c6ef00aa899fb38c08c5e4c92c0e434d0e7f9d574fcb5d4d42cc90ffb07cb`

## Verification boundary

The original source has been inspected, but its Lean build has not been
rerun in this environment. The new Lean source is also uncompiled.
The mathematical proof uses the stated original counter/tape correspondence.
Only the finite integer certificates and Python regression tests have actually
executed here. See the included verification log for their exact scope.
