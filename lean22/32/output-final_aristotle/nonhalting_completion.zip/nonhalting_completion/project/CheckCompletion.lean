import RequestProject.Completion

-- Run only after the project build succeeds.
#check SOC.Completion.neverHalts
#print axioms SOC.Completion.neverHalts
