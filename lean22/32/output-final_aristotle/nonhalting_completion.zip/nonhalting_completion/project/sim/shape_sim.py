"""Exploration of the *shape* of the block sequences of
1LB3RB0LB---2RB_2RA3LA4LB2LB0RA.  UNVERIFIED: only the statements in the Lean
files are machine-checked.  What this script measures:

1.  the shape theorem (proved in `RequestProject/Shape.lean`): the released
    sequence `L'` begins with `|L|` blocks carrying a `44` exactly where `L`
    carries a block different from `14`, followed by fresh blocks, none of
    which is a `44`;

2.  the fresh-material density (the hypothesis `FreshDense` of
    `RequestProject/Fresh.lean`): the worst prefix of the fresh part, counted
    together with the previous sequence, against the admissible `3/5`;

3.  an observation that is *not* proved: in the fresh part, the digit pushed by
    the `t`-th cycle of the normal phase is released as `04` when the gap after
    that cycle is even, and as `14`/`24` when it is odd.

Usage:  python3 sim/shape_sim.py [revolutions]
"""

import sys

from macro_sim import addT, reset_phase, junction, released


def gap(w):
    """The gap of a counter, w[0] the most significant digit."""
    g = 0
    for d in w:
        if d == 0:
            g = 2 * g + 1
        elif d == 1:
            g = 2 * g
        elif d == 2:
            g = (2 * g + 1) // 3
        else:
            g = (2 * g) // 3
    return g


def revolution_with_gaps(blocks):
    """One revolution; also returns the gap after each normal-phase cycle."""
    w = [0]
    assert reset_phase(w, blocks) is None
    assert junction(w) is None
    gaps = []
    while addT(w, 1):
        w.append(2)
        gaps.append(gap(w))
    return released(w[:]), gaps


def ones(seq):
    return sum(1 for x in seq if x == 1)


def worst_fresh(prev, fresh):
    """max over prefixes v of `fresh` of 5*ones(prev[7:]+v) / (3*|prev[7:]+v|)."""
    c = ones(prev[7:])
    n = len(prev) - 7
    worst = 5 * c / (3 * n) if n else 0.0
    k = 0
    for i, x in enumerate(fresh, start=1):
        if x == 1:
            k += 1
        worst = max(worst, 5 * (c + k) / (3 * (n + i)))
    return worst


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    blocks = [4, 4, 4, 0, 4, 0, 2]
    for i in range(1, n + 1):
        nxt, gaps = revolution_with_gaps(blocks)
        m = len(blocks)
        head, fresh = nxt[:m], nxt[m:]
        shape_ok = all((y == 4) == (x != 1) for x, y in zip(blocks, head)) and \
            all(y != 4 for y in fresh)
        cyc = nxt[len(nxt) - len(gaps):]
        parity_ok = all((s in (1, 2)) == (g % 2 == 1) for s, g in zip(cyc, gaps))
        print(f"rev {i}: |L|={m} |fresh|={len(fresh)} "
              f"shape={shape_ok} parity={parity_ok} "
              f"ones(L)/|L|={ones(blocks) / m:.3f} "
              f"ones(fresh)/|fresh|={ones(fresh) / len(fresh):.3f} "
              f"fresh criterion (<= 1 is admissible) = {worst_fresh(blocks, fresh):.3f}")
        sys.stdout.flush()
        blocks = nxt


if __name__ == "__main__":
    main()
