"""Check the density criterion of RequestProject/Density.lean on the block
sequences the machine releases.  UNVERIFIED exploration: only the statements in
the Lean files are machine-checked.

For each revolution it looks for a split of the released block sequence into a
leading part A that builds a gap of at least T (by the exact recurrence of
`gnext`) and a tail M in which, in every prefix, the blocks `14` satisfy
p * k <= q * (n - k), i.e. have density at most q / (p + q).

Usage:  python3 sim/density_sim.py [revolutions]
"""

import sys

from macro_sim import revolution


def gnext(g, x):
    if x == 0:
        return 2 * g
    if x == 2:
        return 2 * g - 1
    if x == 1:
        return 2 * ((2 * (g // 2 - 4)) // 3) + 1
    return 2 * g + 1


def gfold(g, blocks):
    for x in blocks:
        g = gnext(g, x)
    return g


def dense(blocks, p, q):
    """p * k <= q * (n - k) in every prefix."""
    k = 0
    for i, x in enumerate(blocks):
        if x == 1:
            k += 1
        if p * k > q * (i + 1 - k):
            return False
    return True


def best_split(blocks, T, p, q):
    for i in range(len(blocks) + 1):
        if gfold(1, blocks[:i]) >= T and dense(blocks[i:], p, q):
            return i
    return None


def worst_prefix_density(blocks):
    k = 0
    worst = 0.0
    for i, x in enumerate(blocks):
        if x == 1:
            k += 1
        worst = max(worst, k / (i + 1))
    return worst


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    blocks = [4, 4, 4, 0, 4, 0, 2]
    for i in range(1, n + 1):
        s_half = best_split(blocks, 105, 1, 1)
        s_35 = best_split(blocks, 300, 2, 3)
        k = blocks.count(1)
        print(f"rev {i}: len={len(blocks)} #14={k} dens={k / len(blocks):.4f} "
              f"worst prefix dens={worst_prefix_density(blocks):.4f} "
              f"split(T=105,1/2)={s_half} split(T=300,3/5)={s_35}")
        sys.stdout.flush()
        nxt, err, _ = revolution(blocks)
        if err:
            print("STOP:", err)
            return
        blocks = nxt


if __name__ == "__main__":
    main()
