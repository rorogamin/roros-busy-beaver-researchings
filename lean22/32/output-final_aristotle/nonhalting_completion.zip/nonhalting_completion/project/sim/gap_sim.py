"""Exploration of the *domination inequality* of
1LB3RB0LB---2RB_2RA3LA4LB2LB0RA.  UNVERIFIED: only the statements in the Lean
files are machine-checked.  What this script measures:

1.  the condition `GapRatio` of `RequestProject/Trajectory.lean`:

        14 * (capacity the previous sequence built) + 58
          <= (capacity the inherited blocks of the new sequence rebuild),

    which by `freshSafe_of_gapRatio` is all that is still missing for a proof
    that the machine never halts.  It fails at the first two revolutions and
    holds from the third on;

2.  *why* it holds: the ratio of the two capacities is `3 ^ u`, where `u` is the
    number of **upgrades** — positions where the previous sequence had an
    expensive block `14` and the new one has a `04` or a `24` instead.  About
    two thirds of the blocks `14` are upgraded at every revolution, which is why
    the ratio grows so fast (`2^8`, `2^14`, `2^41`, `2^74`, … ).

Usage:  python3 sim/gap_sim.py [revolutions]
"""

import math
import sys

from macro_sim import addT, reset_phase, junction, released


def gap(w):
    """The capacity of a counter, w[0] the most significant digit."""
    g = 0
    for d in w:
        if d == 0:
            g = 2 * g + 1
        elif d == 1:
            g = 2 * g
        elif d == 2:
            g = (2 * g + 1) // 3
        else:
            g = (2 * g) // 3
    return g


def gnext(g, b):
    """One block of a reset phase, as in Lean's `gnext` (a lower bound)."""
    if b == 4:
        return 2 * g + 1
    if b == 0:
        return 2 * g
    if b == 2:
        return max(2 * g - 1, 0)
    return 2 * ((2 * max(g // 2 - 4, 0)) // 3) + 1


def revolution_with_gap(blocks):
    """One revolution; also returns the capacity built by the reset phase."""
    w = [0]
    assert reset_phase(w, blocks) is None
    gamma = gap(w)
    assert junction(w) is None
    while addT(w, 1):
        w.append(2)
    return released(w[:]), gamma


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    blocks = [4, 4, 4, 0, 4, 0, 2]
    for i in range(n):
        nxt, gamma = revolution_with_gap(blocks)
        m = len(blocks)
        inherited = nxt[:m]
        g = 1
        for b in inherited:
            g = gnext(g, b)
        ok = 14 * gamma + 58 <= g
        upgrades = sum(1 for x, y in zip(blocks, inherited) if x == 1 and y != 1)
        ones = blocks.count(1)
        print(f"rev {i}: |L|={m} GapRatio={ok} "
              f"log2(new/old)={math.log2(g / gamma):.2f} "
              f"upgrades={upgrades}/{ones} blocks 14 "
              f"(log2 3^upgrades = {upgrades * math.log2(3):.2f})")
        sys.stdout.flush()
        blocks = nxt


if __name__ == "__main__":
    main()
