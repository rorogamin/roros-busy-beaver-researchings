"""Fast macro-level simulator of 1LB3RB0LB---2RB_2RA3LA4LB2LB0RA.

The counter is a list of digits with the LAST element the least significant one
(the digit nearest the head):

    0 = d0 = 02   (radix 2, value 0)
    1 = d1 = 22   (radix 2, value 1)
    2 = dB = 03   (radix 3/2, value 0)
    3 = dA = 23   (radix 3/2, value 1)

Blocks (labels, as in the Lean development): 4 = 44, 0 = 04, 2 = 24, 1 = 14.

Increments are applied in bulk: a position that receives `t` increments simply
passes on the number of carries it produces, so a single increment costs one
short pass instead of the exponential recursion of the naive definition.
"""

import sys


def addT(w, t, hi=None):
    """Apply t increments in place to w[0:hi] (w[hi-1] the lowest digit).

    Returns True on success, False if the counter overflows (in which case w
    may have been partially modified)."""
    if hi is None:
        hi = len(w)
    i = hi - 1
    c = t
    buf = []
    while c > 0:
        if i < 0:
            return False
        d = w[i]
        if d < 2:
            s = d + c
            buf.append((i, s % 2))
            c = s // 2
        else:
            v = d - 2
            s = v + c
            buf.append((i, 2 + s % 2))
            c = (3 * s) // 2 - (3 * v) // 2
        i -= 1
    for j, v in buf:
        w[j] = v
    return True


def reset_phase(w, blocks):
    """Absorb the blocks (most significant first) into the counter w, in place."""
    for b in blocks:
        if b == 4:
            w.append(0)
        elif b == 0:
            w.append(1)
        elif b == 2:
            if not addT(w, 1):
                return "underflow at a block 24"
            w.append(0)
        elif b == 1:
            if not w or w[-1] >= 2:
                return "block 14 with a radix-3/2 digit at the bottom"
            d = w.pop()
            if not addT(w, 4):
                return "underflow at a block 14"
            w.append(3 if d == 1 else 2)
            w.append(0)
        else:
            raise ValueError(b)
    return None


def junction(w):
    """Read the terminating 1 of the old right material (in place)."""
    if not w or w[-1] >= 2:
        return "junction with a radix-3/2 digit at the bottom"
    d = w.pop()
    if not addT(w, 4):
        return "underflow at the junction"
    w.append(2 if d == 0 else 3)
    w.append(3)
    return None


def normal_phase(w):
    """Spend the counter, pushing digits 03, until it overflows."""
    n = 0
    while addT(w, 1):
        w.append(2)
        n += 1
    return n


def released(w):
    """Blocks released by the overflow of w (tape order, most significant first).

    Destroys w."""
    out = []
    i = len(w)
    while i > 0:
        d = w[i - 1]
        i -= 1
        if d == 1:
            out.append(4)
        elif d == 2:
            out.append(0)
        elif d == 3:
            if addT(w, 1, i):
                out.append(1)
            else:
                out.append(2)
        else:
            raise ValueError("a digit 02 in an overflowing counter")
    out.reverse()
    return out


def revolution(blocks):
    """One super-cycle: block sequence -> next block sequence."""
    w = [0]
    err = reset_phase(w, blocks)
    if err:
        return None, err, None
    err = junction(w)
    if err:
        return None, err, None
    ncyc = normal_phase(w)
    return released(w), None, ncyc


def gnext(g, b):
    if b == 4:
        return 2 * g + 1
    if b == 0:
        return 2 * g
    if b == 2:
        return 2 * g - 1
    return 2 * ((2 * (g // 2 - 4)) // 3) + 1


def safe_run(blocks):
    """SafeRun 1 blocks: gap >= 8 at every 14, >= 1 at every 24 (Lean's gfold)."""
    g = 1
    ok = True
    worst = None
    for b in blocks:
        if b == 1:
            worst = g if worst is None else min(worst, g)
            if g < 8:
                ok = False
        if b == 2 and g < 1:
            ok = False
        g = gnext(g, b)
    return ok, worst, g


LET = {4: 'f', 0: 'z', 2: 't', 1: 'o'}


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    show = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    blocks = [4, 4, 4, 0, 4, 0, 2]
    for i in range(1, n + 1):
        ok, worst, gend = safe_run(blocks)
        c14 = blocks.count(1)
        lead = 0
        while lead < len(blocks) and blocks[lead] == 4:
            lead += 1
        print(f"rev {i}: len={len(blocks)} #14={c14} dens={c14 / len(blocks):.4f} "
              f"lead44={lead} safe={ok} "
              f"log2(min gap at a 14)~{None if worst is None else worst.bit_length()} "
              f"log2(gap end)~{gend.bit_length()}")
        sys.stdout.flush()
        if i <= show:
            print("   ", "".join(LET[b] for b in blocks))
        nxt, err, ncyc = revolution(blocks)
        if err:
            print("STOP:", err)
            return
        blocks = nxt


if __name__ == "__main__":
    main()
