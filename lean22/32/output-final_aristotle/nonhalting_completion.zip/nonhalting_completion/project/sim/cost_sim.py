"""Lower bound on the number of TM steps: mirrors RequestProject/Cost.lean."""
import sys
from macro_sim import addT, reset_phase, junction, released, revolution

WT = {0: 4, 1: 4, 2: 8, 3: 8}


def carries(d, t):
    if d == 0:
        return t // 2
    if d == 1:
        return (t + 1) // 2
    if d == 2:
        return 3 * t // 2
    return (3 * (t + 1)) // 2 - 1


def costT1(w):
    """cost of one increment of w (w: list, last element = lowest digit)."""
    total = 0
    t = 1
    i = len(w) - 1
    while t > 0 and i >= 0:
        d = w[i]
        total += WT[d] * t
        t = carries(d, t)
        i -= 1
    return total


def normal_cost(w):
    total = 0
    while True:
        c = costT1(w)
        if not addT(w, 1):
            return total
        total += c
        w.append(2)


def main():
    nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    blocks = [4, 4, 4, 0, 4, 0, 2]
    for n in range(0, nmax + 1):
        w = [0]
        err = reset_phase(w, blocks)
        assert not err, err
        err = junction(w)
        assert not err, err
        c = normal_cost(list(w))
        print(f"n={n}: blocks={len(blocks)}  normalCost ~ 10^{len(str(c)) - 1}")
        sys.stdout.flush()
        nxt, err, _ = revolution(blocks)
        assert not err, err
        blocks = nxt


main()
