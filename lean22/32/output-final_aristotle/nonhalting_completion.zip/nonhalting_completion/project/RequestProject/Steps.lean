import RequestProject.Cost

/-!
# A lower bound on the running time

`RequestProject.Cost` attaches to every increment of the counter the exact
number of steps the corresponding sweep of the head costs, and adds them up
over a whole normal phase (`normalCost`).  Evaluating that sum for the eleventh
revolution — whose counter is built out of `17534` blocks — and comparing it
with `10 ^ 3500` is a finite computation, carried out here by Lean's compiled
evaluation.

The result is a proved lower bound on the running time of
`1LB3RB0LB---2RB_2RA3LA4LB2LB0RA`: it does not halt within its first `10 ^ 3500`
steps.  For comparison, the bound the same computation gives for the earlier
revolutions is

```
revolution    1     2     3      4     5      6      7       8       9      10      11
steps ≥    2060  4·10⁵  2·10⁹  10¹⁹  10³⁶   10⁸²  10¹⁷³   10³⁷²   10⁷⁵⁶  10¹⁶⁴⁴  10³⁵³³
```

— the number of steps is roughly *squared* at every revolution, because the
counter doubles in length and a sweep crosses a radix-3/2 position at a cost
proportional to the number of increments it has already received.
-/

namespace SOC

/-- **The eleventh revolution's normal phase costs more than `10 ^ 3500` steps.**
Checked by compiled evaluation inside Lean. -/
theorem stepBound_10_ge : 10 ^ 3500 ≤ stepBound 10 := by native_decide

/--
**The machine does not halt within its first `10 ^ 3500` steps.**

This is a proved lower bound, not a simulation: the steps are counted inside the
digit model, where one sweep of the head costs `4` steps per radix-2 position
and `8` steps per radix-3/2 position it crosses, and each position is crossed
once per increment it receives.
-/
theorem no_halt_before_10_pow_3500 : ∀ j ≤ 10 ^ 3500, (run init j).isSome := by
  intro j hj
  exact no_halt_before_stepBound 10 j (Nat.le_trans hj stepBound_10_ge)

end SOC
