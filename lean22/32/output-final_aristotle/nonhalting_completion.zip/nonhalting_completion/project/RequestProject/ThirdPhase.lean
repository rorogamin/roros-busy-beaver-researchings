import RequestProject.SecondPhase

/-!
# The third revolution of the real machine

The same check once more, at the third overflow.  After 502644 steps the machine
faces the thirty-nine blocks

```
44^13 · 14 44 24 44 24 04 04 04 24 14 14 24 24 14 14 14 04 14 24 04 24 04 24 24 14 04
```

(thirteen leading blocks `44` on top of the one written by the overflow itself),
eight of them blocks `14` — so this phase really exercises the expensive rule
`(02|22) B> 14`, which costs four increments and creates a radix-3/2 digit.

The arithmetic test still succeeds with a wide margin: the leading run of `44`s
takes the gap to `2^14 - 1 = 16383` before the first `14` is met, and the
counter built by the whole phase can still perform `167497402` increments.  So
the machine survives its third revolution as well.

The 502644-step run is checked by evaluation inside Lean (as in
`RequestProject/Verified.lean`), everything else by the kernel.
-/

namespace SOC

/-- The blocks released by the third overflow, at step 502644. -/
def thirdBlocks : List Sym :=
  [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 1, 4, 2, 4, 2, 0, 0,
   0, 2, 1, 1, 2, 2, 1, 1, 1, 0, 1, 2, 0, 2, 0, 2, 2, 1, 0]

/-- **After 502644 steps the machine is at the start of its third reset
phase.** -/
theorem run_init_502644 : run init 502644 = some (enc (phaseStart thirdBlocks)) := by
  native_decide

theorem thirdBlocks_labels : ∀ x ∈ thirdBlocks, Label x := by decide

theorem thirdBlocks_safe : SafeRun 1 thirdBlocks := by decide

theorem thirdBlocks_gfold : gfold 1 thirdBlocks = 167497402 := by decide

/--
**The machine survives its third revolution.**  It reaches the start of its
third reset phase after 502644 steps, consumes the phase — eight blocks `14`
included — the junction and the normal phase, and arrives at the start of a
fourth reset phase.
-/
theorem third_revolution :
    ∃ L' : List Sym, (∀ x ∈ L', Label x) ∧ init ⟶+ enc (phaseStart L') := by
  obtain ⟨L', hL', hplus⟩ :=
    super_cycle thirdBlocks_labels thirdBlocks_safe (by rw [thirdBlocks_gfold]; omega)
  exact ⟨L', hL', reaches_trans_reaches1 (reaches_of_run run_init_502644) hplus.sim⟩

end SOC
