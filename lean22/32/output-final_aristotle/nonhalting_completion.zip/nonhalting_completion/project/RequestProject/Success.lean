import RequestProject.Fast
import RequestProject.Density

/-!
# The executable revolution never fails when the arithmetic condition holds

`RequestProject.Fast` turns one revolution into the function `revolutionF`,
which returns `none` exactly at the configurations where the machine would be in
danger, and proves that a successful computation is a genuine run of the
machine.  What it does *not* provide is the converse direction: a reason for the
computation to succeed.

This file supplies it.  Mirroring the relational proofs of
`RequestProject.ResetPhase` and `RequestProject.NormalPhase`:

* `addT_of_le_gap` — a bulk increment of `t ≤ gap w` always succeeds and uses up
  exactly `t` of the gap;
* `resetF_isSome` — the reset phase computes whenever the block sequence passes
  the arithmetic test `SafeRun`;
* `junctionF_isSome`, `normalF_isSome` — the junction computes when the counter
  can pay, and the normal phase always computes;
* `revolutionF_isSome` — hence a whole revolution computes;
* `neverHalts_of_revIter` — and if every revolution computes, the machine never
  halts.

Combining this with the density criterion of `RequestProject.Density` turns the
halting question into a statement about the *shape* of the computed block
sequences alone.
-/

namespace SOC

/-! ## Bulk increments always succeed inside the gap -/

/-- **A bulk increment of at most `gap w` succeeds**, and uses exactly that much
of the gap. -/
theorem addT_of_le_gap : ∀ (t : Nat) {w : List LD}, t ≤ gap w →
    ∃ w', addT w t = some w' ∧ gap w' + t = gap w
  | 0, w, _ => ⟨w, by simp, by simp⟩
  | t + 1, w, h => by
      obtain ⟨u, hu, hgu⟩ := addT_of_le_gap t (w := w) (by omega)
      have hpos : 0 < gap u := by omega
      obtain ⟨u', hu'⟩ := inc_exists hpos
      refine ⟨u', ?_, ?_⟩
      · rw [show t + 1 = t + 1 from rfl, addT_add, hu, Option.bind_some, inc_addT_one hu']
      · have := hu'.gap_eq
        omega

theorem addT_isSome_of_le_gap {t : Nat} {w : List LD} (h : t ≤ gap w) :
    (addT w t).isSome := by
  obtain ⟨w', hw', -⟩ := addT_of_le_gap t h
  rw [hw']
  rfl

/-! ## The overflow and the normal phase -/

/-- **An overflowing counter is released.**  `ovfF` never fails on a counter of
gap `0`: a digit `02` would give the counter a positive gap. -/
theorem ovfF_isSome : ∀ {w : List LD}, gap w = 0 → ∀ acc : List Sym, (ovfF w acc).isSome
  | [], _, acc => by rw [ovfF]; rfl
  | .d0 :: w, h, acc => by simp at h
  | .d1 :: w, h, acc => by
      have hw : gap w = 0 := by simp only [gap_d1] at h; omega
      rw [ovfF]
      exact ovfF_isSome hw _
  | .dB :: w, h, acc => by
      have hw : gap w = 0 := by simp only [gap_dB] at h; omega
      rw [ovfF]
      exact ovfF_isSome hw _
  | .dA :: w, h, acc => by
      simp only [gap_dA] at h
      rw [ovfF]
      cases hone : addT w 1 with
      | none =>
          have hw : gap w = 0 := gap_eq_zero_of_addT_none hone
          simpa [hone] using ovfF_isSome hw (2 :: acc)
      | some w' =>
          have hinc : Inc w w' := addT_one_inc hone
          have hg := hinc.gap_eq
          have hw' : gap w' = 0 := by omega
          have hlen : w'.length = w.length := addT_length hone
          simpa [hone] using ovfF_isSome hw' (1 :: acc)
  termination_by w => w.length
  decreasing_by
    · simp
    · simp
    · simp
    · simp [hlen]

/-- **The normal phase always computes.** -/
theorem normalF_isSome : ∀ (w : List LD) (acc : List Sym), (normalF w acc).isSome
  | w, acc => by
      rw [normalF]
      cases hone : addT w 1 with
      | none =>
          have hw : gap w = 0 := gap_eq_zero_of_addT_none hone
          simpa using ovfF_isSome hw acc
      | some w' =>
          have hinc : Inc w w' := addT_one_inc hone
          have hlt : gap (LD.dB :: w') < gap w := gap_normal_cycle_lt hinc hinc.gap_pos
          simpa using normalF_isSome (LD.dB :: w') acc
  termination_by w => gap w

/-! ## The junction -/

/-- **The junction computes** when the counter can pay for it. -/
theorem junctionF_isSome {w : List LD} (hb : BinHead w) (hg : 9 ≤ gap w) :
    (junctionF w).isSome := by
  match w, hb with
  | .d0 :: v, _ =>
      have hv : 4 ≤ gap v := by simp only [gap_d0] at hg; omega
      obtain ⟨v', hv', -⟩ := addT_of_le_gap 4 hv
      rw [junctionF, hv']
      rfl
  | .d1 :: v, _ =>
      have hv : 4 ≤ gap v := by simp only [gap_d1] at hg; omega
      obtain ⟨v', hv', -⟩ := addT_of_le_gap 4 hv
      rw [junctionF, hv']
      rfl

/-! ## The reset phase -/

/-- **The reset phase computes** whenever the block sequence passes the
arithmetic test, and the counter it builds has the gap predicted by `gfold`. -/
theorem resetF_isSome : ∀ {w : List LD} (hb : BinHead w) {g : Nat} (hgap : g ≤ gap w)
    {L : List Sym}, (∀ x ∈ L, Label x) → SafeRun g L →
      ∃ w', resetF w L = some w' ∧ BinHead w' ∧ gfold g L ≤ gap w'
  | w, hb, g, hgap, [], _, _ => ⟨w, rfl, hb, hgap⟩
  | w, hb, g, hgap, x :: L, hlab, hs => by
      obtain ⟨p1, p2, p3⟩ := hs
      have hx : Label x := hlab x (by simp)
      have hlab' : ∀ y ∈ L, Label y := fun y hy => hlab y (by simp [hy])
      -- one block: produce the next counter, with its gap bound
      have key : ∀ w1 : List LD, resetF w (x :: L) = resetF w1 L → BinHead w1 →
          gnext g x ≤ gap w1 → ∃ w', resetF w (x :: L) = some w' ∧ BinHead w' ∧
            gfold g (x :: L) ≤ gap w' := by
        intro w1 heq hb1 hg1
        obtain ⟨w', hw', hb', hg'⟩ := resetF_isSome hb1 hg1 hlab' p3
        exact ⟨w', by rw [heq, hw'], hb', by rwa [gfold]⟩
      rcases hx with rfl | rfl | rfl | rfl
      · -- block `44`
        refine key (.d0 :: w) rfl trivial ?_
        simp only [gnext_4, gap_d0]
        omega
      · -- block `04`
        refine key (.d1 :: w) rfl trivial ?_
        simp only [gnext_0, gap_d1]
        omega
      · -- block `24`
        have hpos : 1 ≤ gap w := by have := p2 rfl; omega
        obtain ⟨w1, hw1, hgw1⟩ := addT_of_le_gap 1 hpos
        refine key (.d0 :: w1) ?_ trivial ?_
        · rw [resetF, hw1]
        · simp only [gnext_2, gap_d0]
          omega
      · -- block `14`
        have h8 : 8 ≤ gap w := by have := p1 rfl; omega
        match w, hb with
        | .d0 :: v, _ =>
            have hv : 4 ≤ gap v := by simp only [gap_d0] at h8; omega
            obtain ⟨v', hv', hgv⟩ := addT_of_le_gap 4 hv
            refine key (.d0 :: .dB :: v') ?_ trivial ?_
            · rw [resetF, hv']
            · simp only [gnext_1, gap_d0, gap_dB] at *
              omega
        | .d1 :: v, _ =>
            have hv : 4 ≤ gap v := by simp only [gap_d1] at h8; omega
            obtain ⟨v', hv', hgv⟩ := addT_of_le_gap 4 hv
            refine key (.d0 :: .dA :: v') ?_ trivial ?_
            · rw [resetF, hv']
            · simp only [gnext_1, gap_d0, gap_dA, gap_d1] at *
              omega

/-! ## One revolution -/

/-- **A revolution computes** whenever its block sequence passes the arithmetic
test and builds a counter large enough for the junction. -/
theorem revolutionF_isSome {L : List Sym} (hlab : ∀ x ∈ L, Label x) (hs : SafeRun 1 L)
    (h9 : 9 ≤ gfold 1 L) : (revolutionF L).isSome := by
  obtain ⟨w, hw, hb, hg⟩ :=
    resetF_isSome (w := [LD.d0]) trivial (g := 1) (by simp [gap]) hlab hs
  have hjunc := junctionF_isSome hb (Nat.le_trans h9 hg)
  rw [revolutionF, hw, Option.bind_some]
  cases hj : junctionF w with
  | none => rw [hj] at hjunc; simp at hjunc
  | some w' => simpa [hj] using normalF_isSome w' []

/-! ## Non-halting from the computed sequences -/

/--
**If every revolution computes, the machine never halts.**

`revIter n` is the block sequence of the `n`-th reset phase; if the computation
never returns `none`, the machine runs through infinitely many revolutions.
-/
theorem neverHalts_of_revIter (h : ∀ n, (revIter n).isSome) : NeverHalts := by
  -- the sequence of block sequences
  have hval : ∀ n, ∃ L, revIter n = some L := by
    intro n
    cases hn : revIter n with
    | none => have := h n; rw [hn] at this; simp at this
    | some L => exact ⟨L, rfl⟩
  choose F hF using hval
  have hstep : ∀ n, MPlus (phaseStart (F n)) (phaseStart (F (n + 1))) := by
    intro n
    have hn1 : revIter (n + 1) = some (F (n + 1)) := hF (n + 1)
    rw [revIter, hF n, Option.bind_some] at hn1
    exact (revolutionF_spec hn1).2
  have hforever : ∀ n, (run (enc (phaseStart (F 0))) n).isSome := by
    intro n
    obtain ⟨N, hN, hrun⟩ := plus_chain_reaches (fun i => phaseStart (F i)) hstep n
    exact isSome_of_run_le (by rw [hrun]; rfl) hN
  have hreach : init ⟶* enc (phaseStart (F 0)) := revIter_reaches (hF 0)
  exact forever_of_reaches hreach hforever

/--
**Non-halting from the arithmetic test, in the executable model.**

If every block sequence the machine computes passes the test `SafeRun` and
builds a counter large enough for the junction, then the machine never halts.
Nothing has to be assumed about the *relation* between successive sequences: the
sequences are the computed ones.
-/
theorem neverHalts_of_revIter_safe
    (h : ∀ n L, revIter n = some L → SafeRun 1 L ∧ 9 ≤ gfold 1 L) : NeverHalts := by
  refine neverHalts_of_revIter ?_
  intro n
  induction n with
  | zero => rw [revIter]; rfl
  | succ n ih =>
      cases hn : revIter n with
      | none => rw [hn] at ih; simp at ih
      | some L =>
          have hlab : ∀ x ∈ L, Label x := revIter_labels hn
          obtain ⟨hsafe, h9⟩ := h n L hn
          have hsome := revolutionF_isSome hlab hsafe h9
          rw [revIter, hn, Option.bind_some]
          exact hsome

/--
**Non-halting from the density criterion, in the executable model.**
-/
theorem neverHalts_of_revIter_evDense {T p q : ℕ} (hT : 105 ≤ T) (hp : 1 ≤ p)
    (hratio : 1 ≤ afac T ^ p * bfac T ^ q)
    (h : ∀ n L, revIter n = some L → EvDense T p q L) : NeverHalts := by
  refine neverHalts_of_revIter_safe ?_
  intro n L hn
  obtain ⟨hsafe, hgap⟩ := (h n L hn).safe hT hp hratio
  exact ⟨hsafe, by omega⟩

end SOC
