import RequestProject.ResetRules

/-!
# The reset phase

After the counter has overflowed, the machine starts again at the marker with an
empty counter and runs to the right over the material the overflow has released.
Two facts make this phase tractable:

* the released material is always a sequence of **blocks** `44`, `04`, `24`,
  `14` (`Ovf.released`) — this is forced by the shape of an overflow;
* each block has a completely determined effect on the counter and on its gap
  (`reset_block`): `44`, `04`, `24` roughly *double* the gap, whereas a block
  `14` costs four increments and creates a radix-3/2 digit, which *multiplies
  the gap by about 2/3*.

Consequently the whole phase is safe as soon as a purely arithmetical condition
on the block sequence holds: the gap, computed by `gfold`, must stay at least
`8` at every block `14` and at least `1` at every block `24` (`SafeRun`).  This
is the quantitative form of the side condition "the left counter does not
underflow" of the informal analysis — and it is *decidable* for any concrete
sequence of blocks.
-/

namespace SOC

/-- The first cell of a block; the second one is always a `4`. -/
def Label (x : Sym) : Prop := x = 4 ∨ x = 0 ∨ x = 2 ∨ x = 1

instance : DecidablePred Label := fun x => by unfold Label; infer_instance

/-- The cells of a sequence of blocks. -/
def cellsOf : List Sym → List Sym
  | [] => []
  | x :: L => x :: 4 :: cellsOf L

@[simp] theorem cellsOf_nil : cellsOf [] = [] := rfl

@[simp] theorem cellsOf_cons (x : Sym) (L : List Sym) :
    cellsOf (x :: L) = x :: 4 :: cellsOf L := rfl

theorem cellsOf_append (L₁ L₂ : List Sym) :
    cellsOf (L₁ ++ L₂) = cellsOf L₁ ++ cellsOf L₂ := by
  induction L₁ with
  | nil => rfl
  | cons x L ih => simp [ih]

/-- **The material released by an overflow is a sequence of blocks `x4`.** -/
theorem Ovf.released {w : List LD} {s : List Sym} (h : Ovf w s) :
    ∃ L, (∀ x ∈ L, Label x) ∧ s = cellsOf L := by
  induction h with
  | nil => exact ⟨[], by simp, rfl⟩
  | @d1 w s _ ih =>
      obtain ⟨L, hL, rfl⟩ := ih
      refine ⟨L ++ [4], ?_, by rw [cellsOf_append]; rfl⟩
      intro x hx
      rcases List.mem_append.1 hx with hx | hx
      · exact hL x hx
      · simp at hx; subst hx; exact Or.inl rfl
  | @dB w s _ ih =>
      obtain ⟨L, hL, rfl⟩ := ih
      refine ⟨L ++ [0], ?_, by rw [cellsOf_append]; rfl⟩
      intro x hx
      rcases List.mem_append.1 hx with hx | hx
      · exact hL x hx
      · simp at hx; subst hx; exact Or.inr (Or.inl rfl)
  | @dA1 w s _ ih =>
      obtain ⟨L, hL, rfl⟩ := ih
      refine ⟨L ++ [2], ?_, by rw [cellsOf_append]; rfl⟩
      intro x hx
      rcases List.mem_append.1 hx with hx | hx
      · exact hL x hx
      · simp at hx; subst hx; exact Or.inr (Or.inr (Or.inl rfl))
  | @dA2 w w' s _ _ ih =>
      obtain ⟨L, hL, rfl⟩ := ih
      refine ⟨L ++ [1], ?_, by rw [cellsOf_append]; rfl⟩
      intro x hx
      rcases List.mem_append.1 hx with hx | hx
      · exact hL x hx
      · simp at hx; subst hx; exact Or.inr (Or.inr (Or.inr rfl))

theorem cellsOf_injective : ∀ {L₁ L₂ : List Sym}, cellsOf L₁ = cellsOf L₂ → L₁ = L₂
  | [], [], _ => rfl
  | [], _ :: _, h => by simp [cellsOf] at h
  | _ :: _, [], h => by simp [cellsOf] at h
  | x :: L, y :: L', h => by
      simp only [cellsOf_cons, List.cons.injEq] at h
      obtain ⟨hxy, -, ht⟩ := h
      rw [hxy, cellsOf_injective ht]

/-! ## The arithmetic of one block -/

/-- A lower bound for the gap after absorbing the block `x4`. -/
def gnext (g : Nat) (x : Sym) : Nat :=
  match x with
  | 0 => 2 * g
  | 2 => 2 * g - 1
  | 1 => 2 * ((2 * (g / 2 - 4)) / 3) + 1
  | _ => 2 * g + 1

@[simp] theorem gnext_0 (g : Nat) : gnext g 0 = 2 * g := rfl
@[simp] theorem gnext_1 (g : Nat) : gnext g 1 = 2 * ((2 * (g / 2 - 4)) / 3) + 1 := rfl
@[simp] theorem gnext_2 (g : Nat) : gnext g 2 = 2 * g - 1 := rfl
@[simp] theorem gnext_3 (g : Nat) : gnext g 3 = 2 * g + 1 := rfl
@[simp] theorem gnext_4 (g : Nat) : gnext g 4 = 2 * g + 1 := rfl

theorem gnext_mono {g g' : Nat} (h : g ≤ g') (x : Sym) : gnext g x ≤ gnext g' x := by
  rcases sym_cases x with rfl | rfl | rfl | rfl | rfl <;> simp <;> omega

/-- **One block of the reset phase.**  Whatever the counter is, absorbing a
block changes it in a completely determined way, and the new counter again has
a radix-2 digit at the bottom. -/
theorem reset_block {w : List LD} {g : Nat} (hg : g ≤ gap w) (hb : BinHead w)
    {x : Sym} (hx : Label x) (h1 : x = 1 → 8 ≤ g) (h2 : x = 2 → 1 ≤ g) (r : List Sym) :
    ∃ w', BinHead w' ∧ gnext g x ≤ gap w' ∧ MSteps ⟨w, x :: 4 :: r⟩ ⟨w', r⟩ := by
  rcases hx with rfl | rfl | rfl | rfl
  · -- block `44`
    refine ⟨.d0 :: w, trivial, ?_, macro_44 w r⟩
    simp only [gnext_4, gap_d0]
    omega
  · -- block `04`
    refine ⟨.d1 :: w, trivial, ?_, macro_04 w r⟩
    simp only [gnext_0, gap_d1]
    omega
  · -- block `24`
    have hpos : 0 < gap w := by have := h2 rfl; omega
    obtain ⟨w1, hw1⟩ := inc_exists hpos
    have hgap := hw1.gap_eq
    refine ⟨.d0 :: w1, trivial, ?_, macro_24 hw1 r⟩
    simp only [gnext_2, gap_d0]
    omega
  · -- block `14`
    have h8 : 8 ≤ gap w := by have := h1 rfl; omega
    match w, hb with
    | .d0 :: w'', _ =>
        have hw : 4 ≤ gap w'' := by simp only [gap_d0] at h8; omega
        obtain ⟨u1, u2, u3, u4, e1, e2, e3, e4, hg4⟩ := inc4_exists hw
        refine ⟨.d0 :: .dB :: u4, trivial, ?_, macro_14_d0 e1 e2 e3 e4 r⟩
        simp only [gnext_1, gap_d0, gap_dB] at *
        omega
    | .d1 :: w'', _ =>
        have hw : 4 ≤ gap w'' := by simp only [gap_d1] at h8; omega
        obtain ⟨u1, u2, u3, u4, e1, e2, e3, e4, hg4⟩ := inc4_exists hw
        refine ⟨.d0 :: .dA :: u4, trivial, ?_, macro_14_d1 e1 e2 e3 e4 r⟩
        simp only [gnext_1, gap_d0, gap_dA, gap_d1] at *
        omega
    | [], hb => exact hb.elim
    | .dA :: w'', hb => exact hb.elim
    | .dB :: w'', hb => exact hb.elim

/-! ## The whole phase -/

/-- The gap after a whole sequence of blocks (a lower bound). -/
def gfold : Nat → List Sym → Nat
  | g, [] => g
  | g, x :: L => gfold (gnext g x) L

/-- The arithmetical safety condition for a sequence of blocks: at every block
`14` the counter must still be able to perform the four increments the block
costs, and at every block `24` the single increment it costs. -/
def SafeRun : Nat → List Sym → Prop
  | _, [] => True
  | g, x :: L => (x = 1 → 8 ≤ g) ∧ (x = 2 → 1 ≤ g) ∧ SafeRun (gnext g x) L

instance decSafeRun : ∀ (g : Nat) (L : List Sym), Decidable (SafeRun g L)
  | _, [] => .isTrue trivial
  | g, x :: L =>
      have : Decidable (SafeRun (gnext g x) L) := decSafeRun (gnext g x) L
      inferInstanceAs (Decidable ((x = 1 → 8 ≤ g) ∧ (x = 2 → 1 ≤ g) ∧ SafeRun (gnext g x) L))

/-- An example: the block sequence `44 44 44 44 04 44 04 24` is safe, the gap
growing `1, 3, 7, 15, 30, 61, 122, 243`.  It is the sequence of the machine's
first reset phase; see `RequestProject/FirstPhase.lean`, where the configuration
it starts from is verified. -/
example : SafeRun 1 [4, 4, 4, 4, 0, 4, 0, 2] := by decide

theorem gfold_mono {g g' : Nat} (h : g ≤ g') (L : List Sym) : gfold g L ≤ gfold g' L := by
  induction L generalizing g g' with
  | nil => exact h
  | cons x L ih => exact ih (gnext_mono h x)

theorem SafeRun_mono {g g' : Nat} (h : g ≤ g') {L : List Sym} (hs : SafeRun g L) :
    SafeRun g' L := by
  induction L generalizing g g' with
  | nil => trivial
  | cons x L ih =>
      obtain ⟨p1, p2, p3⟩ := hs
      exact ⟨fun hx => Nat.le_trans (p1 hx) h, fun hx => Nat.le_trans (p2 hx) h,
        ih (gnext_mono h x) p3⟩

/--
**The reset phase is safe under an arithmetical condition.**

If the counter has a radix-2 digit at the bottom, its gap is at least `g`, and
the sequence of blocks `L` released by the overflow satisfies `SafeRun g L`,
then the machine consumes the whole of `L`, arrives at the material `r` behind
it with a radix-2 digit at the bottom again, and a gap of at least `gfold g L`.

In particular it does not halt during the phase.
-/
theorem reset_phase {w : List LD} (hb : BinHead w) {g : Nat} (hg : g ≤ gap w)
    {L : List Sym} (hL : ∀ x ∈ L, Label x) (hs : SafeRun g L) (r : List Sym) :
    ∃ w', BinHead w' ∧ gfold g L ≤ gap w' ∧ MSteps ⟨w, cellsOf L ++ r⟩ ⟨w', r⟩ := by
  induction L generalizing w g with
  | nil => exact ⟨w, hb, hg, MSteps.refl _⟩
  | cons x L ih =>
      obtain ⟨p1, p2, p3⟩ := hs
      obtain ⟨w1, hb1, hg1, hsteps⟩ :=
        reset_block hg hb (hL x (by simp)) p1 p2 (cellsOf L ++ r)
      obtain ⟨w2, hb2, hg2, hsteps2⟩ :=
        ih hb1 hg1 (fun y hy => hL y (by simp [hy])) p3
      refine ⟨w2, hb2, hg2, ?_⟩
      simpa using hsteps.trans hsteps2

/--
**The reset phase started by an overflow.**  An overflow leaves the machine with
an empty counter facing a block `44` followed by the released blocks; if the
resulting block sequence is arithmetically safe, the machine survives the whole
phase.
-/
theorem reset_phase_of_ovf {w : List LD} {s : List Sym} (hovf : Ovf w s)
    (r : List Sym) {L : List Sym} (hs : s = cellsOf L)
    (hsafe : SafeRun 1 L) :
    ∃ w', BinHead w' ∧ gfold 1 L ≤ gap w' ∧
      MSteps ⟨[], 4 :: 4 :: (s ++ r)⟩ ⟨w', r⟩ := by
  obtain ⟨L₀, hL₀, hs₀⟩ := hovf.released
  have hLlab : ∀ x ∈ L, Label x := by
    intro x hx
    have hcells : cellsOf L = cellsOf L₀ := by rw [← hs, hs₀]
    rw [cellsOf_injective hcells] at hx
    exact hL₀ x hx
  -- the first block `44` fills the empty counter with a digit `02`
  have hfirst : MSteps ⟨([] : List LD), 4 :: 4 :: (s ++ r)⟩ ⟨[LD.d0], s ++ r⟩ :=
    macro_44 [] (s ++ r)
  obtain ⟨w', hb', hg', hsteps⟩ :=
    reset_phase (w := [LD.d0]) trivial (g := 1) (by simp [gap]) hLlab hsafe r
  exact ⟨w', hb', hg', hfirst.trans (by rw [hs]; exact hsteps)⟩

end SOC
