import RequestProject.Counter
import RequestProject.MacroMachine

/-!
# Where the machine can die, and a non-halting criterion

The macro machine of `RequestProject.MacroMachine` is **total** except at two
patterns (`mstep_exists`), and at those two patterns the Turing machine really
does halt (`danger_halts`).  So the macro model captures halting exactly:

* `B> x3` with `x = 0` or `x = 4` — the head runs into the right-hand cell of a
  digit `23`/`03` from the left;
* `B> 1` with a digit `23`/`03` (or nothing at all) next to the head — the head
  reads the terminating `1` of the right-hand material while the lowest digit of
  the counter is one of the radix-3/2 digits.

Everything else is safe, whatever the counter and the tape context are.

`neverHalts_of_invariant` turns this into a criterion for non-halting: exhibit a
set of macro configurations that contains the starting one, avoids the two
patterns above, and is closed under the macro step.
-/

namespace SOC

open Cfg

/-- The lowest digit of the counter is one of the radix-2 digits `02`, `22`. -/
def BinHead : List LD → Prop
  | .d0 :: _ => True
  | .d1 :: _ => True
  | _ => False

instance : DecidablePred BinHead := fun w => by
  match w with
  | [] => exact inferInstanceAs (Decidable False)
  | .d0 :: _ => exact inferInstanceAs (Decidable True)
  | .d1 :: _ => exact inferInstanceAs (Decidable True)
  | .dA :: _ => exact inferInstanceAs (Decidable False)
  | .dB :: _ => exact inferInstanceAs (Decidable False)

/-- The two configurations from which the machine dies. -/
def Danger (m : MCfg) : Prop :=
  ((hd m.r = 4 ∨ hd m.r = 0) ∧ hd m.r.tail = 3) ∨ (hd m.r = 1 ∧ ¬ BinHead m.w)

theorem sym_cases (x : Sym) : x = 0 ∨ x = 1 ∨ x = 2 ∨ x = 3 ∨ x = 4 := by
  revert x; decide

/-- **The macro machine is total away from the two dangerous patterns.** -/
theorem mstep_exists {m : MCfg} (h : ¬ Danger m) : ∃ m', MStep m m' := by
  obtain ⟨w, r⟩ := m
  simp only [Danger] at h
  have h3 : (hd r = 4 ∨ hd r = 0) → hd r.tail ≠ 3 := fun hx hy => h (Or.inl ⟨hx, hy⟩)
  have h1 : hd r = 1 → ¬ ¬ BinHead w := fun hx hy => h (Or.inr ⟨hx, hy⟩)
  rcases sym_cases (hd r) with h0 | hone | htwo | hthree | hfour
  · -- head cell `0`
    rcases sym_cases (hd r.tail) with g0 | g1 | g2 | g3 | g4
    · exact ⟨_, MStep.a00 h0 g0⟩
    · exact ⟨_, MStep.a01 h0 g1⟩
    · exact ⟨_, MStep.a02 h0 g2⟩
    · exact absurd g3 (h3 (Or.inr h0))
    · exact ⟨_, MStep.a04 h0 g4⟩
  · -- head cell `1`
    have hb : BinHead w := Classical.byContradiction (h1 hone)
    match w, hb with
    | .d0 :: w, _ => exact ⟨_, MStep.one0 hone⟩
    | .d1 :: w, _ => exact ⟨_, MStep.one1 hone⟩
    | [], hb => exact hb.elim
    | .dA :: w, hb => exact hb.elim
    | .dB :: w, hb => exact hb.elim
  · -- head cell `2` : a sweep, or an overflow
    rcases Nat.eq_zero_or_pos (gap w) with hg | hg
    · obtain ⟨s, hs⟩ := ovf_exists hg
      exact ⟨_, MStep.ovf2 hs htwo⟩
    · obtain ⟨w', hw'⟩ := inc_exists hg
      exact ⟨_, MStep.inc2 hw' htwo⟩
  · -- head cell `3` : a sweep, or an overflow
    rcases Nat.eq_zero_or_pos (gap w) with hg | hg
    · obtain ⟨s, hs⟩ := ovf3_exists hg
      exact ⟨_, MStep.ovf3 hs hthree⟩
    · obtain ⟨w', hw'⟩ := inc_exists hg
      exact ⟨_, MStep.inc3 hw' hthree⟩
  · -- head cell `4`
    rcases sym_cases (hd r.tail) with g0 | g1 | g2 | g3 | g4
    · exact ⟨_, MStep.a40 hfour g0⟩
    · exact ⟨_, MStep.a41 hfour g1⟩
    · exact ⟨_, MStep.a42 hfour g2⟩
    · exact absurd g3 (h3 (Or.inl hfour))
    · exact ⟨_, MStep.a44 hfour g4⟩

/-! ## The dangerous patterns really are fatal -/

theorem halts_x3 (l r : List Sym) (h1 : hd r = 4 ∨ hd r = 0) (h2 : hd r.tail = 3) :
    run ⟨l, St.B, r⟩ 2 = none := by
  match r with
  | [] => simp [hd] at h2
  | a :: t =>
    match t with
    | [] => simp [hd] at h2
    | b :: t' =>
      simp [hd] at h1 h2
      subst h2
      rcases h1 with h | h <;> subst h <;> rfl

theorem halts_one_dA (w : List LD) (r : List Sym) (h : hd r = 1) :
    run ⟨lzz (.dA :: w), St.B, r⟩ 2 = none := by
  rw [eq_cons_of_hd h (by decide)]; rfl

theorem halts_one_dB (w : List LD) (r : List Sym) (h : hd r = 1) :
    run ⟨lzz (.dB :: w), St.B, r⟩ 2 = none := by
  rw [eq_cons_of_hd h (by decide)]; rfl

/-- With an empty counter, reading a `1` eats the marker; three steps later the
head comes back onto the `3` it has just written and the machine dies. -/
theorem halts_one_nil (r : List Sym) (h : hd r = 1) :
    run ⟨lzz [], St.B, r⟩ 7 = none := by
  rw [eq_cons_of_hd h (by decide)]; rfl

/-- **The dangerous configurations halt.** -/
theorem danger_halts {m : MCfg} (h : Danger m) : ∃ n, run (enc m) n = none := by
  obtain ⟨w, r⟩ := m
  rcases h with ⟨h1, h2⟩ | ⟨h1, h2⟩
  · exact ⟨2, halts_x3 (lzz w) r h1 h2⟩
  · match w with
    | [] => exact ⟨7, halts_one_nil r h1⟩
    | .d0 :: w => exact absurd trivial h2
    | .d1 :: w => exact absurd trivial h2
    | .dA :: w => exact ⟨2, halts_one_dA w r h1⟩
    | .dB :: w => exact ⟨2, halts_one_dB w r h1⟩

/-! ## A criterion for non-halting -/

/--
**Non-halting criterion.**  If some set `S` of macro configurations contains the
configuration reached from the blank tape, contains no dangerous configuration,
and is closed under the macro step, then the machine never halts.

By `mstep_exists` the closure condition is automatic once `S` is closed under
*the* successor; the content of a non-halting proof for
`1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` is therefore exactly to find such an `S`.
-/
theorem neverHalts_of_invariant (S : MCfg → Prop)
    (h0 : S ⟨[], [4, 4, 4, 4, 2, 4, 0, 4, 1]⟩)
    (hstep : ∀ m, S m → ∃ m', MStep m m' ∧ S m') : NeverHalts := by
  -- build an infinite chain of macro steps out of `S`
  have hnext : ∀ m : { m : MCfg // S m }, ∃ m' : { m : MCfg // S m }, MStep m.1 m'.1 := by
    rintro ⟨m, hm⟩
    obtain ⟨m', hstep', hm'⟩ := hstep m hm
    exact ⟨⟨m', hm'⟩, hstep'⟩
  let nxt : { m : MCfg // S m } → { m : MCfg // S m } := fun m => Classical.choose (hnext m)
  have hnxt : ∀ m, MStep m.1 (nxt m).1 := fun m => Classical.choose_spec (hnext m)
  let f : Nat → { m : MCfg // S m } := fun n => Nat.rec (⟨_, h0⟩ : { m : MCfg // S m })
    (fun _ m => nxt m) n
  have hf : ∀ i, MStep (f i).1 (f (i + 1)).1 := fun i => hnxt (f i)
  exact neverHalts_of_macro_chain (fun i => (f i).1) rfl hf

/--
**Non-halting criterion, in terms of safety only.**  A set `S` that contains the
starting configuration, is closed under macro steps and contains no dangerous
configuration gives non-halting; here the closure hypothesis only has to be
checked for the steps that actually exist.
-/
theorem neverHalts_of_safe_invariant (S : MCfg → Prop)
    (h0 : S ⟨[], [4, 4, 4, 4, 2, 4, 0, 4, 1]⟩)
    (hsafe : ∀ m, S m → ¬ Danger m)
    (hclosed : ∀ m m', S m → MStep m m' → S m') : NeverHalts := by
  refine neverHalts_of_invariant S h0 ?_
  intro m hm
  obtain ⟨m', hm'⟩ := mstep_exists (hsafe m hm)
  exact ⟨m', hm', hclosed m m' hm hm'⟩

end SOC
