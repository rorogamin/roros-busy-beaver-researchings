import RequestProject.Stages

/-!
# The two remaining reset-stage rules

The informal analysis lists five reset-stage rules,

```
(02|22) B> 44  -->  (02|22) 02 B>
(02|22) B> 04  -->  (02|22) 22 B>
(02|22) B> 24  -->  (02|22)< 02 B>
(02|22) B> 14  -->  <<<< (03|23) 02 B>
(02|22) B> 1.  -->  <<<<< B> (40|42) 42 41.
```

The first three are `rule_44`, `rule_04` (`RequestProject/Rules.lean`) and
`reset_rule_24` (`RequestProject/Stages.lean`).  This file proves the remaining
two, the ones that involve several decrements of the left counter.

Throughout, the left counter is written in two-cell digits, *nearest cell first*:
`02` is `2 :: 0`, `22` is `2 :: 2`, `23` is `3 :: 2` and `03` is `3 :: 0`.  Read
with the digit nearest the head as the least significant one and `02 = 0`,
`22 = 1`, the decrement `<` of the informal analysis is the `+1` of `dec_binary`.
The two rules below perform four (resp. five) decrements, so they are stated for
a counter whose lowest digits are binary digits `x0 x1 (x2)` followed by
`(22)^{k+1} 02`; this is exactly the hypothesis that the `+4` (resp. `+5`) does
not run past the digits shown, i.e. that the counter does not underflow.
-/

namespace SOC

open Cfg

/-- Borrowing at a digit `03` standing next to the head (`dec_borrow` with an
empty sweep). -/
theorem dec_borrow_here (a : Sym) (ha : Sweepable a) (l r : List Sym) :
    run ⟨3 :: 0 :: l, St.B, a :: r⟩ 4 = some ⟨l, St.B, 2 :: 0 :: sw a :: r⟩ := by
  have h := dec_borrow [] (by simp) a ha l r
  simpa using h

/-! ## The rule `B> 14` -/

/-- `B> 14` with the two lowest digits of the left counter equal to `02 02`. -/
theorem reset_rule_14_00 (k : Nat) (L r : List Sym) :
    run ⟨2 :: 0 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 1 :: 4 :: r⟩ (4 * k + 52)
      = some ⟨2 :: 0 :: 3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, r⟩ := by
  have s1 : run ⟨2 :: 0 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 1 :: 4 :: r⟩ 10
      = some ⟨3 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 3 :: 4 :: r⟩ := by
    simpa using reset_rule_one_from02 0 (cells22 (k + 1) ++ 2 :: 0 :: L) (4 :: r)
  have s2 : run ⟨3 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 3 :: 4 :: r⟩ 4
      = some ⟨2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 2 :: 0 :: 2 :: 4 :: r⟩ := by
    simpa [sw] using
      dec_borrow_here 3 (Or.inr rfl) (2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) (4 :: r)
  have s3 : run ⟨2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 2 :: 0 :: 2 :: 4 :: r⟩
        (4 * (k + 2) + 4)
      = some ⟨cells02 (k + 2) ++ 2 :: 2 :: L, St.B, 4 :: 0 :: 2 :: 4 :: r⟩ := by
    have h := dec_binary (k + 2) 2 (Or.inl rfl) L (0 :: 2 :: 4 :: r)
    rw [cells22_succ] at h
    simpa [sw] using h
  have s4 : run ⟨cells02 (k + 2) ++ 2 :: 2 :: L, St.B, 4 :: 0 :: 2 :: 4 :: r⟩ 4
      = some ⟨3 :: 2 :: 2 :: 0 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 4 :: r⟩ := by
    rw [cells02_succ (k + 1)]
    simpa using rule_40 (2 :: 0 :: (cells02 (k + 1) ++ 2 :: 2 :: L)) (2 :: 4 :: r)
  have s5 : run ⟨3 :: 2 :: 2 :: 0 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 4 :: r⟩ 10
      = some ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 1 :: 4 :: 4 :: r⟩ := by
    simpa [sw] using dec_binary23 0 2 (Or.inl rfl) (cells02 (k + 1) ++ 2 :: 2 :: L) (4 :: r)
  have s6 : run ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 1 :: 4 :: 4 :: r⟩ 8
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 1 :: 4 :: 4 :: r⟩ := by
    have h := dec_binary 1 2 (Or.inl rfl) (cells02 k ++ 2 :: 2 :: L) (1 :: 4 :: 4 :: r)
    rw [cells02_succ k]
    simpa [cells22, cells02, sw] using h
  have s7 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 1 :: 4 :: 4 :: r⟩ 2
      = some ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 4 :: r⟩ :=
    rule_41 _ _
  have s8 : run ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 4 :: r⟩ 2
      = some ⟨2 :: 0 :: 3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, r⟩ :=
    rule_44 _ _
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4
    (run_trans s5 (run_trans s6 (run_trans s7 s8))))))
  rw [show 4 * k + 52 = 10 + (4 + ((4 * (k + 2) + 4) + (4 + (10 + (8 + (2 + 2)))))) from by omega]
  exact h

/-- `B> 14` with the two lowest digits of the left counter equal to `22 02`
(the digit nearest the head is `02`, the next one `22`). -/
theorem reset_rule_14_02 (k : Nat) (L r : List Sym) :
    run ⟨2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 1 :: 4 :: r⟩ (4 * k + 52)
      = some ⟨2 :: 0 :: 3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, r⟩ := by
  have s1 : run ⟨2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 1 :: 4 :: r⟩
        (4 * (k + 2) + 10)
      = some ⟨3 :: 0 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, 3 :: 4 :: r⟩ := by
    have h := reset_rule_one_from02 (k + 2) L (4 :: r)
    rw [cells22_succ] at h
    simpa using h
  have s2 : run ⟨3 :: 0 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, 3 :: 4 :: r⟩ 4
      = some ⟨cells02 (k + 2) ++ 2 :: 2 :: L, St.B, 2 :: 0 :: 2 :: 4 :: r⟩ := by
    simpa [sw] using dec_borrow_here 3 (Or.inr rfl) (cells02 (k + 2) ++ 2 :: 2 :: L) (4 :: r)
  have s3 : run ⟨cells02 (k + 2) ++ 2 :: 2 :: L, St.B, 2 :: 0 :: 2 :: 4 :: r⟩ 4
      = some ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 4 :: 0 :: 2 :: 4 :: r⟩ := by
    rw [cells02_succ (k + 1)]
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (cells02 (k + 1) ++ 2 :: 2 :: L) (0 :: 2 :: 4 :: r)
  have s4 : run ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 4 :: 0 :: 2 :: 4 :: r⟩ 4
      = some ⟨3 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 4 :: r⟩ :=
    rule_40 _ _
  have s5 : run ⟨3 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 4 :: r⟩
        (4 * 1 + 10)
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 2 :: 1 :: 4 :: 4 :: r⟩ := by
    have h := dec_binary23 1 2 (Or.inl rfl) (cells02 k ++ 2 :: 2 :: L) (4 :: r)
    rw [cells02_succ k]
    simpa [cells22, cells02, sw] using h
  have s6 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 2 :: 1 :: 4 :: 4 :: r⟩ 4
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 1 :: 4 :: 4 :: r⟩ := by
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (2 :: 2 :: (cells02 k ++ 2 :: 2 :: L)) (1 :: 4 :: 4 :: r)
  have s7 : run ⟨2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 1 :: 4 :: 4 :: r⟩ 2
      = some ⟨3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 4 :: r⟩ :=
    rule_41 _ _
  have s8 : run ⟨3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 4 :: r⟩ 2
      = some ⟨2 :: 0 :: 3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, r⟩ :=
    rule_44 _ _
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4
    (run_trans s5 (run_trans s6 (run_trans s7 s8))))))
  rw [show 4 * k + 52
      = (4 * (k + 2) + 10) + (4 + (4 + (4 + ((4 * 1 + 10) + (4 + (2 + 2)))))) from by omega]
  exact h

/-- `B> 14` with the two lowest digits of the left counter equal to `02 22`
(the digit nearest the head is `22`, the next one `02`). -/
theorem reset_rule_14_20 (k : Nat) (L r : List Sym) :
    run ⟨2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 1 :: 4 :: r⟩ (4 * k + 52)
      = some ⟨2 :: 0 :: 3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, r⟩ := by
  have s1 : run ⟨2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 1 :: 4 :: r⟩ 10
      = some ⟨3 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 3 :: 4 :: r⟩ := by
    simpa [cells22] using reset_rule_one_from22 0 (cells22 (k + 1) ++ 2 :: 0 :: L) (4 :: r)
  have s2 : run ⟨3 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 3 :: 4 :: r⟩
        (4 * (k + 2) + 10)
      = some ⟨cells02 (k + 2) ++ 2 :: 2 :: L, St.B, 2 :: 1 :: 2 :: 4 :: r⟩ := by
    have h := dec_binary23 (k + 2) 3 (Or.inr rfl) L (4 :: r)
    rw [cells22_succ] at h
    simpa [sw] using h
  have s3 : run ⟨cells02 (k + 2) ++ 2 :: 2 :: L, St.B, 2 :: 1 :: 2 :: 4 :: r⟩ 4
      = some ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 4 :: 1 :: 2 :: 4 :: r⟩ := by
    rw [cells02_succ (k + 1)]
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (cells02 (k + 1) ++ 2 :: 2 :: L) (1 :: 2 :: 4 :: r)
  have s4 : run ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 4 :: 1 :: 2 :: 4 :: r⟩ 2
      = some ⟨3 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 4 :: r⟩ :=
    rule_41 _ _
  have s5 : run ⟨3 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 4 :: r⟩ 4
      = some ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 0 :: 4 :: 4 :: r⟩ := by
    simpa [sw] using
      dec_borrow_here 2 (Or.inl rfl) (2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L)) (4 :: r)
  have s6 : run ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 0 :: 4 :: 4 :: r⟩ 8
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 0 :: 4 :: 4 :: r⟩ := by
    have h := dec_binary 1 2 (Or.inl rfl) (cells02 k ++ 2 :: 2 :: L) (0 :: 4 :: 4 :: r)
    rw [cells02_succ k]
    simpa [cells22, cells02, sw] using h
  have s7 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 0 :: 4 :: 4 :: r⟩ 4
      = some ⟨3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 4 :: r⟩ :=
    rule_40 _ _
  have s8 : run ⟨3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 4 :: r⟩ 2
      = some ⟨2 :: 0 :: 3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, r⟩ :=
    rule_44 _ _
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4
    (run_trans s5 (run_trans s6 (run_trans s7 s8))))))
  rw [show 4 * k + 52
      = 10 + ((4 * (k + 2) + 10) + (4 + (2 + (4 + (8 + (4 + 2)))))) from by omega]
  exact h

/-- `B> 14` with the two lowest digits of the left counter equal to `22 22`. -/
theorem reset_rule_14_22 (k : Nat) (L r : List Sym) :
    run ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 1 :: 4 :: r⟩ (4 * k + 52)
      = some ⟨2 :: 0 :: 3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, r⟩ := by
  have s1 : run ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 1 :: 4 :: r⟩
        (4 * (k + 2) + 10)
      = some ⟨3 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, 3 :: 4 :: r⟩ := by
    have h := reset_rule_one_from22 (k + 2) L (4 :: r)
    rw [cells22_succ, cells22_succ] at h
    simpa using h
  have s2 : run ⟨3 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, 3 :: 4 :: r⟩ 10
      = some ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 1 :: 2 :: 4 :: r⟩ := by
    rw [cells02_succ (k + 1)]
    simpa [sw] using dec_binary23 0 3 (Or.inr rfl) (cells02 (k + 1) ++ 2 :: 2 :: L) (4 :: r)
  have s3 : run ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, 2 :: 1 :: 2 :: 4 :: r⟩ 8
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 1 :: 2 :: 4 :: r⟩ := by
    have h := dec_binary 1 2 (Or.inl rfl) (cells02 k ++ 2 :: 2 :: L) (1 :: 2 :: 4 :: r)
    rw [cells02_succ k]
    simpa [cells22, cells02, sw] using h
  have s4 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 1 :: 2 :: 4 :: r⟩ 2
      = some ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 2 :: 4 :: r⟩ :=
    rule_41 _ _
  have s5 : run ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 2 :: 4 :: r⟩ 4
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 2 :: 0 :: 4 :: 4 :: r⟩ := by
    simpa [sw] using
      dec_borrow_here 2 (Or.inl rfl) (2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L)) (4 :: r)
  have s6 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 2 :: 0 :: 4 :: 4 :: r⟩ 4
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 0 :: 4 :: 4 :: r⟩ := by
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (2 :: 2 :: (cells02 k ++ 2 :: 2 :: L)) (0 :: 4 :: 4 :: r)
  have s7 : run ⟨2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 0 :: 4 :: 4 :: r⟩ 4
      = some ⟨3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 4 :: r⟩ :=
    rule_40 _ _
  have s8 : run ⟨3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, 4 :: 4 :: r⟩ 2
      = some ⟨2 :: 0 :: 3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, r⟩ :=
    rule_44 _ _
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4
    (run_trans s5 (run_trans s6 (run_trans s7 s8))))))
  rw [show 4 * k + 52
      = (4 * (k + 2) + 10) + (10 + (8 + (2 + (4 + (4 + (4 + 2)))))) from by omega]
  exact h

/--
**The reset-stage rule `(02|22) B> 14`.**

Informally `(02|22) B> 14  -->  <<<< (03|23) 02 B>`: reading the `1` costs four
decrements of the left counter, creates a digit `03` (if the digit nearest the
head was `02`) or `23` (if it was `22`), and finally pushes a new digit `02`, so
that the digit nearest the head after the rule is again `02` — which is why the
machine survives reading the next `1`.

The counter is `x0 x1 (22)^{k+1} 02 …` with `x0`, `x1` binary digits (`u`, `v`
are their left-hand cells), i.e. the `+4` performed by the four decrements does
not run past the digits shown.  The rule takes exactly `4k + 52` steps.
-/
theorem reset_rule_14 (u v : Sym) (hu : u = 0 ∨ u = 2) (hv : v = 0 ∨ v = 2)
    (k : Nat) (L r : List Sym) :
    run ⟨2 :: u :: 2 :: v :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, 1 :: 4 :: r⟩ (4 * k + 52)
      = some ⟨2 :: 0 :: 3 :: u :: 2 :: v :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, r⟩ := by
  rcases hu with rfl | rfl <;> rcases hv with rfl | rfl
  · exact reset_rule_14_00 k L r
  · exact reset_rule_14_02 k L r
  · exact reset_rule_14_20 k L r
  · exact reset_rule_14_22 k L r

end SOC
