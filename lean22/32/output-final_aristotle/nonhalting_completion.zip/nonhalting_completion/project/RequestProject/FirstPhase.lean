import RequestProject.ResetPhase

/-!
# The first reset phase of the real machine

A completely verified instance of the theory of `RequestProject.ResetPhase`.

Started from the blank tape, the machine reaches its first counter overflow
after 306 steps; the tape is then

```
.22 B> 44 44 44 44 04 44 04 24 1.
```

i.e. the empty counter in front of the block sequence `44 · 44 44 44 04 44 04 24`.
The arithmetic test `SafeRun` succeeds on it (the gap runs
`1, 3, 7, 15, 30, 61, 122, 243`), so `reset_phase` applies: the machine consumes
the whole phase without halting and comes out with a counter of gap at least
`243` whose lowest digit is again a radix-2 digit.
-/

namespace SOC

set_option maxRecDepth 10000

/-- The block sequence of the first reset phase, after the leading block `44`. -/
def firstBlocks : List Sym := [4, 4, 4, 0, 4, 0, 2]

/-- After 306 steps the machine is at the start of its first reset phase. -/
theorem run_init_306 :
    run init 306 = some (enc ⟨[], 4 :: 4 :: (cellsOf firstBlocks ++ [1])⟩) := by
  rfl

theorem firstBlocks_labels : ∀ x ∈ firstBlocks, Label x := by decide

theorem firstBlocks_safe : SafeRun 1 firstBlocks := by decide

theorem firstBlocks_gfold : gfold 1 firstBlocks = 243 := by decide

/--
**The machine survives its first reset phase.**  From the blank tape it reaches
a configuration whose counter has a radix-2 digit at the bottom and can still
perform at least `243` increments, with only the terminating `1` left of the old
right-hand material.
-/
theorem first_reset_phase :
    ∃ w' : List LD, BinHead w' ∧ 243 ≤ gap w' ∧ init ⟶* enc ⟨w', [1]⟩ := by
  have hgap : 1 ≤ gap [LD.d0] := by decide
  obtain ⟨w', hb, hg, hsteps⟩ :=
    reset_phase (w := [LD.d0]) trivial hgap firstBlocks_labels firstBlocks_safe [1]
  refine ⟨w', hb, ?_, ?_⟩
  · rw [firstBlocks_gfold] at hg; exact hg
  · have h306 : init ⟶* enc ⟨[], 4 :: 4 :: (cellsOf firstBlocks ++ [1])⟩ :=
      reaches_of_run run_init_306
    have hfirst : MSteps ⟨[], 4 :: 4 :: (cellsOf firstBlocks ++ [1])⟩
        ⟨[LD.d0], cellsOf firstBlocks ++ [1]⟩ := macro_44 [] _
    exact h306.trans (hfirst.sim.trans hsteps.sim)

end SOC
