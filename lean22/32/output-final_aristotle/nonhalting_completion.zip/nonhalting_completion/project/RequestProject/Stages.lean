import RequestProject.Rules

/-!
# Stage-level behaviour

The informal analysis of the machine `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` describes
the tape as two counters:

* a **left counter**, written in two-cell digits `02`, `22`, `23`, `03`, sitting
  between the leading marker `.22` and the head;
* a **right counter**, written in two-cell digits and terminated by a `1`.

This file proves the digit-level behaviour of the *binary* digits `02` and `22`:
a decrement of a left counter whose leading digits are `22`, and the reset-stage
rule `B> 24` of the informal analysis.
-/

namespace SOC

open Cfg

/-- `m` copies of the left-counter digit `22`, as tape cells, nearest cell first. -/
def cells22 (m : Nat) : List Sym := (List.replicate m [(2 : Sym), 2]).flatten

/-- `m` copies of the left-counter digit `02`, as tape cells, nearest cell first. -/
def cells02 (m : Nat) : List Sym := (List.replicate m [(2 : Sym), 0]).flatten

@[simp] theorem cells22_zero : cells22 0 = [] := rfl
@[simp] theorem cells02_zero : cells02 0 = [] := rfl

theorem cells22_succ (m : Nat) : cells22 (m + 1) = 2 :: 2 :: cells22 m := by
  simp [cells22, List.replicate_succ]

theorem cells02_succ' (m : Nat) : cells02 (m + 1) = cells02 m ++ [2, 0] := by
  simp [cells02, List.replicate_succ']

theorem cells02_succ (m : Nat) : cells02 (m + 1) = 2 :: 0 :: cells02 m := by
  simp [cells02, List.replicate_succ]

@[simp] theorem cells22_length (m : Nat) : (cells22 m).length = 2 * m := by
  induction m with
  | zero => rfl
  | succ m ih => rw [cells22_succ]; simp [ih]; omega

theorem cells22_sweepable (m : Nat) : ∀ x ∈ cells22 m, Sweepable x := by
  induction m with
  | zero => simp
  | succ m ih =>
      rw [cells22_succ]
      intro x hx
      rcases List.mem_cons.1 hx with rfl | hx
      · exact Or.inl rfl
      · rcases List.mem_cons.1 hx with rfl | hx
        · exact Or.inl rfl
        · exact ih x hx

/-- Sweeping across `m` digits `22` leaves `m` blocks `44` behind. -/
theorem cells22_swept (m : Nat) :
    (cells22 m).reverse.map sw = (List.replicate m [(4 : Sym), 4]).flatten := by
  induction m with
  | zero => rfl
  | succ m ih =>
      rw [cells22_succ, List.replicate_succ']
      simp [List.map_append, ih, sw]

/--
**Decrement of a binary left counter.**

If the digits nearest the head are `m` copies of `22` followed by a digit `02`,
and the head reads a symbol (`2` or `3`) that sends it left, then the machine
performs a complete decrement: the `m` digits `22` become `02`, the digit `02`
becomes `22`, and the head comes back to where it started, now reading `sw a`.
This takes `4m + 4` steps.
-/
theorem dec_binary (m : Nat) (a : Sym) (ha : Sweepable a) (l r : List Sym) :
    run ⟨cells22 m ++ 2 :: 0 :: l, St.B, a :: r⟩ (4 * m + 4)
      = some ⟨cells02 m ++ 2 :: 2 :: l, St.B, sw a :: r⟩ := by
  have h1 := dec_stop (cells22 m) (cells22_sweepable m) a ha l r
  rw [cells22_length] at h1
  have hsplit : 4 * m + 4 = (2 * m + 4) + 2 * m := by omega
  rw [hsplit, run_add, h1]
  simp only [Option.bind_some, cells22_swept]
  rw [absorb_fours m (2 :: 2 :: l) (sw a :: r)]
  simp [cells02]

/--
**Reset-stage rule `B> 24`** (informally `(02|22) B> 24  ⟶  (02|22)< 02 B>`):
the machine decrements the left counter and then appends a new digit `02`.
-/
theorem reset_rule_24 (m : Nat) (l r : List Sym) :
    run ⟨cells22 m ++ 2 :: 0 :: l, St.B, 2 :: 4 :: r⟩ (4 * m + 6)
      = some ⟨2 :: 0 :: (cells02 m ++ 2 :: 2 :: l), St.B, r⟩ := by
  have h1 := dec_binary m 2 (Or.inl rfl) l (4 :: r)
  have hsplit : 4 * m + 6 = (4 * m + 4) + 2 := by omega
  rw [hsplit, run_add, h1]
  simp only [Option.bind_some]
  exact rule_44 _ _

/--
**Reset-stage rule for the final `1`, from a digit `22`.**

Informally `(22)^{m+1} 02 B> 1 x  ⟶  (02)^m 22 23 <B 3 x` : reading the `1`
sends the head left in state `A` onto the `2` of the nearest digit `22`, which
triggers a decrement of the counter; the two cells freed on the right are read
back as `40` and become a new digit `23`, and the head is left reading a `3`
(so another decrement starts).  This is the first `<` of the informal rules
`(02|22) B> 14 --> <<<< (03|23) 02 B>` and `(02|22) B> 1. --> ...`.
-/
theorem reset_rule_one_from22 (m : Nat) (l r : List Sym) :
    run ⟨cells22 (m + 1) ++ 2 :: 0 :: l, St.B, 1 :: r⟩ (4 * m + 10)
      = some ⟨3 :: 2 :: (cells02 m ++ 2 :: 2 :: l), St.B, 3 :: r⟩ := by
  rw [cells22_succ]
  have hsplit : 4 * m + 10 = 2 + ((4 * m + 4) + 4) := by omega
  rw [hsplit, run_add]
  have h1 : run ⟨2 :: 2 :: (cells22 m ++ 2 :: 0 :: l), St.B, 1 :: r⟩ 2
      = some ⟨cells22 m ++ 2 :: 0 :: l, St.B, 2 :: 0 :: 3 :: r⟩ := digit22_one _ _
  rw [show (2 :: 2 :: cells22 m ++ 2 :: 0 :: l) = 2 :: 2 :: (cells22 m ++ 2 :: 0 :: l) from rfl, h1]
  simp only [Option.bind_some]
  rw [run_add, dec_binary m 2 (Or.inl rfl) l (0 :: 3 :: r)]
  simp only [Option.bind_some, sw]
  exact rule_40 _ _

/--
**Reset-stage rule for the final `1`, from a digit `02`.**

Informally `02 (22)^m 02 B> 1 x  ⟶  (02)^m 22 03 <B 3 x` : the same as
`reset_rule_one_from22`, but the digit adjacent to the head is `02`, and the
new digit created is `03` instead of `23`.
-/
theorem reset_rule_one_from02 (m : Nat) (l r : List Sym) :
    run ⟨2 :: 0 :: (cells22 m ++ 2 :: 0 :: l), St.B, 1 :: r⟩ (4 * m + 10)
      = some ⟨3 :: 0 :: (cells02 m ++ 2 :: 2 :: l), St.B, 3 :: r⟩ := by
  have hsplit : 4 * m + 10 = 4 + ((4 * m + 4) + 2) := by omega
  rw [hsplit, run_add, digit02_one _ _]
  simp only [Option.bind_some]
  rw [run_add, dec_binary m 2 (Or.inl rfl) l (1 :: 3 :: r)]
  simp only [Option.bind_some, sw]
  exact rule_41 _ _

/--
**Decrementing a counter whose leading digit is `23`.**

The sweep crosses the digit `23` and the `k` digits `22` behind it and stops at
the next digit `02`.  On the way back the swept `23` is read as `42`, which the
machine rewrites in place as `21`: the head is therefore sent left *again*
(a second decrement), and after that second decrement the two cells `41` will be
read as a new digit `03`.  This is the "radix 1.5" digit of the informal
analysis: one decrement of a `23` costs two decrements of the binary part.
-/
theorem dec_binary23 (k : Nat) (a : Sym) (ha : Sweepable a) (l r : List Sym) :
    run ⟨3 :: 2 :: (cells22 k ++ 2 :: 0 :: l), St.B, a :: r⟩ (4 * k + 10)
      = some ⟨cells02 k ++ 2 :: 2 :: l, St.B, 2 :: 1 :: sw a :: r⟩ := by
  have hS : ∀ x ∈ [(3 : Sym), 2] ++ cells22 k, Sweepable x := by
    intro x hx
    rcases List.mem_append.1 hx with hx | hx
    · rcases List.mem_cons.1 hx with rfl | hx
      · exact Or.inr rfl
      · rcases List.mem_cons.1 hx with rfl | hx
        · exact Or.inl rfl
        · simp at hx
    · exact cells22_sweepable k x hx
  have h1 := dec_stop ([(3 : Sym), 2] ++ cells22 k) hS a ha l r
  have hlen : ([(3 : Sym), 2] ++ cells22 k).length + 4 = 2 * k + 6 := by
    simp
  have hassoc : [(3 : Sym), 2] ++ cells22 k ++ 2 :: 0 :: l
      = 3 :: 2 :: (cells22 k ++ 2 :: 0 :: l) := by simp
  rw [hlen, hassoc] at h1
  have hrev : (([(3 : Sym), 2] ++ cells22 k).reverse.map sw)
      = (List.replicate k [(4 : Sym), 4]).flatten ++ [4, 2] := by
    rw [List.reverse_append, List.map_append, cells22_swept]
    simp [sw]
  rw [hrev] at h1
  have hsplit : 4 * k + 10 = (2 * k + 6) + (2 * k + 4) := by omega
  rw [hsplit, run_add, h1]
  simp only [Option.bind_some]
  rw [show ((List.replicate k [(4 : Sym), 4]).flatten ++ [4, 2] ++ sw a :: r)
      = (List.replicate k [(4 : Sym), 4]).flatten ++ (4 :: 2 :: sw a :: r) from by simp,
    run_add, absorb_fours k (2 :: 2 :: l) (4 :: 2 :: sw a :: r)]
  simp only [Option.bind_some, cells02]
  exact rule_42 _ _

/--
**A digit `23` becomes a digit `03`.**

Continuing `dec_binary23` through the second decrement: the pair of cells left
by the `21` is read back as `41` and becomes the digit `03`.  So decrementing a
left counter of the shape `23 (22)^{k+1} 02 …` produces `03 22 (02)^k 22 …`.
-/
theorem dec23_creates03 (k : Nat) (a : Sym) (ha : Sweepable a) (l r : List Sym) :
    run ⟨3 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: l), St.B, a :: r⟩ (4 * k + 20)
      = some ⟨3 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: l), St.B, sw a :: r⟩ := by
  have hsplit : 4 * k + 20 = (4 * (k + 1) + 10) + (4 + 2) := by omega
  rw [hsplit, run_add, dec_binary23 (k + 1) a ha l r]
  simp only [Option.bind_some, cells02_succ]
  rw [run_add]
  have h2 := dec_stop [] (by simp) 2 (Or.inl rfl) (cells02 k ++ 2 :: 2 :: l) (1 :: sw a :: r)
  simp only [List.nil_append, List.length_nil, List.reverse_nil, List.map_nil] at h2
  rw [show (0 : Nat) + 4 = 4 from rfl] at h2
  simp only [List.cons_append]
  rw [h2]
  simp only [Option.bind_some, sw]
  exact rule_41 _ _

/--
**Left overflow (counter exhausted).**

If every digit between the head and the marker `.22` is `22` or `23` — i.e. the
left counter has no digit `02` or `03` to borrow from, so a decrement would
"underflow" — the sweep runs all the way to the marker, turns around on the
first blank cell, and the marker is rebuilt one cell further to the left.  The
machine does **not** halt: this is exactly the informal rule
`.22 <B  -->  .22 B> 4`, and it is what makes the normal-stage left overflow
harmless.
-/
theorem left_overflow_general (S : List Sym) (hS : ∀ x ∈ S, Sweepable x)
    (a : Sym) (ha : Sweepable a) (r : List Sym) :
    run ⟨S ++ [2, 2], St.B, a :: r⟩ (S.length + 5)
      = some ⟨[2, 2], St.B, 4 :: (S.reverse.map sw) ++ sw a :: r⟩ := by
  have hS' : ∀ x ∈ S ++ [(2 : Sym), 2], Sweepable x := by
    intro x hx
    rcases List.mem_append.1 hx with hx | hx
    · exact hS x hx
    · rcases List.mem_cons.1 hx with rfl | hx
      · exact Or.inl rfl
      · rcases List.mem_cons.1 hx with rfl | hx
        · exact Or.inl rfl
        · simp at hx
  have h1 := sweep (S ++ [(2 : Sym), 2]) hS' a ha [] r
  have hlen : (S ++ [(2 : Sym), 2]).length + 1 = S.length + 3 := by simp
  have hnil : S ++ [(2 : Sym), 2] ++ ([] : List Sym) = S ++ [2, 2] := by simp
  rw [hlen, hnil] at h1
  have hsplit : S.length + 5 = (S.length + 3) + 2 := by omega
  rw [hsplit, run_add, h1]
  simp only [Option.bind_some, hd_nil, List.tail_nil]
  have hrev : ((S ++ [(2 : Sym), 2]).reverse.map sw) = 4 :: 4 :: (S.reverse.map sw) := by
    simp [sw]
  rw [hrev]
  exact rule_04 [] _

/-! ## The machine from the blank tape -/

/-- After 50 steps the machine is in the configuration `.22 B> 44 44 24 04 1.`
(equivalently `.22 B> 4 44 42 40 41.`), the starting point of the informal
analysis. -/
theorem run_init_50 : run init 50 = some ⟨[2, 2], St.B, [4, 4, 4, 4, 2, 4, 0, 4, 1]⟩ := rfl

end SOC
