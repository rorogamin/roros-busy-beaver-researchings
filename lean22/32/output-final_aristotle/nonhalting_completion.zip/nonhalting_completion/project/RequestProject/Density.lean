import Mathlib
import RequestProject.NormalPhase

/-!
# A density criterion for the reset phase

`RequestProject.ResetPhase` reduces the safety of a reset phase to the decidable
arithmetic test `SafeRun g L`, which follows the gap of the counter block by
block:

```
44 : g ↦ 2g+1     04 : g ↦ 2g      24 : g ↦ 2g-1      14 : g ↦ ≈ 2g/3
```

The test has to be run on a concrete sequence.  This file replaces it, for
large counters, by a **density** condition, which is a statement about the
*shape* of the block sequence alone: the expensive blocks `14` — the only ones
that shrink the counter — must not be too frequent.

Fix a threshold `T ≥ 105`.  As long as the gap stays above `T`, one block
multiplies it by at least

```
afac T = (2T-1)/T  ≈ 2      (blocks 44, 04, 24)
bfac T = (2T-19)/3T ≈ 2/3   (block 14)
```

(`wfac_mul_le_gnext`), so the gap never falls below `T` as long as the product
of these factors over every prefix stays at least `1` (`growth_bound`).  If in
every prefix the blocks `14` satisfy `p · k ≤ q · (n - k)` — a density of at
most `q / (p + q)` — that product is at least `1` as soon as
`afac T ^ p * bfac T ^ q ≥ 1` (`one_le_gwT`), and the whole reset phase is safe
(`safeRun_of_dense`).

Two instances are worked out:

* `T = 105`, `p = q = 1`: a density of at most `1/2` of blocks `14` in every
  prefix;
* `T = 300`, `p = 2`, `q = 3`: a density of at most `3/5`.

The true critical density is `log 2 / log 3 ≈ 0.6309`, which the factors
`2, 2/3` approach as `T → ∞`; the loss comes from the rounding of the
mixed-radix arithmetic.  The observed density in the block sequences the machine
actually releases is about `0.21`, so the criterion has a wide margin —
but proving that it always holds is exactly what is still missing.

`neverHalts_of_evDense` states what is left of the halting problem in these
terms: the machine never halts as soon as *every* block sequence it releases
has this shape.
-/

namespace SOC

/-! ## The weight of a block -/

/-- The guaranteed growth factor of a gap `≥ T` at a block `44`, `04` or `24`. -/
def afac (T : ℕ) : ℚ := (2 * T - 1) / T

/-- The guaranteed growth factor of a gap `≥ T` at a block `14`. -/
def bfac (T : ℕ) : ℚ := (2 * T - 19) / (3 * T)

theorem afac_pos {T : ℕ} (hT : 105 ≤ T) : 0 < afac T := by
  have h : (105 : ℚ) ≤ (T : ℚ) := by exact_mod_cast hT
  unfold afac
  apply div_pos <;> linarith

theorem bfac_pos {T : ℕ} (hT : 105 ≤ T) : 0 < bfac T := by
  have h : (105 : ℚ) ≤ (T : ℚ) := by exact_mod_cast hT
  unfold bfac
  apply div_pos <;> linarith

theorem bfac_le_one {T : ℕ} (hT : 105 ≤ T) : bfac T ≤ 1 := by
  have h : (105 : ℚ) ≤ (T : ℚ) := by exact_mod_cast hT
  unfold bfac
  rw [div_le_one (by linarith)]
  linarith

/-- The growth factor of one block. -/
def wfac (T : ℕ) (x : Sym) : ℚ := if x = 1 then bfac T else afac T

theorem wfac_pos {T : ℕ} (hT : 105 ≤ T) (x : Sym) : 0 < wfac T x := by
  unfold wfac
  split
  · exact bfac_pos hT
  · exact afac_pos hT

/-- The product of the growth factors of a sequence of blocks. -/
def gw (T : ℕ) : List Sym → ℚ
  | [] => 1
  | x :: L => wfac T x * gw T L

@[simp] theorem gw_nil (T : ℕ) : gw T [] = 1 := rfl

@[simp] theorem gw_cons (T : ℕ) (x : Sym) (L : List Sym) :
    gw T (x :: L) = wfac T x * gw T L := rfl

theorem gw_pos {T : ℕ} (hT : 105 ≤ T) (L : List Sym) : 0 < gw T L := by
  induction L with
  | nil => norm_num
  | cons x L ih => exact mul_pos (wfac_pos hT x) ih

/-- **One block, in multiplicative form.**  A counter whose gap is at least `T`
comes out of a block with a gap at least `wfac T x` times as large. -/
theorem wfac_mul_le_gnext {T g : ℕ} (hT : 105 ≤ T) (hg : T ≤ g) (x : Sym) :
    wfac T x * (g : ℚ) ≤ (gnext g x : ℚ) := by
  have hTQ : (105 : ℚ) ≤ (T : ℚ) := by exact_mod_cast hT
  have hgQ : (T : ℚ) ≤ (g : ℚ) := by exact_mod_cast hg
  have hg105 : 105 ≤ g := le_trans hT hg
  have hg105Q : (105 : ℚ) ≤ (g : ℚ) := by exact_mod_cast hg105
  have hTpos : (0 : ℚ) < (T : ℚ) := by linarith
  -- the two factors, cleared of denominators
  have ha : afac T * (g : ℚ) ≤ 2 * (g : ℚ) - 1 := by
    rw [afac, div_mul_eq_mul_div, div_le_iff₀ hTpos]
    nlinarith
  have hb : bfac T * (g : ℚ) ≤ (2 * (g : ℚ) - 19) / 3 := by
    rw [bfac, div_mul_eq_mul_div, div_le_div_iff₀ (by linarith) (by norm_num)]
    nlinarith
  rcases sym_cases x with rfl | rfl | rfl | rfl | rfl
  · -- block `04` : `g ↦ 2g`
    rw [show wfac T 0 = afac T from rfl, gnext_0]
    push_cast
    linarith
  · -- block `14` : `g ↦ ≈ 2g/3`
    have hnat' : 2 * g ≤ 3 * (2 * ((2 * (g / 2 - 4)) / 3) + 1) + 19 := by omega
    have hQ : (2 : ℚ) * (g : ℚ) ≤
        3 * ((2 * ((2 * (g / 2 - 4)) / 3) + 1 : ℕ) : ℚ) + 19 := by
      exact_mod_cast hnat'
    rw [show wfac T 1 = bfac T from rfl, gnext_1]
    linarith
  · -- block `24` : `g ↦ 2g-1`
    have hnat : (2 * g - 1 : ℕ) = 2 * g - 1 := by omega
    have hQ : ((2 * g - 1 : ℕ) : ℚ) = 2 * (g : ℚ) - 1 := by
      have : (1 : ℕ) ≤ 2 * g := by omega
      push_cast [Nat.cast_sub this]
      ring
    rw [show wfac T 2 = afac T from rfl, gnext_2, hQ]
    linarith
  · -- `3` is not a block label, but the bound holds for `gnext` anyway
    rw [show wfac T 3 = afac T from rfl, gnext_3]
    push_cast
    linarith
  · -- block `44` : `g ↦ 2g+1`
    rw [show wfac T 4 = afac T from rfl, gnext_4]
    push_cast
    linarith

/-! ## The growth criterion -/

/--
**The reset phase is safe if the growth factors keep the gap above `T`.**

If the counter starts with gap `g` and, for every prefix `p` of the block
sequence, the product of the growth factors of `p` keeps `g` at least `T`, then
the whole sequence is safe and the gap at the end is at least `g * gw T L`.
-/
theorem growth_bound {T : ℕ} (hT : 105 ≤ T) : ∀ {g : ℕ} {L : List Sym},
    (∀ p, p <+: L → (T : ℚ) ≤ (g : ℚ) * gw T p) →
      SafeRun g L ∧ (g : ℚ) * gw T L ≤ (gfold g L : ℚ)
  | g, [], _ => by
      refine ⟨trivial, ?_⟩
      simp [gfold]
  | g, x :: L, h => by
      have hTg : (T : ℚ) ≤ (g : ℚ) := by
        have := h [] List.nil_prefix
        simpa using this
      have hg : T ≤ g := by exact_mod_cast hTg
      have hg105 : 105 ≤ g := le_trans hT hg
      -- one block
      have hstep : wfac T x * (g : ℚ) ≤ (gnext g x : ℚ) := wfac_mul_le_gnext hT hg x
      -- the hypothesis transfers to the tail
      have htail : ∀ p, p <+: L → (T : ℚ) ≤ ((gnext g x : ℕ) : ℚ) * gw T p := by
        intro p hp
        have hxp : x :: p <+: x :: L := by
          obtain ⟨t, ht⟩ := hp
          exact ⟨t, by simp [← ht]⟩
        have hpre := h (x :: p) hxp
        rw [gw_cons] at hpre
        have hp0 : (0 : ℚ) < gw T p := gw_pos hT p
        calc (T : ℚ) ≤ (g : ℚ) * (wfac T x * gw T p) := hpre
          _ = (wfac T x * (g : ℚ)) * gw T p := by ring
          _ ≤ (gnext g x : ℚ) * gw T p := mul_le_mul_of_nonneg_right hstep (le_of_lt hp0)
      obtain ⟨hsafe, hgap⟩ := growth_bound hT htail
      refine ⟨⟨fun _ => by omega, fun _ => by omega, hsafe⟩, ?_⟩
      have hL0 : (0 : ℚ) < gw T L := gw_pos hT L
      calc (g : ℚ) * gw T (x :: L) = (wfac T x * (g : ℚ)) * gw T L := by rw [gw_cons]; ring
        _ ≤ (gnext g x : ℚ) * gw T L := mul_le_mul_of_nonneg_right hstep (le_of_lt hL0)
        _ ≤ (gfold (gnext g x) L : ℚ) := hgap
        _ = (gfold g (x :: L) : ℚ) := by rw [gfold]

/-! ## Density -/

/-- The number of blocks `14` in a sequence. -/
def ones (L : List Sym) : ℕ := L.count 1

@[simp] theorem ones_nil : ones [] = 0 := rfl

theorem ones_cons_one (L : List Sym) : ones (1 :: L) = ones L + 1 := by
  simp [ones]

theorem ones_cons_ne {x : Sym} (hx : x ≠ 1) (L : List Sym) : ones (x :: L) = ones L := by
  simp [ones, hx]

theorem ones_le_length (L : List Sym) : ones L ≤ L.length := List.count_le_length

/-- The product of the growth factors, in terms of the number of blocks `14`. -/
theorem gw_eq_pow (T : ℕ) (L : List Sym) :
    gw T L = bfac T ^ ones L * afac T ^ (L.length - ones L) := by
  induction L with
  | nil => simp
  | cons x L ih =>
      have hle := ones_le_length L
      by_cases hx : x = 1
      · subst hx
        rw [gw_cons, ih, show wfac T 1 = bfac T from rfl, ones_cons_one]
        simp only [List.length_cons]
        rw [show L.length + 1 - (ones L + 1) = L.length - ones L by omega, pow_succ]
        ring
      · rw [gw_cons, ih, show wfac T x = afac T from by unfold wfac; rw [if_neg hx],
          ones_cons_ne hx]
        simp only [List.length_cons]
        rw [show L.length + 1 - ones L = (L.length - ones L) + 1 by omega, pow_succ]
        ring

/--
**A sequence whose blocks `14` are rare enough does not shrink the counter.**

`p · k ≤ q · (n - k)` is a density of at most `q / (p + q)` of blocks `14`; the
hypothesis `1 ≤ afac T ^ p * bfac T ^ q` is what makes that density admissible.
-/
theorem one_le_gw {T p q : ℕ} (hT : 105 ≤ T) (hp : 1 ≤ p)
    (hratio : 1 ≤ afac T ^ p * bfac T ^ q) {L : List Sym}
    (h : p * ones L ≤ q * (L.length - ones L)) : 1 ≤ gw T L := by
  set k := ones L with hk
  set m := L.length - ones L with hm
  have hb1 : bfac T ≤ 1 := bfac_le_one hT
  have hb0 : 0 < bfac T := bfac_pos hT
  have ha0 : 0 < afac T := afac_pos hT
  have hx0 : 0 < gw T L := gw_pos hT L
  have hval : gw T L = bfac T ^ k * afac T ^ m := gw_eq_pow T L
  -- raise to the power `p`
  have hpow : (1 : ℚ) ≤ (gw T L) ^ p := by
    have h1 : (bfac T) ^ (p * k) ≥ (bfac T) ^ (q * m) :=
      pow_le_pow_of_le_one (le_of_lt hb0) hb1 h
    calc (1 : ℚ) ≤ (afac T ^ p * bfac T ^ q) ^ m := one_le_pow₀ hratio
      _ = afac T ^ (p * m) * bfac T ^ (q * m) := by
          rw [mul_pow, ← pow_mul, ← pow_mul]
      _ ≤ afac T ^ (p * m) * bfac T ^ (p * k) := by
          exact mul_le_mul_of_nonneg_left h1 (le_of_lt (pow_pos ha0 _))
      _ = (bfac T ^ k * afac T ^ m) ^ p := by
          rw [mul_pow, ← pow_mul, ← pow_mul]
          ring_nf
      _ = (gw T L) ^ p := by rw [hval]
  by_contra hlt
  push_neg at hlt
  have : (gw T L) ^ p < 1 := pow_lt_one₀ (le_of_lt hx0) hlt (by omega)
  linarith

/-- **The density condition**: in every prefix of `L`, the blocks `14` make up at
most a fraction `q / (p + q)` of the blocks. -/
def Dense (p q : ℕ) (L : List Sym) : Prop :=
  ∀ s ∈ L.inits, p * ones s ≤ q * (s.length - ones s)

instance (p q : ℕ) : DecidablePred (Dense p q) := fun L =>
  inferInstanceAs (Decidable (∀ s ∈ L.inits, p * ones s ≤ q * (s.length - ones s)))

theorem Dense.prefix {p q : ℕ} {L s : List Sym} (h : Dense p q L) (hs : s <+: L) :
    p * ones s ≤ q * (s.length - ones s) :=
  h s ((List.mem_inits _ _).2 hs)

/--
**The density criterion.**  A counter with gap at least `T` survives a block
sequence of density at most `q / (p + q)`, and comes out with a gap at least as
large as it went in.
-/
theorem safeRun_of_dense {T p q : ℕ} (hT : 105 ≤ T) (hp : 1 ≤ p)
    (hratio : 1 ≤ afac T ^ p * bfac T ^ q) {g : ℕ} (hg : T ≤ g) {M : List Sym}
    (hM : Dense p q M) : SafeRun g M ∧ g ≤ gfold g M := by
  have hgQ : (T : ℚ) ≤ (g : ℚ) := by exact_mod_cast hg
  have hyp : ∀ s, s <+: M → (T : ℚ) ≤ (g : ℚ) * gw T s := by
    intro s hs
    have h1 : (1 : ℚ) ≤ gw T s := one_le_gw hT hp hratio (hM.prefix hs)
    nlinarith [gw_pos hT s]
  obtain ⟨hsafe, hgap⟩ := growth_bound hT hyp
  refine ⟨hsafe, ?_⟩
  have h1 : (1 : ℚ) ≤ gw T M := one_le_gw hT hp hratio (hM.prefix (List.prefix_refl M))
  have hgpos : (0 : ℚ) ≤ (g : ℚ) := by positivity
  have : (g : ℚ) ≤ (gfold g M : ℚ) := by nlinarith
  exact_mod_cast this

/-! ### A linear-time test for the density condition

`Dense` quantifies over all prefixes, so deciding it as stated costs a
quadratic number of operations.  `denseB` performs the same check in one pass,
keeping a running count of the blocks `14`.
-/

/-- One pass of the density test: `k` blocks `14` among the `n` blocks already
seen. -/
def denseGo (p q k n : ℕ) : List Sym → Bool
  | [] => true
  | x :: L =>
      let k' := k + (if x = 1 then 1 else 0)
      let n' := n + 1
      p * k' ≤ q * (n' - k') && denseGo p q k' n' L

/-- The linear-time density test. -/
def denseB (p q : ℕ) (L : List Sym) : Bool := denseGo p q 0 0 L

theorem denseGo_sound {p q : ℕ} : ∀ {L : List Sym} {k n : ℕ}, p * k ≤ q * (n - k) →
    denseGo p q k n L = true →
      ∀ s ∈ L.inits, p * (k + ones s) ≤ q * ((n + s.length) - (k + ones s))
  | [], k, n, h0, _, s, hs => by
      simp only [List.inits, List.mem_singleton] at hs
      subst hs
      simpa using h0
  | x :: L, k, n, h0, hgo, s, hs => by
      rw [denseGo] at hgo
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hgo
      obtain ⟨hhead, htail⟩ := hgo
      have hs' : s <+: x :: L := (List.mem_inits _ _).1 hs
      match s, hs' with
      | [], _ => simpa using h0
      | y :: t, hpre =>
          obtain ⟨u, hu⟩ := hpre
          simp only [List.cons_append, List.cons.injEq] at hu
          obtain ⟨rfl, hu2⟩ := hu
          have ht : t ∈ L.inits := (List.mem_inits _ _).2 ⟨u, hu2⟩
          have hrec := denseGo_sound hhead htail t ht
          have e2 : n + (t.length + 1) = n + 1 + t.length := by omega
          by_cases hx : y = 1
          · subst hx
            rw [ones_cons_one, List.length_cons, e2,
              show k + (ones t + 1) = k + 1 + ones t by omega]
            exact hrec
          · simp only [if_neg hx, Nat.add_zero] at hrec
            rw [ones_cons_ne hx, List.length_cons, e2]
            exact hrec

/-- **The linear-time test is sound.** -/
theorem dense_of_denseB {p q : ℕ} {L : List Sym} (h : denseB p q L = true) : Dense p q L := by
  intro s hs
  have := denseGo_sound (p := p) (q := q) (k := 0) (n := 0) (by simp) h s hs
  simpa using this

/-! ## Splitting a sequence -/

theorem gfold_append (g : ℕ) (A B : List Sym) : gfold g (A ++ B) = gfold (gfold g A) B := by
  induction A generalizing g with
  | nil => rfl
  | cons x A ih => simpa [gfold] using ih (gnext g x)

theorem safeRun_append {g : ℕ} {A B : List Sym} (hA : SafeRun g A)
    (hB : SafeRun (gfold g A) B) : SafeRun g (A ++ B) := by
  induction A generalizing g with
  | nil => exact hB
  | cons x A ih =>
      obtain ⟨p1, p2, p3⟩ := hA
      exact ⟨p1, p2, ih p3 hB⟩

/--
**The criterion in the form the machine needs.**

A block sequence which first builds a gap of at least `T` — checked by the exact
recurrence on its leading part `A` — and continues with a part `M` of density at
most `q / (p + q)` is safe, and the counter it builds has gap at least `T`.
-/
theorem safeRun_append_dense {T p q : ℕ} (hT : 105 ≤ T) (hp : 1 ≤ p)
    (hratio : 1 ≤ afac T ^ p * bfac T ^ q) {A M : List Sym} (hA : SafeRun 1 A)
    (hgA : T ≤ gfold 1 A) (hM : Dense p q M) :
    SafeRun 1 (A ++ M) ∧ T ≤ gfold 1 (A ++ M) := by
  obtain ⟨hs, hg⟩ := safeRun_of_dense hT hp hratio hgA hM
  refine ⟨safeRun_append hA hs, ?_⟩
  rw [gfold_append]
  omega

/-! ## What is left of the halting problem -/

/--
A block sequence is *eventually sparse* (for the threshold `T` and the density
`q / (p + q)`) if it splits into a leading part that builds a gap of at least
`T` and a tail in which the blocks `14` never exceed that density in a prefix.
-/
def EvDense (T p q : ℕ) (L : List Sym) : Prop :=
  ∃ A M, L = A ++ M ∧ SafeRun 1 A ∧ T ≤ gfold 1 A ∧ Dense p q M

theorem EvDense.safe {T p q : ℕ} (hT : 105 ≤ T) (hp : 1 ≤ p)
    (hratio : 1 ≤ afac T ^ p * bfac T ^ q) {L : List Sym} (h : EvDense T p q L) :
    SafeRun 1 L ∧ T ≤ gfold 1 L := by
  obtain ⟨A, M, rfl, hA, hgA, hM⟩ := h
  exact safeRun_append_dense hT hp hratio hA hgA hM

/-! ### Starting the chain of revolutions anywhere -/

/--
**Non-halting from an invariant on block sequences, started at any reachable
reset phase.**  This is `neverHalts_of_phase_invariant` with the first block
sequence replaced by any sequence the machine is known to reach — the criteria
below need a counter that is already large, which the machine only has from its
second revolution on.
-/
theorem neverHalts_of_phase_invariant_from (P : List Sym → Prop) (L₀ : List Sym)
    (hreach : init ⟶* enc (phaseStart L₀)) (h0 : P L₀)
    (hsafe : ∀ L, P L → (∀ x ∈ L, Label x) ∧ SafeRun 1 L ∧ 9 ≤ gfold 1 L)
    (hclosed : ∀ L L', P L → SuperStep L L' → P L') : NeverHalts := by
  have hnext : ∀ L : { L : List Sym // P L }, ∃ L' : { L : List Sym // P L },
      MPlus (phaseStart L.1) (phaseStart L'.1) := by
    rintro ⟨L, hP⟩
    obtain ⟨hlab, hsr, h9⟩ := hsafe L hP
    obtain ⟨L', hL', hplus⟩ := super_cycle hlab hsr h9
    exact ⟨⟨L', hclosed L L' hP ⟨hL', hplus⟩⟩, hplus⟩
  let nxt : { L : List Sym // P L } → { L : List Sym // P L } := fun L =>
    Classical.choose (hnext L)
  have hnxt : ∀ L, MPlus (phaseStart L.1) (phaseStart (nxt L).1) := fun L =>
    Classical.choose_spec (hnext L)
  let f : Nat → { L : List Sym // P L } := fun n =>
    Nat.rec (⟨L₀, h0⟩ : { L : List Sym // P L }) (fun _ L => nxt L) n
  have hchain : ∀ i, MPlus (phaseStart (f i).1) (phaseStart (f (i + 1)).1) := fun i => hnxt (f i)
  have hforever : ∀ n, (run (enc (phaseStart (f 0).1)) n).isSome := by
    intro n
    obtain ⟨N, hN, hrun⟩ := plus_chain_reaches (fun i => phaseStart (f i).1) hchain n
    exact isSome_of_run_le (by rw [hrun]; rfl) hN
  exact forever_of_reaches hreach hforever

/--
**Non-halting from the density condition.**

If every block sequence the machine releases from some reachable reset phase on
is eventually sparse, then `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never halts.
Together with `neverHalts_of_phase_invariant` this is the whole halting
question, stated as a property of the *shape* of the released sequences: the
expensive blocks `14` must not exceed the density `q / (p + q)` in any prefix,
once the counter is large.
-/
theorem neverHalts_of_evDense {T p q : ℕ} (hT : 105 ≤ T) (hp : 1 ≤ p)
    (hratio : 1 ≤ afac T ^ p * bfac T ^ q) (L₀ : List Sym)
    (hreach : init ⟶* enc (phaseStart L₀)) (hlab₀ : ∀ x ∈ L₀, Label x)
    (h0 : EvDense T p q L₀)
    (hclosed : ∀ L L', (∀ x ∈ L, Label x) → EvDense T p q L → SuperStep L L' →
      EvDense T p q L') : NeverHalts := by
  refine neverHalts_of_phase_invariant_from (fun L => (∀ x ∈ L, Label x) ∧ EvDense T p q L)
    L₀ hreach ⟨hlab₀, h0⟩ ?_ ?_
  · rintro L ⟨hlab, hd⟩
    obtain ⟨hs, hgT⟩ := (hd.safe hT hp hratio)
    exact ⟨hlab, hs, by omega⟩
  · rintro L L' ⟨hlab, hd⟩ hstep
    exact ⟨hstep.1, hclosed L L' hlab hd hstep⟩

/-! ## Two admissible densities -/

/-- With the threshold `105`, a density of `1/2` is admissible. -/
theorem ratio_half : (1 : ℚ) ≤ afac 105 ^ 1 * bfac 105 ^ 1 := by
  norm_num [afac, bfac]

/-- With the threshold `255` — the gap that seven leading blocks `44` build — a
density of `3/5` is admissible. -/
theorem ratio_three_fifths_255 : (1 : ℚ) ≤ afac 255 ^ 2 * bfac 255 ^ 3 := by
  norm_num [afac, bfac]

/-- With the threshold `300`, a density of `3/5` is admissible — close to the
critical density `log 2 / log 3 ≈ 0.6309`. -/
theorem ratio_three_fifths : (1 : ℚ) ≤ afac 300 ^ 2 * bfac 300 ^ 3 := by
  norm_num [afac, bfac]

/--
**The half-density criterion.**  A counter with gap at least `105` survives any
block sequence in which at most half of the blocks of every prefix are `14`.
-/
theorem safeRun_of_halfDense {g : ℕ} (hg : 105 ≤ g) {M : List Sym} (hM : Dense 1 1 M) :
    SafeRun g M ∧ g ≤ gfold g M :=
  safeRun_of_dense (le_refl 105) (le_refl 1) ratio_half hg hM

/-- The first sequence the machine releases satisfies the half-density criterion:
its first six blocks already build a gap of `122`, and the single block left over
is a `24`. -/
theorem firstBlocks_evDense : EvDense 105 1 1 firstBlocks :=
  ⟨[4, 4, 4, 0, 4, 0], [2], rfl, by decide, by decide, by decide⟩

/--
**Non-halting from the half-density condition.**  If every block sequence the
machine releases is, after a leading part building a gap of `105`, of density at
most `1/2` in blocks `14`, the machine never halts.
-/
theorem neverHalts_of_evHalfDense
    (hclosed : ∀ L L', (∀ x ∈ L, Label x) → EvDense 105 1 1 L → SuperStep L L' →
      EvDense 105 1 1 L') : NeverHalts :=
  neverHalts_of_evDense (le_refl 105) (le_refl 1) ratio_half firstBlocks
    (reaches_of_run run_init_306) firstBlocks_labels firstBlocks_evDense hclosed

end SOC
