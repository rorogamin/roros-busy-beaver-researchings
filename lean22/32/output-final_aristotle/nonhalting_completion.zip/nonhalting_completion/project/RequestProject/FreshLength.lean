import Mathlib
import RequestProject.Shape

/-!
# How much fresh material one revolution creates

The fresh blocks of a released sequence are the digits the normal phase pushes,
one per cycle, plus the two the junction creates.  Each cycle spends one unit of
the counter's capacity and then divides what is left by `3/2`
(`gap (03 :: inc w) = (2 · gap w − 1) / 3`), so a counter of capacity `g`
supports at most about `log_{3/2} g` cycles:

> **`normalF_cycles`** — if the normal phase starting from the counter `w`
> releases the blocks `L`, the number `m` of digits it pushes satisfies
> `3 ^ m ≤ 2 ^ m · (3 · gap w + 1)`.

This is the quantitative form of "the sequences roughly double in length at
every revolution", and it is what makes the density question delicate: the fresh
part is exactly as long as the counter's capacity measured in base `3/2`, so if
*all* of it consisted of the expensive blocks `14` — each of which divides the
capacity by about `3/2` — the next counter would be back where it started.
-/

namespace SOC

/-- **The normal phase pushes at most `log_{3/2} (3 · gap w + 1)` digits.** -/
theorem normalF_cycles : ∀ {w : List LD} {acc L : List Sym}, normalF w acc = some L →
    ∃ m, L.length = acc.length + w.length + m ∧ 3 ^ m ≤ 2 ^ m * (3 * gap w + 1)
  | w, acc, L, h => by
      rw [normalF] at h
      cases hone : addT w 1 with
      | none =>
          rw [hone] at h
          simp only at h
          obtain ⟨S, hL, hS⟩ := ovfF_pat h
          have hSlen : S.length = w.length := by
            have := congrArg List.length hS
            simpa using this
          refine ⟨0, ?_, by simp⟩
          rw [hL]
          simp [hSlen]
          omega
      | some w' =>
          rw [hone] at h
          simp only at h
          have hinc : Inc w w' := addT_one_inc hone
          have hlt : gap (LD.dB :: w') < gap w := gap_normal_cycle_lt hinc hinc.gap_pos
          have hgw : gap w = gap w' + 1 := hinc.gap_eq
          have hlen : w'.length = w.length := addT_length hone
          obtain ⟨m, hm, hbound⟩ := normalF_cycles h
          refine ⟨m + 1, by simp [hlen] at hm ⊢; omega, ?_⟩
          -- one cycle divides the remaining capacity by `3/2`
          have hg1 : 3 * gap (LD.dB :: w') ≤ 2 * gap w - 1 := by
            simp only [gap_dB]
            omega
          have hstep : 3 * (3 * gap (LD.dB :: w') + 1) ≤ 2 * (3 * gap w + 1) := by
            have : 0 < gap w := hinc.gap_pos
            omega
          calc (3 : ℕ) ^ (m + 1) = 3 * 3 ^ m := by ring
            _ ≤ 3 * (2 ^ m * (3 * gap (LD.dB :: w') + 1)) := by
                exact Nat.mul_le_mul_left 3 hbound
            _ = 2 ^ m * (3 * (3 * gap (LD.dB :: w') + 1)) := by ring
            _ ≤ 2 ^ m * (2 * (3 * gap w + 1)) := Nat.mul_le_mul_left _ hstep
            _ = 2 ^ (m + 1) * (3 * gap w + 1) := by ring
  termination_by w => gap w

end SOC
