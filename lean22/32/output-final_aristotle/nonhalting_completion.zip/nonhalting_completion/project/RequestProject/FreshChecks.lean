import Mathlib
import RequestProject.Fresh
import RequestProject.Inherit

/-!
# The fresh-material criterion along the machine's own revolutions

`RequestProject.Fresh` reduces the halting question to `FreshDense`: at every
revolution, the freshly created blocks must keep the blocks `14` below the
density `3/5`, counted together with the whole previous sequence.

Here that condition is checked, inside Lean, on the revolutions the machine
really performs: the first ten transitions all satisfy it, with a wide margin
(the fresh parts carry about a third of blocks `14`, the inherited parts about a
fifth).
-/

namespace SOC

/-- One pass of the fresh-material test: `c` blocks `14` and `len0` blocks are
already paid for, `k` blocks `14` among the `i` fresh blocks seen so far. -/
def freshGo (c len0 k i : ℕ) : List Sym → Bool
  | [] => true
  | x :: M =>
      let k' := k + (if x = 1 then 1 else 0)
      let i' := i + 1
      (5 * (c + k') ≤ 3 * (len0 + i')) && freshGo c len0 k' i' M

theorem freshGo_sound {c len0 : ℕ} : ∀ {M : List Sym} {k i : ℕ},
    5 * (c + k) ≤ 3 * (len0 + i) → freshGo c len0 k i M = true →
      ∀ v, v <+: M → 5 * (c + k + ones v) ≤ 3 * (len0 + i + v.length)
  | [], k, i, h0, _, v, hv => by
      rw [List.prefix_nil.1 hv]
      simpa using h0
  | x :: M, k, i, h0, hgo, v, hv => by
      rw [freshGo] at hgo
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hgo
      obtain ⟨hhead, htail⟩ := hgo
      match v, hv with
      | [], _ => simpa using h0
      | y :: t, hpre =>
          obtain ⟨u, hu⟩ := hpre
          simp only [List.cons_append, List.cons.injEq] at hu
          obtain ⟨rfl, hu2⟩ := hu
          have hrec := freshGo_sound hhead htail t ⟨u, hu2⟩
          by_cases hy : y = 1
          · subst hy
            have hrec' : 5 * (c + (k + 1) + ones t) ≤ 3 * (len0 + (i + 1) + t.length) := by
              simpa using hrec
            rw [ones_cons_one, List.length_cons]
            omega
          · have hrec' : 5 * (c + k + ones t) ≤ 3 * (len0 + (i + 1) + t.length) := by
              simpa [hy] using hrec
            rw [ones_cons_ne hy, List.length_cons]
            omega

/-- The decidable form of `FreshDense`. -/
def freshDenseB (L L' : List Sym) : Bool :=
  (5 * ones (L.drop 7) ≤ 3 * (L.drop 7).length) &&
    freshGo (ones (L.drop 7)) (L.drop 7).length 0 0 (L'.drop L.length)

/-- **The one-pass test is sound.** -/
theorem freshDense_of_freshDenseB {L L' : List Sym} (h : freshDenseB L L' = true) :
    FreshDense L L' := by
  rw [freshDenseB, Bool.and_eq_true, decide_eq_true_eq] at h
  obtain ⟨h0, hgo⟩ := h
  intro v hv
  have := freshGo_sound (c := ones (L.drop 7)) (len0 := (L.drop 7).length)
    (k := 0) (i := 0) (by simpa using h0) hgo v hv
  rw [ones_append, List.length_append]
  simpa using this

/-! ## The exact condition on the fresh material -/

/-- A tail-recursive form of `SafeRun`, for the long sequences the machine
releases. -/
def safeRunB : ℕ → List Sym → Bool
  | _, [] => true
  | g, x :: L =>
      (if x = 1 then decide (8 ≤ g) else true) &&
        (if x = 2 then decide (1 ≤ g) else true) &&
        safeRunB (gnext g x) L

theorem safeRun_of_safeRunB : ∀ {g : ℕ} {L : List Sym}, safeRunB g L = true → SafeRun g L
  | _, [], _ => trivial
  | g, x :: L, h => by
      rw [safeRunB, Bool.and_eq_true, Bool.and_eq_true] at h
      obtain ⟨⟨h1, h2⟩, h3⟩ := h
      refine ⟨fun hx => ?_, fun hx => ?_, safeRun_of_safeRunB h3⟩
      · rw [if_pos hx] at h1
        exact of_decide_eq_true h1
      · rw [if_pos hx] at h2
        exact of_decide_eq_true h2

/-- The decidable form of `FreshSafe`. -/
def freshSafeB (L L' : List Sym) : Bool :=
  safeRunB (gfold 1 (L'.take L.length)) (L'.drop L.length) &&
    decide (9 ≤ gfold (gfold 1 (L'.take L.length)) (L'.drop L.length))

theorem freshSafe_of_freshSafeB {L L' : List Sym} (h : freshSafeB L L' = true) :
    FreshSafe L L' := by
  rw [freshSafeB, Bool.and_eq_true, decide_eq_true_eq] at h
  exact ⟨safeRun_of_safeRunB h.1, h.2⟩

/-- The two tests, applied to the machine's first `N` revolutions. -/
def freshOK (N : ℕ) : Bool :=
  (List.range N).all fun n =>
    match revIter n with
    | some L =>
        match revolutionF L with
        | some L' => freshDenseB L L' && freshSafeB L L'
        | none => false
    | none => false

/-- **The first ten revolutions of the machine satisfy both fresh-material
criteria.**  Checked by compiled evaluation inside Lean. -/
theorem freshOK_10 : freshOK 10 = true := by native_decide

/-- **Every one of the machine's first ten revolutions creates fresh material of
admissible density.** -/
theorem revIter_freshDense {n : ℕ} (hn : n < 10) {L L' : List Sym}
    (hL : revIter n = some L) (hL' : revIter (n + 1) = some L') : FreshDense L L' := by
  have hall := freshOK_10
  rw [freshOK, List.all_eq_true] at hall
  have hmem := hall n (List.mem_range.2 hn)
  rw [hL] at hmem
  have hrev : revolutionF L = some L' := by
    rw [revIter, hL] at hL'
    simpa using hL'
  have h2 : (match revolutionF L with
      | some L' => freshDenseB L L' && freshSafeB L L'
      | none => false) = true := hmem
  rw [hrev, Bool.and_eq_true] at h2
  exact freshDense_of_freshDenseB h2.1

/-- **The freshly created blocks of the machine's first ten revolutions are safe
for the counter the inherited blocks have built.** -/
theorem revIter_freshSafe {n : ℕ} (hn : n < 10) {L L' : List Sym}
    (hL : revIter n = some L) (hL' : revIter (n + 1) = some L') : FreshSafe L L' := by
  have hall := freshOK_10
  rw [freshOK, List.all_eq_true] at hall
  have hmem := hall n (List.mem_range.2 hn)
  rw [hL] at hmem
  have hrev : revolutionF L = some L' := by
    rw [revIter, hL] at hL'
    simpa using hL'
  have h2 : (match revolutionF L with
      | some L' => freshDenseB L L' && freshSafeB L L'
      | none => false) = true := hmem
  rw [hrev, Bool.and_eq_true] at h2
  exact freshSafe_of_freshSafeB h2.2

end SOC
