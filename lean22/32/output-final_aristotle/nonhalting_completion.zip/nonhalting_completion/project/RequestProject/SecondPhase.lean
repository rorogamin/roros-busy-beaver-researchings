import RequestProject.NormalPhase

/-!
# The second revolution of the real machine

A second completely verified instance of the theory, and a check of the
super-cycle picture of `RequestProject.NormalPhase`.

After 3139 steps the machine is at the start of its second reset phase: the tape
is

```
.22 B> 44 · 44 44 44 44 44 44 44 04 24 04 04 04 24 14 24 14 04 · 1.
```

— an empty counter, the leading block `44` written by the overflow, seventeen
released blocks and the terminating `1`.  This is exactly the shape
`phaseStart secondBlocks` that `super_cycle` starts from, and the leading run of
eight blocks `44` is what the digit analysis predicts: at an overflow every
radix-2 position of the counter releases a block `44`, and the radix-3/2
positions — the two created at the junction, the ones created by the normal
phase and the ones created by the blocks `14` — release `04`, `24` or `14`.

The block sequence passes the arithmetic test with a wide margin — the eight
leading blocks `44` push the gap to `255` before the first block `14` is met,
and the counter built by the whole phase can still perform `28954` increments —
so `super_cycle` applies and the machine also survives its second revolution.
-/

namespace SOC

set_option maxRecDepth 100000

/-- The blocks released by the second overflow, at step 3139. -/
def secondBlocks : List Sym :=
  [4, 4, 4, 4, 4, 4, 4, 0, 2, 0, 0, 0, 2, 1, 2, 1, 0]

/-- **After 3139 steps the machine is at the start of its second reset phase.**
Checked by evaluation. -/
theorem run_init_3139 : run init 3139 = some (enc (phaseStart secondBlocks)) := by
  rfl

theorem secondBlocks_labels : ∀ x ∈ secondBlocks, Label x := by decide

theorem secondBlocks_safe : SafeRun 1 secondBlocks := by decide

theorem secondBlocks_gfold : gfold 1 secondBlocks = 28954 := by decide

/--
**The machine survives its second revolution.**

From the blank tape it reaches the start of its second reset phase (step 3139),
consumes that phase, the junction and the normal phase that follows, and arrives
at the start of a third reset phase with a new block sequence.
-/
theorem second_revolution :
    ∃ L' : List Sym, (∀ x ∈ L', Label x) ∧ init ⟶+ enc (phaseStart L') := by
  obtain ⟨L', hL', hplus⟩ :=
    super_cycle secondBlocks_labels secondBlocks_safe (by rw [secondBlocks_gfold]; omega)
  refine ⟨L', hL', ?_⟩
  exact reaches_trans_reaches1 (reaches_of_run run_init_3139) hplus.sim

end SOC
