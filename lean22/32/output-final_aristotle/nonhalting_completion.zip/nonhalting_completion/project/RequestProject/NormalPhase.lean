import RequestProject.FirstPhase
import RequestProject.OneSafe

/-!
# The normal phase, and the super-cycle

The reset phase of `RequestProject.ResetPhase` ends with the head at the
terminating `1` of the old right-hand material, i.e. at a configuration
`w B> 1.` with nothing written to its right.  This file follows the machine from
there back to the start of the *next* reset phase, and shows that this part of
the cycle needs no side condition at all.

* `junction` — reading that last `1` (the informal rule
  `(02|22) B> 1. --> <<<<< B> (40|42) 42 41.`) takes the machine to a
  configuration `w' B> .` with blank tape to the right.  The only hypothesis is
  that the counter can pay for the five increments this costs, which is
  guaranteed by `9 ≤ gap w`.

* `normal_cycle` — with blank tape to its right the machine repeats the cycle

  ```
  w B> .  ⟶  w B> 21  ⟶  inc(w) B> 41  ⟶  inc(w) 03 B> .
  ```

  writing two cells of new right-hand material and pushing a radix-3/2 digit
  `03` onto the counter, at the cost of one increment.  This is the informal
  "the left counter counts down by one and the right counter counts up by one"
  of the normal stage.

* `normal_phase` — **the normal phase is unconditionally safe**: pushing `03`
  and paying one increment strictly decreases the gap (`(2g-1)/3 < g`), so after
  finitely many cycles the counter overflows, and the overflow releases a
  sequence of blocks `44|04|24|14` followed by the terminating `1` — exactly the
  start of a new reset phase.  No arithmetic hypothesis is needed: the machine
  cannot halt during the normal phase.

* `super_cycle` — one whole revolution: a reset phase whose block sequence
  passes `SafeRun` is followed by a junction and a normal phase, and the machine
  arrives at the start of the next reset phase with a new block sequence.

* `neverHalts_of_phase_invariant` — consequently, **the machine never halts as
  soon as every block sequence it ever releases passes the (decidable)
  arithmetic test**.  All the tape reasoning is gone; what is left is a
  statement about the block sequences alone.
-/

namespace SOC

open Cfg

/-! ## The junction: reading the last `1` of the old right-hand material -/

/-- Five increments are available as soon as the gap is at least `5`. -/
theorem inc5_exists {w : List LD} (h : 4 ≤ gap w) :
    ∃ w1 w2 w3 w4, Inc w w1 ∧ Inc w1 w2 ∧ Inc w2 w3 ∧ Inc w3 w4 := by
  obtain ⟨w1, w2, w3, w4, h1, h2, h3, h4, _⟩ := inc4_exists h
  exact ⟨w1, w2, w3, w4, h1, h2, h3, h4⟩

/--
**The junction `reset ⟶ normal`.**  The head reads the terminating `1` of the
old right-hand material, eats the lowest digit of the counter, pays four further
increments and comes back with blank tape to its right — the informal rule
`(02|22) B> 1. --> <<<<< B> (40|42) 42 41.`, the new right-hand material being
created from the blank tape by the normal phase that follows.
-/
theorem junction {w : List LD} (hb : BinHead w) (hg : 9 ≤ gap w) :
    ∃ w', MSteps ⟨w, [1]⟩ ⟨w', []⟩ := by
  match w, hb with
  | .d1 :: w1, _ =>
      have hw1 : 4 ≤ gap w1 := by simp only [gap_d1] at hg; omega
      obtain ⟨w2, w3, w4, w5, h2, h3, h4, h5⟩ := inc5_exists hw1
      have s1 : MStep ⟨LD.d1 :: w1, [1]⟩ ⟨w1, [2, 0, 3]⟩ := MStep.one1 (r := [1]) rfl
      have s2 : MStep ⟨w1, [2, 0, 3]⟩ ⟨w2, [4, 0, 3]⟩ := MStep.inc2 (r := [2, 0, 3]) h2 rfl
      have s3 : MStep ⟨w2, [4, 0, 3]⟩ ⟨LD.dA :: w2, [3]⟩ := MStep.a40 (r := [4, 0, 3]) rfl rfl
      have s4 : MStep ⟨LD.dA :: w2, [3]⟩ ⟨LD.dB :: w4, [2]⟩ :=
        MStep.inc3 (r := [3]) (Inc.dA h3 h4) rfl
      have s5 : MStep ⟨LD.dB :: w4, [2]⟩ ⟨LD.dA :: w5, [4]⟩ :=
        MStep.inc2 (r := [2]) (Inc.dB h5) rfl
      have s6 : MStep ⟨LD.dA :: w5, [4]⟩ ⟨LD.dA :: LD.dA :: w5, []⟩ :=
        MStep.a40 (r := [4]) rfl rfl
      exact ⟨_, (((((MSteps.single s1).tail s2).tail s3).tail s4).tail s5).tail s6⟩
  | .d0 :: w1, _ =>
      have hw1 : 4 ≤ gap w1 := by simp only [gap_d0] at hg; omega
      obtain ⟨w2, w3, w4, w5, h2, h3, h4, h5⟩ := inc5_exists hw1
      have s1 : MStep ⟨LD.d0 :: w1, [1]⟩ ⟨w1, [2, 1, 3]⟩ := MStep.one0 (r := [1]) rfl
      have s2 : MStep ⟨w1, [2, 1, 3]⟩ ⟨w2, [4, 1, 3]⟩ := MStep.inc2 (r := [2, 1, 3]) h2 rfl
      have s3 : MStep ⟨w2, [4, 1, 3]⟩ ⟨LD.dB :: w2, [3]⟩ := MStep.a41 (r := [4, 1, 3]) rfl rfl
      have s4 : MStep ⟨LD.dB :: w2, [3]⟩ ⟨LD.dA :: w3, [2]⟩ :=
        MStep.inc3 (r := [3]) (Inc.dB h3) rfl
      have s5 : MStep ⟨LD.dA :: w3, [2]⟩ ⟨LD.dB :: w5, [4]⟩ :=
        MStep.inc2 (r := [2]) (Inc.dA h4 h5) rfl
      have s6 : MStep ⟨LD.dB :: w5, [4]⟩ ⟨LD.dA :: LD.dB :: w5, []⟩ :=
        MStep.a40 (r := [4]) rfl rfl
      exact ⟨_, (((((MSteps.single s1).tail s2).tail s3).tail s4).tail s5).tail s6⟩
  | [], hb => exact hb.elim
  | .dA :: w1, hb => exact hb.elim
  | .dB :: w1, hb => exact hb.elim

/-! ## The normal phase -/

/-- **One cycle of the normal phase.**  Facing blank tape, the machine writes
two cells, performs one increment and pushes a radix-3/2 digit `03`. -/
theorem normal_cycle {w w' : List LD} (h : Inc w w') :
    MSteps ⟨w, []⟩ ⟨.dB :: w', []⟩ := by
  have s1 : MStep ⟨w, ([] : List Sym)⟩ ⟨w, [2, 1]⟩ := MStep.a00 (r := ([] : List Sym)) rfl rfl
  have s2 : MStep ⟨w, [2, 1]⟩ ⟨w', [4, 1]⟩ := MStep.inc2 (r := [2, 1]) h rfl
  have s3 : MStep ⟨w', [4, 1]⟩ ⟨.dB :: w', []⟩ := MStep.a41 (r := [4, 1]) rfl rfl
  exact ((MSteps.single s1).tail s2).tail s3

/-- **The end of the normal phase.**  When the counter can no longer be
incremented the cycle overflows instead: the marker moves one cell left, the old
counter is released to the right as the new right-hand material, and the
terminating `1` written by the last cycle closes it off. -/
theorem normal_overflow {w : List LD} {s : List Sym} (h : Ovf w s) :
    MSteps ⟨w, []⟩ ⟨[], 4 :: 4 :: (s ++ [1])⟩ := by
  have s1 : MStep ⟨w, ([] : List Sym)⟩ ⟨w, [2, 1]⟩ := MStep.a00 (r := ([] : List Sym)) rfl rfl
  have s2 : MStep ⟨w, [2, 1]⟩ ⟨[], 4 :: 4 :: (s ++ [1])⟩ := MStep.ovf2 (r := [2, 1]) h rfl
  exact (MSteps.single s1).tail s2

/-- Pushing a digit `03` after an increment strictly decreases the gap. -/
theorem gap_normal_cycle_lt {w w' : List LD} (h : Inc w w') (hp : 0 < gap w) :
    gap (.dB :: w') < gap w := by
  have := h.gap_eq
  simp only [gap_dB]
  omega

/--
**The normal phase is unconditionally safe.**

From any counter, with blank tape to the right, the machine runs through the
normal phase and arrives at the start of a reset phase: an empty counter facing
a block `44`, the blocks `L` released by the overflow, and the terminating `1`.
It cannot halt on the way, and no hypothesis on the counter is needed.
-/
theorem normal_phase : ∀ w : List LD, ∃ L : List Sym, (∀ x ∈ L, Label x) ∧
    MSteps ⟨w, []⟩ ⟨[], 4 :: 4 :: (cellsOf L ++ [1])⟩ := by
  intro w
  rcases Nat.eq_zero_or_pos (gap w) with hz | hp
  · obtain ⟨s, hs⟩ := ovf_exists hz
    obtain ⟨L, hL, rfl⟩ := hs.released
    exact ⟨L, hL, normal_overflow hs⟩
  · obtain ⟨w', hw'⟩ := inc_exists hp
    have hlt : gap (LD.dB :: w') < gap w := gap_normal_cycle_lt hw' hp
    obtain ⟨L, hL, hsteps⟩ := normal_phase (LD.dB :: w')
    exact ⟨L, hL, (normal_cycle hw').trans hsteps⟩
  termination_by w => gap w

/-! ## One whole revolution -/

/-- The configuration at the start of a reset phase: an empty counter, a block
`44`, the released blocks `L`, and the terminating `1`. -/
def phaseStart (L : List Sym) : MCfg := ⟨[], 4 :: 4 :: (cellsOf L ++ [1])⟩

/--
**One super-cycle.**

If the blocks `L` released by an overflow pass the arithmetic test `SafeRun`,
and the counter they build is large enough to survive the junction
(`9 ≤ gfold 1 L`), then the machine

1. consumes the whole reset phase, rebuilding the counter out of `L`;
2. reads the terminating `1` and starts the normal phase;
3. runs the normal phase to its overflow,

and arrives at the start of the next reset phase, with a new block sequence
`L'`.  In particular it does not halt during the revolution.
-/
theorem super_cycle {L : List Sym} (hL : ∀ x ∈ L, Label x) (hs : SafeRun 1 L)
    (h9 : 9 ≤ gfold 1 L) :
    ∃ L' : List Sym, (∀ x ∈ L', Label x) ∧ MPlus (phaseStart L) (phaseStart L') := by
  -- the leading block `44` fills the empty counter
  have hfirst : MStep (phaseStart L) ⟨[LD.d0], cellsOf L ++ [1]⟩ :=
    MStep.a44 (r := 4 :: 4 :: (cellsOf L ++ [1])) rfl rfl
  obtain ⟨w, hb, hgw, hreset⟩ :=
    reset_phase (w := [LD.d0]) trivial (g := 1) (by simp [gap]) hL hs [1]
  obtain ⟨w', hjunc⟩ := junction hb (Nat.le_trans h9 hgw)
  obtain ⟨L', hL', hnormal⟩ := normal_phase w'
  exact ⟨L', hL', ⟨_, hfirst, (hreset.trans hjunc).trans hnormal⟩⟩

/-- The super-cycle as a relation on block sequences. -/
def SuperStep (L L' : List Sym) : Prop :=
  (∀ x ∈ L', Label x) ∧ MPlus (phaseStart L) (phaseStart L')

/--
**Non-halting from an invariant on block sequences.**

If a property `P` of block sequences holds for the first sequence the machine
releases, guarantees the arithmetic safety of the reset phase, and is preserved
by the super-cycle, then `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never halts.

This is the whole halting question for the machine, with no tape reasoning left:
everything has been reduced to the sequences of blocks `44|04|24|14` released by
the successive overflows.
-/
theorem neverHalts_of_phase_invariant (P : List Sym → Prop)
    (h0 : P firstBlocks)
    (hsafe : ∀ L, P L → (∀ x ∈ L, Label x) ∧ SafeRun 1 L ∧ 9 ≤ gfold 1 L)
    (hclosed : ∀ L L', P L → SuperStep L L' → P L') : NeverHalts := by
  -- a successor for every `P`-sequence
  have hnext : ∀ L : { L : List Sym // P L }, ∃ L' : { L : List Sym // P L },
      MPlus (phaseStart L.1) (phaseStart L'.1) := by
    rintro ⟨L, hP⟩
    obtain ⟨hlab, hsr, h9⟩ := hsafe L hP
    obtain ⟨L', hL', hplus⟩ := super_cycle hlab hsr h9
    exact ⟨⟨L', hclosed L L' hP ⟨hL', hplus⟩⟩, hplus⟩
  let nxt : { L : List Sym // P L } → { L : List Sym // P L } := fun L =>
    Classical.choose (hnext L)
  have hnxt : ∀ L, MPlus (phaseStart L.1) (phaseStart (nxt L).1) := fun L =>
    Classical.choose_spec (hnext L)
  let f : Nat → { L : List Sym // P L } := fun n =>
    Nat.rec (⟨firstBlocks, h0⟩ : { L : List Sym // P L }) (fun _ L => nxt L) n
  have hchain : ∀ i, MPlus (phaseStart (f i).1) (phaseStart (f (i + 1)).1) := fun i => hnxt (f i)
  -- the chain runs forever, and the machine reaches its first link after 306 steps
  have hforever : ∀ n, (run (enc (phaseStart (f 0).1)) n).isSome := by
    intro n
    obtain ⟨N, hN, hrun⟩ := plus_chain_reaches (fun i => phaseStart (f i).1) hchain n
    exact isSome_of_run_le (by rw [hrun]; rfl) hN
  have hstart : init ⟶* enc (phaseStart (f 0).1) := reaches_of_run run_init_306
  exact forever_of_reaches hstart hforever

end SOC
