import RequestProject.Fast

/-!
# Eleven verified revolutions

`RequestProject.Fast` turns one revolution of the machine — reset phase,
junction, normal phase, overflow — into a *computable* function `revolutionF`
on block sequences, together with the proof `revolutionF_spec` that a successful
computation is a genuine run of `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA`.

Iterating it from the block sequence of the first overflow (`firstBlocks`,
reached after 306 steps) and checking the result inside Lean therefore proves
that the machine survives that many revolutions.  Here this is carried out for
eleven of them.

The block sequences grow roughly by a factor `2.2` per revolution:

```
revolution   1     2     3     4     5     6     7      8      9      10     11      12
blocks       7    17    39    82   180   378   838   1811   3919   8205  17534   37590
```

so at the end of the eleventh revolution the machine is at a configuration whose
right-hand material consists of `37590` blocks of two cells each — a tape more
than `75000` cells wide, reached after a number of steps far beyond the reach of
simulation (the first three overflows already happen at steps `306`, `3139` and
`502644`, and the step count is roughly squared at every further revolution; see
`RequestProject.Steps` for a proved lower bound).
-/

namespace SOC

/-- **The block sequence of the twelfth reset phase has 37590 blocks.**
Checked by evaluation inside Lean: the eleven revolutions are computed with the
bulk-increment model of `RequestProject.Fast`. -/
theorem revIter_11_length : (revIter 11).map List.length = some 37590 := by native_decide

theorem revIter_11_isSome : (revIter 11).isSome := by
  have h := revIter_11_length
  cases hn : revIter 11 with
  | none => rw [hn] at h; simp at h
  | some L => rfl

/--
**The machine survives eleven revolutions.**

Starting from the blank tape it reaches the start of its twelfth reset
phase — an empty counter facing `37590` blocks `44|04|24|14` closed by the
terminating `1` — without halting on the way.
-/
theorem survives_eleven_revolutions :
    ∃ L : List Sym, (∀ x ∈ L, Label x) ∧ L.length = 37590 ∧ init ⟶* enc (phaseStart L) := by
  have h := revIter_11_length
  cases hn : revIter 11 with
  | none => rw [hn] at h; simp at h
  | some L =>
      rw [hn] at h
      simp only [Option.map_some, Option.some.injEq] at h
      exact ⟨L, revIter_labels hn, h, revIter_reaches hn⟩

end SOC
