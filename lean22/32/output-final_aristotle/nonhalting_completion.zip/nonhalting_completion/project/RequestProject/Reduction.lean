import RequestProject.Leading
import RequestProject.Success

/-!
# The halting question, reduced to a density statement

Three ingredients are combined here.

* `RequestProject.Density` — a reset phase is safe as soon as the block sequence
  first builds a gap of `105` and then keeps the blocks `14` below the density
  `1/2` in every prefix.
* `RequestProject.Leading` — the gap-building part is automatic: every sequence
  the machine releases begins with at least seven blocks `44`, which build a gap
  of `2^8 - 1 = 255`.
* `RequestProject.Success` — if every revolution of the executable model
  computes, the machine never halts.

What is left is `neverHalts_of_tail_dense`:

> if, in every block sequence the machine releases, the blocks `14` never make
> up more than half of a prefix of what follows the seventh block, then
> `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never halts.

No tape, no counter, no gap: a single density statement about the sequences of
blocks.
-/

namespace SOC

/-- Seven leading blocks `44` build a gap of `255`. -/
theorem safeRun_replicate_seven : SafeRun 1 (List.replicate 7 (4 : Sym)) ∧
    gfold 1 (List.replicate 7 (4 : Sym)) = 255 := by
  constructor
  · decide
  · decide

theorem take_seven_of_lead {m : Nat} (hm : 7 ≤ m) (t : List Sym) :
    (List.replicate m (4 : Sym) ++ t).take 7 = List.replicate 7 4 := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hm
  rw [List.replicate_add, List.append_assoc, List.take_left' (by simp)]

/--
**The density of the tail is all that has to be checked.**

Every block sequence the machine computes begins with at least seven blocks
`44`; so if the part after them has its blocks `14` below the density `1/2` in
every prefix, the sequence satisfies the criterion of `RequestProject.Density`.
-/
theorem revIter_evDense_of_tail_dense
    (h : ∀ n L, revIter n = some L → Dense 1 1 (L.drop 7)) :
    ∀ n L, revIter n = some L → EvDense 105 1 1 L
  | 0, L, hL => by
      rw [revIter] at hL
      cases hL
      exact firstBlocks_evDense
  | n + 1, L, hL => by
      rw [revIter] at hL
      cases hprev : revIter n with
      | none => rw [hprev] at hL; simp at hL
      | some L0 =>
          rw [hprev] at hL
          simp only [Option.bind_some] at hL
          obtain ⟨t, rfl⟩ := revolutionF_leading hL
          have hm : 7 ≤ leadRun L0 := revIter_leadRun hprev
          have hL' : revIter (n + 1) = some (List.replicate (leadRun L0) 4 ++ t) := by
            rw [revIter, hprev, Option.bind_some]
            exact hL
          have htake := take_seven_of_lead hm t
          refine ⟨(List.replicate (leadRun L0) 4 ++ t).take 7,
            (List.replicate (leadRun L0) 4 ++ t).drop 7,
            (List.take_append_drop _ _).symm, ?_, ?_, h (n + 1) _ hL'⟩
          · rw [htake]; exact safeRun_replicate_seven.1
          · rw [htake, safeRun_replicate_seven.2]; omega

/--
**Non-halting, reduced to a density statement about the released blocks.**

If in every block sequence the machine releases the expensive blocks `14` never
make up more than half of a prefix of the part after the seventh block, then the
machine never halts.
-/
theorem neverHalts_of_tail_dense
    (h : ∀ n L, revIter n = some L → Dense 1 1 (L.drop 7)) : NeverHalts :=
  neverHalts_of_revIter_evDense (le_refl 105) (le_refl 1) ratio_half
    (revIter_evDense_of_tail_dense h)

/-! ## The sharper threshold

Seven blocks `44` build a gap of exactly `255`, and at a gap of `255` the
growth factors are `afac 255 = 509/255` and `bfac 255 = 491/765`, for which
`afac ^ 2 * bfac ^ 3 ≥ 1`: a density of `3/5` of blocks `14` is admissible,
against a critical density of `log 2 / log 3 ≈ 0.6309`.  The first released
sequence has to be treated separately — its counter only reaches `243` — but it
is a fixed sequence, and its safety is decidable.
-/

/-- Every computed block sequence other than the first one satisfies the
criterion with the threshold `255` and the density `3/5`. -/
theorem revIter_evDense35_of_tail_dense
    (h : ∀ n L, revIter n = some L → Dense 2 3 (L.drop 7)) :
    ∀ n L, revIter (n + 1) = some L → EvDense 255 2 3 L := by
  intro n L hL
  rw [revIter] at hL
  cases hprev : revIter n with
  | none => rw [hprev] at hL; simp at hL
  | some L0 =>
      rw [hprev] at hL
      simp only [Option.bind_some] at hL
      obtain ⟨t, rfl⟩ := revolutionF_leading hL
      have hm : 7 ≤ leadRun L0 := revIter_leadRun hprev
      have hL' : revIter (n + 1) = some (List.replicate (leadRun L0) 4 ++ t) := by
        rw [revIter, hprev, Option.bind_some]
        exact hL
      have htake := take_seven_of_lead hm t
      refine ⟨(List.replicate (leadRun L0) 4 ++ t).take 7,
        (List.replicate (leadRun L0) 4 ++ t).drop 7,
        (List.take_append_drop _ _).symm, ?_, ?_, h (n + 1) _ hL'⟩
      · rw [htake]; exact safeRun_replicate_seven.1
      · rw [htake, safeRun_replicate_seven.2]

/--
**Non-halting, reduced to a density statement — sharper form.**

If in every block sequence the machine releases the blocks `14` never make up
more than *three fifths* of a prefix of the part after the seventh block, then
the machine never halts.  The critical density, which no argument of this kind
can pass, is `log 2 / log 3 ≈ 0.6309`.
-/
theorem neverHalts_of_tail_dense35
    (h : ∀ n L, revIter n = some L → Dense 2 3 (L.drop 7)) : NeverHalts := by
  refine neverHalts_of_revIter_safe ?_
  intro n L hn
  match n with
  | 0 =>
      rw [revIter] at hn
      cases hn
      exact ⟨by decide, by decide⟩
  | k + 1 =>
      obtain ⟨hsafe, hgap⟩ :=
        (revIter_evDense35_of_tail_dense h k L hn).safe (by norm_num) (by norm_num)
          ratio_three_fifths_255
      exact ⟨hsafe, by omega⟩

end SOC
