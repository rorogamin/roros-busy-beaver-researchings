import Mathlib
import RequestProject.Leading
import RequestProject.Density

/-!
# The shape of the released block sequence

`RequestProject.Leading` shows that the leading blocks `44` of a released
sequence are inherited from the previous one.  This file proves the exact
statement behind that: **the whole radix pattern of the released sequence is
inherited**, position by position.

Writing `L = x₀ x₁ … x_{n-1}` for the block sequence absorbed by a reset phase
and `L'` for the sequence the following overflow releases,

```
L' = S ++ M       with   |S| = |L|,
     S i = 44  ⟺  x i ≠ 14,          every block of M is different from 44.
```

The reason is a bookkeeping fact about the radices of the counter positions.
The reset phase pushes one radix-2 digit per block; a block `14` additionally
*converts* the digit pushed by the preceding block into a radix-3/2 one.  The
junction converts the last one and adds a radix-3/2 digit, the normal phase adds
only radix-3/2 digits, and no later operation changes the radix of a position
(`addT_rad2`).  When the counter overflows, the sweep releases a radix-2 digit
as a block `44` and a radix-3/2 digit as one of `04`, `24`, `14`.

So the blocks `14` of `L'` can only sit where `L` already had a block `14`, plus
in the fresh part `M` created by the junction and the normal phase
(`revolutionF_shape`, `ones_prefix_le_of_shape`).  This is the structural half
of the density question: the density of the blocks `14` never has to be checked
again on the inherited part, only on the fresh one.
-/

namespace SOC

/-! ## Patterns -/

/-- The blocks that are not the expensive block `14`. -/
def notOne (x : Sym) : Bool := x != 1

/-- The blocks `44`. -/
def is4 (y : Sym) : Bool := y == 4

@[simp] theorem notOne_one : notOne 1 = false := rfl
@[simp] theorem is4_four : is4 4 = true := rfl

theorem notOne_eq_true {x : Sym} : notOne x = true ↔ x ≠ 1 := by
  simp [notOne]

theorem is4_eq_true {y : Sym} : is4 y = true ↔ y = 4 := by
  simp [is4]

/--
The radix pattern of the counter after a reset phase, as a function of the
pattern it started from: a block pushes a radix-2 digit (`true`), and a block
`14` first turns the lowest digit into a radix-3/2 one (`false`).
The head of the list is the least significant digit.
-/
def patF : List Bool → List Sym → List Bool
  | p, [] => p
  | p, x :: L => patF (if x = 1 then true :: false :: p.tail else true :: p) L

@[simp] theorem patF_nil (p : List Bool) : patF p [] = p := rfl

theorem patF_cons_one (p : List Bool) (L : List Sym) :
    patF p (1 :: L) = patF (true :: false :: p.tail) L := by
  rw [patF]; simp

theorem patF_cons_ne {x : Sym} (hx : x ≠ 1) (p : List Bool) (L : List Sym) :
    patF p (x :: L) = patF (true :: p) L := by
  rw [patF]; simp [hx]

/-- The pattern built from a single radix-2 digit: one entry per block, `false`
exactly at the blocks `14`, and a radix-2 digit at the bottom. -/
theorem patF_true : ∀ (p : List Bool) (L : List Sym),
    patF (true :: p) L = true :: ((L.map notOne).reverse ++ p)
  | p, [] => by simp
  | p, x :: L => by
      by_cases hx : x = 1
      · subst hx
        rw [patF_cons_one, List.tail_cons, patF_true (false :: p) L]
        simp
      · rw [patF_cons_ne hx, patF_true (true :: p) L]
        simp [notOne, hx]

/-! ## The pattern through one revolution -/

/-- **The reset phase builds the pattern `patF`.** -/
theorem resetF_pat : ∀ {w w' : List LD} {L : List Sym}, resetF w L = some w' →
    w'.map rad2 = patF (w.map rad2) L
  | w, w', [], hr => by rw [resetF] at hr; cases hr; simp
  | w, w', x :: L, hr => by
      match x with
      | 4 =>
          rw [resetF] at hr
          rw [resetF_pat hr, patF_cons_ne (by decide)]
          rfl
      | 0 =>
          rw [resetF] at hr
          rw [resetF_pat hr, patF_cons_ne (by decide)]
          rfl
      | 3 => simp at hr
      | 2 =>
          rw [resetF] at hr
          cases hone : addT w 1 with
          | none => rw [hone] at hr; simp at hr
          | some w1 =>
              rw [hone] at hr
              simp only at hr
              rw [resetF_pat hr, patF_cons_ne (by decide)]
              simp [addT_rad2 hone, rad2]
      | 1 =>
          match w with
          | [] => simp at hr
          | .dA :: v => simp at hr
          | .dB :: v => simp at hr
          | .d1 :: v =>
              rw [resetF] at hr
              cases hfour : addT v 4 with
              | none => rw [hfour] at hr; simp at hr
              | some v' =>
                  rw [hfour] at hr
                  simp only at hr
                  rw [resetF_pat hr, patF_cons_one]
                  simp [addT_rad2 hfour, rad2]
          | .d0 :: v =>
              rw [resetF] at hr
              cases hfour : addT v 4 with
              | none => rw [hfour] at hr; simp at hr
              | some v' =>
                  rw [hfour] at hr
                  simp only at hr
                  rw [resetF_pat hr, patF_cons_one]
                  simp [addT_rad2 hfour, rad2]

/-- **The junction converts the lowest digit and adds a radix-3/2 digit.** -/
theorem junctionF_pat {w w' : List LD} (hj : junctionF w = some w') :
    w'.map rad2 = false :: false :: (w.map rad2).tail := by
  match w with
  | [] => simp at hj
  | .dA :: v => simp at hj
  | .dB :: v => simp at hj
  | .d1 :: v =>
      rw [junctionF] at hj
      cases hfour : addT v 4 with
      | none => rw [hfour] at hj; simp at hj
      | some v' =>
          rw [hfour] at hj
          simp only [Option.map_some, Option.some.injEq] at hj
          subst hj
          simp [addT_rad2 hfour, rad2]
  | .d0 :: v =>
      rw [junctionF] at hj
      cases hfour : addT v 4 with
      | none => rw [hfour] at hj; simp at hj
      | some v' =>
          rw [hfour] at hj
          simp only [Option.map_some, Option.some.injEq] at hj
          subst hj
          simp [addT_rad2 hfour, rad2]

/-- **The overflow releases one block per digit, `44` exactly at the radix-2
positions.** -/
theorem ovfF_pat : ∀ {w : List LD} {acc L : List Sym}, ovfF w acc = some L →
    ∃ S, L = S ++ acc ∧ S.map is4 = (w.map rad2).reverse
  | [], acc, L, h => by
      rw [ovfF] at h
      cases h
      exact ⟨[], by simp, by simp⟩
  | .d0 :: w, acc, L, h => by rw [ovfF] at h; exact absurd h (by simp)
  | .d1 :: w, acc, L, h => by
      rw [ovfF] at h
      obtain ⟨S, rfl, hS⟩ := ovfF_pat h
      exact ⟨S ++ [4], by simp, by simp [hS, rad2]⟩
  | .dB :: w, acc, L, h => by
      rw [ovfF] at h
      obtain ⟨S, rfl, hS⟩ := ovfF_pat h
      exact ⟨S ++ [0], by simp, by simp [hS, rad2, is4]⟩
  | .dA :: w, acc, L, h => by
      rw [ovfF] at h
      cases hone : addT w 1 with
      | none =>
          rw [hone] at h
          simp only at h
          obtain ⟨S, rfl, hS⟩ := ovfF_pat h
          exact ⟨S ++ [2], by simp, by simp [hS, rad2, is4]⟩
      | some w' =>
          rw [hone] at h
          simp only at h
          have hlen : w'.length = w.length := addT_length hone
          obtain ⟨S, rfl, hS⟩ := ovfF_pat h
          refine ⟨S ++ [1], by simp, ?_⟩
          simp only [List.map_append, hS, List.map_cons, rad2, List.reverse_cons]
          rw [addT_rad2 hone]
          simp [is4]
  termination_by w => w.length
  decreasing_by
    · simp
    · simp
    · simp
    · simp [hlen]

/-- **The normal phase releases the counter's pattern, followed by fresh blocks
different from `44`.** -/
theorem normalF_pat : ∀ {w : List LD} {acc L : List Sym}, normalF w acc = some L →
    ∃ S M, L = S ++ M ++ acc ∧ S.map is4 = (w.map rad2).reverse ∧ ∀ y ∈ M, y ≠ 4
  | w, acc, L, h => by
      rw [normalF] at h
      cases hone : addT w 1 with
      | none =>
          rw [hone] at h
          simp only at h
          obtain ⟨S, rfl, hS⟩ := ovfF_pat h
          exact ⟨S, [], by simp, hS, by simp⟩
      | some w' =>
          rw [hone] at h
          simp only at h
          have hinc : Inc w w' := addT_one_inc hone
          have hlt : gap (LD.dB :: w') < gap w := gap_normal_cycle_lt hinc hinc.gap_pos
          obtain ⟨S, M, hL, hS, hM⟩ := normalF_pat h
          -- `S` is one block longer than the pattern of `w`: the fresh digit `03`
          have hSlen : S.length = w.length + 1 := by
            have := congrArg List.length hS
            simpa [addT_length hone] using this
          have hsplit : S = S.dropLast ++ [S.getLast (by
            intro hnil
            rw [hnil] at hSlen
            simp at hSlen)] := (List.dropLast_append_getLast _).symm
          set y := S.getLast (by
            intro hnil
            rw [hnil] at hSlen
            simp at hSlen) with hy
          have hmap : (S.dropLast).map is4 ++ [is4 y] = (w'.map rad2).reverse ++ [false] := by
            have h0 : (S.dropLast ++ [y]).map is4 = ((LD.dB :: w').map rad2).reverse := by
              rw [← hsplit]; exact hS
            simpa [rad2] using h0
          have hlast : is4 y = false := by
            have := congrArg (fun l => l.getLast?) hmap
            simpa using this
          have hpre : (S.dropLast).map is4 = (w.map rad2).reverse := by
            have h1 : (S.dropLast).map is4 ++ [is4 y] = (w.map rad2).reverse ++ [false] := by
              rw [hmap, addT_rad2 hone]
            have hlen2 : ((S.dropLast).map is4).length = ((w.map rad2).reverse).length := by
              simp [hSlen]
            exact List.append_inj_left h1 hlen2
          refine ⟨S.dropLast, y :: M, ?_, hpre, ?_⟩
          · rw [hL]
            conv_lhs => rw [hsplit]
            simp
          · intro z hz
            rcases List.mem_cons.1 hz with rfl | hz
            · intro h4
              rw [h4] at hlast
              simp [is4] at hlast
            · exact hM z hz
  termination_by w => gap w

/--
**The shape of a released block sequence.**

One revolution turns the block sequence `L` into a sequence `S ++ M` in which
`S` has exactly as many blocks as `L` and carries a block `44` exactly where `L`
had a block different from `14`; the fresh part `M` contains no block `44`.
-/
theorem revolutionF_shape {L L' : List Sym} (h : revolutionF L = some L') :
    ∃ S M, L' = S ++ M ∧ S.map is4 = L.map notOne ∧ ∀ y ∈ M, y ≠ 4 := by
  rw [revolutionF] at h
  cases hreset : resetF [LD.d0] L with
  | none => rw [hreset] at h; simp at h
  | some w =>
      rw [hreset] at h
      simp only [Option.bind_some] at h
      cases hjunc : junctionF w with
      | none => rw [hjunc] at h; simp at h
      | some w' =>
          rw [hjunc] at h
          simp only [Option.bind_some] at h
          obtain ⟨S, M, hL, hS, hM⟩ := normalF_pat h
          rw [List.append_nil] at hL
          -- the pattern of the counter at the end of the reset phase
          have hw : w.map rad2 = true :: (L.map notOne).reverse := by
            rw [resetF_pat hreset, show ([LD.d0] : List LD).map rad2 = true :: [] from rfl,
              patF_true]
            simp
          have hw' : w'.map rad2 = false :: false :: (L.map notOne).reverse := by
            rw [junctionF_pat hjunc, hw]
            simp
          have hSmap : S.map is4 = L.map notOne ++ [false, false] := by
            rw [hS, hw']
            simp
          have hSlen : S.length = L.length + 2 := by
            have := congrArg List.length hSmap
            simpa using this
          refine ⟨S.take L.length, S.drop L.length ++ M, ?_, ?_, ?_⟩
          · rw [hL, ← List.append_assoc, List.take_append_drop]
          · have := congrArg (fun l => l.take L.length) hSmap
            simpa using this
          · intro y hy
            rcases List.mem_append.1 hy with hy | hy
            · -- the two fresh blocks created by the junction
              have hdrop : (S.drop L.length).map is4 = [false, false] := by
                have := congrArg (fun l => l.drop L.length) hSmap
                simpa using this
              intro h4
              have : is4 y ∈ (S.drop L.length).map is4 := List.mem_map_of_mem hy
              rw [hdrop, h4] at this
              simp [is4] at this
            · exact hM y hy

/-! ## What the shape says about the blocks `14` -/

/-- A sequence carrying a `44` wherever the other one is not a `14` has at most
as many blocks `14`. -/
theorem ones_le_of_shape : ∀ {S L : List Sym}, S.map is4 = L.map notOne → ones S ≤ ones L
  | [], [], _ => le_refl _
  | [], x :: L, h => by simp at h
  | y :: S, [], h => by simp at h
  | y :: S, x :: L, h => by
      simp only [List.map_cons, List.cons.injEq] at h
      obtain ⟨h1, h2⟩ := h
      have hrec := ones_le_of_shape h2
      by_cases hx : x = 1
      · subst hx
        rw [ones_cons_one]
        by_cases hy : y = 1
        · subst hy
          rw [ones_cons_one]
          omega
        · rw [ones_cons_ne hy]
          omega
      · have hy : y = 4 := by
          have : is4 y = true := by rw [h1]; simp [notOne, hx]
          exact is4_eq_true.1 this
        rw [ones_cons_ne hx, ones_cons_ne (by rw [hy]; decide)]
        exact hrec

/-- The same bound on every prefix: the inherited part of a released sequence has
its blocks `14` at positions where the previous sequence already had one. -/
theorem ones_prefix_le_of_shape {S L : List Sym} (h : S.map is4 = L.map notOne) (j : ℕ) :
    ones (S.take j) ≤ ones (L.take j) := by
  refine ones_le_of_shape ?_
  have := congrArg (fun l => l.take j) h
  simpa using this

/-- The inherited part has exactly as many blocks as the sequence it comes
from. -/
theorem length_eq_of_shape {S L : List Sym} (h : S.map is4 = L.map notOne) :
    S.length = L.length := by
  have := congrArg List.length h
  simpa using this

theorem ones_append (A B : List Sym) : ones (A ++ B) = ones A + ones B := by
  simp [ones, List.count_append]

/--
**A revolution only lengthens a sequence, and the blocks `14` can increase by no
more than the number of fresh blocks.**
-/
theorem ones_revolutionF_le {L L' : List Sym} (h : revolutionF L = some L') :
    L.length ≤ L'.length ∧ ones L' ≤ ones L + (L'.length - L.length) := by
  obtain ⟨S, M, rfl, hS, -⟩ := revolutionF_shape h
  have hlen : S.length = L.length := length_eq_of_shape hS
  have hones : ones S ≤ ones L := ones_le_of_shape hS
  have hM : ones M ≤ M.length := ones_le_length M
  rw [ones_append, List.length_append]
  omega

end SOC
