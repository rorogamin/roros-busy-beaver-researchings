import RequestProject.Stages

/-!
# Machine-checked finite runs

Carried out by evaluation inside Lean: started from the blank tape the machine
`1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` does not halt during its first `10^8` steps.

(Whether it halts *ever* is not settled here; see `ANALYSIS.md`.)
-/

namespace SOC

set_option maxRecDepth 100000

/-- The machine does not halt within the first `10^8` steps. -/
theorem no_halt_before_1e8 : (run init 100000000).isSome := by native_decide

/-- Consequently it does not halt within the first `n` steps for any `n ≤ 10^8`. -/
theorem no_halt_of_le_1e8 (n : Nat) (hn : n ≤ 100000000) : (run init n).isSome := by
  have h : run init 100000000 = (run init n).bind (fun c => run c (100000000 - n)) := by
    rw [← run_add]
    congr 1
    omega
  cases hrn : run init n with
  | none =>
      rw [hrn] at h
      simp only [Option.bind] at h
      have := no_halt_before_1e8
      rw [h] at this
      simp at this
  | some _ => simp

end SOC
