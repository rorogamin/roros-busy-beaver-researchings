import Mathlib
import RequestProject.Trajectory
import RequestProject.FreshChecks

/-!
# What is left of the halting question: one inequality per revolution

`RequestProject.Trajectory` proves that the freshly created blocks of a
revolution are safe as soon as the counter rebuilt by the inherited blocks
dominates the counter that created them (`GapRatio`, `freshSafe_of_gapRatio`).
Combined with `neverHalts_of_fresh_safe` — the inherited blocks are safe for
free — this leaves a single inequality per revolution:

> **`neverHalts_of_gapRatio_from`** — if from some revolution on, the counter
> rebuilt by the inherited part of each released sequence is at least `14` times
> the counter the previous sequence built, then
> `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never halts.

The first revolutions, where the counters are still small and the inequality
does not hold, are covered by the direct check of `RequestProject.FreshChecks`.
The inequality is checked here on the revolutions the machine really performs:
it fails for the first two (the counter is then only `2^8`, resp. `2^15`) and
holds from the third on, with a margin that grows quickly — `2^36` against the
required `2^32`, then `2^159` against `2^122`, then `2^1619` against `2^1239`.
-/

namespace SOC

/--
**Non-halting from the domination inequality alone.**

If every revolution from the `N`-th on satisfies `GapRatio` — the counter
rebuilt by the inherited blocks is at least `14` times the previous one — then
the machine never halts.  No density, and no information about the individual
fresh blocks, is needed: each fresh block was created by a cycle in which the
old counter paid at least as much as the new one pays to absorb it.
-/
theorem neverHalts_of_gapRatio_from {N : ℕ} (hN : N ≤ 10)
    (h : ∀ n L L', N ≤ n → revIter n = some L → revIter (n + 1) = some L' → GapRatio L L') :
    NeverHalts := by
  refine neverHalts_of_fresh_safe ?_
  intro n L L' hL hL'
  by_cases hn : n < N
  · exact revIter_freshSafe (by omega) hL hL'
  · have hrev : revolutionF L = some L' := by
      rw [revIter, hL] at hL'
      simpa using hL'
    exact freshSafe_of_gapRatio hrev (h n L L' (by omega) hL hL')

/-! ## The inequality along the machine's own revolutions -/

/-- The domination test on the revolutions `a, a+1, …, b-1`. -/
def gapRatioOK (a b : ℕ) : Bool :=
  (List.range' a (b - a)).all fun n =>
    match revIter n with
    | some L =>
        match revolutionF L with
        | some L' => decide (GapRatio L L')
        | none => false
    | none => false

/-- **The domination inequality holds at the machine's revolutions `2` to `7`.**
Checked by compiled evaluation inside Lean. -/
theorem gapRatioOK_2_8 : gapRatioOK 2 8 = true := by native_decide

/-- The inequality, read off the test, for a single revolution. -/
theorem revIter_gapRatio {n : ℕ} (h2 : 2 ≤ n) (hn : n < 8) {L L' : List Sym}
    (hL : revIter n = some L) (hL' : revIter (n + 1) = some L') : GapRatio L L' := by
  have hall := gapRatioOK_2_8
  rw [gapRatioOK, List.all_eq_true] at hall
  have hmem := hall n (by
    rw [List.mem_range']
    exact ⟨n - 2, by omega⟩)
  rw [hL] at hmem
  have hrev : revolutionF L = some L' := by
    rw [revIter, hL] at hL'
    simpa using hL'
  have hm : (match revolutionF L with
      | some L' => decide (GapRatio L L')
      | none => false) = true := hmem
  rw [hrev] at hm
  exact of_decide_eq_true hm

/--
**What is left of the halting question.**

The machine never halts as soon as, from its eighth revolution on, the counter
rebuilt by the inherited blocks of each released sequence is at least `14` times
the counter the previous sequence built.  Everything before that — the first
seven revolutions, the inherited blocks of every revolution, and all the fresh
blocks — is proved.
-/
theorem neverHalts_of_gapRatio_eight
    (h : ∀ n L L', 8 ≤ n → revIter n = some L → revIter (n + 1) = some L' → GapRatio L L') :
    NeverHalts :=
  neverHalts_of_gapRatio_from (by norm_num) h

end SOC
