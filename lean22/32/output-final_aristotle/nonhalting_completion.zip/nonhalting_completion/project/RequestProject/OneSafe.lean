import RequestProject.ResetPhase

/-!
# Halting can only happen when the head reads a `1`

`RequestProject.Safety` shows that the macro machine dies at exactly two
patterns:

* `B> x3` with `x = 0` or `x = 4`, and
* `B> 1` with a radix-3/2 digit (or nothing) next to the head.

The first of the two can be **eliminated structurally**.  A `3` is never part of
the material released by an overflow (`Ovf.no_three`, `Ovf3.no_three`); the only
way a `3` ever appears to the right of the head is the pair of rules that read
the terminating `1` of the right-hand material,

```
22 B> 1  ⟶  B> 2 0 3        02 B> 1  ⟶  B> 2 1 3
```

and the three macro steps that follow such a rule consume that `3` again — *if*
the counter can still perform one increment after the digit the `1` has eaten.
If it cannot, the sweep overflows instead, the released material is inserted
between the head and the pending `3`, and the machine later runs into `0 3` or
`4 3` and dies.

So the whole halting question is concentrated at the moments the head reads
a `1`:

> **`clean_step`**  From a configuration whose right-hand material contains no
> `3`, the macro machine makes at least one step and reaches another
> configuration whose right-hand material contains no `3`, **unless** the head
> reads a `1` while the lowest digit of the counter is a radix-3/2 digit, the
> counter is empty, or the counter's gap is at most `1`.

`neverHalts_of_one_reads_safe` turns this into the sharpest non-halting
criterion of this development: it suffices to control the counter at the moments
a `1` is read.
-/

namespace SOC

open Cfg

/-! ## No `3` is ever released -/

theorem cellsOf_no_three {L : List Sym} (hL : ∀ x ∈ L, Label x) :
    (3 : Sym) ∉ cellsOf L := by
  induction L with
  | nil => simp
  | cons x L ih =>
      have hx : Label x := hL x (by simp)
      have ih' : (3 : Sym) ∉ cellsOf L := ih (fun y hy => hL y (by simp [hy]))
      simp only [cellsOf_cons, List.mem_cons]
      rintro (h | h | h)
      · rcases hx with rfl | rfl | rfl | rfl <;> exact absurd h (by decide)
      · exact absurd h (by decide)
      · exact ih' h

/-- **An overflow never releases a `3`.** -/
theorem Ovf.no_three {w : List LD} {s : List Sym} (h : Ovf w s) : (3 : Sym) ∉ s := by
  obtain ⟨L, hL, rfl⟩ := h.released
  exact cellsOf_no_three hL

/-- **An overflow started by a `3` never releases a `3` either.** -/
theorem Ovf3.no_three {w : List LD} {s : List Sym} (h : Ovf3 w s) : (3 : Sym) ∉ s := by
  cases h with
  | nil => simp
  | @d1 w s h | @dB w s h | @dA1 w s h | @dA2 w w' s _ h =>
      intro hm
      rcases List.mem_cons.1 hm with h' | h'
      · exact absurd h' (by decide)
      · rcases List.mem_append.1 h' with h'' | h''
        · exact h.no_three h''
        · simp only [List.mem_cons, List.not_mem_nil, or_false] at h''
          rcases h'' with h'' | h'' <;> exact absurd h'' (by decide)

/-! ## Macro steps, at least one of them -/

/-- `MPlus a b` : `b` is reached from `a` in at least one macro step. -/
def MPlus (a b : MCfg) : Prop := ∃ c, MStep a c ∧ MSteps c b

theorem MPlus.single {a b : MCfg} (h : MStep a b) : MPlus a b :=
  ⟨b, h, MSteps.refl b⟩

theorem MPlus.tail {a b c : MCfg} (h : MPlus a b) (h' : MStep b c) : MPlus a c := by
  obtain ⟨d, hd, hdb⟩ := h
  exact ⟨d, hd, hdb.tail h'⟩

theorem reaches1_trans_reaches {c d e : Cfg} (h₁ : c ⟶+ d) (h₂ : d ⟶* e) : c ⟶+ e := by
  obtain ⟨m, hm, hm'⟩ := h₁
  obtain ⟨n, hn⟩ := h₂
  exact ⟨m + n, by omega, run_trans hm' hn⟩

theorem reaches_trans_reaches1 {c d e : Cfg} (h₁ : c ⟶* d) (h₂ : d ⟶+ e) : c ⟶+ e := by
  obtain ⟨m, hm⟩ := h₁
  obtain ⟨n, hn, hn'⟩ := h₂
  exact ⟨m + n, by omega, run_trans hm hn'⟩

/-- A chain of at least one macro step is a run of at least one machine step. -/
theorem MPlus.sim {a b : MCfg} (h : MPlus a b) : enc a ⟶+ enc b := by
  obtain ⟨c, hc, hcb⟩ := h
  exact reaches1_trans_reaches (mstep_sim hc) hcb.sim

theorem plus_chain_reaches (f : Nat → MCfg) (hf : ∀ i, MPlus (f i) (f (i + 1))) :
    ∀ k, ∃ n, k ≤ n ∧ run (enc (f 0)) n = some (enc (f k)) := by
  intro k
  induction k with
  | zero => exact ⟨0, Nat.le_refl 0, rfl⟩
  | succ k ih =>
      obtain ⟨n, hn, hrun⟩ := ih
      obtain ⟨p, hp, hrp⟩ := (hf k).sim
      exact ⟨n + p, by omega, run_trans hrun hrp⟩

/-- **An infinite chain of (multi-)macro steps witnesses non-halting.** -/
theorem neverHalts_of_plus_chain (f : Nat → MCfg)
    (h0 : f 0 = ⟨[], [4, 4, 4, 4, 2, 4, 0, 4, 1]⟩)
    (hf : ∀ i, MPlus (f i) (f (i + 1))) : NeverHalts := by
  have hforever : ∀ n, (run (enc (f 0)) n).isSome := by
    intro n
    obtain ⟨N, hN, hrun⟩ := plus_chain_reaches f hf n
    exact isSome_of_run_le (by rw [hrun]; rfl) hN
  have hstart : init ⟶* enc (f 0) := by
    rw [h0]; exact reaches_of_run init_reaches_start
  exact forever_of_reaches hstart hforever

/-! ## Clean configurations -/

/-- The right-hand material carries no `3`. -/
def Clean (m : MCfg) : Prop := (3 : Sym) ∉ m.r

theorem clean_tail {r : List Sym} (h : (3 : Sym) ∉ r) : (3 : Sym) ∉ r.tail := by
  match r with
  | [] => exact h
  | a :: t => exact fun hm => h (List.mem_cons_of_mem a hm)

/-- The condition under which reading a `1` is safe: the lowest digit of the
counter is a radix-2 digit and the counter can still perform an increment after
that digit has been eaten (equivalently, its gap is at least `2`). -/
def OneOK (w : List LD) : Prop := BinHead w ∧ 2 ≤ gap w

instance : DecidablePred OneOK := fun w =>
  inferInstanceAs (Decidable (BinHead w ∧ 2 ≤ gap w))

/-- After the `1` has eaten the lowest digit, one increment is still available. -/
theorem OneOK.tail_gap {w : List LD} (h : OneOK w) :
    ∃ w1, (w = .d0 :: w1 ∨ w = .d1 :: w1) ∧ 0 < gap w1 := by
  obtain ⟨hb, hg⟩ := h
  match w, hb with
  | .d0 :: w1, _ => exact ⟨w1, Or.inl rfl, by simp only [gap_d0] at hg; omega⟩
  | .d1 :: w1, _ => exact ⟨w1, Or.inr rfl, by simp only [gap_d1] at hg; omega⟩
  | [], hb => exact hb.elim
  | .dA :: w1, hb => exact hb.elim
  | .dB :: w1, hb => exact hb.elim

/-! ## The step theorem

The three steps following a `1` — the sweep, the digit pushed by `40`/`41`, and
the sweep started by the pending `3` — bring the machine back to a configuration
without a `3`.  Note that the *second* sweep may overflow without any harm: the
`3` has already been consumed by then. -/

theorem one_read_step {w1 : List LD} (hg : 0 < gap w1) (x : Sym) (d : LD)
    {t : List Sym} (ht : (3 : Sym) ∉ t)
    (hpush : ∀ {w : List LD}, MStep ⟨w, 4 :: x :: 3 :: t⟩ ⟨d :: w, 3 :: t⟩) :
    ∃ m', MSteps ⟨w1, 2 :: x :: 3 :: t⟩ m' ∧ Clean m' := by
  obtain ⟨w2, hw2⟩ := inc_exists hg
  have s2 : MStep ⟨w1, 2 :: x :: 3 :: t⟩ ⟨w2, 4 :: x :: 3 :: t⟩ :=
    MStep.inc2 (r := 2 :: x :: 3 :: t) hw2 rfl
  have s3 : MStep ⟨w2, 4 :: x :: 3 :: t⟩ ⟨d :: w2, 3 :: t⟩ := hpush
  rcases Nat.eq_zero_or_pos (gap (d :: w2)) with hz | hp
  · -- the second sweep overflows; the pending `3` is consumed by it
    obtain ⟨s, hs⟩ := ovf3_exists hz
    refine ⟨⟨[], 4 :: (s ++ t)⟩, ((MSteps.single s2).tail s3).tail
      (MStep.ovf3 (r := 3 :: t) hs rfl), ?_⟩
    simp only [Clean, List.mem_cons, List.mem_append]
    rintro (h | h | h)
    · exact absurd h (by decide)
    · exact hs.no_three h
    · exact ht h
  · obtain ⟨v, hv⟩ := inc_exists hp
    refine ⟨⟨v, 2 :: t⟩, ((MSteps.single s2).tail s3).tail
      (MStep.inc3 (r := 3 :: t) hv rfl), ?_⟩
    simp only [Clean, List.mem_cons]
    rintro (h | h)
    · exact absurd h (by decide)
    · exact ht h

/--
**The only dangerous moment is a `1` read with a counter that cannot pay.**

From a configuration whose right-hand material carries no `3`, the macro machine
performs at least one step and arrives at another configuration whose right-hand
material carries no `3` — provided that, if the head reads a `1`, the counter
satisfies `OneOK`.  In particular the halting pattern `B> x3` is never reached
from such a configuration.
-/
theorem clean_step {m : MCfg} (hclean : Clean m) (hone : hd m.r = 1 → OneOK m.w) :
    ∃ m', MPlus m m' ∧ Clean m' := by
  obtain ⟨w, r⟩ := m
  simp only [Clean] at hclean ⊢
  have htail : (3 : Sym) ∉ r.tail := clean_tail hclean
  have htail2 : (3 : Sym) ∉ r.tail.tail := clean_tail htail
  rcases sym_cases (hd r) with h0 | hone' | htwo | hthree | hfour
  · -- head cell `0`
    rcases sym_cases (hd r.tail) with g0 | g1 | g2 | g3 | g4
    · exact ⟨_, MPlus.single (MStep.a00 h0 g0), by
        simp only [List.mem_cons]
        rintro (h | h | h) <;> first | exact absurd h (by decide) | exact htail2 h⟩
    · exact ⟨_, MPlus.single (MStep.a01 h0 g1), htail2⟩
    · exact ⟨_, MPlus.single (MStep.a02 h0 g2), by
        simp only [List.mem_cons]
        rintro (h | h | h) <;> first | exact absurd h (by decide) | exact htail2 h⟩
    · exact absurd (eq_cons_of_hd g3 (by decide) ▸ List.mem_cons_self ..) htail
    · exact ⟨_, MPlus.single (MStep.a04 h0 g4), htail2⟩
  · -- head cell `1` : the dangerous moment
    obtain ⟨w1, hw, hg⟩ := (hone hone').tail_gap
    have hr : r = 1 :: r.tail := eq_cons_of_hd hone' (by decide)
    rcases hw with rfl | rfl
    · -- lowest digit `02`
      have s1 : MStep ⟨LD.d0 :: w1, r⟩ ⟨w1, 2 :: 1 :: 3 :: r.tail⟩ := MStep.one0 hone'
      obtain ⟨m', hsteps, hc⟩ :=
        one_read_step (w1 := w1) hg 1 LD.dB htail
          (fun {w} => MStep.a41 (w := w) (r := 4 :: 1 :: 3 :: r.tail) rfl rfl)
      exact ⟨m', ⟨_, s1, hsteps⟩, hc⟩
    · -- lowest digit `22`
      have s1 : MStep ⟨LD.d1 :: w1, r⟩ ⟨w1, 2 :: 0 :: 3 :: r.tail⟩ := MStep.one1 hone'
      obtain ⟨m', hsteps, hc⟩ :=
        one_read_step (w1 := w1) hg 0 LD.dA htail
          (fun {w} => MStep.a40 (w := w) (r := 4 :: 0 :: 3 :: r.tail) rfl rfl)
      exact ⟨m', ⟨_, s1, hsteps⟩, hc⟩
  · -- head cell `2` : a sweep or an overflow, both harmless
    rcases Nat.eq_zero_or_pos (gap w) with hz | hp
    · obtain ⟨s, hs⟩ := ovf_exists hz
      refine ⟨_, MPlus.single (MStep.ovf2 hs htwo), ?_⟩
      simp only [List.mem_cons, List.mem_append]
      rintro (h | h | h | h)
      · exact absurd h (by decide)
      · exact absurd h (by decide)
      · exact hs.no_three h
      · exact htail h
    · obtain ⟨w', hw'⟩ := inc_exists hp
      refine ⟨_, MPlus.single (MStep.inc2 hw' htwo), ?_⟩
      simp only [List.mem_cons]
      rintro (h | h)
      · exact absurd h (by decide)
      · exact htail h
  · -- head cell `3` : impossible, the material is clean
    exact absurd (eq_cons_of_hd hthree (by decide) ▸ List.mem_cons_self ..) hclean
  · -- head cell `4`
    rcases sym_cases (hd r.tail) with g0 | g1 | g2 | g3 | g4
    · exact ⟨_, MPlus.single (MStep.a40 hfour g0), htail2⟩
    · exact ⟨_, MPlus.single (MStep.a41 hfour g1), htail2⟩
    · exact ⟨_, MPlus.single (MStep.a42 hfour g2), by
        simp only [List.mem_cons]
        rintro (h | h | h) <;> first | exact absurd h (by decide) | exact htail2 h⟩
    · exact absurd (eq_cons_of_hd g3 (by decide) ▸ List.mem_cons_self ..) htail
    · exact ⟨_, MPlus.single (MStep.a44 hfour g4), htail2⟩

/-! ## The criterion -/

/-- The configurations the machine can be checked at: the one it reaches after
50 steps, and everything reachable from it by at least one macro step that has
no `3` in its right-hand material. -/
inductive CReach : MCfg → Prop
  | start : CReach ⟨[], [4, 4, 4, 4, 2, 4, 0, 4, 1]⟩
  | step {m m' : MCfg} : CReach m → MPlus m m' → Clean m' → CReach m'

theorem CReach.clean {m : MCfg} (h : CReach m) : Clean m := by
  cases h with
  | start => simp [Clean]
  | step _ _ hc => exact hc

/--
**The sharpest non-halting criterion of this development.**

`1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never halts as soon as, at every checkpoint
configuration at which the head reads a `1`, the lowest digit of the counter is
a radix-2 digit and the counter's gap is at least `2`.

No other condition is needed: the pattern `B> x3` — the other way the machine
could die — can never be reached while the right-hand material carries no `3`,
and `clean_step` shows that the material stays free of `3`s.
-/
theorem neverHalts_of_one_reads_safe
    (h : ∀ m, CReach m → hd m.r = 1 → OneOK m.w) : NeverHalts := by
  have hnext : ∀ m : { m : MCfg // CReach m }, ∃ m' : { m : MCfg // CReach m }, MPlus m.1 m'.1 := by
    rintro ⟨m, hm⟩
    obtain ⟨m', hplus, hc⟩ := clean_step hm.clean (h m hm)
    exact ⟨⟨m', hm.step hplus hc⟩, hplus⟩
  let nxt : { m : MCfg // CReach m } → { m : MCfg // CReach m } := fun m =>
    Classical.choose (hnext m)
  have hnxt : ∀ m, MPlus m.1 (nxt m).1 := fun m => Classical.choose_spec (hnext m)
  let f : Nat → { m : MCfg // CReach m } := fun n =>
    Nat.rec (⟨_, CReach.start⟩ : { m : MCfg // CReach m }) (fun _ m => nxt m) n
  exact neverHalts_of_plus_chain (fun i => (f i).1) rfl (fun i => hnxt (f i))

end SOC
