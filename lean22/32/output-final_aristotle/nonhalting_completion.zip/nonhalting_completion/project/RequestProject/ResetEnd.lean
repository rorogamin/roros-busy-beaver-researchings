import RequestProject.Reset

/-!
# The reset-stage rule at the end of the tape

This file proves the last of the five reset-stage rules of the informal
analysis,

```
(02|22) B> 1.  -->  <<<<< B> (40|42) 42 41.
```

Reading the terminating `1` of the right counter when there is nothing but blank
tape to its right costs **five** decrements of the left counter, consumes the
lowest digit of that counter, and rebuilds a fresh right counter
`(40|42) 42 41.` — the reset stage is over and the normal stage starts again.
The digit `40` or `42` that appears is decided by the digit that was nearest the
head (`02` gives `40`, `22` gives `42`), which is the informal `(40|42)`.

As in `RequestProject/Reset.lean` the counter is written nearest cell first, and
the hypothesis "the counter does not underflow" is expressed by fixing the three
lowest digits `x0 x1 x2` (with left-hand cells `u`, `v`, `w` ∈ {0, 2}) and
requiring the digits above them to be `(22)^{k+1} 02 …`, i.e. the binary `+5`
stays inside the part of the counter that is displayed.  There are eight cases,
one for each choice of `x0 x1 x2`; they differ in where the `+5` lands and hence
in the exact step count.
-/

namespace SOC

open Cfg

/-! ## Two rules at the blank end of the tape -/

/-- `B> 4.  ⟶  23 B> .` (4 steps): the version of `rule_40` where the `0` is the
blank cell at the end of the tape. -/
theorem rule_40_end (l : List Sym) :
    run ⟨l, St.B, [4]⟩ 4 = some ⟨3 :: 2 :: l, St.B, []⟩ := rfl

/-- `B> .  ⟶  B> 21` (2 steps): the version of `rule_00` on blank tape. -/
theorem rule_00_end (l : List Sym) :
    run ⟨l, St.B, []⟩ 2 = some ⟨l, St.B, [2, 1]⟩ := rfl

/-! ## The eight cases of the rule `B> 1.` -/

/-- `B> 1.` with the three lowest digits of the left counter equal to `02 02 02`. -/
theorem reset_rule_end_000 (k : Nat) (L : List Sym) :
    run ⟨2 :: 0 :: 2 :: 0 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ (4 * k + 70)
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 0, 4, 2, 4, 1]⟩ := by
  have s1 : run ⟨2 :: 0 :: 2 :: 0 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ 10
      = some ⟨3 :: 0 :: 2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ := by
    simpa using reset_rule_one_from02 0 (2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s2 : run ⟨3 :: 0 :: 2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ 4
      = some ⟨2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 0, 2]⟩ := by
    simpa [sw] using
      dec_borrow_here 3 (Or.inr rfl) (2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s3 : run ⟨2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 0, 2]⟩ 8
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [4, 0, 2]⟩ := by
    simpa [cells22, cells02, sw] using
      dec_binary 1 2 (Or.inl rfl) (cells22 (k + 1) ++ 2 :: 0 :: L) [0, 2]
  have s4 : run ⟨2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [4, 0, 2]⟩ 4
      = some ⟨3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2]⟩ :=
    rule_40 _ _
  have s5 : run ⟨3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2]⟩ 10
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 1, 4]⟩ := by
    simpa [sw] using dec_binary23 0 2 (Or.inl rfl) (2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s6 : run ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 1, 4]⟩
        (4 * (k + 3) + 4)
      = some ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [4, 1, 4]⟩ := by
    have h := dec_binary (k + 3) 2 (Or.inl rfl) L [1, 4]
    rw [cells22_succ, cells22_succ] at h
    simpa [sw] using h
  have s7 : run ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [4, 1, 4]⟩ 2
      = some ⟨3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [4]⟩ := rule_41 _ _
  have s8 : run ⟨3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [4]⟩ 4
      = some ⟨3 :: 2 :: 3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, []⟩ := rule_40_end _
  have s9 : run ⟨3 :: 2 :: 3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, []⟩ 2
      = some ⟨3 :: 2 :: 3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [2, 1]⟩ :=
    rule_00_end _
  have s10 : run ⟨3 :: 2 :: 3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [2, 1]⟩ 6
      = some ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 0, 4, 2, 4, 1]⟩ := by
    simpa [sw] using
      dec_borrow [3, 2] (by decide) 2 (Or.inl rfl) (cells02 (k + 3) ++ 2 :: 2 :: L) [1]
  have s11 : run ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 0, 4, 2, 4, 1]⟩ 4
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 0, 4, 2, 4, 1]⟩ := by
    rw [cells02_succ (k + 2)]
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (cells02 (k + 2) ++ 2 :: 2 :: L) [0, 4, 2, 4, 1]
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4 (run_trans s5
    (run_trans s6 (run_trans s7 (run_trans s8 (run_trans s9 (run_trans s10 s11)))))))))
  rw [show 4 * k + 70
      = 10 + (4 + (8 + (4 + (10 + ((4 * (k + 3) + 4) + (2 + (4 + (2 + (6 + 4))))))))) from by omega]
  exact h

/-- `B> 1.` with the three lowest digits of the left counter equal to `22 02 02`. -/
theorem reset_rule_end_002 (k : Nat) (L : List Sym) :
    run ⟨2 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ (4 * k + 70)
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 0, 4, 2, 4, 1]⟩ := by
  have s1 : run ⟨2 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ 10
      = some ⟨3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ := by
    simpa using reset_rule_one_from02 0 (2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s2 : run ⟨3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ 4
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 0, 2]⟩ := by
    simpa [sw] using
      dec_borrow_here 3 (Or.inr rfl) (2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s3 : run ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 0, 2]⟩
        (4 * (k + 3) + 4)
      = some ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [4, 0, 2]⟩ := by
    have h := dec_binary (k + 3) 2 (Or.inl rfl) L [0, 2]
    rw [cells22_succ, cells22_succ] at h
    simpa [sw] using h
  have s4 : run ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [4, 0, 2]⟩ 4
      = some ⟨3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [2]⟩ := rule_40 _ _
  have s5 : run ⟨3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [2]⟩ 10
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 1, 4]⟩ := by
    rw [cells02_succ (k + 2)]
    simpa [sw] using dec_binary23 0 2 (Or.inl rfl) (cells02 (k + 2) ++ 2 :: 2 :: L) []
  have s6 : run ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 1, 4]⟩ 8
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 1, 4]⟩ := by
    rw [cells02_succ (k + 1)]
    simpa [cells22, cells02, sw] using
      dec_binary 1 2 (Or.inl rfl) (cells02 (k + 1) ++ 2 :: 2 :: L) [1, 4]
  have s7 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 1, 4]⟩ 2
      = some ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4]⟩ :=
    rule_41 _ _
  have s8 : run ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4]⟩ 4
      = some ⟨3 :: 2 :: 3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
          St.B, []⟩ := rule_40_end _
  have s9 : run ⟨3 :: 2 :: 3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, []⟩ 2
      = some ⟨3 :: 2 :: 3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
          St.B, [2, 1]⟩ := rule_00_end _
  have s10 : run ⟨3 :: 2 :: 3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, [2, 1]⟩ 6
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [2, 0, 4, 2, 4, 1]⟩ := by
    simpa [sw] using
      dec_borrow [3, 2] (by decide) 2 (Or.inl rfl)
        (2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L)) [1]
  have s11 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, [2, 0, 4, 2, 4, 1]⟩ 4
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 0, 4, 2, 4, 1]⟩ := by
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L)) [0, 4, 2, 4, 1]
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4 (run_trans s5
    (run_trans s6 (run_trans s7 (run_trans s8 (run_trans s9 (run_trans s10 s11)))))))))
  rw [show 4 * k + 70
      = 10 + (4 + ((4 * (k + 3) + 4) + (4 + (10 + (8 + (2 + (4 + (2 + (6 + 4))))))))) from by omega]
  exact h

/-- `B> 1.` with the three lowest digits of the left counter equal to `02 22 02`. -/
theorem reset_rule_end_020 (k : Nat) (L : List Sym) :
    run ⟨2 :: 0 :: 2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ (4 * k + 74)
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 0, 4, 2, 4, 1]⟩ := by
  have s1 : run ⟨2 :: 0 :: 2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ 14
      = some ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ := by
    simpa [cells22, cells02] using
      reset_rule_one_from02 1 (cells22 (k + 1) ++ 2 :: 0 :: L) []
  have s2 : run ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ 4
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 0, 2]⟩ := by
    simpa [sw] using
      dec_borrow_here 3 (Or.inr rfl) (2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s3 : run ⟨2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 0, 2]⟩ 4
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [4, 0, 2]⟩ := by
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) [0, 2]
  have s4 : run ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [4, 0, 2]⟩ 4
      = some ⟨3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2]⟩ :=
    rule_40 _ _
  have s5 : run ⟨3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2]⟩
        (4 * (k + 3) + 10)
      = some ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 1, 4]⟩ := by
    have h := dec_binary23 (k + 3) 2 (Or.inl rfl) L []
    rw [cells22_succ, cells22_succ] at h
    simpa [sw] using h
  have s6 : run ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 1, 4]⟩ 4
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 1, 4]⟩ := by
    rw [cells02_succ (k + 2)]
    simpa [sw] using dec_binary 0 2 (Or.inl rfl) (cells02 (k + 2) ++ 2 :: 2 :: L) [1, 4]
  have s7 : run ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 1, 4]⟩ 2
      = some ⟨3 :: 0 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4]⟩ := rule_41 _ _
  have s8 : run ⟨3 :: 0 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4]⟩ 4
      = some ⟨3 :: 2 :: 3 :: 0 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, []⟩ :=
    rule_40_end _
  have s9 : run ⟨3 :: 2 :: 3 :: 0 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, []⟩ 2
      = some ⟨3 :: 2 :: 3 :: 0 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 1]⟩ :=
    rule_00_end _
  have s10 : run ⟨3 :: 2 :: 3 :: 0 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 1]⟩ 6
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 0, 4, 2, 4, 1]⟩ := by
    simpa [sw] using
      dec_borrow [3, 2] (by decide) 2 (Or.inl rfl) (2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L)) [1]
  have s11 : run ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 0, 4, 2, 4, 1]⟩ 8
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 0, 4, 2, 4, 1]⟩ := by
    rw [cells02_succ (k + 1)]
    simpa [cells22, cells02, sw] using
      dec_binary 1 2 (Or.inl rfl) (cells02 (k + 1) ++ 2 :: 2 :: L) [0, 4, 2, 4, 1]
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4 (run_trans s5
    (run_trans s6 (run_trans s7 (run_trans s8 (run_trans s9 (run_trans s10 s11)))))))))
  rw [show 4 * k + 74
      = 14 + (4 + (4 + (4 + ((4 * (k + 3) + 10) + (4 + (2 + (4 + (2 + (6 + 8))))))))) from by omega]
  exact h

/-- `B> 1.` with the three lowest digits of the left counter equal to `22 22 02`. -/
theorem reset_rule_end_022 (k : Nat) (L : List Sym) :
    run ⟨2 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ (4 * k + 78)
      = some ⟨2 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L),
          St.B, [4, 0, 4, 2, 4, 1]⟩ := by
  have s1 : run ⟨2 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩
        (4 * (k + 3) + 10)
      = some ⟨3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [3]⟩ := by
    have h := reset_rule_one_from02 (k + 3) L []
    rw [cells22_succ, cells22_succ] at h
    simpa using h
  have s2 : run ⟨3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [3]⟩ 4
      = some ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 0, 2]⟩ := by
    simpa [sw] using dec_borrow_here 3 (Or.inr rfl) (cells02 (k + 3) ++ 2 :: 2 :: L) []
  have s3 : run ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 0, 2]⟩ 4
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 0, 2]⟩ := by
    rw [cells02_succ (k + 2)]
    simpa [sw] using dec_binary 0 2 (Or.inl rfl) (cells02 (k + 2) ++ 2 :: 2 :: L) [0, 2]
  have s4 : run ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 0, 2]⟩ 4
      = some ⟨3 :: 2 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2]⟩ := rule_40 _ _
  have s5 : run ⟨3 :: 2 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2]⟩ 14
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [2, 1, 4]⟩ := by
    rw [cells02_succ (k + 1)]
    simpa [cells22, cells02, sw] using
      dec_binary23 1 2 (Or.inl rfl) (cells02 (k + 1) ++ 2 :: 2 :: L) []
  have s6 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [2, 1, 4]⟩ 4
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 1, 4]⟩ := by
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L)) [1, 4]
  have s7 : run ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 1, 4]⟩ 2
      = some ⟨3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4]⟩ :=
    rule_41 _ _
  have s8 : run ⟨3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4]⟩ 4
      = some ⟨3 :: 2 :: 3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
          St.B, []⟩ := rule_40_end _
  have s9 : run ⟨3 :: 2 :: 3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, []⟩ 2
      = some ⟨3 :: 2 :: 3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
          St.B, [2, 1]⟩ := rule_00_end _
  have s10 : run ⟨3 :: 2 :: 3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, [2, 1]⟩ 6
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [2, 0, 4, 2, 4, 1]⟩ := by
    simpa [sw] using
      dec_borrow [3, 2] (by decide) 2 (Or.inl rfl)
        (2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L)) [1]
  have s11 : run ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, [2, 0, 4, 2, 4, 1]⟩ 12
      = some ⟨2 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L),
          St.B, [4, 0, 4, 2, 4, 1]⟩ := by
    rw [cells02_succ k]
    simpa [cells22, cells02, sw] using
      dec_binary 2 2 (Or.inl rfl) (cells02 k ++ 2 :: 2 :: L) [0, 4, 2, 4, 1]
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4 (run_trans s5
    (run_trans s6 (run_trans s7 (run_trans s8 (run_trans s9 (run_trans s10 s11)))))))))
  rw [show 4 * k + 78
      = (4 * (k + 3) + 10) + (4 + (4 + (4 + (14 + (4 + (2 + (4 + (2 + (6 + 12)))))))))
        from by omega]
  exact h

/-- `B> 1.` with the three lowest digits of the left counter equal to `02 02 22`. -/
theorem reset_rule_end_200 (k : Nat) (L : List Sym) :
    run ⟨2 :: 2 :: 2 :: 0 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ (4 * k + 68)
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 2, 4, 2, 4, 1]⟩ := by
  have s1 : run ⟨2 :: 2 :: 2 :: 0 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ 10
      = some ⟨3 :: 2 :: 2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ := by
    simpa [cells22, cells02] using
      reset_rule_one_from22 0 (2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s2 : run ⟨3 :: 2 :: 2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ 14
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 1, 2]⟩ := by
    simpa [cells22, cells02, sw] using
      dec_binary23 1 3 (Or.inr rfl) (cells22 (k + 1) ++ 2 :: 0 :: L) []
  have s3 : run ⟨2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 1, 2]⟩ 4
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [4, 1, 2]⟩ := by
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) [1, 2]
  have s4 : run ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [4, 1, 2]⟩ 2
      = some ⟨3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2]⟩ :=
    rule_41 _ _
  have s5 : run ⟨3 :: 0 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2]⟩ 4
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 0, 4]⟩ := by
    simpa [sw] using
      dec_borrow_here 2 (Or.inl rfl) (2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s6 : run ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 0, 4]⟩
        (4 * (k + 3) + 4)
      = some ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [4, 0, 4]⟩ := by
    have h := dec_binary (k + 3) 2 (Or.inl rfl) L [0, 4]
    rw [cells22_succ, cells22_succ] at h
    simpa [sw] using h
  have s7 : run ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [4, 0, 4]⟩ 4
      = some ⟨3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [4]⟩ := rule_40 _ _
  have s8 : run ⟨3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [4]⟩ 4
      = some ⟨3 :: 2 :: 3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, []⟩ := rule_40_end _
  have s9 : run ⟨3 :: 2 :: 3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, []⟩ 2
      = some ⟨3 :: 2 :: 3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [2, 1]⟩ :=
    rule_00_end _
  have s10 : run ⟨3 :: 2 :: 3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [2, 1]⟩ 8
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 2, 4, 2, 4, 1]⟩ := by
    rw [cells02_succ (k + 2)]
    simpa [sw] using
      dec_stop [3, 2, 3, 2] (by decide) 2 (Or.inl rfl) (cells02 (k + 2) ++ 2 :: 2 :: L) [1]
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4 (run_trans s5
    (run_trans s6 (run_trans s7 (run_trans s8 (run_trans s9 s10))))))))
  rw [show 4 * k + 68
      = 10 + (14 + (4 + (2 + (4 + ((4 * (k + 3) + 4) + (4 + (4 + (2 + 8)))))))) from by omega]
  exact h

/-- `B> 1.` with the three lowest digits of the left counter equal to `22 02 22`. -/
theorem reset_rule_end_202 (k : Nat) (L : List Sym) :
    run ⟨2 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ (4 * k + 68)
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 2, 4, 2, 4, 1]⟩ := by
  have s1 : run ⟨2 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ 10
      = some ⟨3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ := by
    simpa [cells22, cells02] using
      reset_rule_one_from22 0 (2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s2 : run ⟨3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩
        (4 * (k + 3) + 10)
      = some ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 1, 2]⟩ := by
    have h := dec_binary23 (k + 3) 3 (Or.inr rfl) L []
    rw [cells22_succ, cells22_succ] at h
    simpa [sw] using h
  have s3 : run ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 1, 2]⟩ 4
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 1, 2]⟩ := by
    rw [cells02_succ (k + 2)]
    simpa [sw] using dec_binary 0 2 (Or.inl rfl) (cells02 (k + 2) ++ 2 :: 2 :: L) [1, 2]
  have s4 : run ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 1, 2]⟩ 2
      = some ⟨3 :: 0 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2]⟩ := rule_41 _ _
  have s5 : run ⟨3 :: 0 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2]⟩ 4
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 0, 4]⟩ := by
    simpa [sw] using
      dec_borrow_here 2 (Or.inl rfl) (2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L)) []
  have s6 : run ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 0, 4]⟩ 8
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 0, 4]⟩ := by
    rw [cells02_succ (k + 1)]
    simpa [cells22, cells02, sw] using
      dec_binary 1 2 (Or.inl rfl) (cells02 (k + 1) ++ 2 :: 2 :: L) [0, 4]
  have s7 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 0, 4]⟩ 4
      = some ⟨3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4]⟩ :=
    rule_40 _ _
  have s8 : run ⟨3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4]⟩ 4
      = some ⟨3 :: 2 :: 3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
          St.B, []⟩ := rule_40_end _
  have s9 : run ⟨3 :: 2 :: 3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, []⟩ 2
      = some ⟨3 :: 2 :: 3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
          St.B, [2, 1]⟩ := rule_00_end _
  have s10 : run ⟨3 :: 2 :: 3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, [2, 1]⟩ 8
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 2, 4, 2, 4, 1]⟩ := by
    simpa [sw] using
      dec_stop [3, 2, 3, 2] (by decide) 2 (Or.inl rfl)
        (2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L)) [1]
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4 (run_trans s5
    (run_trans s6 (run_trans s7 (run_trans s8 (run_trans s9 s10))))))))
  rw [show 4 * k + 68
      = 10 + ((4 * (k + 3) + 10) + (4 + (2 + (4 + (8 + (4 + (4 + (2 + 8)))))))) from by omega]
  exact h

/-- `B> 1.` with the three lowest digits of the left counter equal to `02 22 22`. -/
theorem reset_rule_end_220 (k : Nat) (L : List Sym) :
    run ⟨2 :: 2 :: 2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ (4 * k + 72)
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 2, 4, 2, 4, 1]⟩ := by
  have s1 : run ⟨2 :: 2 :: 2 :: 2 :: 2 :: 0 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ 14
      = some ⟨3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ := by
    simpa [cells22, cells02] using
      reset_rule_one_from22 1 (cells22 (k + 1) ++ 2 :: 0 :: L) []
  have s2 : run ⟨3 :: 2 :: 2 :: 0 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [3]⟩ 10
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 1, 2]⟩ := by
    simpa [sw] using
      dec_binary23 0 3 (Or.inr rfl) (2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L)) []
  have s3 : run ⟨2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [2, 1, 2]⟩
        (4 * (k + 3) + 4)
      = some ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [4, 1, 2]⟩ := by
    have h := dec_binary (k + 3) 2 (Or.inl rfl) L [1, 2]
    rw [cells22_succ, cells22_succ] at h
    simpa [sw] using h
  have s4 : run ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [4, 1, 2]⟩ 2
      = some ⟨3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [2]⟩ := rule_41 _ _
  have s5 : run ⟨3 :: 0 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [2]⟩ 4
      = some ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 0, 4]⟩ := by
    simpa [sw] using dec_borrow_here 2 (Or.inl rfl) (cells02 (k + 3) ++ 2 :: 2 :: L) []
  have s6 : run ⟨cells02 (k + 3) ++ 2 :: 2 :: L, St.B, [2, 0, 4]⟩ 4
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 0, 4]⟩ := by
    rw [cells02_succ (k + 2)]
    simpa [sw] using dec_binary 0 2 (Or.inl rfl) (cells02 (k + 2) ++ 2 :: 2 :: L) [0, 4]
  have s7 : run ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4, 0, 4]⟩ 4
      = some ⟨3 :: 2 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4]⟩ := rule_40 _ _
  have s8 : run ⟨3 :: 2 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [4]⟩ 4
      = some ⟨3 :: 2 :: 3 :: 2 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, []⟩ :=
    rule_40_end _
  have s9 : run ⟨3 :: 2 :: 3 :: 2 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, []⟩ 2
      = some ⟨3 :: 2 :: 3 :: 2 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 1]⟩ :=
    rule_00_end _
  have s10 : run ⟨3 :: 2 :: 3 :: 2 :: 2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 1]⟩ 10
      = some ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 4, 4, 2, 4, 2, 4, 1]⟩ := by
    rw [cells02_succ (k + 1)]
    simpa [sw] using
      dec_stop [3, 2, 3, 2, 2, 2] (by decide) 2 (Or.inl rfl)
        (cells02 (k + 1) ++ 2 :: 2 :: L) [1]
  have s11 : run ⟨2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, [4, 4, 4, 2, 4, 2, 4, 1]⟩ 2
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
          St.B, [4, 2, 4, 2, 4, 1]⟩ := rule_44 _ _
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4 (run_trans s5
    (run_trans s6 (run_trans s7 (run_trans s8 (run_trans s9 (run_trans s10 s11)))))))))
  rw [show 4 * k + 72
      = 14 + (10 + ((4 * (k + 3) + 4) + (2 + (4 + (4 + (4 + (4 + (2 + (10 + 2)))))))))
        from by omega]
  exact h

/-- `B> 1.` with the three lowest digits of the left counter equal to `22 22 22`. -/
theorem reset_rule_end_222 (k : Nat) (L : List Sym) :
    run ⟨2 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ (4 * k + 76)
      = some ⟨2 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L),
          St.B, [4, 2, 4, 2, 4, 1]⟩ := by
  have s1 : run ⟨2 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩
        (4 * (k + 3) + 10)
      = some ⟨3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [3]⟩ := by
    have h := reset_rule_one_from22 (k + 3) L []
    rw [cells22_succ, cells22_succ, cells22_succ] at h
    simpa using h
  have s2 : run ⟨3 :: 2 :: (cells02 (k + 3) ++ 2 :: 2 :: L), St.B, [3]⟩ 10
      = some ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 1, 2]⟩ := by
    rw [cells02_succ (k + 2)]
    simpa [sw] using dec_binary23 0 3 (Or.inr rfl) (cells02 (k + 2) ++ 2 :: 2 :: L) []
  have s3 : run ⟨2 :: 2 :: (cells02 (k + 2) ++ 2 :: 2 :: L), St.B, [2, 1, 2]⟩ 8
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 1, 2]⟩ := by
    rw [cells02_succ (k + 1)]
    simpa [cells22, cells02, sw] using
      dec_binary 1 2 (Or.inl rfl) (cells02 (k + 1) ++ 2 :: 2 :: L) [1, 2]
  have s4 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 1, 2]⟩ 2
      = some ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [2]⟩ :=
    rule_41 _ _
  have s5 : run ⟨3 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [2]⟩ 4
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [2, 0, 4]⟩ := by
    simpa [sw] using
      dec_borrow_here 2 (Or.inl rfl) (2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L)) []
  have s6 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [2, 0, 4]⟩ 4
      = some ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 0, 4]⟩ := by
    simpa [sw] using
      dec_binary 0 2 (Or.inl rfl) (2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L)) [0, 4]
  have s7 : run ⟨2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4, 0, 4]⟩ 4
      = some ⟨3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4]⟩ :=
    rule_40 _ _
  have s8 : run ⟨3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L), St.B, [4]⟩ 4
      = some ⟨3 :: 2 :: 3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
          St.B, []⟩ := rule_40_end _
  have s9 : run ⟨3 :: 2 :: 3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, []⟩ 2
      = some ⟨3 :: 2 :: 3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
          St.B, [2, 1]⟩ := rule_00_end _
  have s10 : run ⟨3 :: 2 :: 3 :: 2 :: 2 :: 2 :: 2 :: 2 :: (cells02 (k + 1) ++ 2 :: 2 :: L),
        St.B, [2, 1]⟩ 12
      = some ⟨2 :: 2 :: (cells02 k ++ 2 :: 2 :: L),
          St.B, [4, 4, 4, 4, 4, 2, 4, 2, 4, 1]⟩ := by
    rw [cells02_succ k]
    simpa [sw] using
      dec_stop [3, 2, 3, 2, 2, 2, 2, 2] (by decide) 2 (Or.inl rfl) (cells02 k ++ 2 :: 2 :: L) [1]
  have s11 : run ⟨2 :: 2 :: (cells02 k ++ 2 :: 2 :: L), St.B, [4, 4, 4, 4, 4, 2, 4, 2, 4, 1]⟩ 2
      = some ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L),
          St.B, [4, 4, 4, 2, 4, 2, 4, 1]⟩ := rule_44 _ _
  have s12 : run ⟨2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L),
        St.B, [4, 4, 4, 2, 4, 2, 4, 1]⟩ 2
      = some ⟨2 :: 0 :: 2 :: 0 :: 2 :: 2 :: (cells02 k ++ 2 :: 2 :: L),
          St.B, [4, 2, 4, 2, 4, 1]⟩ := rule_44 _ _
  have h := run_trans s1 (run_trans s2 (run_trans s3 (run_trans s4 (run_trans s5
    (run_trans s6 (run_trans s7 (run_trans s8 (run_trans s9
      (run_trans s10 (run_trans s11 s12))))))))))
  rw [show 4 * k + 76
      = (4 * (k + 3) + 10) + (10 + (8 + (2 + (4 + (4 + (4 + (4 + (2 + (12 + (2 + 2))))))))))
        from by omega]
  exact h

/--
**The reset-stage rule `(02|22) B> 1.`**

Informally `(02|22) B> 1.  -->  <<<<< B> (40|42) 42 41.`: at the end of the right
counter the machine performs five decrements of the left counter, consumes that
counter's lowest digit `x0` and writes a fresh right counter `(40|42) 42 41.`,
whose first digit is `40` if `x0 = 02` and `42` if `x0 = 22` — i.e. the cell `u`
reappears on the right.  The reset stage is finished and the normal stage
begins.

The eight lemmas `reset_rule_end_uvw` give the resulting counter and the exact
number of steps in each case; here they are combined into the statement that
matters for the stage decomposition.
-/
theorem reset_rule_end (u v w : Sym) (hu : u = 0 ∨ u = 2) (hv : v = 0 ∨ v = 2)
    (hw : w = 0 ∨ w = 2) (k : Nat) (L : List Sym) :
    ∃ (n : Nat) (C : List Sym),
      run ⟨2 :: u :: 2 :: v :: 2 :: w :: (cells22 (k + 1) ++ 2 :: 0 :: L), St.B, [1]⟩ n
        = some ⟨C, St.B, [4, u, 4, 2, 4, 1]⟩ := by
  rcases hu with rfl | rfl <;> rcases hv with rfl | rfl <;> rcases hw with rfl | rfl
  · exact ⟨_, _, reset_rule_end_000 k L⟩
  · exact ⟨_, _, reset_rule_end_002 k L⟩
  · exact ⟨_, _, reset_rule_end_020 k L⟩
  · exact ⟨_, _, reset_rule_end_022 k L⟩
  · exact ⟨_, _, reset_rule_end_200 k L⟩
  · exact ⟨_, _, reset_rule_end_202 k L⟩
  · exact ⟨_, _, reset_rule_end_220 k L⟩
  · exact ⟨_, _, reset_rule_end_222 k L⟩

/-! ## The stage transition `normal ⟶ reset`

The informal analysis closes the loop with

```
.22 <B (44|40|42|41)* 41.  -->  .22 B> 4 (44|40|42|41)* 41.
                           -->  .22 02 B> (44|04|24|14)* 1.
```

The first line is the left overflow `left_overflow`, the second is one
application of `rule_44`; together they are `normal_to_reset` below.  The change
of the right counter's shape is *not* a computation: it is the **parity shift**
`cells_parity_shift`.  Reading the cells of a normal-stage right counter
`4 (4 c₁)(4 c₂) … (4 cₙ) 4 1` one cell further to the left regroups them as
`(4 4)(c₁ 4)(c₂ 4) … (cₙ 4) 1`, i.e. exactly a reset-stage right counter
`(44|04|24|14)* 1` — the digits `c ∈ {4, 0, 2, 1}` are carried over unchanged.
-/

/-- Shifting the reading frame of the right counter by one cell turns the
normal-stage grammar `4 (4c)* 41.` into the reset-stage grammar `44 (c4)* 1.`. -/
theorem cells_parity_shift (cs : List Sym) :
    (4 : Sym) :: ((cs.map (fun c => [(4 : Sym), c])).flatten ++ [4, 1])
      = 4 :: 4 :: ((cs.map (fun c => [c, (4 : Sym)])).flatten ++ [1]) := by
  induction cs with
  | nil => rfl
  | cons c cs ih => simpa using ih

/-- **Normal stage ⟶ reset stage.**  When the left counter underflows, the
marker `.22` sends the head back to the right (`left_overflow`) and the first two
cells of the right counter are absorbed as a new digit `02` (`rule_44`); the
head is then reading the right counter one cell further to the left, which by
`cells_parity_shift` is the reset-stage grammar. -/
theorem normal_to_reset (r : List Sym) :
    run ⟨[2], St.B, 2 :: 4 :: r⟩ 6 = some ⟨[2, 0, 2, 2], St.B, r⟩ := by
  have h1 := left_overflow (4 :: r)
  have h2 := rule_44 [2, 2] r
  simpa using run_trans h1 h2

end SOC
