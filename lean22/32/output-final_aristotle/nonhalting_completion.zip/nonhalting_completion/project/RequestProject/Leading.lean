import Mathlib
import RequestProject.Fast

/-!
# The leading run of blocks `44` never shrinks

Every block sequence the machine releases begins with a run of blocks `44`.
This file proves where that run comes from and that it cannot get shorter.

The reset phase builds the counter by pushing digits at its *least significant*
end, so the digits coming from the **leading** blocks of the sequence end up at
the top of the counter — the most significant end.  Blocks `44`, `04` and `24`
push a radix-2 digit, a block `14` a radix-3/2 one; so if `L` begins with `r`
blocks different from `14`, the counter's top `r` digits are radix-2, and they
stay radix-2 for the whole revolution: every later operation either pushes
digits at the bottom, replaces the lowest digit, or increments the counter, and
an increment never changes the radix of a position (`addT_rad2`).

When the counter finally overflows, the sweep reads it from the bottom up, and
by then every digit it meets is full: a radix-2 digit is read as `22`, i.e.
released as a block `44` — a digit `02` would leave the counter a positive gap,
and `ovfF` fails on it.  Hence the released sequence begins with `r` blocks `44`
(`revolutionF_leading`), and therefore

```
leadRun L ≤ leadRun L'      (leadRun_revolutionF)
```

where `leadRun` is the number of blocks before the first `14`.  Since the
machine's first released sequence has `leadRun = 7`, **every** sequence it
releases begins with at least seven blocks `44` (`revIter_leadRun`), so the
counter always gets a head start of `2^7 - 1 = 127`: the gap-building half of
the criterion of `RequestProject.Density` is automatic, and only the density of
the blocks `14` further on is left.
-/

namespace SOC

/-! ## Radix-2 digits -/

/-- The radix of a position: `true` for the radix-2 digits `02`, `22`. -/
def rad2 : LD → Bool
  | .d0 => true
  | .d1 => true
  | _ => false

theorem rad2_nextD (d : LD) (t : Nat) : rad2 (nextD d t) = rad2 d := by
  unfold nextD
  split
  · rfl
  · cases d <;> rfl

/-- **An increment never changes the radix of a position.** -/
theorem addT_rad2 : ∀ {w w' : List LD} {t : Nat}, addT w t = some w' →
    w'.map rad2 = w.map rad2
  | w, w', 0, h => by simp at h; rw [h]
  | [], w', t + 1, h => by rw [addT_nil (by omega)] at h; exact absurd h (by simp)
  | d :: w, w', t + 1, h => by
      rw [addT_cons d w (by omega : t + 1 ≠ 0)] at h
      cases hv : addT w (carries d (t + 1)) with
      | none => rw [hv] at h; exact absurd h (by simp)
      | some v =>
          rw [hv] at h
          simp only [Option.map_some, Option.some.injEq] at h
          rw [← h]
          simp only [List.map_cons, addT_rad2 hv, List.cons.injEq, and_true]
          exact rad2_nextD d (t + 1)

/-- A counter all of whose digits are radix-2. -/
def AllRad2 (w : List LD) : Prop := ∀ d ∈ w, rad2 d

/-- `Top2 m w` : the `m` most significant digits of `w` are radix-2. -/
def Top2 (m : Nat) (w : List LD) : Prop :=
  ∃ p u, w = p ++ u ∧ u.length = m ∧ AllRad2 u

/-- `Tail2 m w` : moreover the counter has a digit below them.  This is what
survives the operations that consume the counter's lowest digit. -/
def Tail2 (m : Nat) (w : List LD) : Prop := Top2 m w ∧ m < w.length

theorem Top2.cons {m : Nat} {w : List LD} (h : Top2 m w) (d : LD) : Top2 m (d :: w) := by
  obtain ⟨p, u, rfl, hu, hall⟩ := h
  exact ⟨d :: p, u, rfl, hu, hall⟩

theorem Tail2.cons {m : Nat} {w : List LD} (h : Tail2 m w) (d : LD) : Tail2 m (d :: w) :=
  ⟨h.1.cons d, by have := h.2; simp only [List.length_cons]; omega⟩

theorem Tail2.top {m : Nat} {w : List LD} (h : Tail2 m w) : Top2 m w := h.1

/-- Increments do not disturb the top of the counter. -/
theorem Top2.addT {m t : Nat} {w w' : List LD} (h : Top2 m w) (hstep : addT w t = some w') :
    Top2 m w' := by
  obtain ⟨p, u, rfl, hu, hall⟩ := h
  have hmap := addT_rad2 hstep
  have hlen : w'.length = (p ++ u).length := addT_length hstep
  refine ⟨w'.take p.length, w'.drop p.length, (List.take_append_drop _ _).symm, ?_, ?_⟩
  · simp only [List.length_drop, hlen, List.length_append]
    omega
  · intro d hd
    have hdrop : (w'.drop p.length).map rad2 = u.map rad2 := by
      rw [List.map_drop, hmap, List.map_append, List.drop_left' (by simp)]
    have hmem : rad2 d ∈ (w'.drop p.length).map rad2 := List.mem_map_of_mem hd
    rw [hdrop] at hmem
    obtain ⟨e, he, hde⟩ := List.mem_map.1 hmem
    rw [← hde]
    exact hall e he

theorem Tail2.addT {m t : Nat} {w w' : List LD} (h : Tail2 m w) (hstep : addT w t = some w') :
    Tail2 m w' := ⟨h.1.addT hstep, by rw [addT_length hstep]; exact h.2⟩

/-- Below the `m` protected digits there is at least one more, so removing the
lowest digit keeps them. -/
theorem Tail2.tail {m : Nat} {d : LD} {v : List LD} (h : Tail2 m (d :: v)) : Top2 m v := by
  obtain ⟨⟨p, u, hsplit, hu, hall⟩, hlt⟩ := h
  match p with
  | [] =>
      exfalso
      simp only [List.nil_append] at hsplit
      rw [← hsplit] at hu
      simp only [List.length_cons] at hu hlt
      omega
  | e :: p0 =>
      simp only [List.cons_append, List.cons.injEq] at hsplit
      obtain ⟨-, rfl⟩ := hsplit
      exact ⟨p0, u, rfl, hu, hall⟩

/-- Replacing the lowest digit by two new ones keeps the top of the counter. -/
theorem Top2.push2 {m : Nat} {v : List LD} (h : Top2 m v) (hm : m ≤ v.length) (a b : LD) :
    Tail2 m (a :: b :: v) :=
  ⟨(h.cons b).cons a, by simp; omega⟩

/-! ## The overflow releases the top of the counter as blocks `44` -/

theorem ovfF_allRad2 : ∀ {u : List LD}, AllRad2 u → ∀ {acc L : List Sym},
    ovfF u acc = some L → L = List.replicate u.length 4 ++ acc
  | [], _, acc, L, h => by rw [ovfF] at h; simp at h; simp [h]
  | .d0 :: u, _, acc, L, h => by
      rw [ovfF] at h; exact absurd h (by simp)
  | .d1 :: u, hall, acc, L, h => by
      rw [ovfF] at h
      have hrec := ovfF_allRad2 (fun d hd => hall d (by simp [hd])) h
      rw [hrec]
      simp [List.replicate_succ']
  | .dB :: u, hall, acc, L, h => by
      have := hall .dB (by simp)
      simp [rad2] at this
  | .dA :: u, hall, acc, L, h => by
      have := hall .dA (by simp)
      simp [rad2] at this

/-- The sweep of a counter reduces to the sweep of its top part. -/
theorem ovfF_split : ∀ {p u : List LD} {acc L : List Sym}, ovfF (p ++ u) acc = some L →
    ∃ u' acc', u'.map rad2 = u.map rad2 ∧ ovfF u' acc' = some L
  | [], u, acc, L, h => ⟨u, acc, rfl, h⟩
  | .d0 :: p, u, acc, L, h => by
      rw [List.cons_append, ovfF] at h; exact absurd h (by simp)
  | .d1 :: p, u, acc, L, h => by
      rw [List.cons_append, ovfF] at h
      exact ovfF_split h
  | .dB :: p, u, acc, L, h => by
      rw [List.cons_append, ovfF] at h
      exact ovfF_split h
  | .dA :: p, u, acc, L, h => by
      rw [List.cons_append, ovfF] at h
      cases hone : addT (p ++ u) 1 with
      | none =>
          rw [hone] at h
          simp only at h
          exact ovfF_split h
      | some z =>
          rw [hone] at h
          simp only at h
          have hmap : z.map rad2 = (p ++ u).map rad2 := addT_rad2 hone
          have hlen : z.length = (p ++ u).length := addT_length hone
          have hz : z = z.take p.length ++ z.drop p.length := (List.take_append_drop _ _).symm
          have hdrop : (z.drop p.length).map rad2 = u.map rad2 := by
            rw [List.map_drop, hmap, List.map_append, List.drop_left' (by simp)]
          have hplen : (z.take p.length).length = p.length := by
            simp only [List.length_take, hlen, List.length_append]
            omega
          rw [hz] at h
          obtain ⟨u', acc', hu', hovf⟩ := ovfF_split (p := z.take p.length) h
          exact ⟨u', acc', by rw [hu', hdrop], hovf⟩
  termination_by p => p.length
  decreasing_by
    · simp
    · simp
    · simp
    · simp [hplen]

/-- **The overflow releases the top of the counter as blocks `44`.** -/
theorem ovfF_leading {m : Nat} {w : List LD} (h : Top2 m w) {acc L : List Sym}
    (hovf : ovfF w acc = some L) : ∃ t, L = List.replicate m 4 ++ t := by
  obtain ⟨p, u, rfl, hu, hall⟩ := h
  obtain ⟨u', acc', hmap, hovf'⟩ := ovfF_split hovf
  have hall' : AllRad2 u' := by
    intro d hd
    have hmem : rad2 d ∈ u'.map rad2 := List.mem_map_of_mem hd
    rw [hmap] at hmem
    obtain ⟨e, he, hde⟩ := List.mem_map.1 hmem
    rw [← hde]
    exact hall e he
  have hlen : u'.length = m := by
    have := congrArg List.length hmap
    simp only [List.length_map] at this
    omega
  exact ⟨acc', by rw [ovfF_allRad2 hall' hovf', hlen]⟩

/-! ## The top of the counter survives the whole revolution -/

theorem resetF_Tail2 : ∀ {m : Nat} {w w' : List LD} {L : List Sym}, Tail2 m w →
    resetF w L = some w' → Tail2 m w'
  | _, w, w', [], h, hr => by rw [resetF] at hr; cases hr; exact h
  | m, w, w', x :: L, h, hr => by
      match x with
      | 4 => rw [resetF] at hr; exact resetF_Tail2 (h.cons _) hr
      | 0 => rw [resetF] at hr; exact resetF_Tail2 (h.cons _) hr
      | 3 => simp at hr
      | 2 =>
          rw [resetF] at hr
          cases hone : addT w 1 with
          | none => rw [hone] at hr; simp at hr
          | some w1 =>
              rw [hone] at hr
              simp only at hr
              exact resetF_Tail2 ((h.addT hone).cons _) hr
      | 1 =>
          match w with
          | [] => simp at hr
          | .dA :: v => simp at hr
          | .dB :: v => simp at hr
          | .d1 :: v =>
              rw [resetF] at hr
              cases hfour : addT v 4 with
              | none => rw [hfour] at hr; simp at hr
              | some v' =>
                  rw [hfour] at hr
                  simp only at hr
                  have htop : Top2 m v := h.tail
                  have hm : m ≤ v.length := by
                    obtain ⟨-, hlt⟩ := h
                    simp only [List.length_cons] at hlt
                    omega
                  have htop' : Top2 m v' := htop.addT hfour
                  have hm' : m ≤ v'.length := by rw [addT_length hfour]; exact hm
                  exact resetF_Tail2 (htop'.push2 hm' _ _) hr
          | .d0 :: v =>
              rw [resetF] at hr
              cases hfour : addT v 4 with
              | none => rw [hfour] at hr; simp at hr
              | some v' =>
                  rw [hfour] at hr
                  simp only at hr
                  have htop : Top2 m v := h.tail
                  have hm : m ≤ v.length := by
                    obtain ⟨-, hlt⟩ := h
                    simp only [List.length_cons] at hlt
                    omega
                  have htop' : Top2 m v' := htop.addT hfour
                  have hm' : m ≤ v'.length := by rw [addT_length hfour]; exact hm
                  exact resetF_Tail2 (htop'.push2 hm' _ _) hr

/-- The junction keeps the top of the counter. -/
theorem junctionF_Tail2 {m : Nat} {w w' : List LD} (h : Tail2 m w)
    (hj : junctionF w = some w') : Tail2 m w' := by
  match w with
  | [] => simp at hj
  | .dA :: v => simp at hj
  | .dB :: v => simp at hj
  | .d1 :: v =>
      rw [junctionF] at hj
      cases hfour : addT v 4 with
      | none => rw [hfour] at hj; simp at hj
      | some v'' =>
          rw [hfour] at hj
          simp only [Option.map_some, Option.some.injEq] at hj
          subst hj
          have hm : m ≤ v.length := by
            obtain ⟨-, hlt⟩ := h
            simp only [List.length_cons] at hlt
            omega
          exact ((h.tail).addT hfour).push2 (by rw [addT_length hfour]; exact hm) _ _
  | .d0 :: v =>
      rw [junctionF] at hj
      cases hfour : addT v 4 with
      | none => rw [hfour] at hj; simp at hj
      | some v'' =>
          rw [hfour] at hj
          simp only [Option.map_some, Option.some.injEq] at hj
          subst hj
          have hm : m ≤ v.length := by
            obtain ⟨-, hlt⟩ := h
            simp only [List.length_cons] at hlt
            omega
          exact ((h.tail).addT hfour).push2 (by rw [addT_length hfour]; exact hm) _ _

/-- **The normal phase releases the top of the counter as blocks `44`.** -/
theorem normalF_leading : ∀ {m : Nat} {w : List LD} {acc L : List Sym}, Top2 m w →
    normalF w acc = some L → ∃ t, L = List.replicate m 4 ++ t
  | m, w, acc, L, h, hn => by
      rw [normalF] at hn
      cases hone : addT w 1 with
      | none =>
          rw [hone] at hn
          simp only at hn
          exact ovfF_leading h hn
      | some w' =>
          rw [hone] at hn
          simp only at hn
          have hinc : Inc w w' := addT_one_inc hone
          have hlt : gap (LD.dB :: w') < gap w := gap_normal_cycle_lt hinc hinc.gap_pos
          exact normalF_leading ((h.addT hone).cons _) hn
  termination_by _ w => gap w

/-! ## The leading run of a block sequence -/

/-- The number of blocks before the first block `14`. -/
def leadRun (L : List Sym) : Nat := (L.takeWhile (fun x => x != 1)).length

theorem resetF_append : ∀ (w : List LD) (A B : List Sym),
    resetF w (A ++ B) = (resetF w A).bind (fun u => resetF u B)
  | w, [], B => by simp [resetF]
  | w, x :: A, B => by
      match x with
      | 4 => simp only [List.cons_append, resetF]; exact resetF_append _ A B
      | 0 => simp only [List.cons_append, resetF]; exact resetF_append _ A B
      | 3 => simp [resetF]
      | 2 =>
          simp only [List.cons_append, resetF]
          cases addT w 1 with
          | none => simp
          | some w1 => simpa using resetF_append _ A B
      | 1 =>
          match w with
          | [] => simp [resetF]
          | .dA :: v => simp [resetF]
          | .dB :: v => simp [resetF]
          | .d1 :: v =>
              simp only [List.cons_append, resetF]
              cases addT v 4 with
              | none => simp
              | some v' => simpa using resetF_append _ A B
          | .d0 :: v =>
              simp only [List.cons_append, resetF]
              cases addT v 4 with
              | none => simp
              | some v' => simpa using resetF_append _ A B

/-- Absorbing blocks other than `14` only pushes radix-2 digits. -/
theorem resetF_allRad2 : ∀ {w w' : List LD} {A : List Sym}, (∀ x ∈ A, x ≠ 1) →
    AllRad2 w → resetF w A = some w' → AllRad2 w' ∧ w'.length = w.length + A.length
  | w, w', [], _, hw, hr => by
      rw [resetF] at hr; cases hr
      exact ⟨hw, by simp⟩
  | w, w', x :: A, hx, hw, hr => by
      have hA : ∀ y ∈ A, y ≠ 1 := fun y hy => hx y (by simp [hy])
      have hx1 : x ≠ 1 := hx x (by simp)
      have hcons : ∀ (d : LD), rad2 d → AllRad2 (d :: w) := by
        intro d hd e he
        rcases List.mem_cons.1 he with rfl | he
        · exact hd
        · exact hw e he
      match x with
      | 4 =>
          rw [resetF] at hr
          obtain ⟨h1, h2⟩ := resetF_allRad2 hA (hcons .d0 rfl) hr
          exact ⟨h1, by simp at h2 ⊢; omega⟩
      | 0 =>
          rw [resetF] at hr
          obtain ⟨h1, h2⟩ := resetF_allRad2 hA (hcons .d1 rfl) hr
          exact ⟨h1, by simp at h2 ⊢; omega⟩
      | 3 => simp at hr
      | 1 => exact absurd rfl hx1
      | 2 =>
          rw [resetF] at hr
          cases hone : addT w 1 with
          | none => rw [hone] at hr; simp at hr
          | some w1 =>
              rw [hone] at hr
              simp only at hr
              have hw1 : AllRad2 w1 := by
                intro d hd
                have hmem : rad2 d ∈ w1.map rad2 := List.mem_map_of_mem hd
                rw [addT_rad2 hone] at hmem
                obtain ⟨e, he, hde⟩ := List.mem_map.1 hmem
                rw [← hde]
                exact hw e he
              have hlen1 : w1.length = w.length := addT_length hone
              have hcons1 : AllRad2 (LD.d0 :: w1) := by
                intro e he
                rcases List.mem_cons.1 he with rfl | he
                · rfl
                · exact hw1 e he
              obtain ⟨h1, h2⟩ := resetF_allRad2 hA hcons1 hr
              exact ⟨h1, by simp [hlen1] at h2 ⊢; omega⟩

/-- **One revolution releases at least `leadRun L` blocks `44` in front.** -/
theorem revolutionF_leading {L L' : List Sym} (h : revolutionF L = some L') :
    ∃ t, L' = List.replicate (leadRun L) 4 ++ t := by
  set A := L.takeWhile (fun x => x != 1) with hA
  set B := L.dropWhile (fun x => x != 1) with hB
  have hsplit : L = A ++ B := (List.takeWhile_append_dropWhile).symm
  have hAne : ∀ x ∈ A, x ≠ 1 := by
    intro x hx
    have hx' := List.mem_takeWhile_imp (p := fun x : Sym => x != 1) (l := L) hx
    simpa using hx'
  rw [revolutionF] at h
  cases hreset : resetF [LD.d0] L with
  | none => rw [hreset] at h; simp at h
  | some w =>
      rw [hreset] at h
      simp only [Option.bind_some] at h
      cases hjunc : junctionF w with
      | none => rw [hjunc] at h; simp at h
      | some w' =>
          rw [hjunc] at h
          simp only [Option.bind_some] at h
          -- the counter after the leading non-`14` blocks
          rw [hsplit, resetF_append] at hreset
          cases hwA : resetF [LD.d0] A with
          | none => rw [hwA] at hreset; simp at hreset
          | some wA =>
              rw [hwA] at hreset
              simp only [Option.bind_some] at hreset
              obtain ⟨hall, hlen⟩ :=
                resetF_allRad2 hAne (by intro d hd; simp at hd; subst hd; rfl) hwA
              have hlenA : wA.length = A.length + 1 := by simp at hlen; omega
              have htail : Tail2 (leadRun L) wA := by
                refine ⟨⟨wA.take 1, wA.drop 1, (List.take_append_drop _ _).symm, ?_,
                  fun d hd => hall d (List.mem_of_mem_drop hd)⟩, ?_⟩
                · simp only [List.length_drop, hlenA, leadRun, ← hA]
                  omega
                · simp only [hlenA, leadRun, ← hA]
                  omega
              have h1 := resetF_Tail2 htail hreset
              have h2 := junctionF_Tail2 h1 hjunc
              exact normalF_leading h2.top h

/-- A sequence that begins with `n` blocks `44` has a leading run of at least `n`. -/
theorem le_leadRun_replicate_append (n : Nat) (t : List Sym) :
    n ≤ leadRun (List.replicate n 4 ++ t) := by
  induction n with
  | zero => exact Nat.zero_le _
  | succ k ih =>
      rw [List.replicate_succ, List.cons_append, leadRun,
        List.takeWhile_cons_of_pos (p := fun x : Sym => x != 1) (a := 4) rfl,
        List.length_cons]
      exact Nat.succ_le_succ ih

/-- **The leading run of blocks `44` never gets shorter.** -/
theorem leadRun_revolutionF {L L' : List Sym} (h : revolutionF L = some L') :
    leadRun L ≤ leadRun L' := by
  obtain ⟨t, rfl⟩ := revolutionF_leading h
  exact le_leadRun_replicate_append _ t

/-- **Every block sequence the machine releases begins with at least seven blocks
`44`.**  The first one does, and the leading run never gets shorter. -/
theorem revIter_leadRun : ∀ {n : Nat} {L : List Sym}, revIter n = some L → 7 ≤ leadRun L
  | 0, L, h => by
      rw [revIter] at h
      cases h
      decide
  | n + 1, L, h => by
      rw [revIter] at h
      cases hprev : revIter n with
      | none => rw [hprev] at h; simp at h
      | some L0 =>
          rw [hprev] at h
          simp only [Option.bind_some] at h
          exact Nat.le_trans (revIter_leadRun hprev) (leadRun_revolutionF h)

end SOC
