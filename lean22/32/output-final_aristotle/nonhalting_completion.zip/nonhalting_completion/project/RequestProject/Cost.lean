import RequestProject.Fast

/-!
# How long the machine runs

The macro model says *that* the machine keeps moving; this file says *how much*.
Every increment of the counter is a leftward sweep of the head, and the sweep
spends a fixed number of steps at each position it crosses:

| digit | steps per increment received |
|---|---|
| `02`, `22` | `4` |
| `03`, `23` | `8` |

A radix-3/2 position emits **three** carries for every **two** increments it
receives, so the number of increments a position receives grows as one climbs
past such positions — which is why a single cycle of the normal phase can cost
astronomically many steps even though the counter has only a few thousand
digits.

`costT w t` adds these numbers up for `t` increments of the counter `w`, in one
pass (`costT_add` is the corresponding composition law), and `inc_sweep_cost`
proves that the machine really takes at least `costT w 1` steps to perform one
increment.  Summing over the cycles of a normal phase gives `normalCost`, and
`no_halt_before_stepBound` turns it into a lower bound on the number of steps
the machine runs without halting.
-/

namespace SOC

open Cfg

/-! ## The cost of a bulk increment -/

/-- The number of steps the sweep spends at one position per increment that
position receives. -/
def wt : LD → Nat
  | .d0 => 4
  | .d1 => 4
  | .dB => 8
  | .dA => 8

@[simp] theorem wt_nextD (d : LD) (t : Nat) : wt (nextD d t) = wt d := by
  cases d <;> simp only [nextD, flipD] <;> split <;> rfl

/-- `costT w t` is the number of steps the machine spends performing `t`
increments of the counter `w`. -/
def costT : List LD → Nat → Nat
  | _, 0 => 0
  | [], _ => 0
  | d :: w, t => wt d * t + costT w (carries d t)

@[simp] theorem costT_zero (w : List LD) : costT w 0 = 0 := by cases w <;> rfl

@[simp] theorem costT_nil (t : Nat) : costT [] t = 0 := by cases t <;> rfl

theorem costT_cons (d : LD) (w : List LD) {t : Nat} (ht : t ≠ 0) :
    costT (d :: w) t = wt d * t + costT w (carries d t) := by
  cases t with
  | zero => simp at ht
  | succ n => rfl

/-- **Costs add up**: the cost of `a + b` increments is the cost of the first
`a` plus the cost of the remaining `b`, taken at the counter reached in
between. -/
theorem costT_add : ∀ (w : List LD) (a b : Nat) (u : List LD), addT w a = some u →
    costT w (a + b) = costT w a + costT u b
  | [], a, b, u, h => by
      rcases Nat.eq_zero_or_pos a with rfl | ha
      · simp at h; subst h; simp
      · rw [addT_nil (by omega)] at h; simp at h
  | d :: w, a, b, u, h => by
      rcases Nat.eq_zero_or_pos a with rfl | ha
      · simp at h; subst h; simp
      · rw [addT_cons d w (by omega : a ≠ 0)] at h
        cases hv : addT w (carries d a) with
        | none => rw [hv] at h; simp at h
        | some v =>
            rw [hv] at h
            simp only [Option.map_some, Option.some.injEq] at h
            subst h
            rw [costT_cons d w (by omega : a + b ≠ 0), costT_cons d w (by omega : a ≠ 0),
              carries_add d a b, costT_add w (carries d a) (carries (nextD d a) b) v hv]
            rcases Nat.eq_zero_or_pos b with rfl | hb
            · simp
            · rw [costT_cons (nextD d a) v (by omega : b ≠ 0), wt_nextD]
              ring

/-! ### Tail-recursive implementations

Both `costT` and `normalCost` below are summations; evaluating them as written
would build a stack as deep as the counter is long, so they are given
accumulator implementations, registered with `@[csimp]` (kernel-checked).
-/

def costTAux : List LD → Nat → Nat → Nat
  | _, 0, acc => acc
  | [], _, acc => acc
  | d :: w, t, acc => costTAux w (carries d t) (acc + wt d * t)

theorem costTAux_eq : ∀ (w : List LD) (t acc : Nat), costTAux w t acc = acc + costT w t
  | w, 0, acc => by cases w <;> simp [costTAux]
  | [], t + 1, acc => by simp [costTAux]
  | d :: w, t + 1, acc => by
      rw [show costTAux (d :: w) (t + 1) acc
            = costTAux w (carries d (t + 1)) (acc + wt d * (t + 1)) from rfl,
        costTAux_eq w (carries d (t + 1)) (acc + wt d * (t + 1)),
        costT_cons d w (by omega : t + 1 ≠ 0)]
      omega

def costTImpl (w : List LD) (t : Nat) : Nat := costTAux w t 0

@[csimp] theorem costT_eq_costTImpl : @costT = @costTImpl := by
  funext w t
  rw [costTImpl, costTAux_eq]
  omega

/-! ## Reaching a configuration in at least `k` steps -/

/-- `RGE k a b` : the machine goes from `a` to `b` in at least `k` steps. -/
def RGE (k : Nat) (a b : Cfg) : Prop := ∃ n, k ≤ n ∧ run a n = some b

theorem RGE.of_run {a b : Cfg} {n : Nat} (h : run a n = some b) : RGE n a b :=
  ⟨n, Nat.le_refl _, h⟩

theorem RGE.mono {k k' : Nat} {a b : Cfg} (h : RGE k a b) (hk : k' ≤ k) : RGE k' a b := by
  obtain ⟨n, hn, hrun⟩ := h
  exact ⟨n, Nat.le_trans hk hn, hrun⟩

theorem RGE.trans {k m : Nat} {a b c : Cfg} (h₁ : RGE k a b) (h₂ : RGE m b c) :
    RGE (k + m) a c := by
  obtain ⟨n, hn, hrun⟩ := h₁
  obtain ⟨p, hp, hrp⟩ := h₂
  exact ⟨n + p, by omega, run_trans hrun hrp⟩

/-- Nothing halts before the machine has made the steps `RGE` promises. -/
theorem isSome_of_RGE {k : Nat} {c d : Cfg} (hc : init ⟶* c) (h : RGE k c d) :
    ∀ j ≤ k, (run init j).isSome := by
  obtain ⟨m, hm⟩ := hc
  obtain ⟨n, hn, hrun⟩ := h
  intro j hj
  exact isSome_of_run_le (N := m + n) (by rw [run_trans hm hrun]; rfl) (by omega)

/-! ## The cost of one increment -/

/-- **One increment costs `costT w 1` steps.**  This is the sweep theorem
`inc_sweep` of `RequestProject.Macro` with its exact cost attached. -/
theorem inc_sweep_cost {w w' : List LD} (h : Inc w w') :
    ∀ r : List Sym, RGE (costT w 1) ⟨lzz w, St.B, 2 :: r⟩ ⟨lzz w', St.B, 4 :: r⟩ := by
  induction h with
  | d0 w =>
      intro r
      have : costT (LD.d0 :: w) 1 = 4 := by
        rw [costT_cons _ _ (by omega), show carries LD.d0 1 = 0 from rfl]
        simp [wt]
      rw [this]
      exact RGE.of_run (n := 4) rfl
  | @d1 w w' hinc ih =>
      intro r
      have hc : costT (LD.d1 :: w) 1 = 2 + (costT w 1 + 2) := by
        rw [costT_cons _ _ (by omega), show carries LD.d1 1 = 1 from rfl]
        simp [wt]; omega
      rw [hc]
      have h1 : RGE 2 (⟨lzz (LD.d1 :: w), St.B, 2 :: r⟩ : Cfg) ⟨lzz w, St.B, 2 :: 4 :: 4 :: r⟩ :=
        RGE.of_run (n := 2) rfl
      have h3 : RGE 2 (⟨lzz w', St.B, 4 :: 4 :: 4 :: r⟩ : Cfg) ⟨lzz (LD.d0 :: w'), St.B, 4 :: r⟩ :=
        RGE.of_run (rule_44 (lzz w') (4 :: r))
      exact h1.trans ((ih (4 :: 4 :: r)).trans h3)
  | @dB w w' hinc ih =>
      intro r
      have hc : costT (LD.dB :: w) 1 = 4 + (costT w 1 + 4) := by
        rw [costT_cons _ _ (by omega), show carries LD.dB 1 = 1 from rfl]
        simp [wt]; omega
      rw [hc]
      have h1 : RGE 4 (⟨lzz (LD.dB :: w), St.B, 2 :: r⟩ : Cfg) ⟨lzz w, St.B, 2 :: 0 :: 4 :: r⟩ :=
        RGE.of_run (n := 4) rfl
      have h3 : RGE 4 (⟨lzz w', St.B, 4 :: 0 :: 4 :: r⟩ : Cfg) ⟨lzz (LD.dA :: w'), St.B, 4 :: r⟩ :=
        RGE.of_run (rule_40 (lzz w') (4 :: r))
      exact h1.trans ((ih (0 :: 4 :: r)).trans h3)
  | @dA w w' w'' h1' h2' ih1 ih2 =>
      intro r
      have hw' : addT w 1 = some w' := inc_addT_one h1'
      have hc : costT (LD.dA :: w) 1 = 2 + (costT w 1 + (4 + (costT w' 1 + 2))) := by
        rw [costT_cons _ _ (by omega), show carries LD.dA 1 = 1 + 1 from rfl,
          costT_add w 1 1 w' hw']
        simp [wt]; omega
      rw [hc]
      have s1 : RGE 2 (⟨lzz (LD.dA :: w), St.B, 2 :: r⟩ : Cfg) ⟨lzz w, St.B, 2 :: 2 :: 4 :: r⟩ :=
        RGE.of_run (n := 2) rfl
      have s3 : RGE 4 (⟨lzz w', St.B, 4 :: 2 :: 4 :: r⟩ : Cfg) ⟨lzz w', St.B, 2 :: 1 :: 4 :: r⟩ :=
        RGE.of_run (rule_42 (lzz w') (4 :: r))
      have s5 : RGE 2 (⟨lzz w'', St.B, 4 :: 1 :: 4 :: r⟩ : Cfg) ⟨lzz (LD.dB :: w''), St.B, 4 :: r⟩ :=
        RGE.of_run (rule_41 (lzz w'') (4 :: r))
      exact s1.trans ((ih1 (2 :: 4 :: r)).trans (s3.trans ((ih2 (1 :: 4 :: r)).trans s5)))

/-! ## The cost of the normal phase -/

/-- **One cycle of the normal phase costs at least `costT w 1` steps.** -/
theorem normal_cycle_cost {w w' : List LD} (h : Inc w w') :
    RGE (costT w 1) (enc ⟨w, []⟩) (enc ⟨.dB :: w', []⟩) := by
  have s1 : RGE 2 (enc ⟨w, ([] : List Sym)⟩) ⟨lzz w, St.B, [2, 1]⟩ :=
    RGE.of_run (rule00' (lzz w) [] rfl rfl)
  have s2 : RGE (costT w 1) (⟨lzz w, St.B, 2 :: [1]⟩ : Cfg) ⟨lzz w', St.B, 4 :: [1]⟩ :=
    inc_sweep_cost h [1]
  have s3 : RGE 2 (⟨lzz w', St.B, [4, 1]⟩ : Cfg) (enc ⟨LD.dB :: w', []⟩) :=
    RGE.of_run (rule41' (lzz w') [4, 1] rfl rfl)
  exact ((s1.trans (s2.trans s3)).mono (by omega))

/-- The total cost of a normal phase: one `costT w 1` per cycle. -/
def normalCost (w : List LD) : Nat :=
  match h : addT w 1 with
  | some w' => costT w 1 + normalCost (.dB :: w')
  | none => 0
  termination_by gap w
  decreasing_by exact gap_normal_cycle_lt (addT_one_inc h) (addT_one_inc h).gap_pos

/-- **The normal phase started at `w` takes at least `normalCost w` steps.** -/
theorem normal_phase_cost : ∀ w : List LD, ∃ d : Cfg, RGE (normalCost w) (enc ⟨w, []⟩) d
  | w => by
      rw [normalCost]
      cases hone : addT w 1 with
      | none =>
          simp only
          exact ⟨_, RGE.of_run (n := 0) rfl⟩
      | some w' =>
          simp only
          have hinc : Inc w w' := addT_one_inc hone
          have hlt : gap (LD.dB :: w') < gap w := gap_normal_cycle_lt hinc hinc.gap_pos
          obtain ⟨d, hd⟩ := normal_phase_cost (LD.dB :: w')
          exact ⟨d, (normal_cycle_cost hinc).trans hd⟩
  termination_by w => gap w

/-- Tail-recursive implementation of `normalCost`. -/
def normalCostAux (w : List LD) (acc : Nat) : Nat :=
  match h : addT w 1 with
  | some w' => normalCostAux (.dB :: w') (acc + costT w 1)
  | none => acc
  termination_by gap w
  decreasing_by exact gap_normal_cycle_lt (addT_one_inc h) (addT_one_inc h).gap_pos

theorem normalCostAux_eq : ∀ (w : List LD) (acc : Nat),
    normalCostAux w acc = acc + normalCost w
  | w, acc => by
      rw [normalCostAux, normalCost]
      cases hone : addT w 1 with
      | none => simp
      | some w' =>
          simp only
          have hinc : Inc w w' := addT_one_inc hone
          have hlt : gap (LD.dB :: w') < gap w := gap_normal_cycle_lt hinc hinc.gap_pos
          rw [normalCostAux_eq (LD.dB :: w') (acc + costT w 1)]
          omega
  termination_by w => gap w

def normalCostImpl (w : List LD) : Nat := normalCostAux w 0

@[csimp] theorem normalCost_eq_normalCostImpl : @normalCost = @normalCostImpl := by
  funext w
  rw [normalCostImpl, normalCostAux_eq]
  omega

/-! ## A lower bound on the running time -/

/-- The counter at the start of the normal phase of the `n`-th revolution. -/
def lastCounter (n : Nat) : Option (List LD) :=
  (revIter n).bind (fun L => (resetF [.d0] L).bind junctionF)

theorem lastCounter_reaches : ∀ {n : Nat} {w : List LD}, lastCounter n = some w →
    init ⟶* enc ⟨w, []⟩ := by
  intro n w h
  rw [lastCounter] at h
  cases hL : revIter n with
  | none => rw [hL] at h; simp at h
  | some L =>
      rw [hL] at h
      simp only [Option.bind_some] at h
      cases hr : resetF [LD.d0] L with
      | none => rw [hr] at h; simp at h
      | some w0 =>
          rw [hr] at h
          simp only [Option.bind_some] at h
          have hfirst : MStep (phaseStart L) ⟨[LD.d0], cellsOf L ++ [1]⟩ :=
            MStep.a44 (r := 4 :: 4 :: (cellsOf L ++ [1])) rfl rfl
          have hsteps : MSteps (phaseStart L) ⟨w, []⟩ :=
            ((MSteps.single hfirst).trans (resetF_spec hr [1])).trans (junctionF_spec h)
          exact (revIter_reaches hL).trans hsteps.sim

/-- A lower bound on the number of steps the machine makes without halting:
the cost of the normal phase of the `n`-th revolution. -/
def stepBound (n : Nat) : Nat :=
  match lastCounter n with
  | some w => normalCost w
  | none => 0

/-- **The machine does not halt during its first `stepBound n` steps.** -/
theorem no_halt_before_stepBound (n : Nat) : ∀ j ≤ stepBound n, (run init j).isSome := by
  rw [stepBound]
  cases h : lastCounter n with
  | none => intro j hj; simp only [Nat.le_zero] at hj; subst hj; rfl
  | some w =>
      simp only
      obtain ⟨d, hd⟩ := normal_phase_cost w
      exact isSome_of_RGE (lastCounter_reaches h) hd

end SOC
