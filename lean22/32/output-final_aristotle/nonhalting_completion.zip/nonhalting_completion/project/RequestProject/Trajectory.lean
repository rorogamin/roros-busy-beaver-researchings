import Mathlib
import RequestProject.Shape
import RequestProject.Inherit

/-!
# The fresh material is no more expensive than the phase that created it

`RequestProject.Inherit` reduces the halting question to the *fresh* blocks of
each revolution: the blocks the junction and the normal phase create, which the
next reset phase has to absorb (`FreshSafe`).

This file removes the need for any density or equidistribution statement about
those blocks, by comparing the **two counters** involved:

* the counter of the *previous* normal phase, which is being spent — its
  remaining capacity `g` is divided by about `3/2` at every cycle,
  `g ↦ ⌊(2g-1)/3⌋`;
* the counter of the *next* reset phase, which is being built — its capacity `G`
  is multiplied by about `2` at a block `44`, `04`, `24` and by about `2/3` at a
  block `14`.

Each fresh block is released by the digit one cycle pushed, so the two runs are
in **one-to-one correspondence**: a fresh block `14` can only appear where the
old counter also paid a factor `2/3`.  Hence the ratio `G / g` never decreases,
and the domination

```
28 * g + 9  ≤  G
```

is preserved along the whole fresh part (`normalF_fresh`).  Since a block `14`
needs a gap of `8` and the next junction needs a gap of `9`, the domination is
all that the reset phase needs: **the fresh part is safe as soon as the counter
rebuilt by the inherited blocks dominates the counter that produced them**
(`freshSafe_of_gapRatio`, `neverHalts_of_gapRatio_from`).
-/

namespace SOC

/-! ## Lower bounds for one block of the reset phase -/

/-- Whatever the block, a reset-phase step keeps `3 · gnext G x + 19 ≥ 2 · G`:
the blocks `44`, `04`, `24` roughly double the gap, and the block `14` — the
worst one — keeps two thirds of it, less the four decrements it performs. -/
theorem gnext_lb (G : ℕ) (x : Sym) : 2 * G ≤ 3 * gnext G x + 19 := by
  rcases sym_cases x with rfl | rfl | rfl | rfl | rfl <;> simp only [gnext_0, gnext_1, gnext_2,
    gnext_3, gnext_4] <;> omega

/-! ## The fresh blocks of a normal phase -/

/--
**The fresh blocks are safe for any counter that dominates the one which created
them.**

If the normal phase of a counter `w` releases the blocks `S ++ M`, where `S` has
one block per digit of `w`, then `M` — one block per cycle of the phase — is
safe for a reset phase whose gap `G` satisfies `28 · gap w + 9 ≤ G`, and leaves
that reset phase with a gap of at least `9`.

The induction is the correspondence between the two counters: one cycle sends
the old capacity `g` to `⌊(2g-1)/3⌋` and pushes the digit that will be released
as the next fresh block, while absorbing that block sends the new capacity `G`
to at least `(2G-19)/3` — and `28` is exactly the factor that makes the second
bound dominate the first.
-/
theorem normalF_fresh : ∀ {w : List LD} {acc L : List Sym}, normalF w acc = some L →
    ∃ S M, L = S ++ M ++ acc ∧ S.map is4 = (w.map rad2).reverse ∧ (∀ x ∈ S, Label x) ∧
      ∀ G : ℕ, 28 * gap w + 9 ≤ G → SafeRun G M ∧ 9 ≤ gfold G M
  | w, acc, L, h => by
      rw [normalF] at h
      cases hone : addT w 1 with
      | none =>
          rw [hone] at h
          simp only at h
          obtain ⟨S, hL, hS⟩ := ovfF_pat h
          obtain ⟨L0, hL0, hlab0, -⟩ := ovfF_spec h
          have hSL0 : S = L0 := by
            have hcat : S ++ acc = L0 ++ acc := by rw [← hL, ← hL0]
            exact List.append_cancel_right hcat
          refine ⟨S, [], by simpa using hL, hS, by rw [hSL0]; exact hlab0, ?_⟩
          intro G hG
          exact ⟨trivial, by simpa using (by omega : 9 ≤ G)⟩
      | some w' =>
          rw [hone] at h
          simp only at h
          have hinc : Inc w w' := addT_one_inc hone
          have hlt : gap (LD.dB :: w') < gap w := gap_normal_cycle_lt hinc hinc.gap_pos
          obtain ⟨S, M, hL, hS, hlab, hprop⟩ := normalF_fresh h
          -- `S` is one block longer than the pattern of `w`: the fresh digit `03`
          have hSlen : S.length = w.length + 1 := by
            have := congrArg List.length hS
            simpa [addT_length hone] using this
          have hne : S ≠ [] := by
            intro hnil
            rw [hnil] at hSlen
            simp at hSlen
          have hsplit : S = S.dropLast ++ [S.getLast hne] := (List.dropLast_append_getLast _).symm
          set y := S.getLast hne with hy
          have hmap : (S.dropLast).map is4 ++ [is4 y] = (w'.map rad2).reverse ++ [false] := by
            have h0 : (S.dropLast ++ [y]).map is4 = ((LD.dB :: w').map rad2).reverse := by
              rw [← hsplit]; exact hS
            simpa [rad2] using h0
          have hlast : is4 y = false := by
            have := congrArg (fun l => l.getLast?) hmap
            simpa using this
          have hy4 : y ≠ 4 := by
            intro h4
            rw [h4] at hlast
            simp [is4] at hlast
          have hpre : (S.dropLast).map is4 = (w.map rad2).reverse := by
            have h1 : (S.dropLast).map is4 ++ [is4 y] = (w.map rad2).reverse ++ [false] := by
              rw [hmap, addT_rad2 hone]
            have hlen2 : ((S.dropLast).map is4).length = ((w.map rad2).reverse).length := by
              simp [hSlen]
            exact List.append_inj_left h1 hlen2
          have hylab : Label y := hlab y (by rw [hsplit]; simp)
          clear_value y
          refine ⟨S.dropLast, y :: M, ?_, hpre, ?_, ?_⟩
          · rw [hL]
            conv_lhs => rw [hsplit]
            simp
          · intro x hx
            exact hlab x (by rw [hsplit]; exact List.mem_append_left _ hx)
          · intro G hG
            have hgap : gap w = gap w' + 1 := hinc.gap_eq
            have hkey : 28 * gap (LD.dB :: w') + 9 ≤ gnext G y := by
              simp only [gap_dB]
              rcases hylab with rfl | rfl | rfl | rfl
              · exact absurd rfl hy4
              · simp only [gnext_0]; omega
              · simp only [gnext_2]; omega
              · simp only [gnext_1]; omega
            obtain ⟨hsafe', h9'⟩ := hprop (gnext G y) hkey
            exact ⟨⟨fun _ => by omega, fun _ => by omega, hsafe'⟩, h9'⟩
  termination_by w => gap w

/-! ## The junction -/

/-- **The junction divides the counter's capacity by about `9/2`.**  It pops the
lowest digit, performs four increments and pushes two radix-3/2 digits. -/
theorem junction_gap_bound : ∀ {w w' : List LD}, junctionF w = some w' →
    9 * gap w' ≤ 2 * gap w + 2
  | [], _, h => by simp at h
  | .dA :: v, _, h => by simp at h
  | .dB :: v, _, h => by simp at h
  | .d1 :: v, w', h => by
      rw [junctionF] at h
      cases hfour : addT v 4 with
      | none => rw [hfour] at h; simp at h
      | some v' =>
          rw [hfour] at h
          simp only [Option.map_some, Option.some.injEq] at h
          subst h
          obtain ⟨v1, v2, v3, e1, e2, e3, e4⟩ := addT_four hfour
          have h1 := e1.gap_eq
          have h2 := e2.gap_eq
          have h3 := e3.gap_eq
          have h4 := e4.gap_eq
          simp only [gap_d1, gap_dA]
          omega
  | .d0 :: v, w', h => by
      rw [junctionF] at h
      cases hfour : addT v 4 with
      | none => rw [hfour] at h; simp at h
      | some v' =>
          rw [hfour] at h
          simp only [Option.map_some, Option.some.injEq] at h
          subst h
          obtain ⟨v1, v2, v3, e1, e2, e3, e4⟩ := addT_four hfour
          have h1 := e1.gap_eq
          have h2 := e2.gap_eq
          have h3 := e3.gap_eq
          have h4 := e4.gap_eq
          simp only [gap_d0, gap_dA, gap_dB]
          omega

/-! ## The domination condition -/

/-- The capacity of the counter that the reset phase of `L` builds. -/
def resetGap (L : List Sym) : ℕ := (resetF [LD.d0] L).elim 0 gap

/--
`GapRatio L L'` : the counter that the **inherited** blocks of `L'` rebuild is at
least `14` times as large as the counter `L` itself built.

The factor `14` pays for the junction (which divides the capacity by about
`9/2`, while the two blocks it creates only multiply it by at least `4/9`) and
for the constant `28` of `normalF_fresh`.
-/
def GapRatio (L L' : List Sym) : Prop :=
  14 * resetGap L + 58 ≤ gfold 1 (L'.take L.length)

instance (L L' : List Sym) : Decidable (GapRatio L L') := by
  unfold GapRatio; infer_instance

/--
**The fresh material is safe as soon as the inherited material dominates.**

If one revolution turns `L` into `L'` and the counter rebuilt by the inherited
blocks of `L'` is at least `14` times the counter `L` built, then the fresh
blocks of `L'` — the two created by the junction and one per cycle of the normal
phase — are safe for it, and leave it able to perform the next junction.

No density and no information about the individual fresh blocks is used: each of
them was created by a cycle in which the *old* counter paid at least as much.
-/
theorem freshSafe_of_gapRatio {L L' : List Sym} (h : revolutionF L = some L')
    (hG : GapRatio L L') : FreshSafe L L' := by
  rw [revolutionF] at h
  cases hreset : resetF [LD.d0] L with
  | none => rw [hreset] at h; simp at h
  | some w =>
      rw [hreset] at h
      simp only [Option.bind_some] at h
      cases hjunc : junctionF w with
      | none => rw [hjunc] at h; simp at h
      | some wj =>
          rw [hjunc] at h
          simp only [Option.bind_some] at h
          obtain ⟨S, M, hL, hS, -, hprop⟩ := normalF_fresh h
          rw [List.append_nil] at hL
          have hw : w.map rad2 = true :: (L.map notOne).reverse := by
            rw [resetF_pat hreset, show ([LD.d0] : List LD).map rad2 = true :: [] from rfl,
              patF_true]
            simp
          have hw' : wj.map rad2 = false :: false :: (L.map notOne).reverse := by
            rw [junctionF_pat hjunc, hw]
            simp
          have hSmap : S.map is4 = L.map notOne ++ [false, false] := by
            rw [hS, hw']; simp
          have hSlen : S.length = L.length + 2 := by
            have := congrArg List.length hSmap
            simpa using this
          have hdlen : (S.drop L.length).length = 2 := by simp [hSlen]
          obtain ⟨b1, b2, hb⟩ := List.length_eq_two.1 hdlen
          have hdrop : L'.drop L.length = b1 :: b2 :: M := by
            rw [hL, List.drop_append_of_le_length (by omega), hb]
            simp
          have hG' : 14 * gap w + 58 ≤ gfold 1 (L'.take L.length) := by
            rw [GapRatio, resetGap, hreset] at hG
            simpa using hG
          have hlb1 := gnext_lb (gfold 1 (L'.take L.length)) b1
          have hlb2 := gnext_lb (gnext (gfold 1 (L'.take L.length)) b1) b2
          have hjg := junction_gap_bound hjunc
          have hkey : 28 * gap wj + 9 ≤
              gnext (gnext (gfold 1 (L'.take L.length)) b1) b2 := by omega
          obtain ⟨hsafeM, h9M⟩ := hprop _ hkey
          refine ⟨?_, ?_⟩
          · rw [hdrop]
            exact ⟨fun _ => by omega, fun _ => by omega, fun _ => by omega, fun _ => by omega,
              hsafeM⟩
          · rw [hdrop]
            exact h9M

end SOC
