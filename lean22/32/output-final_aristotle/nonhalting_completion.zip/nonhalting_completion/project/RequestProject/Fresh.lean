import Mathlib
import RequestProject.Shape
import RequestProject.Reduction

/-!
# The density question, reduced to the fresh material

`RequestProject.Reduction` reduces the halting question to a density statement
about **every** block sequence the machine releases: in each of them the
expensive blocks `14` must stay below the density `3/5` in every prefix.

`RequestProject.Shape` shows that a released sequence `L'` splits as `S ++ M`
where `S` has one block per block of the previous sequence `L` and carries a
block `14` only where `L` already had one, while `M` — the part created by the
junction and the normal phase — is fresh.  So the density of the inherited part
`S` needs no new argument: it is controlled by the density of `L`.

What is left to check is the fresh part, *with the credit* the inherited part
has accumulated.  This is `FreshDense L L'`:

```
for every prefix v of the fresh part of L' :
    5 · ones (L.drop 7 ++ v)  ≤  3 · |L.drop 7 ++ v|
```

i.e. the old sequence followed by the fresh blocks still has its blocks `14`
below the density `3/5`.  `neverHalts_of_fresh_dense`: if that holds at every
revolution, the machine never halts.

The credit is what makes this weaker than the previous hypothesis: the fresh
part alone starts with a block `14` often enough (a prefix density of `1` at its
first block), so the inherited blocks must be allowed to pay for it — and they
can, since the inherited part is long and its blocks `14` are sparse.
-/

namespace SOC

/-! ## Two list lemmas -/

/-- A prefix of a concatenation either stays inside the first part or covers it
entirely. -/
theorem prefix_append_cases {α : Type*} {A B u : List α} (h : u <+: A ++ B) :
    u <+: A ∨ ∃ t, u = A ++ t ∧ t <+: B := by
  have hu : u = (A ++ B).take u.length := List.prefix_iff_eq_take.1 h
  set n := u.length with hn
  rw [List.take_append] at hu
  by_cases hlen : n ≤ A.length
  · left
    rw [List.prefix_iff_eq_take, ← hn, hu, Nat.sub_eq_zero_of_le hlen]
    simp
  · right
    refine ⟨B.take (n - A.length), ?_, List.take_prefix _ _⟩
    rw [hu, List.take_of_length_le (by omega)]

/-- The density condition `Dense 2 3`, cleared of the truncated subtraction. -/
theorem dense23_le_iff (s : List Sym) :
    2 * ones s ≤ 3 * (s.length - ones s) ↔ 5 * ones s ≤ 3 * s.length := by
  have := ones_le_length s
  omega

theorem leadRun_le_length (L : List Sym) : leadRun L ≤ L.length :=
  (List.takeWhile_prefix _).length_le

/-! ## The condition on the fresh material -/

/--
`FreshDense L L'` : in the sequence `L'` released after `L`, every prefix `v` of
the **fresh** part — what follows the `|L|` inherited blocks — keeps the blocks
`14` of `L.drop 7 ++ v` below the density `3/5`.
-/
def FreshDense (L L' : List Sym) : Prop :=
  ∀ v, v <+: L'.drop L.length → 5 * ones (L.drop 7 ++ v) ≤ 3 * (L.drop 7 ++ v).length

/--
**The inherited part needs no check.**

If at every revolution the fresh material satisfies `FreshDense`, then every
block sequence the machine releases has its blocks `14` below the density `3/5`
in every prefix of the part after the seventh block.
-/
theorem revIter_dense35_of_fresh
    (hfresh : ∀ n L L', revIter n = some L → revIter (n + 1) = some L' → FreshDense L L') :
    ∀ n L, revIter n = some L → Dense 2 3 (L.drop 7)
  | 0, L, hL => by
      rw [revIter] at hL
      cases hL
      decide
  | n + 1, L', hL' => by
      cases hprev : revIter n with
      | none => rw [revIter, hprev] at hL'; simp at hL'
      | some L =>
          have hrev : revolutionF L = some L' := by
            rw [revIter, hprev] at hL'
            simpa using hL'
          have hIH : Dense 2 3 (L.drop 7) := revIter_dense35_of_fresh hfresh n L hprev
          have hF : FreshDense L L' := hfresh n L L' hprev hL'
          obtain ⟨S, M, rfl, hS, -⟩ := revolutionF_shape hrev
          have hlen : S.length = L.length := length_eq_of_shape hS
          have h7 : 7 ≤ L.length := le_trans (revIter_leadRun hprev) (leadRun_le_length L)
          have h7S : 7 ≤ S.length := by omega
          -- the two halves of the released sequence
          have hdrop7 : (S ++ M).drop 7 = S.drop 7 ++ M := by
            rw [List.drop_append_of_le_length h7S]
          have hfreshM : (S ++ M).drop L.length = M := by
            rw [← hlen, List.drop_left]
          -- the inherited part carries the pattern of `L`
          have hSdrop : (S.drop 7).map is4 = (L.drop 7).map notOne := by
            rw [List.map_drop, List.map_drop, hS]
          have hSdroplen : (S.drop 7).length = (L.drop 7).length := by simp [hlen]
          intro s hs
          have hpre : s <+: S.drop 7 ++ M := by
            have := (List.mem_inits _ _).1 hs
            rwa [hdrop7] at this
          rw [dense23_le_iff]
          rcases prefix_append_cases hpre with hin | ⟨v, rfl, hv⟩
          · -- the prefix stays inside the inherited part
            have hjle : s.length ≤ (L.drop 7).length := by
              have := hin.length_le
              omega
            set j := s.length with hj
            have hstake : s = (S.drop 7).take j := List.prefix_iff_eq_take.1 hin
            have hmap : s.map is4 = ((L.drop 7).take j).map notOne := by
              rw [List.map_take, ← hSdrop, ← List.map_take, ← hstake]
            have hones : ones s ≤ ones ((L.drop 7).take j) := ones_le_of_shape hmap
            have hIHs := hIH _ ((List.mem_inits _ _).2 (List.take_prefix j (L.drop 7)))
            rw [dense23_le_iff] at hIHs
            have hlent : ((L.drop 7).take j).length = j := by
              simp only [List.length_take]
              omega
            rw [hlent] at hIHs
            omega
          · -- the prefix reaches into the fresh part
            have hvM : v <+: (S ++ M).drop L.length := by rw [hfreshM]; exact hv
            have hFv := hF v hvM
            rw [ones_append, List.length_append] at hFv
            rw [ones_append, List.length_append]
            have hones : ones (S.drop 7) ≤ ones (L.drop 7) := ones_le_of_shape hSdrop
            omega

/--
**Non-halting, reduced to the fresh material.**

If at every revolution the freshly created blocks keep the density of the blocks
`14` below `3/5` — counted together with the whole previous sequence, which
supplies the credit — then `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never halts.
-/
theorem neverHalts_of_fresh_dense
    (hfresh : ∀ n L L', revIter n = some L → revIter (n + 1) = some L' → FreshDense L L') :
    NeverHalts :=
  neverHalts_of_tail_dense35 (revIter_dense35_of_fresh hfresh)

end SOC
