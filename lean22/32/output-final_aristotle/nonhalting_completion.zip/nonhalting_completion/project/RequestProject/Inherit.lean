import Mathlib
import RequestProject.Shape
import RequestProject.Success

/-!
# The inherited part of a released sequence is safe for free

`RequestProject.Shape` proves that a released block sequence `L'` splits as
`S ++ M`, where the inherited part `S` carries a block `44` at exactly those
positions where the previous sequence `L` carries a block different from `14`,
and the fresh part `M` is what the junction and the normal phase created.

Here that is turned into an *exact* statement about the counter, with no density
and no approximation.  The point is a pointwise domination: at every position,
the block of `S` treats the counter at least as well as the block of `L` at the
same position —

```
where L has 44, 04 or 24, S has 44 :   g ↦ 2g+1,   the best of all blocks;
where L has 14,            S has one of 04, 24, 14,
                                        each at least as good as 14,
                                        and there the counter has gap ≥ 8.
```

Since `gnext` is monotone in the gap, the gap along `S` never falls below the
gap along `L` (`safeRun_gfold_of_shape`), and the blocks `14` of `S` sit at
positions where `L` already had one — where the safety of `L` guarantees a gap
of at least `8`.  So:

> **the reset phase can only fail in the fresh part** (`neverHalts_of_fresh_safe`).

This is the sharpest form of the reduction: the density criteria of
`RequestProject.Density` and `RequestProject.Fresh` are sufficient conditions for
the hypothesis used here.
-/

namespace SOC

/-! ## Pointwise domination of the blocks -/

/-- `44` is the best block for the counter. -/
theorem gnext_le_four (g : ℕ) (x : Sym) : gnext g x ≤ gnext g 4 := by
  rcases sym_cases x with rfl | rfl | rfl | rfl | rfl <;> simp <;> omega

/-- `14` is the worst block for the counter, once the counter can afford it. -/
theorem gnext_one_le {g : ℕ} (hg : 8 ≤ g) (y : Sym) : gnext g 1 ≤ gnext g y := by
  rcases sym_cases y with rfl | rfl | rfl | rfl | rfl <;> simp <;> omega

/--
**The inherited part of a released sequence is at least as good as the sequence
it comes from.**

If `S` carries a `44` exactly where `L` carries a block different from `14`, and
`L` is safe for a counter of gap `g`, then `S` is safe for any counter of gap at
least `g`, and the gap it builds is at least the gap `L` builds.
-/
theorem safeRun_gfold_of_shape : ∀ {S L : List Sym} {g g' : ℕ}, S.map is4 = L.map notOne →
    SafeRun g L → g ≤ g' → SafeRun g' S ∧ gfold g L ≤ gfold g' S
  | [], [], g, g', _, _, hgg => ⟨trivial, hgg⟩
  | [], x :: L, _, _, h, _, _ => by simp at h
  | y :: S, [], _, _, h, _, _ => by simp at h
  | y :: S, x :: L, g, g', h, hsafe, hgg => by
      simp only [List.map_cons, List.cons.injEq] at h
      obtain ⟨h1, h2⟩ := h
      obtain ⟨hs1, hs2, hs3⟩ := hsafe
      by_cases hx : x = 1
      · -- the previous sequence had a block `14` here: the counter can afford it
        subst hx
        have hg8 : 8 ≤ g := hs1 rfl
        have hg8' : 8 ≤ g' := le_trans hg8 hgg
        have hstep : gnext g 1 ≤ gnext g' y :=
          le_trans (gnext_mono hgg 1) (gnext_one_le hg8' y)
        obtain ⟨hS, hgap⟩ := safeRun_gfold_of_shape h2 hs3 hstep
        exact ⟨⟨fun _ => hg8', fun _ => by omega, hS⟩, hgap⟩
      · -- everywhere else the inherited block is a `44`
        have hy : y = 4 := is4_eq_true.1 (by rw [h1]; simp [notOne, hx])
        subst hy
        have hstep : gnext g x ≤ gnext g' 4 :=
          le_trans (gnext_mono hgg x) (gnext_le_four g' x)
        obtain ⟨hS, hgap⟩ := safeRun_gfold_of_shape h2 hs3 hstep
        exact ⟨⟨fun hc => absurd hc (by decide), fun hc => absurd hc (by decide), hS⟩, hgap⟩

/-! ## What is left: the fresh material -/

/--
`FreshSafe L L'` : in the released sequence `L'`, the fresh blocks — those
beyond the `|L|` inherited ones — are safe for the counter the inherited part
has built, and leave it able to perform one more increment.
-/
def FreshSafe (L L' : List Sym) : Prop :=
  SafeRun (gfold 1 (L'.take L.length)) (L'.drop L.length) ∧
    9 ≤ gfold (gfold 1 (L'.take L.length)) (L'.drop L.length)

/-- **Safety propagates through the inherited part.** -/
theorem safeRun_revolutionF {L L' : List Sym} (h : revolutionF L = some L')
    (hL : SafeRun 1 L) (hfresh : FreshSafe L L') : SafeRun 1 L' ∧ 9 ≤ gfold 1 L' := by
  obtain ⟨S, M, rfl, hS, -⟩ := revolutionF_shape h
  have hlen : S.length = L.length := length_eq_of_shape hS
  have htake : (S ++ M).take L.length = S := by rw [← hlen, List.take_left]
  have hdrop : (S ++ M).drop L.length = M := by rw [← hlen, List.drop_left]
  obtain ⟨hsafeM, hgapM⟩ := hfresh
  rw [htake] at hsafeM hgapM
  rw [hdrop] at hsafeM hgapM
  obtain ⟨hsafeS, -⟩ := safeRun_gfold_of_shape hS hL (le_refl 1)
  exact ⟨safeRun_append hsafeS hsafeM, by rw [gfold_append]; exact hgapM⟩

/--
**Non-halting, reduced to the fresh material — exact form.**

If at every revolution the freshly created blocks are safe for the counter that
the inherited blocks have built, then `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never
halts.  Nothing has to be checked about the inherited blocks: they can only
treat the counter better than the blocks they come from.
-/
theorem neverHalts_of_fresh_safe
    (h : ∀ n L L', revIter n = some L → revIter (n + 1) = some L' → FreshSafe L L') :
    NeverHalts := by
  refine neverHalts_of_revIter_safe ?_
  intro n
  induction n with
  | zero =>
      intro L hL
      rw [revIter] at hL
      cases hL
      exact ⟨firstBlocks_safe, by decide⟩
  | succ n ih =>
      intro L' hL'
      cases hprev : revIter n with
      | none => rw [revIter, hprev] at hL'; simp at hL'
      | some L =>
          have hrev : revolutionF L = some L' := by
            rw [revIter, hprev] at hL'
            simpa using hL'
          obtain ⟨hsafe, -⟩ := ih L hprev
          exact safeRun_revolutionF hrev hsafe (h n L L' hprev hL')

end SOC
