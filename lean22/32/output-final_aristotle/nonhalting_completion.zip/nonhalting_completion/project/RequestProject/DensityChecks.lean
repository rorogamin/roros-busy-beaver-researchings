import RequestProject.Density
import RequestProject.SecondPhase
import RequestProject.ThirdPhase

/-!
# The density criterion on the sequences the machine really releases

`RequestProject.Density` proves that a block sequence which first builds a gap
of at least `T` and then keeps the blocks `14` below the density `q / (p + q)`
in every prefix is safe.  Here the criterion is checked on the three block
sequences that have been verified from the tape: those released by the first
three overflows, at steps `306`, `3139` and `502644`.

All three pass, with either of the two admissible settings of the parameters:

| sequence | blocks | split | gap built | tail |
|---|---|---|---|---|
| `firstBlocks`  | 7 | 6 | 122 | 1 |
| `secondBlocks` | 17 | 6 (density `1/2`) | 127 | 11 |
| `secondBlocks` | 17 | 8 (density `3/5`) | 510 | 9 |
| `thirdBlocks`  | 39 | 6 (density `1/2`) | 127 | 33 |
| `thirdBlocks`  | 39 | 8 (density `3/5`) | 511 | 31 |

So the criterion is not vacuous: it is satisfied by the block sequences the
machine actually produces, and with a wide margin (the real density of blocks
`14` is about `0.21`).
-/

namespace SOC

/-! ## The half-density criterion (`T = 105`, density `1/2`) -/

theorem secondBlocks_evDense : EvDense 105 1 1 secondBlocks :=
  ⟨[4, 4, 4, 4, 4, 4], [4, 0, 2, 0, 0, 0, 2, 1, 2, 1, 0], rfl, by decide, by decide, by decide⟩

theorem thirdBlocks_evDense : EvDense 105 1 1 thirdBlocks :=
  ⟨[4, 4, 4, 4, 4, 4],
    [4, 4, 4, 4, 4, 4, 4, 1, 4, 2, 4, 2, 0, 0, 0, 2, 1, 1, 2, 2, 1, 1, 1, 0, 1, 2, 0, 2, 0,
      2, 2, 1, 0], rfl, by decide, by decide, by decide⟩

/-! ## The sharper criterion (`T = 300`, density `3/5`) -/

theorem secondBlocks_evDense35 : EvDense 300 2 3 secondBlocks :=
  ⟨[4, 4, 4, 4, 4, 4, 4, 0], [2, 0, 0, 0, 2, 1, 2, 1, 0], rfl, by decide, by decide, by decide⟩

theorem thirdBlocks_evDense35 : EvDense 300 2 3 thirdBlocks :=
  ⟨[4, 4, 4, 4, 4, 4, 4, 4],
    [4, 4, 4, 4, 4, 1, 4, 2, 4, 2, 0, 0, 0, 2, 1, 1, 2, 2, 1, 1, 1, 0, 1, 2, 0, 2, 0,
      2, 2, 1, 0], rfl, by decide, by decide, by decide⟩

/-! ## The resulting non-halting criteria -/

/--
**Non-halting from the density `3/5`.**

The machine reaches the reset phase of `secondBlocks` after `3139` steps, and
that sequence passes the criterion with the threshold `300`.  So the machine
never halts as soon as every sequence it releases from then on splits into a
part building a gap of `300` and a tail in which the blocks `14` never make up
more than three fifths of a prefix.

The critical density is `log 2 / log 3 ≈ 0.6309`, so `3/5` is close to the best
a density argument of this kind can give; the density actually observed is about
`0.21`.
-/
theorem neverHalts_of_evDense35
    (hclosed : ∀ L L', (∀ x ∈ L, Label x) → EvDense 300 2 3 L → SuperStep L L' →
      EvDense 300 2 3 L') : NeverHalts :=
  neverHalts_of_evDense (by norm_num) (by norm_num) ratio_three_fifths secondBlocks
    (reaches_of_run run_init_3139) secondBlocks_labels secondBlocks_evDense35 hclosed

end SOC
