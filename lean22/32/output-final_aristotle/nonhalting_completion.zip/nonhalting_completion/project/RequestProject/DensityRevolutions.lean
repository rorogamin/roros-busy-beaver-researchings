import RequestProject.Density
import RequestProject.Fast

/-!
# The density criterion along the machine's own revolutions

`RequestProject.Fast` computes the block sequences of the successive reset
phases (`revIter`), and `RequestProject.Density` gives a criterion — a leading
part building a gap of at least `105`, then a tail in which the blocks `14`
never make up more than half of a prefix — under which a reset phase is safe.

Here the criterion is checked, inside Lean, on the sequences the machine really
releases: the first eleven of them all pass, always with the same split after six
blocks (the first six blocks build a gap of `127`).  The worst prefix density of
blocks `14` in those tails is about `0.23`, far below the admissible `0.5`.

This does not settle the halting question — that needs the criterion for *all*
revolutions — but it shows that the invariant of `neverHalts_of_evHalfDense`
is the one the machine actually maintains.
-/

namespace SOC

/-- A decidable form of `EvDense` with the split point given explicitly. -/
def evDenseB (T p q j : ℕ) (L : List Sym) : Bool :=
  decide (SafeRun 1 (L.take j)) && decide (T ≤ gfold 1 (L.take j)) && denseB p q (L.drop j)

/-- **The explicit test implies the criterion.** -/
theorem evDense_of_evDenseB {T p q j : ℕ} {L : List Sym} (h : evDenseB T p q j L = true) :
    EvDense T p q L := by
  rw [evDenseB, Bool.and_eq_true, Bool.and_eq_true, decide_eq_true_eq, decide_eq_true_eq] at h
  obtain ⟨⟨hsafe, hgap⟩, hdense⟩ := h
  exact ⟨L.take j, L.drop j, (List.take_append_drop j L).symm, hsafe, hgap,
    dense_of_denseB hdense⟩

/-- The test, applied to the first `N + 1` block sequences of the machine. -/
def revDenseOK (N : ℕ) : Bool :=
  (List.range (N + 1)).all fun n =>
    match revIter n with
    | some L => evDenseB 105 1 1 6 L
    | none => false

/-- **The first eleven released block sequences satisfy the half-density
criterion.**  Checked by compiled evaluation inside Lean. -/
theorem revDenseOK_10 : revDenseOK 10 = true := by native_decide

/-- **Every one of the machine's first eleven reset phases is covered by the
density criterion**: its block sequence splits after six blocks into a part
building a gap of `127` and a tail whose blocks `14` never exceed half of a
prefix. -/
theorem revIter_evDense (n : ℕ) (hn : n ≤ 10) {L : List Sym} (h : revIter n = some L) :
    EvDense 105 1 1 L := by
  have hall := revDenseOK_10
  rw [revDenseOK, List.all_eq_true] at hall
  have hmem : n ∈ List.range 11 := List.mem_range.2 (by omega)
  have := hall n hmem
  rw [h] at this
  exact evDense_of_evDenseB this

end SOC
