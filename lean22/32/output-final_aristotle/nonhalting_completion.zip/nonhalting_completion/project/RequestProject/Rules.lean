import RequestProject.Machine

/-!
# Local ("macro") rules for `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA`

All the rules below are statements about *arbitrary* contexts `l` (the tape to the
left of the head, nearest cell first) and `r` (the tape to the right of the head):
they describe what the machine does to a bounded window of the tape, whatever the
rest of the tape looks like.

Throughout, a configuration `⟨l, B, x :: y :: r⟩` is drawn as `l |B> x y r` and
corresponds to the notation `… B> x y …` of the informal analysis.
-/

namespace SOC

open Cfg

/-! ## The eight "head moves right / stays" rules

These need no information at all about the tape to the left of the head. -/

/-- `B> 44  ⟶  02 B>` (2 steps). -/
theorem rule_44 (l r : List Sym) :
    run ⟨l, St.B, 4 :: 4 :: r⟩ 2 = some ⟨2 :: 0 :: l, St.B, r⟩ := rfl

/-- `B> 04  ⟶  22 B>` (2 steps). -/
theorem rule_04 (l r : List Sym) :
    run ⟨l, St.B, 0 :: 4 :: r⟩ 2 = some ⟨2 :: 2 :: l, St.B, r⟩ := rfl

/-- `B> 41  ⟶  03 B>` (2 steps). -/
theorem rule_41 (l r : List Sym) :
    run ⟨l, St.B, 4 :: 1 :: r⟩ 2 = some ⟨3 :: 0 :: l, St.B, r⟩ := rfl

/-- `B> 01  ⟶  23 B>` (2 steps). -/
theorem rule_01 (l r : List Sym) :
    run ⟨l, St.B, 0 :: 1 :: r⟩ 2 = some ⟨3 :: 2 :: l, St.B, r⟩ := rfl

/-- `B> 40  ⟶  23 B>` (4 steps). -/
theorem rule_40 (l r : List Sym) :
    run ⟨l, St.B, 4 :: 0 :: r⟩ 4 = some ⟨3 :: 2 :: l, St.B, r⟩ := rfl

/-- `B> 02  ⟶  B> 20` (2 steps, the head does not move). -/
theorem rule_02 (l r : List Sym) :
    run ⟨l, St.B, 0 :: 2 :: r⟩ 2 = some ⟨l, St.B, 2 :: 0 :: r⟩ := rfl

/-- `B> 00  ⟶  B> 21` (2 steps, the head does not move). -/
theorem rule_00 (l r : List Sym) :
    run ⟨l, St.B, 0 :: 0 :: r⟩ 2 = some ⟨l, St.B, 2 :: 1 :: r⟩ := rfl

/-- `B> 42  ⟶  B> 21` (4 steps, the head does not move). -/
theorem rule_42 (l r : List Sym) :
    run ⟨l, St.B, 4 :: 2 :: r⟩ 4 = some ⟨l, St.B, 2 :: 1 :: r⟩ := rfl

/-! ## The leftward sweep

In state `B`, symbols `2` and `3` make the head move left, rewriting `2 ↦ 4` and
`3 ↦ 2`.  This is the "`<`" (decrement) operation of the informal analysis: the
head runs left across the left counter until it meets a `0`. -/

/-- The rewriting performed by a leftward sweep of state `B`: `2 ↦ 4`, `3 ↦ 2`. -/
def sw : Sym → Sym
  | 2 => 4
  | 3 => 2
  | x => x

/-- Symbols the leftward sweep runs across. -/
def Sweepable (x : Sym) : Prop := x = 2 ∨ x = 3

instance : DecidablePred Sweepable := fun x => by
  unfold Sweepable; infer_instance

/--
**Sweep lemma.**  If `S` (listed from the head outwards) consists of symbols `2`
and `3`, and the head reads such a symbol `a`, then in `S.length + 1` steps the
head crosses all of `S`, leaving `sw`-images behind it and stopping on the first
cell beyond `S`.
-/
theorem sweep (S : List Sym) (hS : ∀ x ∈ S, Sweepable x) :
    ∀ (a : Sym), Sweepable a → ∀ (l r : List Sym),
      run ⟨S ++ l, St.B, a :: r⟩ (S.length + 1)
        = some ⟨l.tail, St.B, hd l :: (S.reverse.map sw) ++ sw a :: r⟩ := by
  induction S with
  | nil =>
      intro a ha l r
      rcases ha with rfl | rfl <;> rfl
  | cons s S ih =>
      intro a ha l r
      have hs : Sweepable s := hS s (by simp)
      have hS' : ∀ x ∈ S, Sweepable x := fun x hx => hS x (by simp [hx])
      have hstep : run ⟨(s :: S) ++ l, St.B, a :: r⟩ 1
          = some ⟨S ++ l, St.B, s :: sw a :: r⟩ := by
        rcases ha with rfl | rfl <;> rfl
      have : (s :: S).length + 1 = 1 + (S.length + 1) := by simp [Nat.add_comm]
      rw [this, run_add, hstep]
      simp only [Option.bind_some]
      rw [ih hS' s hs l (sw a :: r)]
      simp

/-! ## Decrementing the left counter

The left counter is written as a sequence of two-cell digits `02`, `22`, `23`,
`03` (leftmost cell first).  A decrement (`<` in the informal analysis) sweeps
left across `2`s and `3`s until it meets the `0` of a digit `02` or `03`:
a digit `02` stops the sweep (and becomes `22`), while a digit `03` lets the
borrow propagate further left. -/

/-- **Decrement, terminating case.**  The sweep stops at the first digit `02`,
which becomes `22`; the head then continues to the right. -/
theorem dec_stop (S : List Sym) (hS : ∀ x ∈ S, Sweepable x) (a : Sym) (ha : Sweepable a)
    (l r : List Sym) :
    run ⟨S ++ 2 :: 0 :: l, St.B, a :: r⟩ (S.length + 4)
      = some ⟨2 :: 2 :: l, St.B, (S.reverse.map sw) ++ sw a :: r⟩ := by
  have hS' : ∀ x ∈ S ++ [(2 : Sym)], Sweepable x := by
    intro x hx
    rcases List.mem_append.1 hx with hx | hx
    · exact hS x hx
    · simp at hx; subst hx; exact Or.inl rfl
  have h1 := sweep (S ++ [(2 : Sym)]) hS' a ha (0 :: l) r
  have hlen : (S ++ [(2 : Sym)]).length + 1 = S.length + 2 := by simp
  have hassoc : S ++ [(2 : Sym)] ++ (0 :: l) = S ++ 2 :: 0 :: l := by simp
  rw [hlen, hassoc] at h1
  have h2 : S.length + 4 = (S.length + 2) + 2 := by omega
  rw [h2, run_add, h1]
  simp only [Option.bind_some]
  have : ((S ++ [(2 : Sym)]).reverse.map sw) = (4 : Sym) :: (S.reverse.map sw) := by
    simp [sw]
  simp only [hd_cons, List.tail_cons, this]
  exact rule_04 l _

/-- **Decrement, borrowing case.**  At a digit `03` the borrow propagates: the
head turns around on the `0` but is sent left again, so the sweep continues. -/
theorem dec_borrow (S : List Sym) (hS : ∀ x ∈ S, Sweepable x) (a : Sym) (ha : Sweepable a)
    (l r : List Sym) :
    run ⟨S ++ 3 :: 0 :: l, St.B, a :: r⟩ (S.length + 4)
      = some ⟨l, St.B, 2 :: 0 :: (S.reverse.map sw) ++ sw a :: r⟩ := by
  have hS' : ∀ x ∈ S ++ [(3 : Sym)], Sweepable x := by
    intro x hx
    rcases List.mem_append.1 hx with hx | hx
    · exact hS x hx
    · simp at hx; subst hx; exact Or.inr rfl
  have h1 := sweep (S ++ [(3 : Sym)]) hS' a ha (0 :: l) r
  have hlen : (S ++ [(3 : Sym)]).length + 1 = S.length + 2 := by simp
  have hassoc : S ++ [(3 : Sym)] ++ (0 :: l) = S ++ 3 :: 0 :: l := by simp
  rw [hlen, hassoc] at h1
  have h2 : S.length + 4 = (S.length + 2) + 2 := by omega
  rw [h2, run_add, h1]
  simp only [Option.bind_some]
  have : ((S ++ [(3 : Sym)]).reverse.map sw) = (2 : Sym) :: (S.reverse.map sw) := by
    simp [sw]
  simp only [hd_cons, List.tail_cons, this]
  exact rule_02 l _

/-! ## Absorbing a run of `4`s

A block of `2n` consecutive `4`s in front of the head is turned into `n` digits
`02` of the left counter. -/

/-- `B> (44)^n  ⟶  (02)^n B>`. -/
theorem absorb_fours (n : Nat) (l r : List Sym) :
    run ⟨l, St.B, (List.replicate n [(4 : Sym), 4]).flatten ++ r⟩ (2 * n)
      = some ⟨(List.replicate n [(2 : Sym), 0]).flatten ++ l, St.B, r⟩ := by
  induction n generalizing l with
  | zero => simp
  | succ n ih =>
      have hrep : (List.replicate (n + 1) [(4 : Sym), 4]).flatten ++ r
          = 4 :: 4 :: ((List.replicate n [(4 : Sym), 4]).flatten ++ r) := by
        simp [List.replicate_succ]
      have h2 : 2 * (n + 1) = 2 + 2 * n := by omega
      rw [hrep, h2, run_add, rule_44]
      simp only [Option.bind_some]
      rw [ih (2 :: 0 :: l)]
      simp [List.replicate_succ']

/-! ## Overflow rules

These are the four "right overflow" rules and the "left overflow" rule of the
informal analysis. -/

/-- **Left overflow** (normal stage ⟶ reset stage): `.22 <B  ⟶  .22 B> 4`.
The head is on the right `2` of the leading `22`, with only blanks further left. -/
theorem left_overflow (r : List Sym) :
    run ⟨[2], St.B, 2 :: r⟩ 4 = some ⟨[2, 2], St.B, 4 :: r⟩ := rfl

/-- When the sweep runs off the written part of the tape it turns around on the
first blank cell and rebuilds the marker `22`: `. <B 2  ⟶  .22 B>` (3 steps).
So running off the left end of the tape is harmless. -/
theorem blank_edge_turn (r : List Sym) :
    run ⟨[], St.B, 2 :: r⟩ 3 = some ⟨[2, 2], St.B, r⟩ := rfl

/-- **Right overflow** `B> 1.  ⟶  <A 3.` -/
theorem right_overflow_1 (l : List Sym) :
    run ⟨l, St.B, [1]⟩ 1 = some ⟨l.tail, St.A, [hd l, 3]⟩ := rfl

/-- **Right overflow** `B> 3.  ⟶  <B 2.` -/
theorem right_overflow_3 (l : List Sym) :
    run ⟨l, St.B, [3]⟩ 1 = some ⟨l.tail, St.B, [hd l, 2]⟩ := rfl

/-- **Right overflow** `B> 2.  ⟶  <B 4.` -/
theorem right_overflow_2 (l : List Sym) :
    run ⟨l, St.B, [2]⟩ 1 = some ⟨l.tail, St.B, [hd l, 4]⟩ := rfl

/-- **Right overflow** `B> 4.  ⟶  <B 42 41.` (9 steps). -/
theorem right_overflow_4 (l : List Sym) :
    run ⟨l, St.B, [4]⟩ 9 = some ⟨l.tail, St.B, [hd l, 4, 2, 4, 1]⟩ := rfl

/-! ## Reading the final `1` of the right counter from a left digit

When the head reads the `1` it moves left *in state `A`*.  The cell it lands on
is the right-hand cell of the adjacent left digit: `2` for the digits `02`, `22`
and `3` for the digits `23`, `03`.  In the latter case the machine halts
(see `halts_on_3_left`), which is why the informal analysis always records the
adjacent digit as `(02|22)`. -/

/-- `22 B> 1  ⟶  B> 203` (2 steps). -/
theorem digit22_one (l r : List Sym) :
    run ⟨2 :: 2 :: l, St.B, 1 :: r⟩ 2 = some ⟨l, St.B, 2 :: 0 :: 3 :: r⟩ := rfl

/-- `02 B> 1  ⟶  B> 213` (4 steps). -/
theorem digit02_one (l r : List Sym) :
    run ⟨2 :: 0 :: l, St.B, 1 :: r⟩ 4 = some ⟨l, St.B, 2 :: 1 :: 3 :: r⟩ := rfl

/-! ## The halting configurations

The machine halts exactly when state `A` reads a `3`.  State `A` is entered by
`B0` and `B4` (moving right) and by `B1` (moving left), so the machine halts
iff the head, in state `B`, reads a `0` or a `4` with a `3` on its right, or
reads a `1` with a `3` on its left. -/

/-- **The halting criterion**: the machine halts exactly when state `A` reads `3`. -/
theorem halt_iff (c : Cfg) : step c = none ↔ (c.q = St.A ∧ hd c.r = 3) := by
  unfold step
  split <;> simp_all

/-- State `A` reading `3` is the halting transition. -/
theorem halts_A3 (l r : List Sym) : step ⟨l, St.A, 3 :: r⟩ = none := rfl

/-- `B> 03` halts after two steps. -/
theorem halts_B03 (l r : List Sym) : run ⟨l, St.B, 0 :: 3 :: r⟩ 2 = none := rfl

/-- `B> 43` halts after two steps. -/
theorem halts_B43 (l r : List Sym) : run ⟨l, St.B, 4 :: 3 :: r⟩ 2 = none := rfl

/-- `3 <B 1` halts after two steps: this is the dangerous configuration in which
the head reads the final `1` of the right counter next to a digit `23` or `03`. -/
theorem halts_on_3_left (l r : List Sym) : run ⟨3 :: l, St.B, 1 :: r⟩ 2 = none := rfl

end SOC
