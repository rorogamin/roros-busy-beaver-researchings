# `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` — what is proved, and what is still open

```
      0     1     2     3     4
A    1LB   3RB   0LB   ---   2RB
B    2RA   3LA   4LB   2LB   0RA
```

Two states, five symbols, blank symbol `0`.  The only missing transition is
`A` on `3`, so **the machine halts iff state `A` ever reads a `3`**
(`SOC.halt_iff`, `RequestProject/Rules.lean`).

Notation follows the informal analysis: `q>` is a head that is about to read the
cell on its right, `<q` a head about to read the cell on its left, and `.` marks
the blank part of the tape.  In Lean a configuration is a zipper
`⟨l, q, r⟩` where `l` lists the cells strictly left of the head *nearest cell
first*, and `r` lists the cells from the head rightwards; cells beyond either
list are blank.

## 1. What is proved in Lean

Everything below is proved for an **arbitrary tape context** on both sides,
i.e. as a statement `run ⟨l, q, r⟩ k = some ⟨l', q', r'⟩` with `l`, `r`
universally quantified, so the rules may be composed freely.

### Local rules (`RequestProject/Rules.lean`)

| rule | steps | name |
|---|---|---|
| `B> 44 ⟶ 02 B>` | 2 | `rule_44` |
| `B> 04 ⟶ 22 B>` | 2 | `rule_04` |
| `B> 41 ⟶ 03 B>` | 2 | `rule_41` |
| `B> 01 ⟶ 23 B>` | 2 | `rule_01` |
| `B> 40 ⟶ 23 B>` | 4 | `rule_40` |
| `B> 02 ⟶ B> 20` | 2 | `rule_02` |
| `B> 00 ⟶ B> 21` | 2 | `rule_00` |
| `B> 42 ⟶ B> 21` | 4 | `rule_42` |

The first five are the "absorb the next two cells into the left counter" rules;
the last three rewrite two cells in place and then hand the head to the leftward
sweep.

### The leftward sweep and the decrement `<`

* `sweep` — in state `B` the symbols `2` and `3` send the head left, rewriting
  `2 ↦ 4` and `3 ↦ 2`.  If the `n` cells next to the head are all `2`s or `3`s,
  the head crosses all of them in `n + 1` steps.
* `dec_stop` — the sweep stops at the first digit `02`, which becomes `22`, and
  the head turns back to the right.
* `dec_borrow` — at a digit `03` the borrow propagates instead: the head turns
  around on the `0` but is immediately sent left again.
* `absorb_fours` — `B> (44)^n ⟶ (02)^n B>` in `2n` steps.

### Overflow rules

* `left_overflow`   : `.22 <B ⟶ .22 B> 4` (4 steps).
* `blank_edge_turn` : `. <B 2 ⟶ .22 B>` (3 steps) — the marker is rebuilt out of
  blank tape.
* `right_overflow_1/3/2/4` : `B> 1. ⟶ <A 3.`, `B> 3. ⟶ <B 2.`, `B> 2. ⟶ <B 4.`,
  `B> 4. ⟶ <B 42 41.` (1, 1, 1 and 9 steps).

### Digit-level rules (`RequestProject/Stages.lean`)

Writing the left counter as two-cell digits `02`, `22`, `23`, `03` (leftmost
cell first) and `(22)^m` for `m` digits `22` next to the head:

* `dec_binary` : `(22)^m 02 <  ⟶  (02)^m 22`, a complete decrement of the binary
  part, in exactly `4m + 4` steps.
* `reset_rule_24` : the informal rule `(02|22) B> 24 ⟶ (02|22)< 02 B>`
  (decrement, then push a new digit `02`), `4m + 6` steps.
* `reset_rule_one_from22`, `reset_rule_one_from02` : reading the terminating `1`
  of the right counter next to a digit `22` (resp. `02`) decrements the counter
  and creates a new digit `23` (resp. `03`), leaving the head reading a `3`, so
  that a further decrement starts at once — the first `<` of the informal rules
  `(02|22) B> 14 --> <<<< (03|23) 02 B>` and `(02|22) B> 1. --> …`.
* `reset_rule_14` (`RequestProject/Reset.lean`) : the **whole** rule
  `(02|22) B> 14 --> <<<< (03|23) 02 B>`.  Reading the `1` costs four decrements,
  turns the digit nearest the head into `03`/`23`, and then pushes a fresh digit
  `02`; in exactly `4k + 52` steps, for any counter of the shape
  `x0 x1 (22)^{k+1} 02 …` with `x0`, `x1` binary digits (four cases
  `reset_rule_14_00/02/20/22`).  The hypothesis on the shape is exactly the
  statement that the `+4` performed by the four decrements stays inside the
  digits shown, i.e. that the counter does not underflow.
* `reset_rule_end` (`RequestProject/ResetEnd.lean`) : the **whole** rule
  `(02|22) B> 1. --> <<<<< B> (40|42) 42 41.`, in the same style: five
  decrements, the lowest digit of the counter is consumed and reappears as the
  first digit `40`/`42` of the brand-new right counter, after which the normal
  stage starts again.  Eight cases `reset_rule_end_uvw` (`u`, `v`, `w` the three
  lowest digits), with exact step counts `4k + 68` … `4k + 78`.
* `dec_binary23`, `dec23_creates03` : the "radix 1.5" digit.  Decrementing a
  counter whose leading digit is `23` costs **two** decrements of the binary
  part: the swept `23` comes back as `42`, which is rewritten in place as `21`,
  sending the head left a second time; the leftover cells `41` then become a new
  digit `03`.  Altogether `23 (22)^{k+1} 02 … ⟶ 03 22 (02)^k 22 …`.
* `left_overflow_general` : if *every* cell between the head and the marker
  `.22` is a `2` or a `3` — no digit `02`/`03` is left to borrow from, i.e. the
  decrement underflows — the sweep runs to the marker, turns around on the first
  blank cell, and the marker is rebuilt one cell further left.  **The machine
  does not halt when the left counter underflows**; the only effect is that the
  written part of the tape grows by one cell.  So the `TODO` of the informal
  analysis ("show the left counter doesn't overflow at that time") is not a
  *safety* condition: an underflow during the reset stage cannot kill the
  machine, it only shifts the tape by one cell and so flips the parity — which
  is what breaks the stage decomposition, not the machine.  What has to be
  controlled for non-halting is the condition in §2.
* `normal_to_reset`, `cells_parity_shift` (`RequestProject/ResetEnd.lean`) : the
  stage transition `normal ⟶ reset`.  The dynamic part is 6 steps (left overflow
  followed by `rule_44`, creating the first digit `02` of the new left counter);
  the change of the right counter's grammar is a pure **parity shift**, the list
  identity `4 (4c₁)(4c₂)…(4cₙ) 4 1 = (44)(c₁4)(c₂4)…(cₙ4) 1`, which turns the
  normal-stage grammar `(44|40|42|41)* 41.` into the reset-stage grammar
  `(44|04|24|14)* 1.` with the digits `c` carried over unchanged.
* `run_init_50` : from the blank tape, after 50 steps the machine is in
  `.22 B> 44 44 24 04 1.` = `.22 B> 4 44 42 40 41.`, the starting configuration
  of the informal analysis.

### Finite run (`RequestProject/Verified.lean`)

* `no_halt_before_1e8` / `no_halt_of_le_1e8` : evaluated inside Lean, the
  machine does not halt during its first `10^8` steps.

## 2. Where a halt could come from

State `A` is entered by `B0` and `B4` (moving right) and by `B1` (moving left),
so the machine halts exactly in one of these three situations:

* `B` reads `0` with a `3` immediately to its right (`halts_B03`);
* `B` reads `4` with a `3` immediately to its right (`halts_B43`);
* `B` reads `1` with a `3` immediately to its **left** (`halts_on_3_left`).

`3`s do occur all the time — they are the right-hand cells of the digits `23`
and `03` of the left counter.  The third case is the delicate one: when the head
reads the terminating `1` of the right counter it moves left in state `A` onto
the right-hand cell of the adjacent left digit, which is `2` for `02`/`22` and
`3` for `23`/`03`.  This is exactly why the informal analysis always writes the
adjacent digit as `(02|22)`: **the machine survives the end of the right counter
only because the digit next to the head is never `23` or `03` at that moment.**
Proving that is the heart of a non-halting proof, and it is not a local
property — it depends on the values of the counters.

The two rules `reset_rule_14` and `reset_rule_end` now make that statement
precise and prove the safe case: **as long as the left counter is long enough
for the four (five) decrements, reading a `1` cannot kill the machine**, and the
digit it leaves next to the head is again a binary digit `02`, so the *next* `1`
is safe as well.  What is not proved is that the counter is always long
enough — an underflow is harmless in itself (`left_overflow_general`) but it
shifts the tape by one cell, which flips the parity of the junction and so
breaks the two-cell digit structure that the rules above rely on.

## 3. The counter picture

Simulation (not verified in Lean) shows the following steady-state behaviour,
which matches the informal analysis:

* The tape is `.22 (left counter) [head] (right counter) 1.` and the head
  oscillates in a **short band** around the junction: over `10^10` steps the
  average leftward sweep crosses 4 cells and the average rightward absorption
  run 8 cells, while the written tape is hundreds of cells wide.  The junction
  drifts slowly; there is no long traversal.
* The left counter, read with the **least significant digit next to the head**
  and `02 = 0`, `22 = 1`, counts **up by one per oscillation**; e.g. observed
  consecutively: `…010`, `…110`, `…001`, `…101`, `…011`, `…111`, then an
  overflow which appends a new digit `23`.
  This is exactly the content of the proved lemma `dec_binary`
  (`(22)^m 02 ↦ (02)^m 22`, i.e. `1^m 0 ↦ 0^m 1` with the least significant
  digit first): the sweep `<` of the informal analysis *is* the `+1` of this
  counter, and its cost `4m + 4` is observed on the nose in the simulation (a
  carry-free increment takes 4 steps, one with two carries 12 steps, …).
* The digits `23`/`03` are the "radix 1.5" positions: as proved in
  `dec23_creates03` they cost an extra decrement and flip `23 ↦ 03`.  A pair of
  one radix-2 and one radix-1.5 position behaves like a radix-3 position, which
  is what one sees on the right-hand side (digits `0,1,2` separated by `4`s).
* Growth is very slow: after `10^11` steps the written tape is 269 cells wide,
  and the head returns to the far left end only at steps
  306, 1600, 3134, 251475, 502639, 1292138162, 2585400356, … — each such visit
  costing roughly the previous one raised to a power ≈ 1.5.

* The dangerous event — the head reading a `1` in state `B` — is **rare**: in
  `2·10^10` steps it happens only 32 times, and only 6 of those are at the right
  end of the tape.  At those six moments the tape is, in full, the marker, the
  left counter and the terminating `1`; they occur at steps
  62, 207, 330, 3323, 503732 and 2585402073, with tape widths
  11, 15, 19, 39, 83 and 169 — the width roughly doubles and the step count is
  roughly raised to the power 1.5 each time.  In all of them the digit next to
  the head is `02` or `22`, as it has to be for the machine to survive.

No halt was found in `10^11` steps of external simulation (`10^8` of them
re-checked inside Lean).

## 4. The digit-level (macro) model

*(new: `RequestProject/Macro.lean`, `MacroMachine.lean`, `Counter.lean`,
`Safety.lean`, `ResetRules.lean`, `ResetPhase.lean`)*

The rules of §1 have been assembled into a **complete finite rule set** on a
small state space, together with a proof that it simulates the machine.

### The counter as a digit string

The left counter is a list of digits, **least significant (nearest the head)
first**:

| digit | cells | kind |
|---|---|---|
| `d0` | `02` | radix 2, value 0 |
| `d1` | `22` | radix 2, value 1 |
| `dA` | `23` | radix 3/2 |
| `dB` | `03` | radix 3/2 |

`lzz w` writes such a string on the tape (marker `22` included), and the `+1` of
the counter is the relation `Inc`:

```
inc (02 w) = 22 w                inc (03 w) = 23 inc(w)
inc (22 w) = 02 inc(w)           inc (23 w) = 03 inc(inc(w))
```

A digit `23` emits **two** carries for one increment, which is what "radix 1.5"
means: two increments of a `23`/`03` position cost three of the position above.

**`inc_sweep`** proves that one leftward sweep of the machine is exactly one
`Inc`, for an arbitrary counter and an arbitrary tape context:

```
w B> 2 r  ⟶+  inc(w) B> 4 r          w B> 3 r  ⟶+  inc(w) B> 2 r
```

**`ovf_sweep`** covers the other case: if no increment is possible, the sweep
runs into the marker, the marker is rebuilt one cell further left, and the cells
of the old counter are released to the right:

```
w B> 2 r  ⟶+  .22 B> 44 s r ,      Ovf w s
```

and `Ovf.released` shows that the released cells `s` are **always** a sequence
of blocks `44`, `04`, `24`, `14` — which is precisely the reset-stage grammar of
the informal analysis, now a theorem rather than an observation.

### The macro machine

`MCfg = (counter, cells to the right of the head)`, with fourteen rules
(`MStep`): the two sweeps, the two overflows, the five "push a digit" rules
(`44 ↦ 02`, `04 ↦ 22`, `40 ↦ 23`, `41 ↦ 03`, `01 ↦ 23`), the three in-place
rewrites (`42`, `00`, `02` ↦ `21`, `21`, `20`) and the two rules for reading the
terminating `1` next to a radix-2 digit.

* `mstep_sim` : every macro step is a run of **at least one** step of the
  Turing machine, in an arbitrary context.
* `neverHalts_of_macro_chain` : an infinite chain of macro steps from the
  configuration reached after 50 steps proves non-halting.
* `mstep_exists` : the macro machine **always** has a successor except at the
  two patterns
  * `B> x3` (`x = 0, 4`), and
  * `B> 1` with a radix-3/2 digit (or nothing) next to the head;
* `danger_halts` : at those two patterns the machine really does halt.

So the model is exact: **the machine halts iff the macro run meets one of those
two patterns.**

### The gap of a counter

```
gap [] = 0        gap (02 w) = 2·gap w + 1        gap (03 w) = (2·gap w + 1)/3
                  gap (22 w) = 2·gap w            gap (23 w) = (2·gap w)/3
```

`gap w` is the number of increments the counter can still perform:
`Inc.gap_eq` (an increment costs exactly one), `gap_pos_iff` (an increment is
possible iff `gap > 0`) and `gap_eq_zero_iff` (the counter overflows iff
`gap = 0`).  This is the quantitative content of the informal `TODO`
("show the left counter doesn't overflow at that time").

### The reset stage, for an arbitrary counter

With the gap available, the reset-stage rules of the informal analysis hold for
*every* counter, not just for counters of a special shape
(`RequestProject/ResetRules.lean`):

| block | effect on the counter | effect on the gap |
|---|---|---|
| `44` | push `02` | `g ↦ 2g+1` |
| `04` | push `22` | `g ↦ 2g` |
| `24` | one increment, push `02` | `g ↦ 2g-1` |
| `14` | four increments, the lowest digit `02`/`22` becomes `03`/`23`, push `02` | `g ↦ ≈ 2g/3` |

(`macro_14_of_gap` is the last line; its hypothesis is exactly `4 ≤ gap w`.)

Iterating this, `reset_phase` proves that the machine survives a whole reset
stage as soon as the arithmetic run `SafeRun` — the gap must stay `≥ 8` at every
block `14` and `≥ 1` at every block `24` — succeeds.  `SafeRun` is **decidable**,
so for any concrete released material this is a finite check; e.g. the block
sequence `44 44 44 44 04 44 04 24` that the machine really meets in its first
reset stage is safe, the gap running `1, 3, 7, 15, 30, 61, 122, 243`.

## 5. Only one kind of moment can kill the machine

*(new: `RequestProject/OneSafe.lean`)*

The two fatal patterns of §4 are not equally dangerous — the first one can be
ruled out once and for all.

A `3` is never part of the material an overflow releases (`Ovf.no_three`,
`Ovf3.no_three`: the released blocks are `44|04|24|14`).  The *only* way a `3`
ever appears to the right of the head is the pair of rules that read the
terminating `1` of the right-hand material,

```
22 B> 1  ⟶  B> 2 0 3          02 B> 1  ⟶  B> 2 1 3
```

and the three macro steps that follow such a rule consume that `3` again:

```
B> 2 0 3    ⟶  inc:  B> 4 0 3  ⟶  push 23:  B> 3  ⟶  sweep:  B> 2
```

— **provided the counter can still perform one increment** after the digit the
`1` has just eaten.  If it cannot, the sweep overflows instead, the released
material is inserted between the head and the pending `3`, and the machine later
runs into `0 3` or `4 3` and dies.

This is the content of `clean_step`:

> from a configuration whose right-hand material carries no `3`, the macro
> machine makes at least one step and reaches another configuration whose
> right-hand material carries no `3` — **unless** the head reads a `1` while the
> lowest digit of the counter is a radix-3/2 digit, the counter is empty, or the
> counter's gap is at most `1`.

Writing `OneOK w` for "the lowest digit of `w` is `02` or `22` and `gap w ≥ 2`",
the resulting criterion `neverHalts_of_one_reads_safe` is

> the machine never halts as soon as `OneOK` holds at every configuration at
> which the head reads a `1`.

Nothing else has to be checked.  The `TODO` of the informal analysis — "show the
left counter doesn't overflow at that time" — is thus not merely sufficient for
non-halting, it is the *whole* of it.

## 6. The normal phase, and the super-cycle

*(new: `RequestProject/NormalPhase.lean`)*

The reset phase of §4 ends with the head on the terminating `1` of the old
right-hand material and nothing written to its right.  What happens next needs
no hypothesis at all.

* `junction` — reading that last `1` (the informal rule
  `(02|22) B> 1. --> <<<<< B> (40|42) 42 41.`) costs five increments and leaves
  the head facing blank tape.  The only side condition is that the counter can
  pay, which `9 ≤ gap w` guarantees.

* `normal_cycle` — facing blank tape the machine repeats

  ```
  w B> .  ⟶  w B> 21  ⟶  inc(w) B> 41  ⟶  inc(w) 03 B> .
  ```

  writing two new cells of right-hand material, paying one increment and pushing
  a radix-3/2 digit `03` onto the counter.  This is the "-1 on the left, +1 on
  the right" of the informal normal stage.

* `normal_phase` — **the normal phase is unconditionally safe.**  One cycle
  sends the gap `g` to `(2g-1)/3`, which is strictly smaller, so after finitely
  many cycles the counter overflows; the overflow releases a block sequence
  `44|04|24|14` and the terminating `1` written by the last cycle closes it off.
  The machine therefore always arrives at the start of a *new* reset phase, and
  it cannot halt anywhere in between.

* `super_cycle` — one whole revolution.  If the blocks `L` of a reset phase pass
  the decidable test `SafeRun 1 L` and build a counter big enough for the
  junction (`9 ≤ gfold 1 L`), the machine consumes the reset phase, the
  junction and the normal phase, and reaches the start of the next reset phase,
  with a new block sequence `L'`.

So the orbit of the machine is an infinite chain of revolutions

```
phaseStart L  =  .22 B> 44 (blocks of L) 1.
    reset phase    (L is absorbed into the counter)
    junction       (the terminating 1 is read)
    normal phase   (the counter is spent, a new right counter is written)
    overflow       (the counter is released as the blocks of L')
phaseStart L'
```

and `neverHalts_of_phase_invariant` says: **the machine never halts as soon as
every block sequence it releases passes the arithmetic test.**  The starting
sequence is verified (`firstBlocks`, §4), so what is left of the halting
problem is a purely arithmetical statement about the sequences
`L ↦ L'`, with no tape reasoning in it at all.

## 7. The revolution as a computable function, and eleven verified revolutions

*(new: `RequestProject/Fast.lean`, `Revolutions.lean`)*

Sections 4–6 reduce the machine to a chain of revolutions on block sequences,
but `super_cycle` only *asserts* that a next sequence exists; to follow the
machine one has to compute it.  The obstacle is that the digit model is not
faster than the machine: one increment of a counter with `k` radix-3/2 positions
recursively triggers up to `2^k` increments of the positions above it
(`inc (23 w) = 03 inc (inc w)`).

`RequestProject/Fast.lean` removes that blow-up.  A position is no longer
incremented one step at a time; it is told **how many** increments it receives
and reports **how many** carries it emits:

| digit | value | carries after `t` increments | digit afterwards |
|---|---|---|---|
| `02` | `0` | `t / 2` | parity of `t` |
| `22` | `1` | `(t+1) / 2` | parity of `t` |
| `03` | `0` | `3t / 2` | parity of `t` |
| `23` | `1` | `3(t+1)/2 - 1` | parity of `t` |

`addT w t` applies `t` increments in a single pass and stops as soon as the
carry count reaches `0`.  The two theorems that make this legitimate are
`addT_add` (bulk increments compose: `t` then `u` is `t + u`) and
`addT_one_inc` / `inc_addT_one` (a bulk increment of size one is exactly one
`Inc` of the macro model).  On top of them the whole revolution becomes a
*function*:

* `ovfF` — the blocks an overflow releases;
* `resetF` — the reset phase (each block absorbed, `24` paying one increment and
  `14` four);
* `junctionF` — reading the terminating `1`;
* `normalF` — the normal phase, pushing `03` per cycle until the counter
  overflows;
* `revolutionF = resetF ∘ junctionF ∘ normalF`, with
  `revolutionF_spec : revolutionF L = some L' → MPlus (phaseStart L) (phaseStart L')`.

Nothing is assumed: the function returns `none` exactly where the machine would
be in danger, and a successful computation *is* a proof of a run of the Turing
machine.  Iterating it from the first overflow (`revIter`) and checking the
result inside Lean gives

> **`survives_eleven_revolutions`** — the machine reaches the start of its
> twelfth reset phase, i.e. it survives eleven counter overflows.  At that point
> the right-hand material consists of `37590` blocks, so the tape is more than
> `75000` cells wide.

The block sequences (lengths `7, 17, 39, 82, 180, 378, 838, 1811, 3919, 8205,
17534, 37590`) grow by a factor of about `2.2` per revolution, and the first
three agree with the sequences verified from the real tape in §4 — the
executable model reproduces `firstBlocks`, `secondBlocks` and `thirdBlocks`
exactly.

## 8. How long does it run?  A proved lower bound

*(new: `RequestProject/Cost.lean`, `Steps.lean`)*

The macro steps also carry their cost.  A sweep spends `4` steps at each
radix-2 position and `8` steps at each radix-3/2 position it crosses, once per
increment that position receives, so the cost of `t` increments is again
computable in one pass (`costT`, with the composition law `costT_add`).
`inc_sweep_cost` is the sweep theorem of §4 with that number attached:

```
Inc w w'  →  w B> 2 r  reaches  inc(w) B> 4 r  in at least costT w 1 steps
```

Summing over the cycles of a normal phase gives `normalCost`, and
`no_halt_before_stepBound` turns it into a statement about the real machine.
Evaluating it for the eleventh revolution gives

> **`no_halt_before_10_pow_3500`** — the machine does not halt within its first
> `10 ^ 3500` steps.

This is a *proof*, not a simulation: no tape is ever written down, the steps are
counted inside the digit model.  Revolution by revolution the bound is

```
revolution    1     2     3      4     5      6      7       8       9      10      11
steps ≥    2060  4·10⁵  2·10⁹  10¹⁹  10³⁶   10⁸²  10¹⁷³   10³⁷²   10⁷⁵⁶  10¹⁶⁴⁴  10³⁵³³
```

so the running time is roughly *squared* at every revolution.  The bound is
tight in the only places where it can be checked: the first reset phase really
ends at step `3139` (bound `2060 + 306`), the second at `502644`
(bound `4 · 10^5`).

## 9. What the sequences look like

The computation also gives data about the sequences themselves.  These numbers
come from the exploratory scripts `sim/macro_sim.py` and `sim/cost_sim.py`,
which implement the same digit model outside Lean; they are **not** verified,
only the statements listed in §§7–8 are machine-checked.

| revolution | blocks | blocks `14` | density | leading run of `44` |
|---|---|---|---|---|
| 3 | 39 | 8 | 0.21 | 13 |
| 5 | 180 | 40 | 0.22 | 22 |
| 7 | 838 | 169 | 0.20 | 42 |
| 9 | 3919 | 890 | 0.23 | 184 |
| 11 | 17534 | 3660 | 0.21 | 184 |
| 12 | 37590 | 8021 | 0.21 | 184 |

The density of the expensive blocks `14` stays near `0.21`.  The critical
density is `log 2 / log 3 ≈ 0.63`: a block `14` multiplies the counter's
capacity by about `2/3` and every other block by about `2`, so a sequence whose
`14`-density stays below `0.63` builds a counter that grows.  The observed
margin is large, which is why the machine survives; a proof would have to bound
that density for *all* revolutions, and that is exactly the part that is still
missing.

Two structural facts visible in the data are worth recording: the leading run of
blocks `44` stabilises at `184`, and the smallest capacity the counter ever has
at a block `14` stays at about `2^185` from the ninth revolution on — the
successive sequences appear to share a growing common prefix.

## 10. Halting or not?

**Still open.**  Collecting §§4–6, the machine can halt *only* if at some point
the head reads a `1` while the counter cannot pay (gap `≤ 1`, or a radix-3/2
digit at the bottom) — every other configuration is safe.  Inside a revolution
the danger is concentrated at the blocks `14`:

| block | effect on the gap |
|---|---|
| `44` | `g ↦ 2g+1` |
| `04` | `g ↦ 2g` |
| `24` | `g ↦ 2g-1` |
| `14` | `g ↦ ≈ 2g/3`, and four increments must be available |

so survival is a **density** statement: the blocks `14` released by an overflow
must not be too frequent, and in particular the sequence must not start with
them.  Eleven revolutions are now verified in this sense (§7); the first three
of them were verified directly from the tape
(`RequestProject/FirstPhase.lean`, `SecondPhase.lean`, `ThirdPhase.lean`): the
machine reaches the starts of its first three reset phases after `306`, `3139`
and `502644` steps, the released block sequences are

```
44 · 44 44 44 04 44 04 24
44 · 44^7 04 24 04 04 04 24 14 24 14 04
44 · 44^13 14 44 24 44 24 04 04 04 24 14 14 24 24 14 14 14 04 14 24 04 24 04 24 24 14 04
```

and each passes `SafeRun` with a wide margin (the counters they build can still
perform `243`, `28954` and `167497402` increments), so `super_cycle` carries the
machine through all three.  Written in the letters of the simulation, these are

```
ffffzfzt                    (4 blocks 44, then 04 44 04 24)
ffffffffztzzztotoz          (8 blocks 44, then 10 mixed, 2 of them 14)
ffffffffffffffoftftzzztoottooozotztzttoz
                            (14 blocks 44, then 26 mixed, 8 of them 14)
```

(`f = 44`, `z = 04`, `t = 24`, `o = 14`), each starting with a long run of `44`s
which gives the gap a head start of about `2^k`, and `SafeRun` holds with a wide
margin in all three.  A block `14` is released by a digit `23` whose more
significant part has gap exactly `1`, so bounding their density means
controlling the digit pattern of the counter at the moment it overflows — that
is the remaining mathematical content.

A remark on simulation speed.  The macro model of §4 is *not* an accelerated
simulator: a single sweep across a counter with `k` radix-3/2 digits recursively
triggers up to `2^k` increments of the digits above it
(`inc (23 w) = 03 inc(inc w)`), so evaluating it costs as much as running the
machine.  The bulk increments of §7 are the speedup this calls for — every
position has a fixed radix, so a position can be told *how many* increments it
receives instead of receiving them one at a time — and they are what makes the
eleven verified revolutions and the step bound of §8 possible.

Machine-checked non-halting is now available in three forms: the explicit
`10^8`-step run of `RequestProject/Verified.lean`; the eleven verified
revolutions of §7, i.e. the machine does not halt before its *twelfth* counter
overflow; and the quantitative bound of §8, `10^3500` steps.

## 11. The density criterion: from a test on a sequence to a condition on its shape

*(new: `RequestProject/Density.lean`, `DensityChecks.lean`,
`DensityRevolutions.lean`)*

Up to §10 the safety of a reset phase was the decidable test `SafeRun`, which
has to be *run* on a concrete block sequence.  It is now replaced, for large
counters, by a condition on the **shape** of the sequence alone.

Fix a threshold `T ≥ 105`.  As long as the gap stays above `T`, one block
multiplies it by at least

```
afac T = (2T-1)/T   ≈ 2      at a block 44, 04 or 24
bfac T = (2T-19)/3T ≈ 2/3    at a block 14
```

(`wfac_mul_le_gnext`; the `-1` and the `-19` are exactly the rounding losses of
the mixed-radix arithmetic, which is why a threshold is needed at all).  Hence
(`growth_bound`) the phase is safe as soon as the product of these factors over
*every prefix* keeps the gap above `T`, and the gap at the end is at least the
product over the whole sequence.

If in every prefix the number `k` of blocks `14` and the number `n` of blocks
satisfy `p·k ≤ q·(n-k)` — a density of at most `q/(p+q)` — that product is at
least `1` provided `afac T ^ p * bfac T ^ q ≥ 1` (`one_le_gw`), because a block
`14` followed by enough cheap blocks is a net gain.  This gives

> **`safeRun_of_dense`** — a counter with gap at least `T` survives any block
> sequence whose blocks `14` have density at most `q/(p+q)` in every prefix, and
> comes out at least as large as it went in;
>
> **`safeRun_append_dense`** — so a sequence that first builds a gap of `T` (by
> the exact recurrence, on a leading part) and then stays below that density is
> safe.

Two settings of the parameters are worked out:

| threshold `T` | `p`, `q` | admissible density |
|---|---|---|
| `105` | `1`, `1` | `1/2`  (`ratio_half`) |
| `300` | `2`, `3` | `3/5`  (`ratio_three_fifths`) |

The critical density is `log 2 / log 3 ≈ 0.6309` — the factors `2` and `2/3`
themselves — and `3/5 = 0.6` is close to it; the remaining margin is the price of
the rounding.  The density actually observed in the released sequences is about
`0.21`.

What is left of the halting problem, in these terms, is
`neverHalts_of_evDense`:

> the machine never halts as soon as **every** block sequence it releases splits
> into a leading part building a gap of `T` and a tail whose blocks `14` never
> exceed the density `q/(p+q)` in a prefix.

(`neverHalts_of_evHalfDense` is the instance `T = 105`, density `1/2`, started
at the machine's first overflow; `neverHalts_of_evDense35` the instance
`T = 300`, density `3/5`, started at the second one, which is where the counter
first exceeds `300`.  `neverHalts_of_phase_invariant_from` is the version of the
super-cycle argument that may be started at any reachable reset phase.)

The criterion is not vacuous.  It is verified for the block sequences the
machine really produces:

* `firstBlocks`, `secondBlocks`, `thirdBlocks` — the sequences of the first
  three overflows, verified from the tape in §4 — pass with both settings
  (`DensityChecks.lean`); the split is after six blocks for `T = 105` (the gap
  built is `127`) and after eight for `T = 300` (gap `510`);
* **`revIter_evDense`** (`DensityRevolutions.lean`) — *all eleven* block
  sequences computed in §7 pass the half-density criterion, with the same split
  after six blocks.  The check is a single pass (`denseB`, proved sound in
  `dense_of_denseB`) and is carried out inside Lean.

Unverified exploration (`sim/density_sim.py`) gives the worst prefix density of
blocks `14` over the first eleven revolutions:

```
revolution         1      2      3      4      5      6      7      8      9     10     11
blocks             7     17     39     82    180    378    838   1811   3919   8205  17534
worst prefix dens  0    0.125  0.226  0.185  0.227  0.183  0.202  0.201  0.227  0.211  0.209
```

— always about a third of the admissible `1/2`, and it is never the prefix but
the bulk of the sequence that is worst.  So the gap the counter carries is not
merely positive, it grows by a factor of about `2^0.58` per block.

**What is still missing is unchanged in nature but sharper in form:** one has to
prove that *every* released sequence keeps the blocks `14` below the density
`1/2` (or `3/5`) in each of its prefixes.  A block `14` comes from a digit `23`
whose more significant part can still absorb one increment at the moment the
overflow sweep reaches it, so this is a statement about the digit pattern of the
counter when it overflows — still the open part of the problem.

## 12. The leading run of `44`s, and what the halting question now is

*(new: `RequestProject/Leading.lean`, `Success.lean`, `Reduction.lean`)*

The criterion of §11 has two halves: the block sequence must first build a gap
of `105`, and then keep the blocks `14` sparse.  **The first half is now
automatic.**

### The leading run never gets shorter

The reset phase builds the counter by pushing digits at its *least significant*
end, so the digits coming from the **leading** blocks end up at the top of the
counter.  Blocks `44`, `04`, `24` push a radix-2 digit and a block `14` a
radix-3/2 one, so if `L` begins with `r` blocks different from `14`, the top `r`
digits of the counter are radix-2 — and they stay radix-2 for the whole
revolution, because every later operation either pushes digits at the bottom,
replaces the lowest digit, or increments the counter, and **an increment never
changes the radix of a position** (`addT_rad2`).

When the counter overflows, the sweep reads it from the bottom up and every
radix-2 digit it meets is full (a digit `02` would leave a positive gap, so the
overflow could not have happened): it is read as `22` and released as a block
`44`.  Hence

> **`revolutionF_leading`** — the sequence released by the next overflow begins
> with `leadRun L` blocks `44`, where `leadRun L` is the number of blocks of `L`
> before its first `14`;
>
> **`leadRun_revolutionF`** — so the leading run never gets shorter, and since
> the machine's first released sequence has `leadRun = 7`,
>
> **`revIter_leadRun`** — *every* sequence the machine releases begins with at
> least seven blocks `44`.

Seven blocks `44` build a gap of `2^8 - 1 = 255 ≥ 105`, so the counter always
has the head start the criterion of §11 asks for.  (This also explains the
observation of §9 that the leading run grows — `7, 13, 13, 22, …` — and that the
sequences share a growing common prefix.)

### The executable model never fails without a reason

`RequestProject/Success.lean` proves the converse of `revolutionF_spec`: a bulk
increment of at most `gap w` always succeeds (`addT_of_le_gap`), so the reset
phase computes whenever `SafeRun` holds (`resetF_isSome`), the junction computes
when the counter can pay, the normal phase always computes, and hence a whole
revolution computes (`revolutionF_isSome`).  Consequently
`neverHalts_of_revIter`: **if every revolution of the model computes, the
machine never halts.**

### What the halting question is now

Putting the three pieces together (`RequestProject/Reduction.lean`):

> **`neverHalts_of_tail_dense`** — if, in every block sequence the machine
> releases, the blocks `14` never make up more than half of a prefix of what
> follows the seventh block, then
> `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never halts.

There is no tape, no counter and no gap left in the hypothesis: it is a single
statement about the shape of the sequences of blocks `44|04|24|14` the machine
produces, and the quantity it bounds — about `0.21` in the data, against an
admissible `0.5` — is checked for the first eleven of them (§11).  Proving that
bound for all of them is what remains.

### The sharper form

Seven blocks `44` build a gap of exactly `255`, and at that size the growth
factors of §11 are `afac 255 = 509/255` and `bfac 255 = 491/765`, which satisfy
`afac ^ 2 * bfac ^ 3 ≥ 1`.  So the same argument runs with the density `3/5`:

> **`neverHalts_of_tail_dense35`** — if the blocks `14` never make up more than
> *three fifths* of a prefix of the part of a released sequence after its
> seventh block, the machine never halts.

`3/5 = 0.6` against the critical `log 2 / log 3 ≈ 0.6309`: what is left is a
density bound within 5 % of the best that any argument of this shape could use,
for a quantity whose observed value is `0.21`.

## 13. The shape of a released sequence, and the density of the fresh blocks

§12 left the halting question as a density statement about **every** block
sequence the machine releases.  A large part of that statement is now proved
away: a released sequence inherits its shape, block by block, from the previous
one, so only the *freshly created* blocks need a density argument.

### The shape theorem

`RequestProject/Shape.lean` proves

> **`revolutionF_shape`** — if the reset phase absorbs `L` and the following
> overflow releases `L'`, then
> ```
> L' = S ++ M,      |S| = |L|,
> S i = 44  ⟺  L i ≠ 14,        no block of M is a 44.
> ```

The proof is bookkeeping on the *radices* of the counter positions, and it
explains every feature of the sequences observed in §9:

* the reset phase pushes one radix-2 digit per block, and a block `14`
  additionally converts the digit pushed by the **preceding** block into a
  radix-3/2 one (`resetF_pat`);
* the junction converts the lowest digit and adds one radix-3/2 digit
  (`junctionF_pat`), and every cycle of the normal phase adds one more;
* no operation ever changes the radix of a position — an increment cannot
  (`addT_rad2`), and the later phases only push digits below;
* at the overflow, the sweep releases a radix-2 digit as `44` and a radix-3/2
  digit as one of `04`, `24`, `14` (`ovfF_pat`, `normalF_pat`).

So the positions of the expensive blocks `14` in the inherited part `S` are a
*subset* of the positions of the blocks `14` in `L` (`ones_prefix_le_of_shape`),
and the sequence can only grow, by exactly the number of fresh blocks
(`ones_revolutionF_le`).  The leading-run theorem of §12 is the special case of
this statement for the first blocks.

### Only the fresh material is left

`RequestProject/Fresh.lean` turns the shape theorem into a reduction.  Define

```
FreshDense L L' :  for every prefix v of the fresh part of L',
                   5 · ones (L.drop 7 ++ v)  ≤  3 · |L.drop 7 ++ v|
```

— i.e. the previous sequence followed by the fresh blocks still keeps the blocks
`14` below the density `3/5`.  Then

> **`neverHalts_of_fresh_dense`** — if every revolution of the machine satisfies
> `FreshDense`, the machine never halts.

The induction is exactly the shape theorem: a prefix of `L'` that stays inside
the inherited part has no more blocks `14` than the corresponding prefix of `L`,
which the induction hypothesis already covers; a prefix that reaches into the
fresh part is covered by `FreshDense`.  The *credit* carried by the inherited
part is what makes this hypothesis weaker than the one of §12: the fresh part
often begins with a block `14`, so its own first prefixes have density `1` and
must be paid for by the long, sparse inherited part — which can pay, since it is
about five times longer than its blocks `14` are numerous.

`RequestProject/FreshChecks.lean` checks the condition inside Lean on the
machine's first ten revolutions (`revIter_freshDense`); in the measured data the
left-hand side reaches at most about `0.5` of the admissible value.

### Why a purely arithmetic bound cannot finish the job

It is worth recording why the fresh part really has to be understood, rather
than bounded crudely.  Write `n` for the length of a sequence, `a` for its
number of blocks `14`, and `m` for the number of fresh blocks.  Every block
multiplies the counter's capacity by about `2`, except a `14`, which multiplies
it by about `2/3`; the normal phase adds one block per factor `3/2` of capacity,
so

```
m ≈ [ (n - a) log 2 + a log (2/3) ] / log (3/2).
```

If one assumes nothing about the fresh part beyond "all of it could be `14`",
the density of the next sequence is at most `(a + m) / (n + m)`, and asking this
to stay below a threshold `c` gives, after simplification, exactly
`c ≥ log 2 / log 3 = 0.6309…`: the critical density, which no criterion of this
type can reach.  In other words the crude bound is precisely borderline, and any
proof has to use that the fresh part is *not* all blocks `14`.

### What the fresh part looks like (unverified)

The fresh blocks are the digits pushed by the normal phase, read from the
earliest cycle to the latest.  Writing `g_t` for the counter's gap after the
`t`-th cycle — so `g_{t+1} = ⌊(2 g_t − 1)/3⌋` and the phase stops at `g = 0` —
the data (`sim/shape_sim.py`, eight revolutions, several thousand positions)
shows

```
the t-th fresh block is 04   ⟺   g_t is even,
                        14 or 24  ⟺   g_t is odd.
```

Since the map `g ↦ ⌊(2g−1)/3⌋` sends four of the six residues mod `6` to an odd
value, this accounts for the observed proportion of about `2/3` of radix-3/2
digits that come out full, of which roughly half are released as the expensive
`14` and half as the harmless `24`; the measured density of `14` in the fresh
parts is `0.27`–`0.36`, against the admissible `3/5`.  Which of the two a full
digit becomes depends on whether the counter above it still has one unit of
capacity at the moment the sweep reads it, and we have no formula for that.

So the remaining gap is an equidistribution statement about the trajectory of
`g ↦ ⌊(2g−1)/3⌋` — the same kind of question as the distribution of the digits
of `(3/2)^k`.  That is why the halting problem for this machine is still open
here, and it is now isolated in a single, purely arithmetic place.

## 14. The sharp form: only the fresh material can kill the machine

§13 keeps a density criterion for the fresh blocks.  In fact no density is
needed at all — the inherited part is safe *for free*.

### Inheritance is monotone

Compare the inherited part `S` of a released sequence with the sequence `L` it
comes from, position by position (the shape theorem of §13).  Where `L` has a
block different from `14`, `S` has a `44`, which is the *best* block for the
counter (`g ↦ 2g+1`, `gnext_le_four`).  Where `L` has a `14`, `S` has one of
`04`, `24`, `14`, each at least as good as a `14` — provided the counter can
afford a `14` at all, which is exactly what the safety of `L` says at that
position (`gnext_one_le`).  Since `gnext` is monotone in the gap, an induction
gives (`RequestProject/Inherit.lean`)

> **`safeRun_gfold_of_shape`** — if `L` is safe for a counter of gap `g`, then
> `S` is safe for any counter of gap at least `g`, and it builds a gap at least
> as large as `L` does.

Hence:

> **`neverHalts_of_fresh_safe`** — if at every revolution the freshly created
> blocks are safe for the counter that the inherited blocks have built
> (`FreshSafe`), then `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never halts.

This is the exact, minimal form of the reduction: the density conditions of §§11
–13 are merely sufficient conditions for it.  It is checked inside Lean for the
machine's first ten revolutions (`revIter_freshSafe`).

### How long the fresh part is

`RequestProject/FreshLength.lean` adds the quantitative companion:

> **`normalF_cycles`** — a normal phase starting from a counter of capacity
> `gap w` pushes `m` digits with `3 ^ m ≤ 2 ^ m · (3 · gap w + 1)`,

i.e. `m ≤ log_{3/2}(3 · gap w + 1)`: the fresh part is exactly as long as the
counter's capacity measured in base `3/2`.  This is the arithmetical reason why
the whole question is borderline.  The counter that the inherited part rebuilds
has a capacity `G` at least as large as the one that produced the sequence, and
the fresh part has about `log_{3/2} G` blocks; each block `14` divides the
capacity by about `3/2` and each other block multiplies it by about `2`, so a
fresh part consisting *only* of blocks `14` would bring the capacity back to
`O(1)` — and anything better is safe with an exponential margin.  Quantitatively
(a heuristic computation, not formalised): with `j` non-`14` blocks in a prefix
the capacity is about `3 ^ j`, so the machine could only be endangered by a
fresh part in which some prefix contains fewer than about `2 log₂ m` blocks
different from `14`, out of `m`.  The measured proportion of blocks different
from `14` in the fresh parts is about `2/3`.

## 15. The sharpest form: the fresh material costs nothing new

§§11–14 left the halting question as a statement about the *fresh* blocks of
each revolution — in the best form (§14), that they should be safe for the
counter the inherited blocks have rebuilt.  That statement is now **proved**,
under a single inequality between the two counters, and with no density and no
equidistribution anywhere.

### The two counters run in step

A fresh block is not an arbitrary block: it is released by a digit that one
cycle of the normal phase pushed.  So the fresh part of a released sequence is
in one-to-one correspondence with the cycles of the phase that produced it, and
the two counters involved can be compared cycle by cycle:

```
old counter (being spent)   :  g ↦ ⌊(2g-1)/3⌋            one cycle
new counter (being built)   :  G ↦ 2G+1, 2G, 2G-1        blocks 44, 04, 24
                               G ↦ 2⌊(2(⌊G/2⌋-4))/3⌋+1   block 14
```

A fresh block `14` — the only expensive one — can therefore only appear at a
cycle at which the *old* counter also paid a factor `2/3`; everywhere else the
new counter doubles while the old one shrinks.  The ratio `G / g` never
decreases, and in fact it is multiplied by `3` at every fresh block different
from `14`.  In integer form (`RequestProject/Trajectory.lean`):

> **`normalF_fresh`** — if the normal phase of a counter `w` releases the blocks
> `S ++ M`, where `S` has one block per digit of `w`, then for every `G` with
> `28 · gap w + 9 ≤ G` the fresh part `M` satisfies `SafeRun G M` and
> `9 ≤ gfold G M`.

The constant `28` is exactly what the arithmetic allows: a block `14` leaves at
least `(2G-19)/3`, one cycle leaves at most `(2g-1)/3`, and
`28 = 19 + 9` is the smallest multiplier for which the first bound dominates the
second while still leaving the `9` that the next junction needs.  Note that the
hypothesis has to hold only *once*, at the beginning of the fresh part: from
there on it propagates by itself, whatever the fresh blocks turn out to be.

### What is left: one inequality per revolution

The junction costs a further factor: it divides the capacity by about `9/2`
(`junction_gap_bound`: `9 · gap (junction w) ≤ 2 · gap w + 2`), while the two
blocks it creates multiply the new counter by at least `4/9`.  Putting the two
together (`freshSafe_of_gapRatio`) and using the fact that the inherited blocks
are safe for free (§14) gives the current state of the problem:

> **`neverHalts_of_gapRatio_eight`** — if from its eighth revolution on the
> machine satisfies
> ```
> GapRatio L L' :  14 · (capacity the sequence L built) + 58
>                    ≤  (capacity the inherited blocks of L' rebuild),
> ```
> then `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA` never halts.

Compared with §§11–14 this is a genuine simplification: the fresh material — the
part nobody could control, and the part whose blocks `14` come from an
equidistribution question about the trajectory of `g ↦ ⌊(2g-1)/3⌋` — has
disappeared from the hypothesis.  What remains is a statement about the
**inherited** part alone, i.e. about a sequence and its successor, and it is a
*growth* statement rather than a density one: the counters must keep growing by
a factor `14` per revolution.

`RequestProject/TrajectoryChecks.lean` checks the inequality inside Lean on the
machine's own revolutions: it fails at the first two, where the counter is still
only `2^8`, resp. `2^15`, and holds from the third on (`revIter_gapRatio`, for
revolutions `2` to `7`), which is why the statement above starts at the eighth
revolution — everything before it is covered by the direct checks of
`RequestProject/FreshChecks.lean`.

### Why the inequality holds, and what would prove it (unverified)

The measured ratio of the two capacities is not merely `≥ 14`: it is

```
new capacity / old capacity  =  3 ^ u,
```

where `u` counts the **upgrades** — the positions at which the previous sequence
had a block `14` and the new one has a `04` or a `24` instead (`sim/gap_sim.py`,
seven revolutions, unverified).  This is exactly what the shape theorem of §13
predicts: an upgraded position replaces a factor `2/3` by a factor `2`, and
every other position is paired with an equally good one.  The data:

```
revolution      0     1      2      3      4      5      6
upgrades        0   1/2    5/8   9/15  26/40  47/68 114/169
log2(ratio)  0.07  1.59   7.93  14.26  41.21  74.49  180.69
log2(3^u)    0.00  1.58   7.92  14.26  41.21  74.49  180.69
```

So proving the halting question now amounts to showing that **at least three of
the blocks `14` of each sequence are upgraded** — about two thirds of them are,
in the measured range.  An upgrade happens when the radix-3/2 digit of that
position is not full at the overflow, or is full but the part of the counter
above it can no longer absorb an increment; this is a question about the state
of the counter at the moment the sweep reads it, and it is the last thing that
is not proved here.
