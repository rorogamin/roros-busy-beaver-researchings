# Proposed nonhalting completion

Machine: `1LB3RB0LB---2RB_2RA3LA4LB2LB0RA`.

## Result and verification status

This package supplies an unconditional **mathematical completion argument** and
an **uncompiled candidate Lean implementation**. The argument replaces the
unproved `GapRatio` hypothesis by a preserved invariant:

> The block sequence is safely resettable; its exact reset gap is even and at
> least 62.

The crucial new semantic fact is that saturation labels do not change under a
successful counter increment. Consequently the entire fresh suffix is a known
function of the old reset gap. An elementary strong induction, with 67 small
base cases, and 273 finite junction checks prove closure of the invariant.

**What has actually run:** the two finite certificates, 1,200 inverse-map boundary
checks, all 21,845 counter words of length at most seven, nine comparisons with
the original macro simulator, and 400 randomized safely resettable sequences.
All passed. The raw results and terminal log are included.

**What has not run:** Lean compilation or kernel verification of the three new
Lean modules, or a rebuild of the uploaded project. There was no Lean/Lake
executable in the authoring environment, and fetching the toolchain failed.
The `.lean` files must therefore be treated as candidates, not as certified
artifacts. They contain proof bodies rather than admitted lemmas, but elaboration
or tactic fixes may still be needed. Their intended final theorem is
`SOC.Completion.neverHalts : SOC.NeverHalts`.

Finite simulation is **not** being used as an argument for an infinite run. The
infinite part is the explicit induction in `NONHALTING_PROOF.md`.

## Files

- `NONHALTING_PROOF.md`: full argument, including the semantic bridge, exact
  integer formulas, induction, finite certificates, and the initial sequence.
- `verify_completion.py`: standard-library-only executable certificate and
  regression checker.
- `verification_results.json`, `verification_log.txt`: actual outputs of the
  checker in this environment.
- `lean_candidate/RequestProject/CompletionArithmetic.lean`: exact reset maps,
  fresh-word requirement, finite certificates, and the scalar closure theorem.
- `lean_candidate/RequestProject/CompletionSaturation.lean`: saturation invariant
  and the exact fresh-suffix formula for the original executable macro model.
- `lean_candidate/RequestProject/Completion.lean`: exact reset correspondence,
  inherited domination, invariant propagation, and the final nonhalting theorem.
- `reference/macro_sim.py`: unchanged original simulator from the supplied
  Aristotle archive, retained only for independent comparisons.
- `ORIGINAL_PROOF_DEPENDENCIES.md`: original source locations and SHA-256 hashes.
- `project/`: the full original project with the candidate additions, ready for
  a build attempt in an environment with its pinned toolchain and dependencies.
- `SHA256SUMS.txt`: integrity hashes for every other delivered file.

## Reproduce the executed checks

```sh
python3 verify_completion.py
```

Python 3.10 or newer is sufficient. No packages or network access are required.
The script uses explicit checks that remain active under `python -O`.

## Check the Lean candidate

A complete copy of the original project plus the candidate additions is in
`project/`. From this package directory, the intended check is:

```sh
cd project
lake build RequestProject.Completion
lake env lean CheckCompletion.lean
```

The second command prints the final theorem and its axiom dependencies.
Neither command has been run in this environment.

Alternatively, apply just the additions to your existing checkout:

Keep the original project and its pinned Lean/mathlib versions. Copy the three
files in `lean_candidate/RequestProject/` into its `RequestProject/` directory,
then run from the original project root:

```sh
lake build RequestProject.Completion
```

The finite certificates use `native_decide`, as does the supplied project.
Compilation has not been tested here; do not report the new theorem as
Lean-verified until this command succeeds and the final theorem's dependencies
have been inspected. There is no need to prove `GapRatio`, a density estimate,
or an upgrade-count conjecture on this route.

## Attribution

The machine semantics, counter model, executable macro simulator, and original
reduction lemmas are from the user's supplied Aristotle development. The new
saturation/scalar-suffix argument, invariant, arithmetic certificates, verifier,
and candidate Lean modules are the continuation produced in this session.
