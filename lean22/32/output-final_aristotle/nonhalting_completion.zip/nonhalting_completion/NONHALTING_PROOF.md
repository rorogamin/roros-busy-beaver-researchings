# A proposed completion of the nonhalting proof

## Status

This is an unconditional mathematical argument for the machine
`1LB3RB0LB---2RB_2RA3LA4LB2LB0RA`, using the counter/tape correspondence proved in
the supplied development. All finite arithmetic certificates specified below
were executed successfully. A candidate Lean implementation is included, but
**it has not been compiled or kernel-checked in this environment**. Accordingly,
the package is not yet a formally certified Lean completion. The semantic and
arithmetic proofs below are written out so that they can be audited independently
of the candidate source or of simulations.

The proof does **not** establish or assume the old `GapRatio` conjecture. It
bypasses that stronger sufficient condition.

Throughout, a block label `b` denotes the two-cell block `b4`: labels `4,0,2,1`
mean `44,04,24,14`. A list of labels is in tape order. The original Lean counter
lists digits least significant first; the reference Python simulator uses the
opposite order. The proof respects these conventions explicitly.

## 1. What is retained from the original development

The following results are already present in the archive.

1. `Inc.gap_eq`: one successful increment decreases the counter's gap by exactly
   one. Increments exist whenever the gap is positive, and overflow corresponds
   to zero gap (`Counter.lean`).
2. The exact digit-level increment and overflow rules (`Macro.lean`,
   `Fast.lean`), and their correspondence with genuine, positive-length tape
   runs.
3. Resetting a labelled block sequence preserves a binary least-significant
   digit whenever the required increments can be paid. The executable junction
   succeeds for a binary-headed counter of gap at least nine; the normal phase
   always succeeds (`Success.lean`).
4. The reset radix pattern is `true :: reverse(map notOne L)`
   (`resetF_pat`, `patF_true`, `Shape.lean`). In particular, the inherited
   released part has a `44` exactly where the old sequence does not have `14`.
5. `neverHalts_of_revIter`: if the executable revolution succeeds at every
   index, the original blank-tape Turing machine never halts (`Success.lean`).

No existing statement is changed. In particular, the old `gnext` remains a
valid lower bound. We introduce a different function for the **exact** gap.

## 2. Use the exact reset map

For a binary-headed counter of actual gap `G`, define

```
R_4(G) = 2G + 1,
R_0(G) = 2G,
R_2(G) = 2G - 1,                      requiring G >= 1,
R_1(G) = 2 floor((G - 8)/3) + 1,       requiring G >= 8.
```

These are exact, not asymptotic estimates. A word is called safely resettable
from `G` when its `14` blocks are read at gap at least eight and its `24` blocks
at gap at least one. Write `R_L(G)` for the iterated exact map on a safe word.

Only the formula for `14` needs explanation. Write the counter as a binary
lowest digit above a tail of gap `h`.

- If the lowest digit is `02`, its gap is `G = 2h+1`. The `14` rule increments
  the tail four times, replaces that digit by `03`, and pushes `02`. Its new
  gap is `2 floor((2(h-4)+1)/3)+1`.
- If the lowest digit is `22`, its gap is `G = 2h`. The rule instead creates
  `23` below the incremented tail, then pushes `02`. Its new gap is
  `2 floor(2(h-4)/3)+1`.

Both expressions are exactly `2 floor((G-8)/3)+1`. The condition `G >= 8`
ensures `h >= 4`, so no truncated subtraction is being used illicitly.
The formulas for the other three blocks follow immediately from `Inc.gap_eq`
and the digit definitions of `gap`.

Every map is monotone. At an affordable gap, `R_1` is the least of the four maps
and `R_4` is the greatest.

### Exact inherited domination

Suppose a safe word `L` is followed by a revolution releasing `S ++ M`, with
`|S| = |L|` and the original shape relation. Compare the two reset computations
of `L` and `S`, both starting at gap one.

At a position where `L` is not `14`, `S` is `44`, the best block. At a position
where `L` is `14`, its old gap is at least eight; the new gap is at least the old
one by induction, and whichever labelled block occurs in `S` is affordable and
at least as good as `14`. Monotonicity propagates the comparison.

Thus `S` is safely resettable and

```
R_S(1) >= R_L(1).
```

This is comparison with the **actual old reset gap**, not merely its former
`gfold` lower bound. It needs no upgrades at all.

## 3. The new semantic fact: saturation is invariant under increments

For a tail of gap `h`, define two label functions:

| `h mod 3` | `beta(h)` | `alpha(h)` |
|---|---:|---:|
| 0 | 0 | 2 |
| 1 | 2 | 1 |
| 2 | 1 | 0 |

Define a tape-order word `Sat(w)` recursively on a least-significant-first
counter:

```
Sat([])       = [],
Sat(02 :: w)  = Sat(w) ++ [4],
Sat(22 :: w)  = Sat(w) ++ [4],
Sat(03 :: w)  = Sat(w) ++ [beta(gap w)],
Sat(23 :: w)  = Sat(w) ++ [alpha(gap w)].
```

### Lemma 1: a successful increment preserves `Sat`

The binary cases preserve the final label `4`. The two fractional-digit cases
reduce, using the induction hypothesis on the tail and `Inc.gap_eq`, to

```
beta(h+1)  = alpha(h),
alpha(h+2) = beta(h).
```

Both identities follow from the three-row table. These correspond exactly to
`03` emitting one carry and becoming `23`, and `23` emitting two carries and
becoming `03`. Therefore `Inc w w'` implies `Sat(w') = Sat(w)`.

In particular, four successful increments also preserve saturation.

### Lemma 2: at zero gap, overflow emits `Sat(w)`

Prove this by induction on the counter length using `ovfF`.

A lowest binary digit must be `22` and emits `4`. A lowest `03` with zero gap
has tail gap zero and emits `0 = beta(0)`. A lowest `23` with zero gap has tail
gap zero or one. At zero it emits `2 = alpha(0)`; at one it increments the tail
once and emits `1 = alpha(1)`. Lemma 1 preserves the saturation of that
incremented tail. These are all the overflow cases.

Consequently saturation is a finite, local description of the eventual
released labels. One does not need to predict the timing of the final sweep.

## 4. The exact fresh word of a normal phase

For positive `g`, put

```
f(g) = floor((2g - 1)/3),

d(g) = 1 if g mod 3 = 0,
       0 if g mod 3 = 1,
       2 if g mod 3 = 2.
```

Define

```
F(0) = [],
F(g) = [d(g)] ++ F(f(g))     for g > 0.
```

This terminates since `0 <= f(g) < g`.

### Lemma 3: normal-phase decomposition

A normal phase starting from counter `w` releases precisely

```
Sat(w) ++ F(gap w).
```

At gap zero, this is Lemma 2. Otherwise the phase increments `w` to `w'` and
pushes `03`. Write the old gap as `g`; then `gap w' = g-1` and the new total gap
is `floor((2g-1)/3) = f(g)`. Moreover,

```
Sat(03 :: w') = Sat(w') ++ [beta(g-1)]
             = Sat(w)  ++ [d(g)].
```

The first equality is the definition, the second uses Lemma 1 and the residue
table. Induction on the strictly decreasing gap proves the claimed formula.

This is the information missing from a bound that permits an arbitrary fresh
block at each cycle. For example, the last positive gap is necessarily one,
because `f(g)=0` for positive `g` forces `g=1`. At this last cycle `d(1)=0`.
Therefore **every nonempty `F(g)` ends with `04`**.

## 5. The junction gives an equally explicit suffix

Let `g` be the exact gap at the end of a safe reset. Put

```
t(g) = floor((g-8)/3),
j(g) = floor(2 t(g)/3),
J(g) = [g mod 3, alpha(t(g))] ++ F(j(g)).
```

Here `g mod 3` is interpreted as the block label `0`, `1`, or `2`.

### Lemma 4: one revolution releases `S ++ J(g)`

The junction removes the lowest binary digit and increments its tail four
times. The converted fractional digit has gap `t(g)`: this is the same
calculation as for `14`, but without the final pushed binary digit. The junction
then pushes `23`, giving total gap `j(g)`.

By Lemma 1, the four tail increments do not change its saturation word. The
first converted digit's saturation label is `g mod 3`. This follows in its two
binary-head cases by substituting `g=2h+1` into `beta(h-4)`, or `g=2h` into
`alpha(h-4)`, respectively. The second junction digit has label `alpha(t(g))`.
Lemma 3 supplies the remaining word `F(j(g))`.

The part above the removed lowest digit is precisely the inherited part `S`:
its pattern follows from `resetF_pat` and `patF_true`, or from the original
shape theorem. Thus its length is `|L|`, and its shape is the one used for exact
inherited domination in Section 2.

## 6. Prove that the suffix is safe: a finite base and an infinite induction

We will maintain final reset gap at least **62**, as well as even parity.
For a required final gap `T >= 0`, the exact minimum starting gaps for a single
block are

```
I_4(T) = floor(T/2),
I_0(T) = floor((T+1)/2),
I_2(T) = floor((T+2)/2),
I_1(T) = 8 + 3 floor(T/2).
```

Direct substitution in the reset maps proves both affordability and
`R_b(G) >= T` whenever `G >= I_b(T)`. These really are the minima; this is useful
for the finite checks, though minimality is not needed for sufficiency.

Let `B(g)` be the required starting gap for `F(g)` to finish at least at 62:

```
B(0) = 62,
B(g) = I_{d(g)}(B(f(g)))     for g > 0.
```

By induction on `g`, starting with `G >= B(g)` safely reads `F(g)` and leaves
gap at least 62. This implication includes every intermediate safety test.

### Lemma 5: for all `g >= 133`, `B(g)+30 <= 2g`

The base cases are exactly `133 <= g < 200`, 67 integers. They are checked by
evaluating the recurrence above; the full values are in
`verification_results.json` and reproduced by `verify_completion.py`.

For `g >= 200`, let `m=f(g)`. Then `133 <= m < g`, so the induction hypothesis
says `B(m) <= 2m-30`. Split into the three residue classes.

* `g = 3k`: `m=2k-1`, so `2g=3m+3`, and
  `B(g)+30 = 38 + 3 floor(B(m)/2) <= 3m-7 <= 2g`.
* `g = 3k+1`: `m=2k`, so `2g=3m+2`, and
  `B(g)+30 <= m+15 <= 2g`.
* `g = 3k+2`: `m=2k+1`, so `2g=3m+1`, and
  `B(g)+30 <= m+16 <= 2g`.

The latter inequalities hold since `m >= 133`. This proves the **unbounded**
claim by strong induction. It is not an extrapolation of the finite test.

### Lemma 6: the full suffix is safe from any `G >= g`, for even `g >= 62`

Its sufficient starting gap is

```
H(g) = I_{g mod 3}( I_{alpha(t(g))}( B(j(g)) ) ).
```

We show `H(g) <= g`.

For the small range, evaluate this expression for the 273 even integers

```
g = 62, 64, 66, ..., 606.
```

All pass. The tightest requirement is at `g=76`: `H(76)=74`, and reading the
suffix from gap 76 finishes at gap 62. This edge case is why one must not
silently replace 62 by the more convenient constant 64.

For `g >= 608`, we have `t(g) >= 200`, hence `j(g) >= 133`. Apply Lemma 5. For
any of the block labels, its inverse map satisfies

```
2 I_b(T) <= 3T+16.
```

Applying this twice gives

```
4 H(g) <= 9 B(j(g)) + 80.
```

Since `B(j)+30 <= 2j`, it follows that

```
4 H(g) + 190 <= 18j(g).
```

Finally, the floor formula for the junction gives `9j(g) <= 2g`. Therefore
`4H(g)+190 <= 4g`, in particular `H(g) <= g`.

The large-range proof does not even require parity. Parity is needed only in
the small finite base. The assumption `g >= 62` also guarantees `j(g)>0`.
By Section 4, the last block of `F(j(g))`, and hence of `J(g)`, is `04`.
Consequently the final reset gap is **even**.

We have proved the universal closure fact

> If `g >= 62` is even and `G >= g`, the word `J(g)` is safely resettable from
> `G` and finishes with an even gap at least 62.

## 7. The invariant closes the actual machine's revolutions

Define the property of a labelled word `L`:

```
L is safely resettable from gap 1;
g = R_L(1) satisfies g >= 62 and g mod 2 = 0.
```

Suppose `L` has this property. Its reset succeeds and has a binary lowest digit.
Its junction succeeds since `g >= 62 >= 9`. The normal phase always succeeds,
so there is a next word `L'`.

By Lemma 4, `L' = S ++ J(g)`. Section 2 gives a safe inherited reset and
`G=R_S(1) >= g`. Lemma 6 then gives a safe reset of the suffix and an even final
gap at least 62. Thus **`L'` has the same property**.

This is a genuine inductive invariant; no density, upgrade count, future
trajectory assumption, or `GapRatio` premise appears in it.

## 8. Entering the invariant from the blank tape

The original `revIter 0` is

```
L0 = [4,4,4,0,4,0,2].
```

Its exact reset gaps are

```
1 -> 3 -> 7 -> 15 -> 30 -> 61 -> 122 -> 243.
```

It is safe, and its gap 243 is large enough for the junction, but it is odd.
Handle this one revolution explicitly. Its inherited part consists of seven
`44` blocks. For its suffix,

```
t(243)=78,   j(243)=52,
J(243) = [0,2,0,0,0,2,1,2,1,0].
```

Hence

```
L1 = [4,4,4,4,4,4,4,0,2,0,0,0,2,1,2,1,0].
```

Its exact gap after the seven initial `44` blocks is 255, and the remaining
reset gaps are

```
510, 1019, 2038, 4076, 8152, 16303, 10863, 21725, 14479, 28958.
```

Every block is affordable. The final gap 28958 is even and at least 62.
Therefore `L1` satisfies the invariant. The original development connects
`revIter 0` to the blank tape, and this is its genuine next revolution.

By induction, every later revolution exists. Together with the already existing
`neverHalts_of_revIter`, this gives nonhalting of the original Turing machine.

## 9. What the executable checks do, and do not, certify

The two finite base certificates are logically part of the mathematical proof:
67 values for Lemma 5, and 273 values for Lemma 6. They were all evaluated with
exact Python integers. Their entire tables are included, and the candidate Lean
module restates them as bounded `native_decide` theorems.

Additional regression tests were executed to check the derivation against the
original macro simulator, independently of the new scalar implementation:

- all 21,845 counter words of length at most seven, verifying increment-gap
  behavior, saturation preservation on every successful increment, and the full
  normal decomposition;
- nine complete revolutions of the actual initial sequence, with exact word
  equality between the old counter simulator and the new scalar transducer;
- 400 random safely resettable words with even reset gap at least 62, testing
  the junction suffix formula, inherited domination, and the invariant;
- 1,200 boundary checks of the inverse block maps.

These regression tests are not substitutes for the universal semantic lemmas.
Those lemmas are proved above by induction over the original counter rules.
Likewise, these checks do not certify that the candidate Lean source elaborates.
A successful Lean build and dependency audit remain necessary before calling
this a formally verified completion.
