#!/usr/bin/env python3
"""Reproduce the finite certificates and regression checks for the completion.

This is NOT a Lean kernel checker. The universal induction and semantic bridge
are proved in NONHALTING_PROOF.md and supplied as uncompiled Lean candidates.
The finite certificates below are exhaustive over their stated bounded domains.

Requires Python 3.10+ and only the standard library. Run from any directory:
    python3 verify_completion.py
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path
import random
import sys
from typing import Iterable, Sequence

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "reference"))
import macro_sim as reference  # Original, unchanged simulator from the archive.

LABELS = (4, 0, 2, 1)
FIRST = [4, 4, 4, 0, 4, 0, 2]
SEED = [4, 4, 4, 4, 4, 4, 4, 0, 2, 0, 0, 0, 2, 1, 2, 1, 0]
TARGET = 62


def require(condition: bool, message: str) -> None:
    """Do not use assert: checks must also run under python -O."""
    if not condition:
        raise RuntimeError(message)


def xnext(g: int, block: int) -> int | None:
    """Exact reset gap; None denotes an unaffordable block."""
    if g < 0:
        raise ValueError("negative gap")
    if block == 4:
        return 2 * g + 1
    if block == 0:
        return 2 * g
    if block == 2:
        return 2 * g - 1 if g >= 1 else None
    if block == 1:
        return 2 * ((g - 8) // 3) + 1 if g >= 8 else None
    raise ValueError(f"invalid block {block}")


def run_reset(g: int, blocks: Iterable[int]) -> int | None:
    for block in blocks:
        next_gap = xnext(g, block)
        if next_gap is None:
            return None
        g = next_gap
    return g


def inverse(block: int, target: int) -> int:
    """Least gap that affords the block and leaves gap >= target."""
    if target < 0:
        raise ValueError("negative target")
    if block == 4:
        return target // 2
    if block == 0:
        return (target + 1) // 2
    if block == 2:
        return (target + 2) // 2
    if block == 1:
        return 8 + 3 * (target // 2)
    raise ValueError(f"invalid block {block}")


def required_gap(blocks: Sequence[int], target: int = TARGET) -> int:
    result = target
    for block in reversed(blocks):
        result = inverse(block, result)
    return result


def descend(g: int) -> int:
    if g < 1:
        raise ValueError("normal cycle needs positive gap")
    return (2 * g - 1) // 3


def fresh(g: int) -> list[int]:
    if g < 0:
        raise ValueError("negative gap")
    result: list[int] = []
    while g:
        result.append((1, 0, 2)[g % 3])
        g = descend(g)
    return result


def beta(h: int) -> int:
    return (0, 2, 1)[h % 3]


def alpha(h: int) -> int:
    return (2, 1, 0)[h % 3]


def junction_top(g: int) -> int:
    if g < 8:
        raise ValueError("junction needs gap >= 8")
    return (g - 8) // 3


def junction_gap(g: int) -> int:
    return 2 * junction_top(g) // 3


def suffix(g: int) -> list[int]:
    t = junction_top(g)
    return [g % 3, alpha(t)] + fresh(2 * t // 3)


def counter_gap(w: Sequence[int]) -> int:
    """Original simulator order: MOST significant digit first."""
    h = 0
    for digit in w:
        if digit == 0:
            h = 2 * h + 1
        elif digit == 1:
            h = 2 * h
        elif digit == 2:
            h = (2 * h + 1) // 3
        elif digit == 3:
            h = 2 * h // 3
        else:
            raise ValueError(f"invalid counter digit {digit}")
    return h


def saturation(w: Sequence[int]) -> list[int]:
    h = 0
    out: list[int] = []
    for d in w:
        if d == 0:
            out.append(4)
            h = 2 * h + 1
        elif d == 1:
            out.append(4)
            h *= 2
        elif d == 2:
            out.append(beta(h))
            h = (2 * h + 1) // 3
        elif d == 3:
            out.append(alpha(h))
            h = 2 * h // 3
        else:
            raise ValueError(f"invalid counter digit {d}")
    return out


def scalar_revolution(blocks: Sequence[int]) -> tuple[list[int], int]:
    """An additional independently testable consequence of saturation.

    At an old 14, the inherited label is the pre-block gap modulo three.
    This stronger observation is not required by the nonhalting proof.
    """
    g = 1
    inherited: list[int] = []
    for b in blocks:
        inherited.append(g % 3 if b == 1 else 4)
        nxt = xnext(g, b)
        if nxt is None:
            raise ValueError("unsafe input sequence")
        g = nxt
    if g < 9:
        raise ValueError("junction not guaranteed by the original lemma")
    return inherited + suffix(g), g


def finite_certificates() -> dict:
    # Compute B bottom-up: every dependency is a strictly smaller integer.
    B = [TARGET] * 200
    for g in range(1, 200):
        B[g] = inverse((1, 0, 2)[g % 3], B[descend(g)])
        require(B[g] == required_gap(fresh(g)), f"B mismatch at {g}")
    normal_rows = []
    for g in range(133, 200):
        require(B[g] + 30 <= 2 * g, f"normal base failed at {g}")
        normal_rows.append({"g": g, "B": B[g], "slack": 2 * g - B[g] - 30})
    suffix_rows = []
    for g in range(62, 608, 2):
        word = suffix(g)
        need = required_gap(word)
        end = run_reset(g, word)
        require(need <= g, f"suffix base requirement failed at {g}")
        require(end is not None and end >= 62 and end % 2 == 0,
                f"suffix base direct replay failed at {g}")
        suffix_rows.append({"g": g, "required": need, "margin": g - need,
                            "end_at_G_equals_g": end})
    return {
        "normal_base": {"count": len(normal_rows), "range_inclusive": [133, 199],
                        "rows": normal_rows},
        "suffix_base": {"count": len(suffix_rows), "even_range_inclusive": [62, 606],
                        "rows": suffix_rows},
    }


def check_small_counters(max_length: int = 7) -> dict:
    count = 0
    increments = 0
    for length in range(max_length + 1):
        for digits in itertools.product(range(4), repeat=length):
            original = list(digits)
            g = counter_gap(original)
            sat = saturation(original)
            w = original.copy()
            ok = reference.addT(w, 1)
            require(ok == (g > 0), "increment/gap equivalence mismatch")
            if ok:
                increments += 1
                require(counter_gap(w) == g - 1, "increment gap mismatch")
                require(saturation(w) == sat, "saturation invariance mismatch")
            w = original.copy()
            reference.normal_phase(w)
            require(counter_gap(w) == 0, "normal phase did not reach zero gap")
            got = reference.released(w)
            require(got == sat + fresh(g), f"normal decomposition mismatch: {digits}")
            count += 1
    return {"all_counters_through_length": max_length, "counters": count,
            "successful_increment_checks": increments}


def check_reference_revolutions(count: int = 9) -> list[dict]:
    rows = []
    blocks = FIRST.copy()
    for n in range(count):
        predicted, g = scalar_revolution(blocks)
        got, error, cycles = reference.revolution(blocks)
        require(error is None and got == predicted, f"reference revolution mismatch at {n}")
        w = [0]
        require(reference.reset_phase(w, blocks) is None, "reference reset failed")
        require(counter_gap(w) == g, "exact reset gap mismatch")
        if n >= 1:
            require(g >= 62 and g % 2 == 0, f"seed/orbit invariant failed at {n}")
        if n == 0:
            require(g == 243 and got == SEED, "seed sequence mismatch")
        if n == 1:
            require(g == 28958, "seed gap mismatch")
        new_g = run_reset(1, got)
        require(new_g is not None and new_g >= 62 and new_g % 2 == 0,
                f"successor invariant failed at {n}")
        inherited = got[:len(blocks)]
        G = run_reset(1, inherited)
        require(G is not None and G >= g, "inherited domination mismatch")
        rows.append({"revolution_index": n, "input_length": len(blocks),
                     "output_length": len(got), "reset_gap_bit_length": g.bit_length(),
                     "normal_cycles": cycles,
                     "output_sha256": hashlib.sha256(bytes(got)).hexdigest()})
        blocks = got
    return rows


def check_random_safe_sequences(samples: int = 400) -> dict:
    rng = random.Random(0x625A7)
    checked = 0
    attempts = 0
    while checked < samples and attempts < 100 * samples:
        attempts += 1
        blocks = [4] * 7 + [rng.choice(LABELS) for _ in range(rng.randrange(1, 160))]
        g = run_reset(1, blocks)
        if g is None or g < 62 or g % 2:
            continue
        predicted, exact = scalar_revolution(blocks)
        got, err, _ = reference.revolution(blocks)
        require(err is None and got == predicted and exact == g, "random semantic mismatch")
        G = run_reset(1, got[:len(blocks)])
        require(G is not None and G >= g, "random inherited domination mismatch")
        require(got[len(blocks):] == suffix(g), "random junction suffix mismatch")
        result = run_reset(1, got)
        require(result is not None and result >= 62 and result % 2 == 0,
                "random closure mismatch")
        checked += 1
    require(checked == samples, "not enough random safe sequences")
    return {"samples": checked, "attempts": attempts, "seed": "0x625A7"}


def inverse_boundary_checks() -> int:
    count = 0
    for b in LABELS:
        for target in range(300):
            g = inverse(b, target)
            got = xnext(g, b)
            require(got is not None and got >= target, "inverse sufficiency failure")
            if g:
                smaller = xnext(g - 1, b)
                require(smaller is None or smaller < target, "inverse minimality failure")
            count += 1
    return count


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "verification_results.json")
    parser.add_argument("--revolutions", type=int, default=9)
    parser.add_argument("--counter-length", type=int, default=7)
    parser.add_argument("--random-samples", type=int, default=400)
    args = parser.parse_args()
    require(1 <= args.revolutions <= 12, "choose 1..12 reference revolutions")
    require(0 <= args.counter_length <= 8, "choose counter length 0..8")
    require(0 <= args.random_samples <= 10000, "choose 0..10000 random samples")
    print("Checking the finite proof certificates...", flush=True)
    results = finite_certificates()
    results["inverse_boundary_cases"] = inverse_boundary_checks()
    print("Checking saturation against the original counter simulator...", flush=True)
    results["exhaustive_counter_checks"] = check_small_counters(args.counter_length)
    print("Comparing revolutions with the original simulator...", flush=True)
    results["reference_revolutions"] = check_reference_revolutions(args.revolutions)
    results["random_sequence_checks"] = check_random_safe_sequences(args.random_samples)
    results["status"] = {
        "finite_certificates": "PASS",
        "regression_checks": "PASS",
        "lean_kernel_check": "NOT RUN - Lean toolchain unavailable in authoring environment",
        "universal_claim": "See the strong induction and semantic proof in NONHALTING_PROOF.md",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {results['normal_base']['count']} normal base cases; "
          f"{results['suffix_base']['count']} junction base cases.")
    print(f"PASS: {results['exhaustive_counter_checks']['counters']} counters; "
          f"{len(results['reference_revolutions'])} original-model revolutions; "
          f"{results['random_sequence_checks']['samples']} random safe sequences.")
    print("NOT a Lean kernel check. Lean sources are explicitly uncompiled candidates.")
    print(f"Results written to {args.output}")


if __name__ == "__main__":
    main()
