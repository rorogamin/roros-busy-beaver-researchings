# Nonhalting of the sibling with B3 = 4RB and B4 = 0LB

Machine under discussion:

```
S = 1RB2LA0RB1LB---_1LA3RA1RA4RB0LB
```

The previously proved machine to compare with is **0RB**, not 0LB:

```
O = 1RB2LA0RB1LB---_1LA3RA1RA4LB0RB.
```

## Result and certification status

**Theorem.** S does not halt from the blank tape. More strongly, its run has
exactly the same ordinary return checkpoints as the proved machine O, at the
same base-step times, until any common spinout alternative is taken. Those
spinouts are also nonhalting for S.

This document gives a mathematical proof by transferring the already proved
0RB return argument. The new ingredient is an exact, time-preserving
replacement of each pop episode. There is no new unproved arithmetic or
reachability invariant. This is **not a new Lean certificate**: the supplied
Lean source contains local proof candidates and the episode composition,
not the completed machine-polymorphic return integration. It has not been
compiled here. Existing project theorems are identified by module and name;
the original project was not changed.

The test results are consistency checks, not premises of the infinite proof.

## 1. Notation and what really changes

Write stacks bottom first and omit the permanent L = ^11 when writing a
counter core. Use the project's blocks:

```
left:  X = 11, Z = 01, W = 03, L = ^11
right: X = 11, Y = 22, V = 21, U = 12
       R = blank right end, R1 = 1$, R2 = 2$
       P1 = pending 1, P2 = pending 2
```

`<B1` means a left-reading B head with an extra 1 immediately to its right.
The extra 1 is not part of the displayed right word. Tape words in formulas
are in their physical left-to-right order; Lean's left lists have the
opposite order.

S and O differ at exactly B3 and B4. Consequently, one cannot simply
instantiate the old family theorem at B4 = 0LB. The old W-on-B rule is false
for S. Instead introduce a new left marker

```
Q = 043.
```

The four relevant exact rules of S, with unchanged exterior contexts, are:

| Rule | Base steps |
|---|---:|
| `03 <B1 -> 043 A>` | 2 |
| `043 <A -> <A 101` | 3 |
| `A> 101 -> <A 201` | 1 |
| `A> 201 -> <B1 22` | 9 |

The first rule is B3 followed by B1. The second is A3, B4, B0.
For the last rule the instruction sequence is

```
A2, B0, A0, B1, A1, A3, B1, A1, A3.
```

In particular it does not use either changed transition. The three-step
marker erasure enters the 4 cell in state B, not A. This explicitly checks
the potentially fatal point.

All ordinary counter, bit-scan, pending-digit and end rules used below
remain valid. For example:

```
W <A -> <A X        (2)       A> X -> <A V      (1)
Z <A -> X A>        (3)       A> V -> W A>      (2)
X <A -> <A Y        (2)       A> Y -> Z A>      (2)
Z <B1 -> <A X P2    (4)       A> U -> <A Y      (1)
X <B1 -> <B1 Y      (6)
A> R -> <A V R      (3)
A> R1 -> <A R2      (1)
A> R2 -> <B1 Y R1  (11)
L <A -> L A> P2     (4).
```

These are direct transition-table identities, not consequences of treating S
as an old-family member. None of them executes B3 or B4. Pending-digit
reparsings change no physical tape and cost zero steps.

## 2. The supplied decrement is unchanged

The ordinary value of a counter core is

```
v(empty) = 0
v(cX) = 2v(c)
v(cZ) = 2v(c)+1
v(cW) = floor(v(c)/2).
```

For v(c) > 0, the project's decrement excursion D is finite and satisfies

```
c <A t -> D(c) A> t,
v(D(c)) = v(c)-1.
```

It uses only the common ordinary rules. It does not enter the pre-existing
right suffix t. Thus its time delta(c) depends on c, not on t or on whether
the machine is S or O.

In particular v(c) >= 2 supplies both D(c) and D^2(c). This hypothesis is
essential. No episode theorem below asserts safety for a core of value zero
or one.

Project interfaces: `Prefix/Stack.lean` and the counter excursion lemmas,
especially `brun_cdec_of`, `brun_cdec_rep_of`, `cdec_cval`.

## 3. The untouched-marker interface

Temporarily regard a marker K and everything below it as a protected base.
We need an excursion of the form

```
K A> t -> K <A f(t),
```

which does not read any marker cell before its final configuration. Its time
will be denoted tau(t). If this is true, both the marker's contents and the
underlying core can be changed without changing this local computation.

Only two types of right suffix occur at a pop in the 0RB return proof. The
interface holds for both, using only the common rules of Section 1.

### 3.1 Even terminal: an arbitrary colored Dyck prefix

Let w be a word over Y,X,V whose prefixes all have nonnegative height, with
Y contributing +1 and X,V contributing -1. Let h be its final height. Then

```
K A> w R -> K <A w X^h V R.                         (E)
```

A proof independent of the marker is useful here. Decompose w into balanced
groups separated by its unmatched Y openings. A balanced group restores the
counter below it: its opening Y pushes a one, the interior restores that
one, and the closing V or X matches it without borrowing below it. The X
case first changes that one to zero. Therefore all unmatched bits after
reading w are ones and the local counter value is 2^h-1; its decoder is w.

At R, a positive drain round decrements and appends W. On the all-ones
unmatched numeral, this matches one last bit, which has become zero, so its
decoder appends X. There are exactly h such rounds. The final zero-counter
excursion deposits the whole decoder and the last right-end V, giving (E).
The counter decreases and no marker cell is accessed before the endpoint.

This is exactly the proof of `marker_return_word` in
`Prefix/RB/Count.lean`, built from `cfold_props` and `drain_plain`. In
particular, "untouched" is not merely a claim about the endpoint: the proof
constructs the intervening run over a foreign base.

### 3.2 Odd terminal: Y^r R1, with r >= 2

Define f_r by

```
f_2 = X Y Y V
f_3 = Y V Y Y V
f_r = Y^(r-2) V Y Y V X V^(r-3)       for r >= 4.
```

Then, up to zero-cost pending-digit re-parsing,

```
K A> Y^r R1 -> K <A f_r R.                       (O)
```

Here is the complete case split behind this interface. Reading Y^r pushes
Z^r. The R1 turn spends one decrement; the R2 rule then enters B with right
word YR1. B strips the top X, sees the next Z, and leaves

```
K Z^(r-2) <A X P2 Y Y R1.
```

The condition r >= 2 is exactly what makes that next bit a Z. Thus this
local computation does not execute a B-on-W or B-on-marker rule.

For r=2 the marker is already exposed. The suffix `P2 Y Y R1` is the same
physical tape as `Y Y V R`, so the emitted word is f_2.

For r=3 a six-step decrement/turn/overflow across the single remaining Z
adds YV before that suffix. This gives f_3.

For r>=4 put j=r-2>=2. Starting with Z^j, the local computation spends two
decrements, appends W, reads the re-parsed YYV, and reaches the bare end with
local stack

```
D^2(Z^j) W Z Z W.
```

Its counter is 2^j-3 and its decoder is `Y^j V Y Y V`. The ordinary drain
adds `X V^(j-2)`, followed by the final V. This yields exactly
`Y^j V Y Y V X V^(j-1)`, which is f_r. The drain is finite. Again all reads
are strictly above the marker until the return in state <A.

The existing implementation is the local portion of `first_episode` in
`Prefix/RB/Sweep.lean`, with the large case supplied by `marker_drain_gen`.
The initial and final old-marker instructions in `first_episode` are NOT
being reused for S.

## 4. The decisive commuting diagram

Suppose v(c)>=2 and t is one of the two supported suffixes of Section 3.
Put c1=D(c), c2=D^2(c), and t'=f(t). Let the decrement times be k1,k2 and
let the untouched-marker time be tau.

### Old proved machine O

Its F=141, G=241, J0=003 episode is

```
c W <B1 t
    --2--> c <A F t
    --k1-> c1 A> F t
    --1--> c1 <A G t
    --k2-> c2 A> G t
    --3--> c2 J0 A> t
    --tau-> c2 J0 <A t'
    --9--> c2 <B1 Y t'.
```

### New sibling S

Its corresponding episode is

```
c W <B1 t
    --2--> c Q A> t
    --tau-> c Q <A t'
    --3--> c <A N1 t'
    --k1-> c1 A> N1 t'
    --1--> c1 <A N2 t'
    --k2-> c2 A> N2 t'
    --9--> c2 <B1 Y t',
```

where N1=101 and N2=201.

Every arrow has been justified above. Most importantly, the local marker
excursion leaves c unchanged, so the two decrements needed *after* it are
still supplied by the original v(c)>=2. Their costs are the same because
they do not inspect the right suffix.

**Both endpoints are the identical full configuration**, not merely equal
counter values. Both elapsed times are

```
k1 + k2 + tau + 15.
```

Thus the sibling delays the two counter decrements until after the local
marker computation, but otherwise has precisely the old pop effect.

No unproved commutativity of arbitrary machine steps is being assumed.
The argument is a composition of the displayed, context-protected finite
runs. It is not an equivalence theorem for arbitrary starting tapes.

## 5. Both exact sweep rules transfer

For the first pop, with r>=2, let w0(r)=Y f_r. Section 4 gives for S

```
c W <B1 Y^r R1 -> D^2(c) <B1 w0(r) R.
```

Explicitly:

```
w0(2) = Y X Y Y V
w0(3) = Y Y V Y Y V
w0(r) = Y^(r-1) V Y Y V X V^(r-3), r>=4.
```

For a subsequent pop, if w is a colored Dyck prefix of height h,

```
c W <B1 w R -> D^2(c) <B1 Y w X^h V R.
```

These are exactly `first_episode` and `rb_pop_episode` of the old 0RB
argument, including their ordinary output configurations. Consequently the
same generated right-word language applies:

```
w0(r)                         has height h0(r), r>=2;
w -> Yw                       increases height by one;
w -> Y w X^h V                has height zero.
```

Here h0(3)=2 and h0(r)=1 otherwise. This is precisely `Gen` in
`Prefix/RB/Gen.lean`. In particular, we have not replaced this correlated
language by arbitrary clean words in the later Z/reset proof.

## 6. The existing closed invariant is enough

Use the old CP0 predicate, without strengthening or weakening it:

* the core is an admissible counter stack;
* it is Good: each bottom prefix p has b(p)>=v(p), where b=rho(P(p));
* it is strictly admissible: every nonempty bottom prefix has positive height;
* its value is positive and its top block is X;
* its finite two-decrement B scan is Ready.

For completeness, P emits Y on each bit, X at a W matched to a zero bit,
and V at a W matched to a one bit. The decoder value b uses integer maps
Y:a->2a+1, V:a->2a, X:a->floor(a/2)-1, starting from zero.

With permanent L omitted, Ready is the inductive predicate

```
Ready(empty) = true
Ready(cZ) = true
Ready(cX) iff Ready(c)
Ready(cW) iff v(c)>=2 and Ready(D^2(c)).
```

It is a condition on a finite present stack, not an assumption of nonhalting.
Each continuing scan action removes one block, since decrements preserve
block length.

The ordinary checkpoint is `L s <B1 Y R1`. Since its top is X, the first
scan action costs six steps and gives two right-hand Y blocks. Thus the
first pop can only have r>=2. Ready provides v(c)>=2 at each pop. The first
pop creates w0(r), and every later pop and stripped X preserves membership
in Gen exactly as in the original proof.

The scan therefore terminates at Z or the bottom. If it reaches Z, the old
odd- or even-terminal Z/reset proof applies with unchanged stack and word.
Those proofs use the ordinary counter/reset/end rules, not the F/G/J0 pop
rules: the changed pop routine has already been eliminated into the macro
rules of Section 5. The arithmetic closure results (Good, strictness,
positivity, top X and Ready) are statements about precisely the same words
and stacks, so they are unchanged.

The relevant existing results are:

```
Prefix.LA.Final.zready              (the ordinary odd-terminal Z branch)
Prefix.RB.Even.zeven                (the Gen-word even-terminal Z branch)
Prefix.RB.Sweep.sweep_odd / sweep_even
Prefix.RB.Sweep.cp0_returns
Prefix.RB.Final.cp0_seed
```

Here the dotted file portions are module paths: the declarations themselves
are in namespace `BB25.Prefix`. The supplied source's final theorem is
`BB25.Prefix.not_halts_0RB` in `Prefix/RB/Final.lean`.

### Why the reused Z proofs do not silently use B3

The low-level rule list in Section 1 supports all supplied decrements,
zero-counter overflows, clean and exceptional paid resets, and right-end
turns. These computations end at the new B checkpoint before its next pop.
The only B-on-counter moves used within the odd local clock are B-on-X and
B-on-Z; its remaining portion is an A-counter drain. The even marker clock
is entirely a counter construction/drain until the boundary is exposed.

Thus at the level of the return-proof derivation, every use of a changed
transition is inside one of the two pop episodes replaced in Section 5.
This is the reason the transfer works; universal quantification over B4 in
an old theorem, by itself, would not have justified it.

### Escape alternatives are also safe

The original return proof allows two elementary nonhalting exits. For S the
same literal base identities hold, with arbitrary untouched suffix t:

```
L <B1 t       -> [] <A 1122t       (7 steps)
[] <A 1122t   -> [] <A 112222t     (8 steps)
L <A 1122t    -> L <A 11222t       (9 steps).
```

The last two may be iterated forever. These routines do not execute B3 or
B4. Therefore transferring the return proof does not lose a nonhalting
branch that the old argument handles by an escape rather than another CP0.

## 7. Entry and positive-time conclusion

Both machines reach the same CP0 seed after 156 base steps:

```
L Z Z Z X X X <B1 Y R1.
```

Its value is 56 and decoded value 63. It is an all-bit, strict, Good stack;
Ready strips three X blocks and stops at a Z. No changed transition is used
on this finite entry path.

From any CP0 checkpoint the transferred return argument either reaches one
of the displayed nonhalting spinouts, or reaches another CP0 checkpoint.
In the latter case at least six base steps elapsed, because the initial X
removal costs six. Thus zero-cost pending-digit reparsings cannot produce a
spurious infinite computation with bounded base time.

If there is no spinout, iterate the return theorem: for each n there is a
defined run covering at least 156+6n base steps from blank. A finite halting
time would contradict one of these defined runs. Hence

```
not Halts(S, init).
```

The commuting diagram preserves elapsed time at each pop, and all other
parts are identical common-rule computations. It also proves equality of
the ordinary checkpoint sequence and its base-step clock with O, not just
nonhalting of S. This does not say the intermediate configurations are
identical: they are different inside a pop episode.

## 8. Reproducible checks and their limits

`python verify.py` reproduces these finite checks, with no third-party
Python dependencies:

* 21,142 common-rule/machine context instances, 1,922 new-marker context
  instances, and 434 boundary/spinout instances.
* 279,822 old/sibling pop-episode pairs, checking the entire directed
  configuration, the predicted output word, the twice-decremented core and
  exact elapsed time. This includes all cores of length at most 7 with
  value at least 2 (admissibility is not imposed), all colored Dyck prefixes
  through length 6, and first-pop tails 2<=r<=9.
* 4,800 additional episode pairs checked without stride acceleration, by
  replaying every block arrow with the raw transition tables; 952,640 base
  transitions were replayed in total.
* 32 successive ordinary checkpoints from blank match exactly, including
  elapsed times; the largest tested core has 810 blocks.
* An independent absolute-position sparse-tape simulator executes each
  machine for 188,820 primitive steps from blank and checks the first six
  checkpoint tapes, head positions and states, including equality in
  absolute coordinates between the two machines.

The initial matching checkpoint times are

```
156, 585, 1079, 1229, 188670, 188820.
```

The first differing instruction is executed from time 591. The first pop
runs from time 591 to time 721 in both machines; the next two end at 827
and 967. Such finite agreement is not the proof. The proof is Sections
2-7, especially the protected-marker commuting diagram and the established
CP0/Gen closure.
