/-
Local lemmas for 1RB2LA0RB1LB---_1LA3RA1RA4RB0LB.

Status: SOURCE CANDIDATE, NOT COMPILED in this environment.
No `sorry`, new axiom, or nonhalting theorem is asserted here. The complete
mathematical transfer argument is PROOF.md; FORMALIZATION.md describes the
remaining machine-polymorphic core/return integration.

Install this file under RequestProject/BB25/SiblingLocal.lean in the supplied
project, then run `lake env lean RequestProject/BB25/SiblingLocal.lean`.
-/
import RequestProject.BB25.Prefix.RB.Final

namespace BB25.Sibling

/-- The sibling, NOT the original family member with B4 = 0LB. -/
def machine : Machine
  | .A => famA
  | .B => fun s => match s with
    | 0 => some (1, .L, .A)
    | 1 => some (3, .R, .A)
    | 2 => some (1, .R, .A)
    | 3 => some (4, .R, .B)
    | 4 => some (0, .L, .B)

variable (l r : List Sym)

/-- 03 <B1 -> 043 A>, in two base transitions. -/
theorem rule_W_B1 :
    steps machine 2 (Cfg.mk (3 :: 0 :: l) .B .L (1 :: r)) =
      some (Cfg.mk (3 :: 4 :: 0 :: l) .A .R r) := rfl

/-- 043 <A -> <A 101, in three base transitions. -/
theorem rule_Q_A :
    steps machine 3 (Cfg.mk (3 :: 4 :: 0 :: l) .A .L r) =
      some (Cfg.mk l .A .L (1 :: 0 :: 1 :: r)) := rfl

/-- A> 101 -> <A 201. -/
theorem rule_A_N1 :
    steps machine 1 (Cfg.mk l .A .R (1 :: 0 :: 1 :: r)) =
      some (Cfg.mk l .A .L (2 :: 0 :: 1 :: r)) := rfl

/-- A> 201 -> <B1 22, in nine base transitions. -/
theorem rule_A_N2 :
    steps machine 9 (Cfg.mk l .A .R (2 :: 0 :: 1 :: r)) =
      some (Cfg.mk l .B .L (1 :: 2 :: 2 :: r)) := rfl

/- The ordinary core rules really hold for this new transition table. -/
theorem rule_W_A :
    steps machine 2 (Cfg.mk (3 :: 0 :: l) .A .L r) =
      some (Cfg.mk l .A .L (1 :: 1 :: r)) := rfl

theorem rule_Z_A :
    steps machine 3 (Cfg.mk (1 :: 0 :: l) .A .L r) =
      some (Cfg.mk (1 :: 1 :: l) .A .R r) := rfl

theorem rule_X_A :
    steps machine 2 (Cfg.mk (1 :: 1 :: l) .A .L r) =
      some (Cfg.mk l .A .L (2 :: 2 :: r)) := rfl

theorem rule_Z_B1 :
    steps machine 4 (Cfg.mk (1 :: 0 :: l) .B .L (1 :: r)) =
      some (Cfg.mk l .A .L (1 :: 1 :: 2 :: r)) := rfl

theorem rule_X_B1 :
    steps machine 6 (Cfg.mk (1 :: 1 :: l) .B .L (1 :: r)) =
      some (Cfg.mk l .B .L (1 :: 2 :: 2 :: r)) := rfl

theorem rule_A_X :
    steps machine 1 (Cfg.mk l .A .R (1 :: 1 :: r)) =
      some (Cfg.mk l .A .L (2 :: 1 :: r)) := rfl

theorem rule_A_V :
    steps machine 2 (Cfg.mk l .A .R (2 :: 1 :: r)) =
      some (Cfg.mk (3 :: 0 :: l) .A .R r) := rfl

theorem rule_A_Y :
    steps machine 2 (Cfg.mk l .A .R (2 :: 2 :: r)) =
      some (Cfg.mk (1 :: 0 :: l) .A .R r) := rfl

theorem rule_A_U :
    steps machine 1 (Cfg.mk l .A .R (1 :: 2 :: r)) =
      some (Cfg.mk l .A .L (2 :: 2 :: r)) := rfl

theorem rule_A_R :
    steps machine 3 (Cfg.mk l .A .R []) =
      some (Cfg.mk l .A .L [2, 1]) := rfl

theorem rule_A_R1 :
    steps machine 1 (Cfg.mk l .A .R [1]) =
      some (Cfg.mk l .A .L [2]) := rfl

theorem rule_A_R2 :
    steps machine 11 (Cfg.mk l .A .R [2]) =
      some (Cfg.mk l .B .L [1, 2, 2, 1]) := rfl

theorem rule_L_A :
    steps machine 4 (Cfg.mk [1, 1] .A .L r) =
      some (Cfg.mk [1, 1] .A .R (2 :: r)) := rfl

/-- The new placement of the two decrements, composed at base-machine level.
The marker hypothesis must be supplied by the untouched-marker theorem.
The two decrement hypotheses must be supplied by v(c) >= 2, not assumed for
arbitrary stacks. They are explicitly quantified over the untouched right
context, so the word emitted by the marker causes no interference. -/
theorem pop_composition
    (l d1 d2 r out : List Sym) (k1 k2 tau : Nat)
    (h1 : forall t : List Sym,
      steps machine k1 (Cfg.mk l .A .L t) = some (Cfg.mk d1 .A .R t))
    (h2 : forall t : List Sym,
      steps machine k2 (Cfg.mk d1 .A .L t) = some (Cfg.mk d2 .A .R t))
    (hm : steps machine tau (Cfg.mk (3 :: 4 :: 0 :: l) .A .R r) =
      some (Cfg.mk (3 :: 4 :: 0 :: l) .A .L out)) :
    steps machine (2 + (tau + (3 + (k1 + (1 + (k2 + 9))))))
      (Cfg.mk (3 :: 0 :: l) .B .L (1 :: r)) =
      some (Cfg.mk d2 .B .L (1 :: 2 :: 2 :: out)) := by
  exact steps_trans (rule_W_B1 l r)
    (steps_trans hm
      (steps_trans (rule_Q_A l out)
        (steps_trans (h1 (1 :: 0 :: 1 :: out))
          (steps_trans (rule_A_N1 d1 out)
            (steps_trans (h2 (2 :: 0 :: 1 :: out)) (rule_A_N2 d2 out))))))

/-- The old and new episode bookkeeping give the same base-step count. -/
theorem equal_episode_cost (k1 k2 tau : Nat) :
    2 + (k1 + (1 + (k2 + (3 + (tau + 9))))) =
      2 + (tau + (3 + (k1 + (1 + (k2 + 9))))) := by omega

/- The two escape alternatives used by the old return proof are unchanged. -/
theorem leftend_B1_run (t : List Sym) :
    steps machine 7 (Cfg.mk [1, 1] .B .L (1 :: t)) =
      some (Cfg.mk [] .A .L (1 :: 1 :: 2 :: 2 :: t)) := rfl

theorem spinout_step (t : List Sym) :
    steps machine 8 (Cfg.mk [] .A .L (1 :: 1 :: 2 :: 2 :: t)) =
      some (Cfg.mk [] .A .L (1 :: 1 :: 2 :: 2 :: 2 :: 2 :: t)) := rfl

theorem xy_spinout_step (t : List Sym) :
    steps machine 9 (Cfg.mk [1, 1] .A .L (1 :: 1 :: 2 :: 2 :: t)) =
      some (Cfg.mk [1, 1] .A .L (1 :: 1 :: 2 :: 2 :: 2 :: t)) := rfl

set_option maxRecDepth 100000 in
/-- The original CP0 seed is reached at exactly the same time. -/
theorem seed_run :
    steps machine 156 init = some (Prefix.cpCfg Prefix.seedStack).den := rfl

/-- This statement is about the old arithmetic predicate, not yet new-machine
return soundness. CP0 is independent of the transition table. -/
theorem seed_CP0 : Prefix.CP0 Prefix.seedStack := Prefix.cp0_seed

end BB25.Sibling
