"""Reproduce finite checks for the macro-equivalence proof. No external packages.
Run: python verify.py
"""
from __future__ import annotations

from collections import Counter
from itertools import product
from pathlib import Path
import hashlib
import json
import time

from model import (OLD, SIBLING, base, reference, decrement, first_word, height,
                   next_checkpoint, pop_episode, sparse_from_blocks, sparse_step, value)

ROOT = Path(__file__).resolve().parent


def cores(max_length: int):
    # No admissibility restriction: the local pop lemma needs only CStack and v>=2.
    for n in range(2, max_length + 1):
        for s in product("XZW", repeat=n):
            if value(s) >= 2:
                yield s


def dycks(max_length: int):
    for n in range(max_length + 1):
        for w in product("YXV", repeat=n):
            try:
                yield w, height(w)
            except ValueError:
                pass


def raw_run(machine, cfg, steps):
    for _ in range(steps):
        cfg = base.step(machine, cfg)
        assert cfg is not None
    return cfg


def primitive_checks():
    contexts = [list(w) for n in range(3) for w in product(range(5), repeat=n)]
    common = [
        (2, lambda l,r: ([3,0]+l,"A","L",r), lambda l,r: (l,"A","L",[1,1]+r)),
        (3, lambda l,r: ([1,0]+l,"A","L",r), lambda l,r: ([1,1]+l,"A","R",r)),
        (2, lambda l,r: ([1,1]+l,"A","L",r), lambda l,r: (l,"A","L",[2,2]+r)),
        (4, lambda l,r: ([1,0]+l,"B","L",[1]+r), lambda l,r: (l,"A","L",[1,1,2]+r)),
        (6, lambda l,r: ([1,1]+l,"B","L",[1]+r), lambda l,r: (l,"B","L",[1,2,2]+r)),
        (1, lambda l,r: (l,"A","R",[1,1]+r), lambda l,r: (l,"A","L",[2,1]+r)),
        (2, lambda l,r: (l,"A","R",[2,1]+r), lambda l,r: ([3,0]+l,"A","R",r)),
        (2, lambda l,r: (l,"A","R",[2,2]+r), lambda l,r: ([1,0]+l,"A","R",r)),
        (1, lambda l,r: (l,"A","R",[1,2]+r), lambda l,r: (l,"A","L",[2,2]+r)),
        (1, lambda l,r: (l,"A","R",[1,0,1]+r), lambda l,r: (l,"A","L",[2,0,1]+r)),
        (9, lambda l,r: (l,"A","R",[2,0,1]+r), lambda l,r: (l,"B","L",[1,2,2]+r)),
    ]
    new = [
        (2, lambda l,r: ([3,0]+l,"B","L",[1]+r), lambda l,r: ([3,4,0]+l,"A","R",r)),
        (3, lambda l,r: ([3,4,0]+l,"A","L",r), lambda l,r: (l,"A","L",[1,0,1]+r)),
    ]
    ct = Counter()
    for l in contexts:
        for r in contexts:
            for k, start, end in common:
                for m in (OLD, SIBLING):
                    assert raw_run(m, start(l,r), k) == end(l,r)
                    ct['common_machine_instances'] += 1
            for k, start, end in new:
                assert raw_run(SIBLING, start(l,r), k) == end(l,r)
                ct['new_marker_instances'] += 1
    for t in contexts:
        special = [
            (4, ([1,1],"A","L",t), ([1,1],"A","R",[2]+t)),
            (7, ([1,1],"B","L",[1]+t), ([],"A","L",[1,1,2,2]+t)),
            (8, ([],"A","L",[1,1,2,2]+t), ([],"A","L",[1,1,2,2,2,2]+t)),
            (9, ([1,1],"A","L",[1,1,2,2]+t), ([1,1],"A","L",[1,1,2,2,2]+t)),
            (3, (t,"A","R",[]), (t,"A","L",[2,1])),
            (1, (t,"A","R",[1]), (t,"A","L",[2])),
            (11, (t,"A","R",[2]), (t,"B","L",[1,2,2,1])),
        ]
        for k, start, end in special:
            for m in (OLD,SIBLING):
                assert raw_run(m,start,k) == end
                ct['end_and_spinout_machine_instances'] += 1
    return dict(ct)


def episode_checks(max_core: int, max_word: int, max_r: int, *, raw: bool):
    ss = list(cores(max_core)); ws = list(dycks(max_word))
    ct = Counter(); total_raw = 0; maxcost = 0
    for s in ss:
        d, k1 = decrement(s); d, k2 = decrement(d)
        expected_left = list(reversed(d)) + ['L']
        tails = [(['Y']*r+['R1'], first_word(r)+['R'], 'odd')
                 for r in range(2,max_r+1)]
        tails += [(list(w)+['R'], ['Y']+list(w)+['X']*h+['V','R'], 'even') for w,h in ws]
        for tail, outword, tag in tails:
            a = pop_episode('old', s, tail, base_check=raw)
            b = pop_episode('sibling', s, tail, base_check=raw)
            assert a.configuration == b.configuration
            assert a.base_steps == b.base_steps
            expected = reference.denote(expected_left,'B',outword)
            assert a.configuration == expected
            assert a.base_steps >= k1+k2+15
            ct[tag] += 1; maxcost=max(maxcost,a.base_steps)
            if raw: total_raw += a.base_steps+b.base_steps
    return {'core_bound':max_core,'word_bound':max_word,'odd_r_max':max_r,
            'core_count':len(ss),'even_word_count':len(ws),'counts':dict(ct),
            'pairs':sum(ct.values()),'base_transitions_replayed':total_raw,
            'largest_episode_steps':maxcost}


def checkpoint_checks(n: int):
    sa=sb=None;ta=tb=5; records=[]; targets={}; maxlen=0
    for i in range(n):
        sa,ta,ja=next_checkpoint('old',sa,ta)
        sb,tb,jb=next_checkpoint('sibling',sb,tb)
        assert sa==sb and ta==tb
        stack=''.join(reversed(sa[0][:-1]))
        maxlen=max(maxlen,len(stack))
        records.append({'index':i,'time':str(ta),'length':len(stack),
                        'stack_sha256':hashlib.sha256(stack.encode()).hexdigest(),
                        **({'stack':stack} if i<6 else {})})
        if ta<=188820:targets[ta]=sparse_from_blocks(sa, origin=0)
    # Independent direct simulation from blank, in absolute tape coordinates.
    transitions=0; first_b3={}; absolute_snapshots={}
    for label,m in [('old',OLD),('sibling',SIBLING)]:
        tape={};pos=0;q='A'
        for t in range(1,188821):
            if q=='B' and tape.get(pos,0)==3 and label not in first_b3:
                first_b3[label]=t-1
            pos,q=sparse_step(m,tape,pos,q);transitions+=1
            if t in targets:
                expected_tape,expected_pos,expected_q=targets[t]
                origin=min(tape)
                shifted={origin+i:v for i,v in expected_tape.items()}
                assert (tape,pos,q)==(shifted,origin+expected_pos,expected_q),(label,t)
                if label=='old':
                    absolute_snapshots[t]=(dict(tape),pos,q)
                else:
                    assert (tape,pos,q)==absolute_snapshots[t],('absolute mismatch',t)
    return {'checkpoint_count':n,'max_stack_length':maxlen,'checkpoints':records,
            'direct_blank_checks':len(targets)*2,'direct_steps_per_machine':188820,
            'direct_base_transitions_total':transitions,'first_B3_time':first_b3}


def main():
    start=time.time(); results={}
    results['primitives']=primitive_checks();print('Primitive identities checked.',flush=True)
    results['macro_exhaustive']=episode_checks(7,6,9,raw=False)
    print('Exhaustive pop pairs:',results['macro_exhaustive']['pairs'],flush=True)
    results['macro_base_replay']=episode_checks(5,4,6,raw=True)
    print('Raw-replayed pop pairs:',results['macro_base_replay']['pairs'],flush=True)
    results['checkpoints']=checkpoint_checks(32)
    print('Matching checkpoints:',results['checkpoints']['checkpoint_count'],flush=True)
    results['elapsed_seconds']=round(time.time()-start,3)
    results['status']='all_checks_passed'
    (ROOT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({k:v for k,v in results.items() if k!='checkpoints'},indent=2))

if __name__=='__main__':
    main()
