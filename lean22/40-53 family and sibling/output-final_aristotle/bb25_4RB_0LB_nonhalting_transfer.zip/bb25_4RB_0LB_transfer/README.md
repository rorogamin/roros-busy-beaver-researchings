# BB(2,5): the 4RB/0LB sibling

Target:

```
1RB2LA0RB1LB---_1LA3RA1RA4RB0LB
```

## Main result

The target has the same ordinary checkpoint dynamics, including base-step
counts, as the already proved family member

```
1RB2LA0RB1LB---_1LA3RA1RA4LB0RB.
```

Both pop episodes spend two decrements and perform the same local marker
excursion. The old member spends the decrements before the excursion; the
sibling spends them after. The existing Ready invariant supplies both. The
new marker is Q=043, with `Q <A -> <A 101` in three steps.

This gives a complete mathematical transfer proof of nonhalting from blank.
It is not yet a new kernel-checked Lean theorem. No original project file
was modified.

## Contents

- `PROOF.md`: full transfer proof, both marker clocks, the exact commuting
  diagram, existing invariant, entry, spinouts and positive-time conclusion.
- `FORMALIZATION.md`: precise source mapping and the remaining Lean transport
  work. It explains why the old family soundness theorem cannot simply be
  applied with a different B4.
- `SiblingLocal.lean`: uncompiled local lemma and composition source candidate.
  It does not claim the final nonhalting theorem.
- `model.py`, `verify.py`: executable comparisons and raw/base checks.
- `reference/`: the unchanged original project's two Python simulator files.
- `results.json`, `verification.log`: complete retained finite-test results.
- `PROVENANCE.json`, `SHA256SUMS.txt`: input and output provenance.

## Reproduce the checks

From this directory, using Python 3.10 or later:

```
python verify.py
```

There are no third-party Python dependencies. A failed resource bound raises
an error; it is never classified as halting or nonhalting. The checks include
279,822 exact pop comparisons, 4,800 raw-replayed pop pairs, 32 checkpoint
comparisons, and independent primitive runs from blank through 188,820 steps
for each transition table.

The mathematical proof does not depend on these finite checks.
