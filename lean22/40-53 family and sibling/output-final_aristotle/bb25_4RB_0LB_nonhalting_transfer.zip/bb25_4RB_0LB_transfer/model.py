"""Exact block comparison for the 4RB/0LB sibling and the proved 4LB/0RB TM.

This module is an executable check, not a formal nonhalting certificate.
The unmodified project simulator is retained under reference/.
All public core-stack arguments are bottom first, with permanent L omitted.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Sequence
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "reference"))
import blocksim as reference
import sim as base

Mode = Literal["old", "sibling"]
BlockState = tuple[list[str], str, list[str]]
Core = tuple[str, ...]

reference.LDEN["Q"] = [3, 4, 0]  # Q = 043, nearest-head first in LDEN.
OLD = base.machine((0, "R", "B"))
SIBLING = base.machine((0, "L", "B"))
SIBLING["B"][3] = (4, "R", "B")


@dataclass(frozen=True)
class Episode:
    configuration: tuple
    base_steps: int
    block_steps: int
    state: BlockState
    base_checked: bool


def value(core: Sequence[str]) -> int:
    a = 0
    for ch in core:
        if ch == "X":
            a *= 2
        elif ch == "Z":
            a = 2 * a + 1
        elif ch == "W":
            a //= 2
        else:
            raise ValueError(f"Non-counter block {ch!r}")
    return a


def decrement(core: Sequence[str]) -> tuple[Core, int]:
    result = reference.stride(list(reversed(core)))
    if result is None:
        raise ValueError("Decrement is not supplied")
    out, cost = result
    return tuple(reversed(out)), cost


def height(word: Sequence[str]) -> int:
    h = 0
    for ch in word:
        if ch not in ("Y", "X", "V"):
            raise ValueError("Not a colored Dyck word")
        h += 1 if ch == "Y" else -1
        if h < 0:
            raise ValueError("Not a colored Dyck prefix")
    return h


def first_word(r: int) -> list[str]:
    if r < 2:
        raise ValueError("The odd-terminal marker theorem requires r >= 2")
    if r == 2:
        return list("YXYYV")
    if r == 3:
        return list("YYVYYV")
    return ["Y"] * (r - 1) + list("VYYVX") + ["V"] * (r - 3)


def block_step(mode: Mode, state: BlockState, *, fast: bool = True) -> tuple[BlockState, int]:
    if mode not in ("old", "sibling"):
        raise ValueError(mode)
    lt, st, rt = state
    if fast and st == "L":
        result = reference.stride(lt)
        if result is not None:
            out, cost = result
            return (out, "R", rt), cost
    if mode == "sibling":
        # Old dangerous-marker rules must never silently be used for the sibling.
        if any(b in ("F", "G") for b in rt) or "J0" in lt:
            raise ValueError("Old marker in sibling execution")
        if st == "B" and lt and lt[0] == "W":
            return (["Q"] + lt[1:], "R", rt), 2
        if st == "L" and lt and lt[0] == "Q":
            return (lt[1:], "L", ["N1"] + rt), 3
        if st == "B" and lt and lt[0] == "Q":
            raise ValueError("B reached the new marker: outside the proven interface")
    out_l, out_s, out_r, cost = reference.bstep("0RB", lt, st, rt)
    return (out_l, out_s, out_r), cost


def pop_episode(mode: Mode, core: Sequence[str], right: Sequence[str], *,
                base_check: bool = False, limit: int = 100_000) -> Episode:
    """Run from cW <B1 right until the marker has been removed and B returns.

    In base_check mode EVERY announced block transition is independently replayed
    using the supplied project's raw transition-table simulator, without stride.
    """
    if value(core) < 2:
        raise ValueError("The episode theorem requires v(c) >= 2")
    state = (["W"] + list(reversed(core)) + ["L"], "B", list(right))
    raw = reference.denote(*state)
    total = 0
    machine = OLD if mode == "old" else SIBLING
    for j in range(limit):
        lt, st, rt = state
        if j and st == "B" and set(lt) <= {"L", "X", "Z", "W"} and not (
            set(rt) & {"F", "G", "N1", "N2"}
        ):
            return Episode(reference.denote(*state), total, j, state, base_check)
        state, cost = block_step(mode, state, fast=not base_check)
        total += cost
        if base_check:
            for _ in range(cost):
                raw = base.step(machine, raw)
                if raw is None:
                    raise AssertionError(("HALT", mode, core, right, j))
            if raw != reference.denote(*state):
                raise AssertionError(("block/base mismatch", mode, core, right, j))
    raise RuntimeError("Episode resource limit exceeded; not a halting conclusion")


def next_checkpoint(mode: Mode, state: BlockState | None = None, time: int = 5,
                    *, limit: int = 200_000) -> tuple[BlockState, int, int]:
    state = state or (["L"], "R", ["R1"])
    for j in range(limit):
        state, cost = block_step(mode, state)
        time += cost
        lt, st, rt = state
        if st == "B" and rt == ["Y", "R1"] and set(lt) <= {"L", "X", "Z", "W"}:
            return state, time, j + 1
    raise RuntimeError("Checkpoint resource limit exceeded; not a halting conclusion")


def sparse_from_blocks(state: BlockState, origin: int = -1) -> tuple[dict[int, int], int, str]:
    """Physical tape coordinates, with the leftmost permanent L cell at origin."""
    left, q, direction, right = reference.denote(*state)
    cells = list(reversed(left)) + right
    tape = {origin + i: v for i, v in enumerate(cells) if v}
    pos = origin + len(left) - (direction == "L")
    return tape, pos, q


def sparse_step(machine: dict, tape: dict[int, int], pos: int, state: str) -> tuple[int, str]:
    """Independent absolute-position base simulator; zero cells are omitted."""
    instruction = machine[state][tape.get(pos, 0)]
    if instruction is None:
        raise RuntimeError("HALT")
    write, direction, new_state = instruction
    if write:
        tape[pos] = write
    else:
        tape.pop(pos, None)
    return pos + (1 if direction == "R" else -1), new_state
