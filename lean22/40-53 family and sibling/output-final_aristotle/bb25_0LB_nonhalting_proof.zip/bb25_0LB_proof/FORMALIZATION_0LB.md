# Lean implementation map for the 0LB completion

This is a dependency plan for formalizing `PROOF_0LB.md`, not a claim that
any of its new universal lemmas is already present or Lean-certified.
The uploaded project has `leanprover/lean4:v4.28.0` in `lean-toolchain`.
No Lean executable was available in this working environment, so neither
the original project nor the added candidate entry file was compiled here.

## 1. What changes relative to the previous progress

Do not spend the remaining effort proving the old assertion that the
`ZZZ` rooted class is restored after one or two returns. The new theorem
uses a different invariant and closes after **one** return.

The first three bit **positions** must remain unmatched, but their values
are unrestricted. This matters already at the new finite entry:

```
base time 931:
    bottom-first ordinary core: ZXZZX
    stopping bit:               Z
    right exponent:             7
```

The old argument's supply energy is retained. Two additional quantitative
conditions close the larger structural class:

```
24 * (bval core + 1) >= 23 * 2^(decodedHeight core)
decodedEnergy core  >= 3 * 2^(height core - 2) + 4
```

Counter value at least two, height at least five, Good, nonnegative ordinary
energy, and right exponent at least four complete the invariant.

## 2. Exact correspondence of notation

| Proof notation | Project expression or new definition |
| --- | --- |
| Bottom-first `c`, omitting L | Reverse the ordinary block list, then append `.L`. |
| `v(c)` | `cval core : Nat` |
| `P(c)` | `pdec core : List RB` |
| `b(c)` | `bval core : Int` |
| `h(c)` | `nbit core - nsh core : Nat`, under `Adm core` |
| `D(c)` | `cdec core` under its supply hypothesis |
| `T(w)` | `TW w` |
| `rho_1(w,a)` | `rrun w a` |
| Transduced rho_1 | `trun w a b` |
| Expanding-close count | `qcnt w a` |
| Raw Dyck prefix | `Digs w` and `DyckPre w` |
| Raw balance | `bal w : Int` |
| `E(c)` | New nearest-first integer recursion, described below |
| `rho_3` | New word evaluator with `X: e / 2 - 3` |
| `F(c)` | `erun (pdec core) 0` |
| `H(c)` | `nbit (TW (pdec core)) - nsh (TW (pdec core))` |

Integer division must be floor division. The existing development already
uses `Int` division by the positive integer two; keep energy in `Int`,
not `Nat`, because negative energy must not be truncated to zero.

A possible nearest-first definition of the energy recursion is:

```lean
def energy : List LB -> Int
  | .X :: s => 2 * energy s
  | .Z :: s => 2 * energy s + 1
  | .W :: s => energy s / 2 - 2
  | _ => 0
```

A useful exact encoding of structural protection, with L included in the
nearest-first list `s`, is:

```
CStack s;
4 <= s.length;
for every suffix t of s with 4 <= t.length:
    nsh t + 3 <= nbit t.
```

The suffix of length four contains L and the first three ordinary blocks;
the inequality forces all three to be bits. The longer suffix inequalities
say that no later pop matches any of them. Thus this is equivalent to the
paper's position-protection predicate, without fixing their bit values.

For a Z checkpoint, use a fresh constructor distinct from the existing
`cpCfg` (which fixes right exponent one):

```lean
def zCfg (core : List LB) (r : Nat) : BCfg :=
  { lt := .Z :: core, st := .Bt,
    rt := List.replicate r .Y ++ [.R1] }
```

The field names `lt`, `st`, and `rt` were checked against `BCfg`.
`Entry0LB.lean` uses the same record notation for the concrete checkpoint.

## 3. Existing results to reuse, not reprove

The following names were inspected in the uploaded source:

- `Prefix/Stack.lean`: `pdec_cdec`, `bval_cdec`, `Good.cdec`, `Adm.cdec`,
  `Good.suffix`, `Adm.suffix`, `bval_eq_rrun`, `bal_pdec`.
- `Prefix/Reset.lean`: `tfold_props`, `brun_paid`, and the paid-stack
  correspondence. A clean reset is `CStack`, `Adm`, and `Good`.
- `Prefix/Word.lean`: `rstep`, `rrun`, `qout`, `trun`, their append and
  monotonicity lemmas, and the Dyck-word decomposition framework.
- `Prefix/Expand.lean`: expansion counting through `qcnt` and the
  first-close parity argument.
- `Prefix/Slack.lean`: `qloss`, `three_qloss`, `qgain`,
  **`trun_ge_qgain`**. Its first-counter parameter is arbitrary, so it
  applies to the suffix after `YYY` with first counter seven.
- `Prefix/LA/Exact.lean`: `exact_zero`, `exact_drain`, `exact_tail`.
  These are generic in `b4`, despite their location under `LA`.
- `Family.lean`: `G_0LB`, `rule_A_101`, `rule_A_201`.
- `Blocks.lean`: ordinary block transitions and `BRun` soundness interfaces.
- `Prefix/Main.lean`: `seed_run` at time 156 and the existing nonhalting
  proof pattern. The new Z invariant needs its own recurrence rather than
  supplying the existing generic `WCase` for all old safe checkpoints.

Suggested new files below are **not** names of existing proved modules.

## 4. Proposed module `Prefix/LB0/Energy.lean`

Implement Sections 2 and the basic word-energy identities.

The essential stack lemmas are:

```
energy_le_cval
energy_cdec_of_supplied
energy_cdecn_of_supplied
energy_nonneg_of_bottom_prefix
two_le_cval_sub_energy_of_has_W
```

The decrement theorem should carry ordinary-stack, admissibility, and
supply assumptions. One robust proof route is the matched-forest cost
representation `energy s = (cval s : Int) - cost s`. Balanced forests
subtract a nonnegative constant from incoming energy; unmatched bits
multiply preceding costs. The constant depends on matched bits and shape,
not unmatched bit values. This also proves the strict cost of any `W`.

Next define `estep`, `erun`, and prove:

```
negative energy persists through a digit word;
nonnegative final erun implies nonnegative prefixes;
rrun w a >= erun w a for equal initial values;
energy (TW w) = erun w 0 for a clean reset;
```

For the actual B scan, prove a four-decrement `W` branch using the ordinary
stride four times with the `F/G/N1/N2` transitions. Then induct on ordinary
stack length to obtain a supplied scan, preserving Good and energy, and
ending at Z or the bottom spinout. The final theorem here should not yet
claim that the scan necessarily finds a Z; the clock analysis proves that.

## 5. Proposed module `Prefix/LB0/EnergyGain.lean`

Define a transduced energy run, **keeping the first counter at charge one**:

```
etrun (digit :: w) a e =
    etrun w (rstep digit a) (estep (qout digit a) e)
```

The main new inequality is:

```
Digs w, DyckPre w, bal w = ell, e >= 1
  ==> etrun w a e + 1 >=
      2^ell * (4^q * (e+1) - 5 * qloss q)
```

with `q = qcnt w a` (or any lower bound on that count, after the required
monotonicity proof). First counter `a` can be any integer.

Prove the balanced-group lemma with

```
G q e = 4^q * e - 2 * qloss q.
```

The contracting tree case uses: its balanced interior is nonempty;
therefore its expansion count `j >= 1`; therefore `A=4^j >= 4`; and
`(A+2)/3` is even. The final inequality is exactly `5*(A-4)/6 >= 0`.
Use integral equalities to avoid gratuitous rational casts in Lean.

Concatenation uses `G p (G q e) = G (p+q) e`. Opening separation uses
`G q (2*e+1) >= 2*G q e + 1`. These are the complete induction cases;
there is no conjectural asymptotic estimate.

Apply this and the existing `trun_ge_qgain` after the leading `YYY` to obtain:

```
24*(bval c + 1) >= 23*2^H + 2^L
24*(decodedEnergy c + 1) >= 19*2^H + 5*2^L
```

for `c = D^k(TW (YYY ++ v))` and raw-Dyck `v`, with supplied decrements.
Use `pdec_cdec` iteratively to remove the decrement from both conclusions.
If the full word identity `pdec (TW w) = Q(w)` is not yet stated, prove it
by induction on digits: bits emit Y; a reset X emits its incoming counter
parity, and its paid decrement leaves the decoder unchanged. The existing
reset file states the corresponding numeric `bval`/`trun` identity, but a
word-level identity is useful for the new energy evaluator.

## 6. Proposed module `Prefix/LB0/Clock.lean`

Implement the generic Z formula for `a >= 2`, `r >= 4`:

```
TW (pdec core ++ [d] ++ Y^r ++ [V] ++ X^(r-1) ++ chi(a/2) ++ [V])
```

Do not silently use a stronger hypothesis such as `a >= 7`. The proof's
new invariant allows the small counters two and three. After two
supplied decrements and a pop, the counter is `a/2-1`, the decoder is
`pdec core ++ [d]`, and the pending-two tail supplies the existing strong
drain inequality with a factor-four margin over its required factor three.

Prove the word energy formula:

```
erun (Y^r ++ [V] ++ X^(r-1)) e = 4*e - 2  (r >= 4).
```

The all-X threshold for a length-t word over `X,V` is `6*(2^t-1)`.
The decoded-energy field of the invariant then makes the complete reset
and scan supplied. The finite Z execution and the supply proof should be
kept separate: one determines the exact endpoint; the other certifies
that the subsequent `0LB` scan cannot encounter an exceptional pending N.

## 7. Proposed module `Prefix/LB0/Debt.lean`

This is reverse scanning of **paid reset prefixes**, not ordinary counter
value alone. Establish the five-row debt table in Section 6 of the proof,
including the exact core below a stopping Z.

The two alternatives for the stopped prefix are:

```
chi stop:
  w' = pdec core ++ [d] ++ Y^r ++ [V] ++ X^(r-1) ++ eta
  eta is a prefix of chi(a/2)
  |eta| <= height core - 5
  raw balance L >= 4
  next right exponent >= 4

buffer stop:
  w' = pdec core ++ [d] ++ Y^(r-2)
  k = 2^(r-4)*(n+6)-1
  n+6 <= 6*2^(height core-2)
  L = height core+r-3 >= 6
  next right exponent = r+|chi(a/2)|+3
```

In both cases the new core is exactly `D^k(TW w')`, not merely a stack of
the same counter value. This identity is what lets `pdec_cdec` transfer
the transducer bounds.

For a chi stop, at least three chi letters must be examined: an X creates
positive even debt; a V is needed to make it odd; a later V can then stop.
If chi is completely crossed, write the debts after the buffer as
`2^(r-1)*(n+6)-6`, `2^(r-2)*(n+6)-3`, and `2^(r-3)*(n+6)-2`.
Their parities force the penultimate Y stop; this is why `r >= 4` is used.

## 8. Proposed module `Prefix/LB0/Return.lean`

Package the invariant and prove its positive-time closure.

The key checks not to drop are:

1. `w'` begins `YYY` and its suffix is raw Dyck, despite the core's first
   three actual bits possibly being zeros. This follows from structural
   protection, not from the counter value.
2. New height is at least six. In the chi case, raw height four is not
   enough by itself: use the retained buffer V to get two extra actual
   reset-height units.
3. New counter is at least two. In the chi case, use the retained W and
   `cval - energy >= 2`. In the buffer case use equation (31) of the proof
   and the `23/24` counter-density bound.
4. The energy threshold at **height six** uses the extra `5*2^L` term in
   the gain bound. Dropping it prematurely loses the small-height proof.
   For heights at least seven, the `19/24` term alone exceeds the required
   `18/24` term plus the additive four.
5. The positive base-time witness is immediate from the first Z rule,
   whose cost is four. Do not rely on positive block-step count, since
   reparsings can have zero base cost.

The target return statement is of the form:

```
I core r -> exists core' r' k,
  0 < k and
  BRun b4_0LB (zCfg core r) (zCfg core' r') k and
  I core' r'
```

## 9. Proposed module `Prefix/LB0/Final.lean`

At time 931 the exact core is nearest-first

```
[.X, .Z, .Z, .X, .Z, .L]
```

and the full Z checkpoint prepends `.Z`. Its counter is 22, decoded value
31, energy 22, decoded energy 31, and both heights five. All invariant
checks reduce to short finite calculations plus the easy all-bit prefix
properties.

`Entry0LB.lean` supplies a small, **uncompiled candidate** for the direct
finite entry statement using `rfl`, with no `sorry` or new axioms. Its
claimed base endpoint was independently verified by the raw simulator.
Compile this file in the project before treating it as a certificate.

Iterate the positive-time return theorem to build arbitrarily long defined
base runs, then rule out `Halts`. The final project-level target is:

```
BB25.Prefix.not_halts_0LB : Not (Halts (M b4_0LB) init)
```

Only after checking that theorem should the top-level project status be
changed from twelve formally proved members to thirteen. The delivered
mathematical argument does not by itself justify changing that formal
status.
