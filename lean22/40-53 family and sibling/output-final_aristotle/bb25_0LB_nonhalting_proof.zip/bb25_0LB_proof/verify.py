"""Reproducible finite tests of every new arithmetic interface and invariant.

Run `python verify.py` and `python verify_reference.py` from this directory.
These checks are evidence against mistakes, not a substitute for PROOF_0LB.md.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import asdict
from itertools import product
import argparse
import json
from pathlib import Path
import random
import time
from model import *

HERE = Path(__file__).resolve().parent


def stack_words(n: int, prefix: Stack = (), h: int = 0) -> Iterator[Stack]:
    if n == 0:
        yield prefix
        return
    for bit in ('X', 'Z'):
        yield from stack_words(n-1, prefix+(bit,), h+1)
    if h:
        yield from stack_words(n-1, prefix+('W',), h-1)


def protected_stacks(n: int) -> Iterator[Stack]:
    if n < 3: return
    for prefix in product('XZ', repeat=3):
        for suffix in stack_words(n-3):
            yield prefix+suffix


def check_energy_gain(max_length: int):
    ct = Counter()
    for length in range(max_length+1):
        for w in dyck_words(length):
            ct['words'] += 1
            ell = balance(w)
            for a in (-4, -1, 0, 1, 2, 3, 7, 31):
                Q, q = transduce(w, a)
                p = 4**q
                for e in (1, 2, 7):
                    result = rho(Q, e, charge=3)
                    assert 3*(result+1) >= (1 << ell)*(3*p*(e+1)-5*(p-1)), (w, a, e, Q, q)
                    if ell == 0:
                        assert 3*result >= 3*p*e-2*(p-1), ('balanced gain', w, a, e)
                        assert result >= 1
                    ct['parameter_instances'] += 1
    return dict(ct)


def check_decrement(max_length: int):
    ct = Counter()
    for length in range(max_length+1):
        for s in stack_words(length):
            a = value(s)
            e = energy(s)
            assert e <= a
            if 'W' in s: assert a-e >= 2
            for n in sorted({0, min(1,a), min(2,a), a//2, a}):
                out = decrement(s, n)
                assert value(out) == a-n
                assert energy(out) == e-n, (s, n, e, energy(out))
                assert decode(out) == decode(s)
                assert height(out) == height(s)
                if good(s): assert good(out)
                ct['decrement_instances'] += 1
            ct['admissible_stacks'] += 1
    return dict(ct)


def check_invariant(max_length: int):
    ct = Counter()
    stages = []
    examples = {}
    for length in range(5, max_length+1):
        for s in protected_stacks(length):
            if not invariant(s, 4): continue
            for r in (4, 5, 7):
                out, R, kind = successor(s, r, audit=True)
                ct['inputs'] += 1
                ct[kind] += 1
                if s[:3] != ('Z','Z','Z'): ct['non_ZZZ_inputs'] += 1
                if out[:3] != ('Z','Z','Z'): ct['non_ZZZ_outputs'] += 1
                if 'W' in s: ct['inputs_containing_W'] += 1
                ct['even_a' if value(s)%2 == 0 else 'odd_a'] += 1
                key = kind + ('_W' if 'W' in s else '_bits')
                if key not in examples:
                    examples[key] = {'input': ''.join(s), 'r': r, 'output': ''.join(out),
                                     'next_r': R, 'output_measures': asdict(measures(out))}
        stages.append({'length': length, **dict(ct)})
        print('invariant through length', length, dict(ct), flush=True)
    return {'totals': dict(ct), 'by_length_cumulative': stages, 'examples': examples}


def check_random(count: int):
    rng = random.Random(20260924)
    ct = Counter()
    for _ in range(count):
        # Protected decoded reset witnesses with 4--35 more raw-Dyck letters.
        w = 'YYY'; bal = 0
        for _ in range(rng.randint(4, 35)):
            ch = rng.choice('YXV' if bal else 'Y')
            w += ch; bal += 1 if ch == 'Y' else -1
        if rho(w, charge=3) < 0: continue
        s = reset(w)
        if value(s): s = decrement(s, rng.randrange(value(s)+1))
        r = rng.randint(4, 16)
        if not invariant(s, r): continue
        out, R, kind = successor(s, r)
        ct['inputs'] += 1
        ct[kind] += 1
        if s[:3] != ('Z','Z','Z'): ct['non_ZZZ_inputs'] += 1
    return {'random_seed': 20260924, 'attempted': count, **dict(ct)}


def check_trajectory(cycles: int):
    s, r = tuple('ZXZZX'), 7
    rows = []
    for i in range(cycles):
        assert invariant(s, r)
        row = {'cycle': i, 'core_length': len(s), 'r': r, **asdict(measures(s))}
        if len(s) < 250: row['core'] = ''.join(s)
        s, r, kind = successor(s, r)
        row['stop_kind'] = kind
        rows.append(row)
    rows.append({'cycle': cycles, 'core_length': len(s), 'r': r,
                 'endpoint_invariant': invariant(s, r), **asdict(measures(s))})
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--max-length', type=int, default=12)
    parser.add_argument('--gain-length', type=int, default=10)
    parser.add_argument('--decrement-length', type=int, default=9)
    parser.add_argument('--random-count', type=int, default=3000)
    parser.add_argument('--trajectory', type=int, default=12)
    args = parser.parse_args()
    if not 5 <= args.max_length <= 16: parser.error('max-length must be between 5 and 16')
    start = time.monotonic()
    results = {'parameters': vars(args)}
    results['energy_gain'] = check_energy_gain(args.gain_length)
    print('energy gain:', results['energy_gain'], flush=True)
    results['decrement'] = check_decrement(args.decrement_length)
    print('decrement:', results['decrement'], flush=True)
    results['invariant'] = check_invariant(args.max_length)
    results['random'] = check_random(args.random_count)
    results['trajectory'] = check_trajectory(args.trajectory)
    results['elapsed_seconds'] = round(time.monotonic()-start, 3)
    results['status'] = 'PASS: finite tests only; universal argument is in PROOF_0LB.md'
    (HERE/'results').mkdir(exist_ok=True)
    (HERE/'results'/'arithmetic.json').write_text(json.dumps(results, indent=2)+'\n')
    print('PASS', results['elapsed_seconds'], 'seconds', flush=True)

if __name__ == '__main__': main()
