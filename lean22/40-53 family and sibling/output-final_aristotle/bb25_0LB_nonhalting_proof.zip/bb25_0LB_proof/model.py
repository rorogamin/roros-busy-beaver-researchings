"""Executable mathematics for the proposed 0LB nonhalting proof.

Bottom-first left stacks use X (zero), Z (one), W (pop), omitting L.
Right words use Y, V, X. All arithmetic is exact; no third-party packages.
This file is not a Lean certificate. See PROOF_0LB.md for universal proofs.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterator

Stack = tuple[str, ...]


def height(s: Stack) -> int:
    return sum(-1 if ch == 'W' else 1 for ch in s)


def value(s: Stack) -> int:
    a = 0
    for ch in s:
        if ch == 'W': a //= 2
        elif ch in ('X', 'Z'): a = 2*a + int(ch == 'Z')
        else: raise ValueError(f'Unknown stack block: {ch}')
    return a


def energy(s: Stack) -> int:
    e = 0
    for ch in s:
        if ch == 'W': e = e//2 - 2
        elif ch in ('X', 'Z'): e = 2*e + int(ch == 'Z')
        else: raise ValueError(f'Unknown stack block: {ch}')
    return e


def active_positions(s: Stack) -> list[int]:
    positions: list[int] = []
    for i, ch in enumerate(s):
        if ch in ('X', 'Z'): positions.append(i)
        elif ch == 'W' and positions: positions.pop()
        else: raise ValueError('Not an admissible ordinary stack')
    return positions


def decrement(s: Stack, n: int = 1) -> Stack:
    """Subtract n from unmatched bits, preserving every matched bit/pair."""
    if n < 0: raise ValueError('Negative decrement')
    positions = active_positions(s)
    a = value(s)
    if n > a: raise ValueError('Counter underflow')
    a -= n
    out = list(s)
    for i in reversed(positions):
        out[i] = 'Z' if a & 1 else 'X'
        a >>= 1
    assert a == 0
    return tuple(out)


def decode(s: Stack) -> str:
    bits: list[str] = []
    out: list[str] = []
    for ch in s:
        if ch in ('X', 'Z'):
            bits.append(ch); out.append('Y')
        elif ch == 'W' and bits:
            out.append('V' if bits.pop() == 'Z' else 'X')
        else: raise ValueError('Not an admissible ordinary stack')
    return ''.join(out)


def rstep(a: int, ch: str, charge: int = 1) -> int:
    if ch == 'Y': return 2*a+1
    if ch == 'V': return 2*a
    if ch == 'X': return a//2-charge
    raise ValueError(f'Unknown right digit: {ch}')


def rho(w: str, a: int = 0, charge: int = 1) -> int:
    for ch in w: a = rstep(a, ch, charge)
    return a


def good(s: Stack) -> bool:
    bits: list[str] = []
    a = b = 0
    for ch in s:
        if ch in ('X', 'Z'):
            bits.append(ch)
            a = 2*a+int(ch == 'Z'); b = 2*b+1
        elif ch == 'W' and bits:
            label = 'V' if bits.pop() == 'Z' else 'X'
            a //= 2; b = rstep(b, label)
        else: return False
        if b < a: return False
    return True


def reset(w: str) -> Stack:
    """T(w), with the pending decrement paid after every right X."""
    s: Stack = ()
    for ch in w:
        if ch == 'Y': s += ('Z',)
        elif ch == 'V': s += ('X',)
        elif ch == 'X':
            if value(s) < 2: raise ValueError('Unclean paid reset')
            s = decrement(s+('W',))
        else: raise ValueError(ch)
    return s


def transduce(w: str, a: int = 0) -> tuple[str, int]:
    """Return Q_a(w) and the number of expanding closes of w."""
    out: list[str] = []
    q = 0
    for ch in w:
        if ch == 'Y': dest = 'Y'
        elif ch == 'V': dest = 'Y'; q += 1
        elif ch == 'X':
            dest = 'V' if a % 2 else 'X'
            q += int(a % 2 == 1)
        else: raise ValueError(ch)
        out.append(dest); a = rstep(a, ch)
    return ''.join(out), q


def balance(w: str) -> int:
    return sum(1 if ch == 'Y' else -1 for ch in w)


def dyck_prefix(w: str) -> bool:
    h = 0
    for ch in w:
        if ch not in 'YVX': return False
        h += 1 if ch == 'Y' else -1
        if h < 0: return False
    return True


def dyck_words(length: int, prefix: str = '', h: int = 0) -> Iterator[str]:
    if length == 0:
        yield prefix
    else:
        yield from dyck_words(length-1, prefix+'Y', h+1)
        if h:
            yield from dyck_words(length-1, prefix+'X', h-1)
            yield from dyck_words(length-1, prefix+'V', h-1)


def structurally_protected(s: Stack) -> bool:
    """First three positions are bits, never matched; their values are arbitrary."""
    if len(s) < 3 or any(ch not in ('X', 'Z') for ch in s[:3]): return False
    h = 0
    for ch in s[3:]:
        if ch not in ('X', 'Z', 'W'): return False
        h += -1 if ch == 'W' else 1
        if h < 0: return False
    return True


@dataclass(frozen=True)
class Measures:
    a: int
    h: int
    e: int
    b: int
    f: int
    H: int


def measures(s: Stack) -> Measures:
    w = decode(s)
    return Measures(value(s), height(s), energy(s), rho(w), rho(w, charge=3),
                    sum(-1 if ch == 'X' else 1 for ch in w))


def invariant(s: Stack, r: int) -> bool:
    if r < 4 or not structurally_protected(s): return False
    a, h, e = value(s), height(s), energy(s)
    if h < 5 or a < 2 or e < 0 or not good(s): return False
    m = measures(s)
    return 24*(m.b+1) >= 23*(1 << m.H) and m.f >= 3*(1 << (h-2))+4


def chi(m: int) -> str:
    if m < 1: raise ValueError('chi requires a positive integer')
    return ''.join('V' if ch == '1' else 'X' for ch in bin(m)[3:][::-1])


def z_word(s: Stack, r: int) -> str:
    a = value(s)
    if a < 2 or r < 4: raise ValueError('Direct Z clock hypotheses fail')
    d = 'V' if a % 2 else 'X'
    return decode(s)+d+'Y'*r+'V'+'X'*(r-1)+chi(a//2)+'V'


def scan4(s: Stack, r: int = 1) -> tuple[Stack, int]:
    """Return (core below stopping Z, new right exponent); underflow is an error."""
    while s:
        if s[-1] == 'Z': return s[:-1], r
        if s[-1] == 'X': s = s[:-1]
        elif s[-1] == 'W': s = decrement(s[:-1], 4)
        else: raise ValueError('Nonordinary stack')
        r += 1
    raise ValueError('Scan reaches bottom, outside this invariant')


def reverse_stop(w: str) -> tuple[int, int]:
    """Index of stopping letter, debt on its preceding paid prefix."""
    n = 0
    for i in range(len(w)-1, -1, -1):
        ch = w[i]
        if ch == 'X': n = 2*n+6
        elif ch == 'Y':
            if n % 2 == 0: return i, n//2
            n //= 2
        elif ch == 'V':
            if n % 2: return i, (n+1)//2
            n //= 2
        else: raise ValueError(ch)
    raise ValueError('Reverse scan does not stop in this word')


def successor(s: Stack, r: int, audit: bool = True) -> tuple[Stack, int, str]:
    if not invariant(s, r): raise ValueError('Input violates invariant')
    w = z_word(s, r)
    full = reset(w)
    out, R = scan4(full)
    i, k = reverse_stop(w)
    prefix = w[:i]
    kind = 'chi' if i > len(decode(s))+r else 'buffer'
    if audit:
        assert energy(full) >= 0
        assert out == decrement(reset(prefix), k)
        assert prefix[:3] == 'YYY' and dyck_prefix(prefix[3:])
        L = balance(prefix)
        assert L >= 4 and height(out) >= 6
        Q, q = transduce(prefix)
        assert Q == decode(out)
        m = measures(out)
        assert m.H == L+2*q
        assert 24*(m.b+1) >= 23*(1 << m.H)+(1 << L)
        assert 24*(m.f+1) >= 19*(1 << m.H)+5*(1 << L)
        assert invariant(out, R), (s, r, out, R, m)
    return out, R, kind
