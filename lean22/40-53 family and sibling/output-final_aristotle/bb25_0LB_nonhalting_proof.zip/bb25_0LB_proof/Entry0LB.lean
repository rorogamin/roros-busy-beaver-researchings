/-
UNCOMPILED CANDIDATE, not a certificate delivered as Lean-checked.

The 931-step endpoint has been independently replayed on the raw base
machine; the declarations below have not been checked by a Lean executable
in this environment. This file proves only the finite entry, not the new
universal nonhalting argument in PROOF_0LB.md. It introduces no new axioms
and contains no proof placeholders.

Place in the original project and run, for example:
  lake env lean Entry0LB.lean
-/
import RequestProject.BB25.Prefix.Main

namespace BB25.Prefix.LB0Candidate

open BB25

set_option maxRecDepth 1000000
set_option maxHeartbeats 0

/-- The core ZXZZX, nearest first and including L. -/
def entryCore : List LB := [.X, .Z, .Z, .X, .Z, .L]

/-- The stopping Z is prepended to the core. -/
def entryCfg : BCfg :=
  { lt := .Z :: entryCore, st := .Bt,
    rt := List.replicate 7 .Y ++ [.R1] }

theorem entry_counter : cval entryCore = 22 := rfl

theorem entry_decoded_counter : bval entryCore = 31 := rfl

/-- Candidate finite entry equation; compile before treating as certified. -/
theorem entry_run : steps (M b4_0LB) 931 init = some entryCfg.den := rfl

end BB25.Prefix.LB0Candidate
