"""Independent endpoint checks against unchanged project block/base simulators."""
from __future__ import annotations
import json
import sys
from pathlib import Path
from itertools import product
from dataclasses import asdict

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE/'reference'))
import blocksim as ref
import sim
from model import invariant, successor, measures, scan4, reset, z_word


def reference_cycle(s: tuple[str, ...], r: int, *, base: bool = False,
                    limit: int = 2_000_000):
    lt, st, rt = list(reversed(s+('Z',)))+['L'], 'B', ['Y']*r+['R1']
    m = sim.machine(ref.machineB4('0LB'))
    c = ref.denote(lt, st, rt) if base else None
    paid_return = False
    clock = 0
    first_stack = None
    for i in range(limit):
        if st == 'L' and not base:
            stride = ref.stride(lt)
        else:
            stride = None
        if stride is not None:
            lt, k = stride; st = 'R'
        else:
            lt, st, rt, k = ref.bstep('0LB', lt, st, rt)
        clock += k
        if base:
            for _ in range(k):
                c = sim.step(m, c)
                assert c is not None, ('halt', s, r, clock)
            assert c == ref.denote(lt, st, rt), ('base/block mismatch', s, r, i)
        if not paid_return and st == 'B' and rt == ['Y', 'R1']:
            paid_return = True
            first_stack = tuple(reversed(lt[:-1]))
            assert first_stack == reset(z_word(s, r)), ('Z clock', s, r, first_stack)
        if paid_return and st == 'B' and lt[0] == 'Z':
            assert rt[-1] == 'R1' and all(ch == 'Y' for ch in rt[:-1])
            assert lt[-1] == 'L' and all(ch in 'XZW' for ch in lt[:-1])
            out = tuple(reversed(lt[1:-1])); R = len(rt)-1
            expected, expected_R, kind = successor(s, r)
            assert (out, R) == (expected, expected_R), ('endpoint', s, r, out, R)
            return {'core': ''.join(s), 'r': r, 'output': ''.join(out), 'next_r': R,
                    'kind': kind, 'base_steps': clock, 'block_iterations': i+1,
                    'base_replayed': base}
    raise RuntimeError('Reference block-step budget exhausted')


def blank_entry():
    m = sim.machine(ref.machineB4('0LB'))
    c = ([], sim.A, 'R', [])
    target = ref.denote(list(reversed(tuple('ZXZZXZ')))+['L'], 'B', ['Y']*7+['R1'])
    seed = ref.denote(list(reversed(tuple('ZZZXXX')))+['L'], 'B', ['Y','R1'])
    checkpoints = {
        'first_Z_step': ref.denote(list(reversed(tuple('ZZZ')))+['L'], 'B', ['Y']*4+['R1']),
        'first_reset_step': ref.denote(list(reversed(tuple('ZZXZXXXXWWWX')))+['L'], 'B', ['Y','R1']),
    }
    hits = {}
    for t in range(100_001):
        if c == seed: hits['seed_step'] = t
        for name, checkpoint in checkpoints.items():
            if c == checkpoint: hits[name] = t
        if c == target:
            assert invariant(tuple('ZXZZX'), 7)
            return {'target_step': t, **hits, 'core': 'ZXZZX', 'r': 7,
                    'measures': asdict(measures(tuple('ZXZZX'))),
                    'raw_base_steps_replayed': t}
        c = sim.step(m, c)
        assert c is not None, ('halt before entry', t)
    raise RuntimeError('Entry target not found')


def main():
    import argparse
    import time
    p = argparse.ArgumentParser()
    p.add_argument('--quick', action='store_true')
    args = p.parse_args()
    start = time.monotonic()
    results = {'blank_entry': blank_entry(), 'reference_cycles': []}
    # All admissible protected bit-only cores of height five, including a=2,3.
    for bits in product('XZ', repeat=5):
        if not invariant(bits, 4): continue
        results['reference_cycles'].append(reference_cycle(bits, 4, base=True))
    # The exact reachable entry and two subsequent cycles.
    s, r = tuple('ZXZZX'), 7
    for i in range(2 if args.quick else 3):
        results['reference_cycles'].append(reference_cycle(s, r, base=(i == 0)))
        s, r, _ = successor(s, r)
    # Longer non-rooted examples with genuine W matches.
    count = 0
    for n in range(7, 11):
        for s in product('XZW', repeat=n):
            if 'W' not in s or not invariant(s, 4): continue
            results['reference_cycles'].append(reference_cycle(s, 4))
            count += 1
            if count >= (100 if args.quick else 1000): break
        if count >= (100 if args.quick else 1000): break
    results['original_block_base_crosscheck'] = ref.crosscheck('0LB', 5000)
    assert results['original_block_base_crosscheck'] == 'ok'
    results['cycle_count'] = len(results['reference_cycles'])
    results['base_replayed_cycle_count'] = sum(x['base_replayed'] for x in results['reference_cycles'])
    results['total_cycle_base_steps_replayed'] = sum(x['base_steps'] for x in results['reference_cycles'] if x['base_replayed'])
    results['elapsed_seconds'] = round(time.monotonic()-start, 3)
    results['status'] = 'PASS: finite independent checks, not a universal proof or Lean certificate'
    dest = HERE/'results'/'reference.json'
    dest.write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps({k:v for k,v in results.items() if k != 'reference_cycles'}, indent=2))

if __name__ == '__main__': main()
