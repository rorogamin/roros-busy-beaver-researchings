# 0LB nonhalting proof completion

Target: `1RB2LA0RB1LB---_1LA3RA1RA4LB0LB`.

## Result

`PROOF_0LB.md` gives a complete mathematical nonhalting argument using a new
single-return invariant. It bypasses the previous unproved one-or-two-return
`ZZZ` restoration conjecture. The new idea protects the bottom three bit
positions, not their bit values, and maintains explicit decoded counter
and energy bounds.

The raw machine reaches the invariant at **base step 931**, at

```
L ZXZZX Z <B1 Y^7 R1
```

where the core has `(counter, height, energy, decoded counter,
decoded energy, decoded height) = (22, 5, 22, 31, 31, 5)`.

**Certification status:** this is a new mathematical proof, not a delivered
Lean-certified universal theorem. No Lean compiler was available here.
The original uploaded archive was left unchanged. Its twelve previously
formalized members should not be relabeled as thirteen formally proved
until the new argument has been encoded and checked.

## Files

- `PROOF_0LB.md`: full universal proof, including the new energy transducer
  lemma, the exact two stopping cases, the small-height checks, and entry.
- `FORMALIZATION_0LB.md`: mapping to existing Lean definitions and theorem
  names, with a proposed module/dependency order.
- `Entry0LB.lean`: **uncompiled candidate** for the finite 931-step entry
  calculation only; no universal nonhalting theorem is asserted by this file.
- `model.py`: independent executable definitions of stacks, decrement,
  energy, decoder, paid reset, clock word, reverse debt, and the invariant.
- `verify.py`: exhaustive arithmetic/invariant checks and fixed-seed tests.
- `verify_reference.py`: independent endpoint checks using the original
  project simulators, including direct base-machine replay.
- `reference/blocksim.py`, `reference/sim.py`: unchanged copies of the
  original project reference simulators.
- `results/`: completed JSON reports and corresponding logs.
- `PROVENANCE.json`: source archive and source-file hashes.
- `MANIFEST.sha256`: checksums of the delivered files, except this manifest.

## Reproduce the finite checks

Use Python 3.10 or newer; only its standard library is needed. Run from the
extracted package directory:

```sh
python verify.py
python verify_reference.py
```

The scripts fail on the first violated assertion. A completed run writes
`results/arithmetic.json` and `results/reference.json`. The default arithmetic
run examines all qualifying protected cores of lengths five through twelve,
each with right exponent four, five, and seven. The exponential enumeration
and growing trajectories can be reduced with command-line flags; use
`python verify.py --help` to inspect them.

The completed reports contain:

| Check | Completed count |
| --- | ---: |
| Invariant return inputs | 208,560 |
| Such inputs not beginning ZZZ | 180,066 |
| Such inputs containing matched W blocks | 184,128 |
| Energy gain parameter instances | 134,136 |
| Supplied decrement interface instances | 61,152 |
| Additional fixed-seed random invariant inputs | 2,144 |
| Exact independent block-simulator return checks | 1,033 |
| Return cycles also replayed on the base machine | 31 |
| Base steps in those replayed cycles | 110,519 |
| Separately replayed blank entry | 931 base steps |

Both return stopping cases were exercised. Twelve further return cycles
from the reachable invariant entry were also checked, without treating a
finite orbit prefix as a proof of nonhalting.

These finite tests are safeguards against errors. They do **not** establish
an unbounded theorem. The mathematical proof is in `PROOF_0LB.md`; the
formal certificate remains to be produced in Lean.

## Check the candidate finite entry in the original project

Copy `Entry0LB.lean` into the root of the supplied Lean project, then run:

```sh
lake env lean Entry0LB.lean
```

The file has no new axioms or proof placeholders, but it has not been
compiled in this environment. Successful compilation would certify only
its stated finite entry and two numerical values, not the new universal
return theorem. For that theorem, follow `FORMALIZATION_0LB.md` and the
complete accompanying mathematical proof.
