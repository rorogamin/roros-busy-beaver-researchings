# The remaining 0LB machine: a closed nonhalting invariant

Machine: `1RB2LA0RB1LB---_1LA3RA1RA4LB0LB`.

Date: 24 September 2026.

## Result and certification boundary

The argument below gives a mathematical nonhalting proof from blank for the
remaining `0LB` member of the uploaded project. It replaces the unproved
one-or-two-return rootedness statement in `PROGRESS_0LB.md` with a **single-return
closed invariant**. It does not prove, assume, or need that old statement.

The new lemmas have **not been checked by Lean**. The accompanying Python tests
are finite checks, not a proof of the universal assertion. The argument uses
the existing counter, decoder, clean-reset, and exact-drain interfaces in the
project, and proves the additional energy and closure estimates below. An
implementation map is in `FORMALIZATION_0LB.md`.

The essential change is to protect the bottom three **positions**, allowing
their bits to change, and impose quantitative lower bounds on the decoded
counter and decoded energy. The constants that close the proof are `23/24`
for counter density and `19/24` for energy density; the scan needs only an
asymptotic energy density of `3/4 = 18/24`.

## 1. Conventions and existing interfaces

Stacks in this document are **bottom first**, with the permanent `L` omitted.
The Lean project stores the same stacks nearest first, including `L`.

Left blocks are `X = 11` (zero bit), `Z = 01` (one bit), and `W = 03` (pop).
Right digits are `Y = 22`, `V = 21`, and `X = 11`; `R1` is the terminal `1$`.
A Z checkpoint has the form

\[
        L\,c\,Z\;\langle B1\;Y^r R1 .                       \tag{1}
\]

Here the stopping `Z` is **not** part of the core `c`.

An ordinary stack is admissible if every bottom prefix has at least as many
bits as pops. Match each `W` with the last unmatched preceding bit. Define

\[
 h(c)=\#X+\#Z-\#W,\qquad
 v(\epsilon)=0,\quad v(cX)=2v(c),\quad v(cZ)=2v(c)+1,
 \quad v(cW)=\lfloor v(c)/2\rfloor.
\]

Thus `v(c)` is the binary numeral of the unmatched bits, and
`0 <= v(c) < 2^h(c)`.

The decoder `P(c)` replaces bits by `Y`, and replaces a `W` by `V` if its
matched bit is `Z`, otherwise by `X`. Let `D` be a supplied ordinary counter
decrement. The project's counter/stack lemmas give

\[
 v(D^k c)=v(c)-k,\qquad P(D^k c)=P(c),                       \tag{2}
\]

with matching and height unchanged. The decoder identity is especially
important: decrements modify unmatched bits, not matched bits.

For a word over `Y,V,X`, define the integer-valued evaluation `rho_j` by

\[
 Y:a\mapsto2a+1,\qquad V:a\mapsto2a,\qquad
 X:a\mapsto\lfloor a/2\rfloor-j .                           \tag{3}
\]

Unless an initial value is specified, it is zero. In particular `rho_1` is
the existing reset arithmetic. Write

\[
 b(c)=\rho_1(P(c)).
\]

`Good(c)` means `b(p) >= v(p)` for **every** bottom prefix `p` of `c`.
Admissibility and Good are preserved by supplied decrements; both pass to
bottom prefixes.

The paid reset `T` is

\[
 T(\epsilon)=\epsilon,\quad T(wY)=T(w)Z,\quad T(wV)=T(w)X,
 \quad T(wX)=D(T(w)W).                                      \tag{4}
\]

The last operation requires the incoming counter to be at least two. Every
clean reset is admissible and Good, and `v(T(w)) = rho_1(w)`.

For the transducer `Q_a`, advance its first counter by `rho_1`, starting at
`a`. Output `Y` at an input `Y` or `V`; at input `X`, output `V` for an odd
incoming first counter and `X` for an even one. Then

\[
                       P(T(w))=Q_0(w).                     \tag{5}
\]

The word identity (5) follows directly from (4): input `Y,V` appends a bit
and hence decoder letter `Y`; input `X` appends a pop whose color is the
parity of the incoming counter, and paying the decrement does not change
its decoder by (2). The counter, Good, and paid-reset interfaces are those
of `Prefix/Stack.lean`, `Prefix/Reset.lean`, and `Prefix/Word.lean`.
The exact common Z excursion is derived in Section 5
from the counter and `Prefix/LA/Exact.lean` interfaces.

## 2. Energy pays for the complete four-decrement scan

Define integer energy by

\[
 E(\epsilon)=0,\quad E(cX)=2E(c),\quad E(cZ)=2E(c)+1,
 \quad E(cW)=\lfloor E(c)/2\rfloor-2.                        \tag{6}
\]

### Lemma 2.1: decrement and positivity facts

For every admissible `c`, there is an integer `K(c) >= 0` such that

\[
 E(c)=v(c)-K(c),\qquad E(D^k c)=E(c)-k.                     \tag{7}
\]

`K(c)` is independent of the values of the unmatched bits. If `c` contains
any `W`, then `K(c) >= 2`.

**Proof.** Decompose the stack into unmatched bits and balanced matched
forests. A balanced tree, with opening bit `beta`, interior energy cost `k`,
and closing `W`, acts on an incoming integer `z` by

\[
 z\longmapsto\left\lfloor\frac{2z+\beta-k}{2}\right\rfloor-2
 =z-\left(\left\lceil\frac{k-\beta}{2}\right\rceil+2\right).
\]

The tree cost is at least two. Forest costs add, and an unmatched bit doubles
all preceding costs. The counter itself ignores balanced forests. This
proves the representation, its nonnegativity, and the lower bound when a
pop occurs. Decrement changes only unmatched bits, so it changes `v` but not
`K`. This proves (7).

Each map in (6) preserves negative integers. Consequently `E(c) >= 0`
implies nonnegative energy for every bottom prefix of `c`.

### Lemma 2.2: the entire B scan is supplied

The ordinary `0LB` scan acts by

\[
 cX\longmapsto c,\qquad cW\longmapsto D^4(c),                \tag{8}
\]

stopping at a `Z` or at the bottom spinout. Each removal prepends one `Y` to
the right. In the `W` case the four decrements consume, in order, the
ordinary `F/G` part and the `N1/N2` part of the `0LB` branch.

If the incoming stack is admissible and has nonnegative energy, **every**
operation in this scan is supplied, and energy remains nonnegative.
Indeed, `E(cW) >= 0` implies `E(c) >= 4`, hence `v(c) >= 4`, and the new
energy is `E(c)-4 >= 0`. Removing `X` also preserves nonnegative energy.
Each operation deletes one block; thus the scan terminates. Good is
preserved whenever it held initially.

The machine interpretation follows directly by composing the existing
ordinary counter stride with `G_0LB`, `rule_A_101`, and `rule_A_201` in
`Family.lean`. There is no unpaid decrement or pending-`N` exception under
the displayed energy hypothesis.

### Lemma 2.3: reset energy

For every clean reset,

\[
                         E(T(w))=\rho_3(w).                 \tag{9}
\]

At an input `X`, appending `W` costs two in (6), and the paid decrement costs
one by (7). The `Y,V` cases are immediate.

All maps of `rho_3` preserve negative integers. If `rho_3(w) >= 0`, every
prefix has nonnegative `rho_3`; its `rho_1` value is at least as large, so
the whole paid reset is clean. Thus (9) and Lemma 2.2 can certify a complete
reset followed by its complete B scan using a single final energy bound.

## 3. The new transducer energy gain

Give a right word its **raw balance** by counting `Y` as `+1`, both `V` and
`X` as `-1`. A raw Dyck prefix never has negative balance. A close is
**expanding** if it is `V`, or if it is `X` with odd incoming first counter.
Let `q_a(w)` be the number of these closes during the `rho_1` run from `a`.
The first close of any nonempty raw balanced word is expanding: it is
preceded only by a nonempty run of `Y`, which leaves the first counter odd.

### Lemma 3.1: energy analogue of `trun_ge_qgain`

For any raw Dyck prefix `w` of balance `ell`, any integer first counter `a`,
and any integer second energy `e >= 1`, put `q=q_a(w)`. Then

\[
 \rho_3(Q_a(w),e)+1
 \ \ge\ 2^\ell\left(4^q(e+1)-5\frac{4^q-1}{3}\right).       \tag{10}
\]

The first counter is always advanced by `rho_1`, not `rho_3`.

**Proof.** Define the integer affine function

\[
                       G_q(e)=4^q e-2\frac{4^q-1}{3}.
\]

First prove that a balanced word with `q` expanding closes sends `e >= 1`
to at least `G_q(e) >= 1` under transduced energy evaluation. Forest
concatenation uses `G_p(G_q(e))=G_{p+q}(e)`.

For a tree `Y u C`, let `j` count expanding closes in its balanced interior,
and put `A=4^j`. After its opening and interior the energy is at least

\[
                G_j(2e+1)=2Ae+(A+2)/3.                      \tag{11}
\]

If the final close expands, its transduced map is doubling or doubling plus
one, which gives at least `G_{j+1}(e)`.

If it contracts, it is an `X` with even incoming first counter. The interior
cannot be empty, since an immediately preceding `Y` gives an odd first
counter. The interior therefore has at least one expanding close, so
`j >= 1` and `A >= 4`. Moreover `(A+2)/3` is even. Applying the contracting
energy map to (11) gives at least

\[
 Ae+(A-16)/6\ \ge\ Ae-2(A-1)/3=G_j(e),
\]

because the difference is `5(A-4)/6 >= 0`. This proves the balanced-word
claim, including its `e >= 1` induction hypothesis.

Decompose a Dyck prefix into balanced forests separated by its unmatched
openings. Its numerical lower bound is a composition of the corresponding
`G` maps and `e -> 2e+1`. The inequality

\[
                G_q(2e+1)\ge2G_q(e)+1
\]

has difference `5(4^q-1)/3 >= 0`. Moving all the lower-bound `G` maps before
the unmatched openings can therefore only decrease that lower bound.
This gives `2^ell(G_q(e)+1)-1`, exactly (10). This rearranges affine bounds,
not the actual first-counter run; the `q` values are those of the original
word. QED.

### Corollary 3.2: two protected-prefix density bounds

Suppose

\[
 w=YYYv,\quad v\text{ is a raw Dyck prefix},\quad
 L=\operatorname{bal}(w),\quad c=D^k(T(w)),                   \tag{12}
\]

where the reset and decrements are supplied. Define

\[
 F(c)=\rho_3(P(c)),\qquad H(c)=h(T(P(c))).
\]

Let `q=q_0(w)`. Then

\[
 H(c)=L+2q,                                                  \tag{13}
\]
\[
 24(b(c)+1)\ge23\,2^{H(c)}+2^L,                             \tag{14}
\]
\[
 24(F(c)+1)\ge19\,2^{H(c)}+5\,2^L.                          \tag{15}
\]

**Proof.** By (2) and (5), `P(c)=Q_0(w)`. Both first and second counters,
and also the second energy, are seven after the initial `YYY`. Apply the
existing `Prefix/Slack.lean` theorem `trun_ge_qgain` to the remaining Dyck
prefix, starting the second counter at seven. It gives

\[
 b(c)+1\ge 2^{L-3}\left(8\,4^q-\frac{4^q-1}{3}\right).
\]

Apply (10) with second energy seven to get

\[
 F(c)+1\ge 2^{L-3}\left(8\,4^q-5\frac{4^q-1}{3}\right).
\]

These are (14) and (15). A raw close changes its contribution to reset
height from `-1` to `+1` exactly when it expands, proving (13). In
particular (15) is positive for `L >= 3`, so the decoded reset is clean.
The height in (13) can equivalently be defined by counting `Y,V` positively
and `X` negatively in `P(c)`, before invoking cleanliness. QED.

## 4. The invariant

Call a core **position-protected** when

\[
 c=\beta_1\beta_2\beta_3t,\qquad \beta_i\in\{X,Z\},          \tag{16}
\]

and every prefix of `t` has nonnegative relative height. None of the bottom
three bit positions is matched; their bit values are unrestricted.

At checkpoint (1), define `I(c,r)` by the following conditions:

\[
\begin{aligned}
 &c\text{ is ordinary, admissible, Good, and position-protected};\\
 &h=h(c)\ge5,\quad a=v(c)\ge2,\quad E(c)\ge0,\quad r\ge4;\\
 &24(b(c)+1)\ge23\,2^{H(c)};                                \tag{17}\\
 &F(c)\ge3\,2^{h-2}+4.                                     \tag{18}
\end{aligned}
\]

Here `F=rho_3(P(c))`, and `H=h(T(P(c)))`. Good guarantees the decoded reset
is clean. Counting one-matched pops also gives

\[
 H=h+2\#\{\text{one-matched pops in }c\}\ge h.                \tag{19}
\]

All conditions in `I` concern the present configuration. There is no
assumption about a future return, future supply, or restoration of `ZZZ`.

**Main return theorem.** Every checkpoint satisfying `I(c,r)` makes a
finite positive-time nonhalting run to another Z checkpoint satisfying
`I(c',r')`.

The next four sections prove this theorem.

## 5. Exact Z excursion and supplied return scan

Let `I(c,r)` hold. Set

\[
 m=\lfloor a/2\rfloor\ge1,\qquad
 d=\begin{cases}X&a\text{ even},\\V&a\text{ odd}.\end{cases}
\]

For positive `m`, let `chi(m)` list its lower binary digits in
least-significant-first order, omitting the leading one, with `0 -> X` and
`1 -> V`. Thus `chi(1)` is empty, and

\[
                       t=|\chi(m)|\le h-2.                  \tag{20}
\]

The common Z excursion returns to an ordinary B checkpoint, with right
side `YR1`, whose complete left stack is

\[
 S=T(W_{\rm total}),\qquad
 W_{\rm total}=P(c)\,d\,Y^r V X^{r-1}\chi(m)V.               \tag{21}
\]

For completeness, two decrements below the source Z followed by a pop give
`sigma = D^2(c)W`, of value `m-1` and decoder `P(c)d`. This stack is Good:
for even `a`, its decoded value is `floor(b/2)-1 >= m-1`; for odd `a`, it
is `2b >= m-1`. The pending-two tail pushes `r` one bits and pops one,
adding `Y^r V` to the decoder and giving drain counter
`2^(r-1)m-1`. If `b_sigma` is the decoded value before this tail, then the
tail's decoded value plus two is `2^(r+1)(b_sigma+1)`, at least
`4*2^(r-1)m`; this supplies the existing strong-drain inequality with
coefficient three. `exact_drain` emits `chi(2^(r-1)m)`, namely
`X^(r-1)chi(m)`, followed by `V`. This proves (21), including the cases
`a=2,3`; no small-counter exception is being omitted.

### Energy of the clock

For any integer `e` and `r >= 4`, direct iteration of (3) gives

\[
                   \rho_3(Y^r V X^{r-1},e)=4e-2.             \tag{22}
\]

For example, iterating `X` uses
`rho_3(X^k,x)=floor((x+6)/2^k)-6`. After `Y^r V`, the relevant numerator is
`2^(r+1)(e+1)+4`; the remaining floor contributes zero from the extra four
because `r >= 4`.

The energy after `P(c)d` and this buffer is therefore

\[
 A=\begin{cases}
 4\lfloor F(c)/2\rfloor-14,&a\text{ even},\\
 8F(c)-2,&a\text{ odd}.
 \end{cases}                                                \tag{23}
\]

A word of length `t` in `X,V` requires at most `6(2^t-1)` initial energy to
finish with nonnegative `rho_3`. Prove this backwards from required energy
zero: a required output `R >= 0` demands `2R+6` before `X`, and only
`ceil(R/2)` before `V`. The all-`X` recurrence bounds every such word.

Put `M=6*2^(h-2)-6`. The threshold in (18) is even. Substituting it into
(23) gives `A >= M` for even `a`, and an even larger bound for odd `a`.
By (20), `M >= 6(2^t-1)`. The final `V` preserves nonnegativity. Hence

\[
                       \rho_3(W_{\rm total})\ge0.             \tag{24}
\]

Lemma 2.3 makes the reset clean, `S` Good, and `E(S) >= 0`. Lemma 2.2 then
supplies its **entire** four-decrement B scan.

## 6. Locate the stopping Z exactly

A reverse scan of a paid word can be tracked by a nonnegative **debt** `n`:
a remaining prefix `u` represents the current stack as `D^n(T(u))`.
Initially `n=0`. Processing the last letter gives

| Last letter | Debt update or stop |
| --- | --- |
| `X` | Cross its `W`; replace `n` by `2n+6`. |
| `Y`, odd `n` | Cross its current zero bit; replace `n` by `(n-1)/2`. |
| `Y`, even `n` | Stop at Z; the core below it is `D^(n/2)(T(u))`. |
| `V`, even `n` | Cross its current zero bit; replace `n` by `n/2`. |
| `V`, odd `n` | Stop at Z; the core below it is `D^((n+1)/2)(T(u))`. |

In the stopping rows, `u` is the prefix **before** the stopping letter.
These identities follow by binary subtraction. At input `X`, the reset has
already paid one decrement after its pop. Moving the total `n+1` decrement
through that pop doubles it, and the B scan adds four more, hence `2n+6`.
Supply was established in Section 5, so these are identities of actual
supplied stacks, not merely formal arithmetic with possible underflows.

The final `V` of (21) is crossed with debt zero. There are only two cases.

### Case A: stop inside `chi(m)`

Starting from zero debt, an `X` is needed to create nonzero debt; it gives
six, still even. A crossed `V` is then needed to create odd debt before a
subsequent `V` can stop the scan. Thus at least three `chi` letters,
including the stopping one, must be examined.

If `eta` is the retained `chi` prefix and `j=|eta|`, then

\[
 j\le t-3\le h-5,\qquad
 w'=P(c)dY^rVX^{r-1}\eta,\qquad c'=D^k(T(w')).               \tag{25}
\]

Its raw balance is

\[
                         L=h-1-j\ge4.                       \tag{26}
\]

At least two `chi` letters and the final `V` were crossed, so `r' >= 4`.
More exactly, `r'=t-j+1`.

### Case B: no stop inside `chi(m)`

Let `n` be the debt after crossing all of `chi(m)`. Under a crossed `X`,
`n+6` doubles; under a crossed `V` it does not increase. Consequently

\[
                         n+6\le6\,2^t\le6\,2^{h-2}.          \tag{27}
\]

Crossing `X^(r-1)`, then the preceding `V`, then the last buffer `Y` gives
successive debts

\[
 2^{r-1}(n+6)-6,\quad
 2^{r-2}(n+6)-3,\quad
 2^{r-3}(n+6)-2.
\]

The middle debt is odd and the last is even, since `r >= 4`. Therefore the
scan stops at the **penultimate buffer Y**, with

\[
 w'=P(c)dY^{r-2},\qquad
 k=2^{r-4}(n+6)-1,\qquad c'=D^k(T(w')),                      \tag{28}
\]
\[
                  L=h+r-3\ge6,\qquad r'=r+t+3\ge7.          \tag{29}
\]

This also proves that the supplied scan stops before reaching the bottom.

## 7. Structural protection and counter supply at the new Z

In both cases `w'` begins with `YYY`, and what follows is a raw Dyck prefix.
Indeed, position protection of `c` gives this for `P(c)`. The added `d`
leaves raw height `h-1 >= 4`. In Case B all remaining letters are openings.
In Case A the buffer returns to height `h-1` without going below it, and
its retained `chi` prefix removes at most `j <= h-5` raw height units.
Thus the raw height never drops below three after the first three letters.

For every prefix, actual reset height is raw height plus twice its number
of input `V` letters. It is therefore no smaller than raw height. The
first three bits of `T(w')` remain unmatched. Decrement preserves matching,
so `c'` is position-protected, although those bits need not be `ZZZ`.

Let `h'=h(c')`. In Case B, (29) gives `h' >= 6`. In Case A, `w'` contains
the buffer `V`, so its actual height is at least `L+2 >= 6`. Hence

\[
                            h'\ge6.                         \tag{30}
\]

The scan preserves admissibility and Good. Its final full stack `c'Z` has
nonnegative energy; `E(c'Z)=2E(c')+1` implies, integrally, `E(c') >= 0`.

We must separately check `a'=v(c') >= 2`; nonnegative energy alone is not
enough for a bit-only stack.

In Case A, `w'` retains all `r-1 >= 3` buffer `X` letters. Thus `T(w')`, and
also `c'`, contains a `W`. Lemma 2.1 gives `a' >= E(c')+2 >= 2`.

In Case B, put `b=b(c)`. From (28), exact counter arithmetic gives

\[
 a'=\begin{cases}
 2^{r-4}\bigl(4\lfloor b/2\rfloor-n-6\bigr),&a\text{ even},\\
 2^{r-4}\bigl(8b-n-2\bigr),&a\text{ odd}.
 \end{cases}                                                \tag{31}
\]

The odd bracket is at least the even bracket because `b >= 0`. From (17),
(19), and (27), the even bracket is at least

\[
\begin{aligned}
 4\lfloor b/2\rfloor-n-6
 &\ge 2b-2-6\,2^{h-2}\\
 &\ge \frac{5}{12}2^h-4\\
 &\ge \frac{28}{3}>2,
\end{aligned}                                               \tag{32}
\]

where the last line uses `h >= 5`. Since `2^(r-4) >= 1`, (31) supplies the
required counter bound in this case as well.

## 8. Close both quantitative bounds

Section 6 and Section 7 give exactly the hypothesis (12), with `L >= 4`,
for the new core `c'`. Apply Corollary 3.2:

\[
 24(b(c')+1)\ge23\,2^{H(c')}+2^L\ge23\,2^{H(c')},             \tag{33}
\]

so the counter-density condition is preserved.

For the energy condition, write `F'=F(c')`, `H'=H(c')`. We have `H' >= h'`
and

\[
                   F'+1\ge\frac{19\,2^{H'}+5\,2^L}{24}.      \tag{34}
\]

If `h'=6`, use `L >= 4` to obtain

\[
 F'+1\ge(19\cdot64+5\cdot16)/24=54,
 \qquad F'\ge53\ge3\cdot2^4+4.
\]

If `h' >= 7`, then `2^h'/24 >= 128/24 > 5`, so already

\[
 F'\ge\frac{19}{24}2^{h'}-1
       \ge\frac34\,2^{h'}+4
       =3\,2^{h'-2}+4.                                     \tag{35}
\]

Thus (18) is preserved too. Sections 6 and 7 supply every remaining
condition, including `r' >= 4`, `a' >= 2`, and `h' >= 5`.

This proves the main return theorem. The run takes positive base time:
its first Z block transition alone takes four base steps. No appeal to
an indefinitely long sequence of zero-cost reparsings is involved.

## 9. Blank-tape entry and nonhalting

The reference base transition function, run directly from blank, gives
these exact checkpoints:

| Base time | Full ordinary stack above L, bottom first | Right side |
| ---: | --- | --- |
| 156 | `ZZZXXX` | `Y R1` |
| 174 | `ZZZ` | `Y^4 R1` |
| 585 | `ZZXZXXXXWWWX` | `Y R1` |
| 931 | `ZXZZXZ` | `Y^7 R1` |

The first is also the project's `seed_run`. At time 931 the core below the
stopping Z is `c=ZXZZX`, with

\[
 a=22,\quad h=5,\quad E=22,\quad P(c)=Y^5,\quad
 b=31,\quad F=31,\quad H=5,\quad r=7.
\]

It is an all-bit core, hence admissible and position-protected. Every
prefix has decoder value `2^j-1`, at least its ordinary counter value, so
it is Good. Finally

\[
 24(b+1)=768\ge736=23\,2^H,
 \qquad F=31\ge28=3\,2^{h-2}+4.
\]

Thus `I(c,7)` holds. Notice that its first three bits are already `ZXZ`,
not `ZZZ`; this entry uses the new position invariant directly.

Iterate the main return theorem. After `N` further returns there is a
defined, nonhalting computation of length at least `931+4N`. These lengths
are unbounded. A deterministic computation which halted at any finite time
could not have such extensions. Therefore

\[
 \boxed{\neg\operatorname{Halts}(M(b4_{0LB}),\operatorname{init}).}
\]

The only remaining task for a **formally certified** result is to encode
and check this argument in Lean; the old two-return rootedness conjecture
is no longer a required mathematical premise.

## 10. Finite verification performed

`results/arithmetic.json` records a completed exhaustive check of every
position-protected core of lengths 5 through 12 satisfying `I(c,4)`, each
with `r` in `{4,5,7}`. All **208,560** inputs satisfy the asserted successor
identities, both density bounds, and `I` at the next Z. Of these inputs,
**180,066** do not begin `ZZZ`; **184,128** contain an actual matched pop.
Both stopping cases occur: 129,651 buffer stops and 78,909 chi stops.

The same run checks Lemma 3.1 on 5,589 colored Dyck-prefix words of lengths
0 through 10, with eight initial first counters and three second energies:
**134,136** parameter instances. It also checks energy decrement and
decoder invariance on **61,152** supplied decrements of 15,785 admissible
stacks. Additional fixed-seed random inputs and twelve reachable return
cycles are recorded in the same JSON.

`results/reference.json` records **1,033** complete return endpoint checks
against the unchanged original project block simulator. Thirty-one of
those cycles were also replayed base step by base step, covering 110,519
base steps. These include every all-bit height-five core with counter at
least two, so the lower-counter boundary of the Z formula is tested. The
931-step blank entry is separately replayed directly on the base machine.
The original simulator's own 5,000-block-step base cross-check also passes.

These computations test for implementation and algebraic mistakes. The
universal reasoning is Sections 2 through 9; none of its infinite or
unbounded claims is inferred from simulation.
