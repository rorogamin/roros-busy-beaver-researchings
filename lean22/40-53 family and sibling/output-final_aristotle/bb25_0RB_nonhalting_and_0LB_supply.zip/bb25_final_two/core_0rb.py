"""Constructive 0RB return derived in this session. Not a formal certificate."""
from profiles import *

def rho_from(x,w):
    for ch in w:x=m.old.adjusted_step(x,ch)
    return x

def normal_rb(s):
    return normal(s) and strict_admissible(s)

def successor_rb(s):
    assert normal_rb(s)
    tag,sc,rt,events=scan_0RB(s)
    if tag=='spinout':return 'spinout',(), 'scan-bottom'
    c=sc[:-1];a=value(c)
    assert good(c) and (not c or strict_admissible(c))
    if rt[-1]=='R1':
        r=len(rt)-1
        tag,out=certify_z(c,r)
        branch='odd-Z'
    else:
        w=''.join(rt[:-1]);h=dyck_height(w)
        if a>=2:
            z=decn(c,2)+('W',)
            assert good(z) and strict_admissible(z)
            if rho_from(value(z),w)>=0:
                out=reset(z,w);tag='B';branch='direct-even'
            else:
                assert w=='YXYYV' and value(z)==0
                q=z+('Z','W')
                assert good(q) and strict_admissible(q)
                t=reset((),decode(q)+'Y');x=value(t)
                word=decode(t)+'YYVX'+chi(x+1)+'V'
                assert adjusted(word)>0
                out=reset((),word);tag='B';branch='zero-even-repair'
        else:
            c=decn(c,a);u=decode(c);d='V' if a else 'X'
            if adjusted(u+d)>=0:
                t=reset((),u+d);x=value(t);B=adjusted(decode(t))
                assert B>=x
                if (x+1)&x==0:assert B>=x+1,(s,u,d,t,x,B)
                word=decode(t)+'Y'+w+'X'*(h+1)+chi(x+1)+'V'
                assert adjusted(word)>0,(s,word,x,B)
                out=reset((),word);tag='B';branch='early-clean'
            else:
                assert d=='X' and adjusted(u) in (0,1)
                if not u:return 'spinout',(),'early-empty'
                t=reset((),u)+('W',)
                assert good(t) and value(t)==0
                word=decode(t)+'Y'+w
                assert adjusted(word)>0
                out=reset((),word);tag='B';branch='early-repair'
    assert tag=='spinout' or normal_rb(out),(branch,s,out)
    return tag,out,branch

if __name__=='__main__':
    import time,json,random
    st=time.time();ct=Counter();maxsteps=0
    for length in range(2,13):
        for p in product('XZW',repeat=length-1):
            s=p+('X',)
            if not normal_rb(s):continue
            tag,t,b=successor_rb(s);ct[b]+=1
            ref_tag,out,steps,cost=reference_one('0RB',s)
            assert (tag,t)==(ref_tag,out),(s,tag,t,ref_tag,out)
            maxsteps=max(maxsteps,steps)
        print(length,dict(ct),maxsteps,round(time.time()-st,3),flush=True)
    result={'counts':dict(ct),'max_reference_steps':maxsteps,'elapsed':time.time()-st}
    print(json.dumps(result))
    (Path(__file__).parent/'results_rb_initial.json').write_text(json.dumps(result,indent=2))
