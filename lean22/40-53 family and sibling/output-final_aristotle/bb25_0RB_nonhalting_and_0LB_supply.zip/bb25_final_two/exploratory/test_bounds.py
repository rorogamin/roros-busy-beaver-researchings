from roots2 import *
ct=Counter();bad=[]
for l in range(3,13):
 for tail in product('XZW',repeat=l-3):
  c=('Z',)*3+tail
  if not root(c) or not good(c) or energy(c)<0:continue
  ct['inputs']+=1
  a=value(c);e=energy(c);h=height(c);u=decode(c);q=u.count('V');t=reset((),u);F=energy(t);H=height(t)
  assert (F+1)*(1<<h)>=(e+1)*(1<<H),(c,'transfer')
  assert 7*F>=3*a+14,(c,a,e,F,'lower')
  if q:assert 2*F>=a+4*e+3,(c,a,e,F,'qplus')
  else:assert F>=5*a-4*((1<<h)-1),(c,a,e,F,'q0')
  if not root(t):ct['t_not_root']+=1;bad.append((''.join(c),q,''.join(t),F))
  for r in (4,5,6,9):
   tag,s=m.common_Z(c,r);assert tag=='B' and energy(s)>=0,(c,r,s,energy(s))
   tag,cc,R=bscan_d(s);assert tag=='Z' and R>=4 and energy(cc)>=0,(c,r,tag,cc,R)
   ct['returns']+=1
 print(l,dict(ct),bad[:1],flush=True)
print('bad',bad[:10])
