from roots2 import *
def protect(c):
 if len(c)<3 or ''.join(c[:3]) not in ('ZZZ','ZZX','ZXZ'):return False
 h=0
 for ch in c[3:]:
  h+= -1 if ch=='W' else 1
  if h<0:return False
 return True
if __name__=='__main__':
 ct=Counter();bad=[]
 for l in range(3,12):
  for seed in ('ZZZ','ZZX','ZXZ'):
   for tail in product('XZW',repeat=l-3):
    c=tuple(seed)+tail
    if not protect(c) or not good(c) or energy(c)<0:continue
    for r in (4,5,6,9):
     kind,s=m.common_Z(c,r);tag,cc,R=bscan_d(s);ct['cases']+=1
     fail=tag!='Z'
     if tag=='Z':
      cc=cc[:-1];fail=not protect(cc) or energy(cc)<0 or R<4
     if fail:
      ct['fail']+=1
      if len(bad)<15:bad.append((''.join(c),r,value(c),energy(c),tag,''.join(cc),R,energy(cc)))
  print(l,dict(ct),bad[:3],flush=True)
 print('bad',bad)
