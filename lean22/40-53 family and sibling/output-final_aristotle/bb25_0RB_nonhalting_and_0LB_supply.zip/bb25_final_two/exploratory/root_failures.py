from roots2 import *
import json
out=[]; ct=Counter()
for l in range(3,13):
 for tail in product('XZW',repeat=l-3):
  c=('Z',)*3+tail
  if not root(c) or not good(c) or energy(c)<0:continue
  for r in (4,5,6,9):
   kind,s=m.common_Z(c,r); tag,cc,R=bscan_d(s);q=decode(c).count('V')
   assert tag=='Z' and energy(cc)>=0
   cc=cc[:-1]
   if root(cc) and energy(cc)>=0 and R>=4:continue
   ct[(q,r, ''.join(cc[:3]))]+=1
   out.append(dict(c=''.join(c),r=r,a=value(c),e=energy(c),h=height(c),q=q,out=''.join(cc),R=R,a2=value(cc),e2=energy(cc),h2=height(cc),q2=decode(cc).count('V')))
print(dict(ct));print('count',len(out))
print(json.dumps(out[:45],indent=2))
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
