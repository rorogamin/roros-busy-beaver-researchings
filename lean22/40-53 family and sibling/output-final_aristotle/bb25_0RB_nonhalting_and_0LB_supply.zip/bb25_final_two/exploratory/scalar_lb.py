from roots2 import *
from fractions import Fraction

def cls(c,r=4,ratio=Fraction(3,4),k=3,margin=0):
 if not c or not strict_admissible(c) or not good(c) or r<4:return False
 a=value(c); e=energy(c); f=energy(reset((),decode(c)))
 return a>=4 and e*ratio.denominator>=a*ratio.numerator+margin and f>=k*a+margin

if __name__=='__main__':
 ct=Counter();bad=[]
 for l in range(1,12):
  for c in product('XZW',repeat=l):
   if not cls(c):continue
   for r in (4,5,6,9):
    ct['cases']+=1
    tag,s=m.common_Z(c,r)
    if tag!='B': ct['spinout']+=1;continue
    tag,cc,R=bscan_d(s)
    if tag=='Z' and cls(cc[:-1],R):ct['ok']+=1;continue
    ct['fail']+=1
    if len(bad)<12:bad.append((''.join(c),r,value(c),energy(c),energy(reset((),decode(c))),tag,''.join(cc),R,value(cc),energy(cc)))
  print(l,dict(ct),bad[:3],flush=True)
 print('bad',bad)
