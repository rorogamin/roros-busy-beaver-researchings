from core_0rb import *
import time
st=time.time();ct=0
for p in product('XZW',repeat=12):
 s=p+('X',)
 if not normal_rb(s):continue
 ct+=1
 if ct%1000==1:print(ct,''.join(s),time.time()-st,flush=True)
 ans=successor_rb(s);refans=reference_one('0RB',s,limit=200000)
 assert ans[:2]==refans[:2]
print('complete',ct,time.time()-st)
