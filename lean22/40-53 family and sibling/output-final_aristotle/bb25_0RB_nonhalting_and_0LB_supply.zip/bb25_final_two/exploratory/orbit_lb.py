from research import *
from profiles import profile
import json,time
s=tuple('ZZZXXX');data=[]
for i in range(250):
    tag,c,r=bscan_d(s)
    rec={'i':i,'len':len(s),'v_bits':value(s).bit_length(),'prefix':''.join(s[:30]),'suffix':''.join(s[-40:]),'ready4':tag,'r':r,'scanned_counter':value(c[:-1]) if tag=='Z' else value(c)}
    data.append(rec)
    print(rec,flush=True)
    if tag=='unsafe':
        print('unsafe stack',''.join(s),flush=True)
        rt,out,steps,cost=reference_one('0LB',s,limit=1000000,extended=True)
        print('repaired?',rt,len(out) if rt=='B' else out,'steps',steps,flush=True)
        if rt!='B':break
        s=out
    elif tag=='spinout':break
    else:
        ans,out=m.common_Z(c[:-1],r)
        if ans=='spinout':print('Z spinout');break
        s=out
    if len(s)>10000:break
(Path(__file__).parent/'orbit_lb.json').write_text(json.dumps(data,indent=2))
