from profiles import *
from collections import defaultdict
import json,time
st=time.time(); gaps={};eq={};ct=0
for l in range(1,15):
    for u in dyck_words(l):
        h=dyck_height(u)
        if h<1:continue
        f=adjusted(u)
        if f<0:continue
        t=reset((),u);B=adjusted(decode(t));ct+=1
        if f and f&(f-1)==0:
            if f not in gaps or B-f<gaps[f][0]:gaps[f]=(B-f,u,B)
        if B-f<=1 and f%2==0 and f not in eq:eq[f]=(u,B)
    print(l,'count',ct,'powers',gaps,'eqeven',dict(list(sorted(eq.items()))[:35]),'time',time.time()-st,flush=True)
