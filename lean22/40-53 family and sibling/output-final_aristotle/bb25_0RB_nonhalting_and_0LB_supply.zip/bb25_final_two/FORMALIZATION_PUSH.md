# Formalization map: 0RB nonhalting and the partial 0LB return theorem

Date: 2026-09-16.

## What is and is not supplied

PROOF_0RB.md gives a complete proposed mathematical return proof for 0RB.
PROGRESS_0LB.md gives three new theorems, the third proving one complete Z
excursion and subsequent B scan for a specified class. It does not prove the
class closed under iteration. No new Lean file is represented as certified;
this map specifies the missing formal work rather than hiding it behind axioms.

The original Lean source is retained at
`dependencies/bb25_remaining_proofs/prior/source_project/RequestProject/BB25/`.
The preceding proof maps are retained as well. Proof names below are proposed
names, not claims that declarations already exist in that source tree.

## 1. Shared interface to import or formalize first

1. Define bottom-first ordinary stacks, admissible last-in-first-out matching,
   unmatched-bit value v, and positive decrement D. Prove D preserves the
   matching and paired decoder P, including all prefix decoders.
2. Connect the stack rules with base reachability, using the unchanged
   Machine/Rules/Simulation/Counter/Pairing/Overflow/Stride development.
3. Define integer adjusted reset arithmetic rho, the paid stack operation T,
   and Good. Prove prefix borrowing, Good preservation by D, by bits, and by
   D^d(s)W for d>=2; prove clean reset above a Good stack preserves Good.
4. Keep the physical pending phase explicit in the reset simulation theorem.
   A charged T(w) is a stack effect, not an identical intermediate head state.
5. Prove the earlier common Z-return theorem with Ready2 from PROOF_1LA.md,
   its dual-credit lemma, counted matched-group expansion, and the small
   zero-counter overflow repair. These are previous proposed mathematical
   results, not automatically certified by importing the original archive.

The paired decoder must remember whether a W closes X or Z. A scalar count of
W's is insufficient. Nat subtraction must not replace negative integer reset
arithmetic: the absorbing negative region is used to certify cleanliness.

## 2. Recommended new 0RB definitions

`Strict(s)`: every nonempty prefix has strictly positive matching height.
`Ready2(s)`: the length-bounded scan cX->c, cW->D^2(c), stopping at Z or bottom,
never requests an unavailable decrement.
`Normal0RB(s)`: Good, Strict, positive v, literal final X, and Ready2.

Use an inductive language for each initial exponent r>=2:

- initial word w0(r) from PROOF_0RB.md (1);
- if w is generated, so is Yw;
- if w is generated with Dyck height h, so is YwX^hV.

This definition is the right level for the base simulation theorem. The
explicit Y^p w0 e form is a derived arithmetic lemma, not an independent
assumption about reachable right words.

## 3. 0RB lemma order and exact statements

### A. Shape and machine scan

`generated_shape`: derive (3), including its two height cases and counts of X.
`marker_return`: reuse the preceding exact w->wX^hV marker theorem.
`scan0RB_sound`: a Normal0RB B checkpoint safely reaches bottom or an unmarked Z.
Before the first W its suffix is Y^rR1; afterwards it is wR with Generated(r,w).
The remaining core is Good and either empty or Strict. No F/G/J0 survives.

### B. Reset supply

`reverse_debt2_sound`: equation (4), using full paid-stack identities.
`credit_envelope`: C=f+2 forward bounds and N=n+4 reverse bounds, for every prefix.
`leading_ones_stop`: L>=J+2 suffices to stop before an older stack.
`generated_reset`: Lemma A, with exactly one exception: w=YXYYV needs x>=1.

For `generated_reset`, keep r=2, r=3, r>=4 separate. In the r=2,m>=1 case,
its internal X is crossed only when q=6 modulo 8; prove its supply at the
specific earlier prefix, not merely at the final reset endpoint.

### C. Exceptional reset margin

`dyadic_decoder_slack`: Lemma B, h>=1, f=2^j with j>=1 implies B>=f+2.
It depends on the counted-expansion theorem and the one-expanding-close nested
chain classification. Include f=2 and f=4 explicitly.
`post_close_slack`: t=T(ud), ud clean, u positive-height clean Dyck prefix,
d=X or V implies b(t)>=v(t), and an extra unit whenever v(t)+1 is dyadic.
This includes v(t)=0; that boundary is needed by the early clock.

### D. Clocks and full return

`early_clean_clock`: Lemma C for
P(t)YwX^(height(w)+1)chi(v(t)+1)V.
`auxiliary_clock`: P(t)YYVXchi(v(t)+1)V for Good t with v(t)>=1.
Both must prove clean/positive, full-stack reset equality, and Ready2. In the
branches where the reverse scan enters T(P(t)), use dual credit on t and the
proved bound v(t)>=2n+2; do not assume that Good alone implies Ready2.

`even_Z_return`: the four cases of Section 8, including exact raw-symbol
re-parsing of the additional pending P2. Its conclusion is Normal0RB or the
known XY spinout. Reuse the old common-Z return for the untouched odd terminal.

`normal0RB_returns`: combine scan and both Z cases. Include positive base-step
length: the initial literal X forces at least six defined base transitions.
`blank_seed0RB`: finite 156-transition seed.
`blank0RB_nonhalting`: iterate the positive return relation, or use the supplied
spinout witness. This does not need any growth estimate on successive counters.

## 4. Independent 0LB formalization targets

These can be formalized without claiming the final 0LB nonhalting theorem.

`energy`: define E in Int using genuine floor division by the positive number 2.
`balanced_energy_cost`: a matched group acts by subtracting a fixed nonnegative
integer. Derive E(s)<=v(s) and E(D(s))=E(s)-1.
`energy_prefix_nonneg`: negativity is absorbing under all three energy maps.
`energy_ready4`: E(s)>=0 supplies the whole four-decrement B scan and preserves
E>=0 at each successive B checkpoint. Connect D^4 to the actual F/G/N1/N2 rules.
`energy_paid_reset`: E(T(w))=rho3(w), with X fee three.
`energy_transfer`: Theorem 2, cross-multiplied to avoid rational denominators:

    (E(T(P(c)))+1)*2^(height(c))
      >= (E(c)+1)*2^(height(T(P(c)))).

The height difference is twice the number of V's in P(c). Formalize the proof
before and after the first such V separately. The theorem holds even for
negative E, although its safety corollary uses E>=0.

`Root3(c)`: literal initial ZZZ with no later matching pop reaching those bits.
`root3_counter_lower`: v(c)>=7*2^(height(c)-3).
`zero_pop_cost_comparison`: C2<=4C1 and C3<=5C1 for no V in P(c).
`root3_reset_energy`: F>=3a/7+2; preferably state 7F>=3a+14 in integers.
Prove the strengthened 2F>=a+4E(c)+3 after the first one-matched pop.
`rho3_clock`: for r>=4, Y^rVX^(r-1) acts by e->4e-2.
`rho3_binary_requirement`: when m has three leading binary ones,
7*(required_energy(chi(m))+6)<=6m.
`root3_one_return`: Theorem 3, output Good core, E>=0, and right exponent>=4.
It does NOT include Root3 in the conclusion.

## 5. Statement that must remain open in this package

The proposed two-return root recovery (U) in PROGRESS_0LB.md has no proof here.
Do not replace it with a finite enumeration, a bounded random search, or an
unjustified invariant declaration. A hypothetical final theorem would need:

- either prove (U), including safe supply through the second cycle;
- or construct a different inductive class containing the explicitly reached
  rooted Z configuration and prove its return closure.

The recorded first-cycle outputs ZZXZZX and ZXZZWZX refute one-cycle rooted
closure. The q=2 example refutes using the number of one-matched pops alone to
avoid that issue. Retain these as regression tests during formalization.

## 6. Verification artifacts

`verification_push.json`: complete 0RB reference endpoint comparisons, seed
replays, and unaccelerated base/block comparisons; two 0LB finite seed returns.
`component_results_push.json`: generated-language profiles, dyadic slack, clock
instances, energy/decrement/transfer checks and binary thresholds.
`rooted_0LB_results.json`: tests of Theorem 3 and a separately labeled probe of
(U), with exact non-rooted intermediate examples.
`random_roots.json`: deterministic randomized probe of (U), not certification.

Python uses the old reference simulator unchanged. Its successful execution is
an independent calculation check, not a substitute for the base-reachability
proofs or a proof of universal statements from finite data.
