from __future__ import annotations
import sys
from pathlib import Path
D=Path(__file__).parent/'dependencies'/'bb25_remaining_proofs'
sys.path.insert(0,str(D))
from remaining_tools import *
from itertools import product
from collections import Counter

def bscan_d(s,d=4,r=1):
    while s:
        if s[-1]=='Z': return 'Z',s,r
        if s[-1]=='X': s=s[:-1];r+=1;continue
        s=s[:-1]
        if value(s)<d: return 'unsafe',s,r
        s=decn(s,d);r+=1
    return 'spinout',s,r

def normal_d(s,d=4):
    return bool(s) and s[-1]=='X' and strict_admissible(s) and good(s) and value(s)>0 and bscan_d(s,d)[0]!='unsafe'

def reference_one(member,s,limit=30000,extended=False):
    lt=list(reversed(s))+['L']; st='B'; rt=['Y','R1'];cost=0
    for i in range(limit):
        if st=='B' and lt==['L']:return 'spinout',(),i,cost
        if st=='L' and lt==['L'] and denote(lt,st,rt)[3][:4]==[1,1,2,2]:return 'spinout',(),i,cost
        if i and st=='B' and rt==['Y','R1'] and all(x in 'XZW' for x in lt[:-1]):return 'B',tuple(reversed(lt[:-1])),i,cost
        stride=ref.stride(lt) if st=='L' else None
        if stride:lt,k=stride;st='R'
        else:
            try:lt,st,rt,k=(extended_bstep if extended else ref.bstep)(member,lt,st,rt)
            except ref.Stuck as e:return 'stuck',(lt,st,rt,str(e)),i,cost
        cost+=k
    return 'limit',(lt,st,rt),limit,cost

if __name__=='__main__':
    for text in ['ZXZX','ZZXXWZX','ZZZXXXWWXXWX','ZZZXXX']:
        s=tuple(text); a=bscan_d(s)
        print(text,'ready4',a[0], 'at', ''.join(a[1]),a[2])
        if a[0]=='Z':
            kind,t=m.common_Z(a[1][:-1],a[2]);print('out',kind,''.join(t),'ready4',bscan_d(t)[0])
    ct=Counter();bad=[]
    for length in range(2,12):
        for p in product('XZW',repeat=length-1):
            s=p+('X',)
            if not normal_d(s):continue
            tag,t,r=bscan_d(s);ct['inputs']+=1
            if tag=='spinout':ct['spinout']+=1;continue
            kind,out=m.common_Z(t[:-1],r)
            ct[kind]+=1
            if kind=='B' and not normal_d(out):
                ct['bad']+=1
                if len(bad)<12:bad.append((''.join(s),''.join(out),bscan_d(out)))
        print(length,dict(ct),flush=True)
    print('bad',bad)
