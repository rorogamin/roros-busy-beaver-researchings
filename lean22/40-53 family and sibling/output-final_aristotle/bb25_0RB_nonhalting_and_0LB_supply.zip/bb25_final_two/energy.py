from research import *
def energy(s,d=2):
    a=0
    for ch in s:a=2*a+(ch=='Z') if ch!='W' else a//2-d
    return a

def height(s):return sum(1 if c!='W' else -1 for c in s)

if __name__=='__main__':
 ct=Counter();bad=[];goodbad=[]
 for L in range(1,12):
    for s in product('XZW',repeat=L):
        if not good(s):continue
        e=energy(s);h=height(s)
        if e<0:continue
        t=reset((),decode(s));f=energy(t);H=height(t);ct['inputs']+=1
        if (f<<h)<(e<<H):
            ct['density_drop']+=1
            if len(bad)<12:bad.append((''.join(s),value(s),e,h,f,H))
        if e*3>=2*(1<<h) and s[-1]=='X':
            ct['candidate']+=1
            tag,c,r=bscan_d(s)
            assert tag!='unsafe'
            if tag=='Z':
                ans,u=m.common_Z(c[:-1],r)
                if ans=='B' and not energy(u)*3>=2*(1<<height(u)):
                    ct['closure_fail']+=1
                    if len(goodbad)<12:goodbad.append((''.join(s),''.join(u),energy(u),height(u)))
    print(L,dict(ct),bad[:3],goodbad[:3],flush=True)
 print('bad',bad);print('goodbad',goodbad)
