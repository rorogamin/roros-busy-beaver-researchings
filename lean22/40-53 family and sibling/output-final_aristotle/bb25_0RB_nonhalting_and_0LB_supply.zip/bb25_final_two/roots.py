from energy import *
def root(s,k=3):
    if s[:k]!=('Z',)*k:return False
    h=0
    for ch in s[k:]:
        h+=1 if ch!='W' else -1
        if h<0:return False
    return True

def test(c,r):
    a=value(c)
    kind,out=m.common_Z(c,r)
    tag,t,R=bscan_d(out)
    if tag!='Z':return tag,out,t,R
    cc=t[:-1]
    if not root(cc) or energy(cc)<0 or R<4:return 'lost',out,cc,R
    return 'ok',out,cc,R

if __name__=='__main__':
 ct=Counter();bad=[]
 for l in range(3,13):
    for tail in product('XZW',repeat=l-3):
        c=('Z',)*3+tail
        if not root(c) or not good(c) or energy(c)<0:continue
        for r in (4,5,6,9):
            tag,out,cc,R=test(c,r);ct[tag]+=1
            if tag!='ok' and len(bad)<20:bad.append((''.join(c),r,tag,''.join(cc),R,energy(c),energy(cc),height(cc)))
    print(l,dict(ct),bad[:5],flush=True)
 print('bad',bad)
