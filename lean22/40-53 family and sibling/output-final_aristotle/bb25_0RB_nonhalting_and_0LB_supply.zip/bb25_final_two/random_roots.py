from roots2 import *
import random,json,time
rng=random.Random(25001609);ct=Counter();bad=[];start=time.time()
for case in range(3000):
    c=('Z',)*rng.randrange(3,11)
    for i in range(rng.randrange(10,120)):
        op=rng.choice('XXZZWWD')
        try:
            t=dec(c) if op=='D' else c+(op,)
        except Exception:continue
        if root(t) and good(t) and energy(t)>=0:c=t
    r=rng.randrange(4,40)
    tag,steps,t,R=return_root(c,r);ct[(tag,steps)]+=1
    if tag not in ('ok','spinout'):
        bad.append({'input':''.join(c),'r':r,'status':tag,'iterations':steps,'output':''.join(t),'R':R});print('BAD',bad[-1],flush=True);break
    if case%250==0:print(case,dict(ct),time.time()-start,flush=True)
result={'status':'counterexample' if bad else 'no counterexamples in finite test','counts':{str(k):v for k,v in ct.items()},'counterexamples':bad,'seed':25001609,'elapsed':time.time()-start}
(Path(__file__).parent/'random_roots.json').write_text(json.dumps(result,indent=2))
print(result,flush=True)
