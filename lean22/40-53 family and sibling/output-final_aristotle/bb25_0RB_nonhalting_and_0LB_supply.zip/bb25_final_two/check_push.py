#!/usr/bin/env python3
"""Finite checks for the new 0RB proof and the partial 0LB theorems.

A passing run is not a formal certificate. Assertion failures, uncovered
reference rules, and step limits are errors, never nonhalting conclusions.
"""
from __future__ import annotations
import argparse
import json
import random
import time
from pathlib import Path
from collections import Counter
from itertools import product
from core_0rb import *
from roots2 import root, return_root
from energy import energy, height

HERE_PUSH = Path(__file__).resolve().parent


def write_result(name, counts, start, **extra):
    result = dict(status='all assertions passed',
                  scope='finite consistency checks; not a Lean certificate',
                  counts=dict(counts), elapsed_seconds=round(time.time()-start, 3),
                  **extra)
    (HERE_PUSH/name).write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2), flush=True)
    return result


def check_returns(max_length=12, random_count=300):
    start=time.time(); ct=Counter(); branches=Counter(); outcomes=Counter()
    rng=random.Random(2026091612); maxref=0
    def check(s, category):
        nonlocal maxref
        assert normal_rb(s)
        tag,out,branch=successor_rb(s)
        rtag,rout,steps,cost=reference_one('0RB',s,limit=200000)
        assert (tag,out)==(rtag,rout),(s,tag,out,rtag,rout)
        assert cost>0
        ct[category]+=1;ct['exact_0RB_endpoints']+=1
        branches[branch]+=1;outcomes[tag]+=1;maxref=max(maxref,steps)
        if ct['exact_0RB_endpoints']%10000==0:print('return cases',ct['exact_0RB_endpoints'],round(time.time()-start,2),flush=True)
    for length in range(2,max_length+1):
        for p in product('XZW',repeat=length-1):
            s=p+('X',)
            if normal_rb(s):check(s,'exhaustive')
        print('0RB length',length,dict(ct),round(time.time()-start,2),flush=True)
    made=0
    while made<random_count:
        s=()
        for _ in range(rng.randrange(20,130)):
            if value(s)>=2 and rng.random()<.42:s=decn(s,2)+('W',)
            else:s+=(rng.choice(('X','Z')),)
        if not value(s):s+=('Z',)
        s+=('X',)
        if not normal_rb(s):continue
        check(s,'random_long');made+=1
    for h in range(3,14):
        for pairs in (0,1,3,7,15):
            w='Y'*h+'VX'*min(pairs,2**(h-1)-1)+'YV'
            s=reset((),w)
            if normal_rb(s):check(s,'constructed')
    seed=tuple('ZZZXXX')
    for member in ('0RB','0LB'):
        machine=base.machine(ref.machineB4(member));c=([],base.A,'R',[])
        for _ in range(156):c=base.step(machine,c);assert c is not None
        assert c==ref.denote(list(reversed(seed))+['L'],'B',['Y','R1'])
        ct['blank_seed_base_transitions']+=156
    assert ref.crosscheck('0RB',5000)=='ok'
    ct['0RB_unaccelerated_base_block_transitions']=5000
    # Replay the two complete B-to-B returns that bring 0LB to the rooted
    # Z class; then inspect the next finite supplied B scan.
    s=seed;entry=[]
    for i in range(2):
        tag,cc,r=bscan_d(s);assert tag=='Z'
        kt,out=m.common_Z(cc[:-1],r)
        rt,ro,steps,cost=reference_one('0LB',s,limit=200000,extended=True)
        assert (kt,out)==(rt,ro) and cost>0
        entry.append(dict(input=''.join(s),core=''.join(cc[:-1]),r=r,
                          output=''.join(out),base_transitions=cost))
        ct['0LB_seed_prefix_exact_returns']+=1;s=out
    tag,cc,r=bscan_d(s);c=cc[:-1]
    assert tag=='Z' and root(c) and good(c) and energy(c)>=0 and r>=4
    entry.append(dict(rooted_Z_core=''.join(c),r=r,energy=energy(c),counter=value(c)))
    return write_result('verification_push.json',ct,start,member='0RB',
                        exhaustive_max_length=max_length,random_seed=2026091612,
                        branches=dict(branches),outcomes=dict(outcomes),
                        max_reference_steps=maxref,zeroLB_rooted_entry=entry)


def rho3(x,w):
    for ch in w:
        x=2*x+1 if ch=='Y' else 2*x if ch=='V' else x//2-3
    return x


def threshold3(w):
    n=0
    for ch in reversed(w):
        n=n//2 if ch=='Y' else (n+1)//2 if ch=='V' else 2*n+6
    return n


def check_components():
    start=time.time();ct=Counter();rng=random.Random(2026091613)
    # Exact generated-word language, all histories of at most ten operations.
    selected=[]
    for r in range(2,11):
        for depth in range(11):
            for ops,w in gen_words(r,depth):
                clean,threshold,kind,_,_=profile(w)
                exceptional=(r==2 and not ops)
                assert clean==(1 if exceptional else 0),(r,ops,w,clean)
                assert threshold<=int(exceptional) and kind=='stop',(r,ops,w,threshold,kind)
                ct['generated_word_local_reset_and_reverse_profiles']+=1
                if depth<=4:selected.append((r,w))
    # Dyadic gap and post-X/V consequence, independent concrete paid stacks.
    for length in range(1,15):
        for u in dyck_words(length):
            if dyck_height(u)<1:continue
            f=adjusted(u)
            if f<0:continue
            t=reset((),u);B=adjusted(decode(t))
            assert good(t) and value(t)==f
            ct['clean_positive_height_Dyck_words']+=1
            if f>=2 and not f&(f-1):
                assert B>=f+2,(u,f,B);ct['dyadic_gap_instances']+=1
            for d in 'XV':
                if adjusted(u+d)<0:continue
                tt=reset((),u+d);x=value(tt);BB=adjusted(decode(tt))
                assert BB>=x
                if not x&(x+1):
                    assert BB>=x+1,(u,d,x,BB)
                    ct['post_close_dyadic_slack']+=1
        print('dyadic length',length,ct['clean_positive_height_Dyck_words'],flush=True)
    # Lemma C and the auxiliary clock on arbitrary Good underlying stacks,
    # not only on the particular T(ud) outputs occurring in the machine.
    goods=[]
    for length in range(0,9):
        for t in product('XZW',repeat=length):
            if not good(t):continue
            x=value(t);B=adjusted(decode(t));goods.append(t)
            if x>=1:
                word=decode(t)+'YYVX'+chi(x+1)+'V'
                out=reset((),word)
                assert adjusted(word)>0 and normal_rb(out),(t,word)
                ct['auxiliary_clock_instances']+=1
    for _ in range(14000):
        t=rng.choice(goods);x=value(t);B=adjusted(decode(t))
        if not x&(x+1) and B<x+1:continue
        r,w=rng.choice(selected);h=dyck_height(w)
        word=decode(t)+'Y'+w+'X'*(h+1)+chi(x+1)+'V'
        out=reset((),word)
        assert adjusted(word)>0 and normal_rb(out),(t,r,w)
        ct['early_clean_clock_instances']+=1
    # Energy identities on every Good stack through length eleven, including
    # negative-energy stacks for the normalized transfer theorem.
    for length in range(0,12):
        for s in product('XZW',repeat=length):
            if not good(s):continue
            a=value(s);e=energy(s);h=height(s);u=decode(s);t=reset((),u)
            F=energy(t);H=height(t);q=u.count('V')
            assert H==h+2*q and energy(t)==rho3(0,u)
            assert (F+1)*(1<<h)>=(e+1)*(1<<H),(s,e,F,h,H)
            ct['normalized_energy_transfer']+=1
            if a:
                assert energy(dec(s))==e-1
                ct['energy_decrement_identity']+=1
            if e>=0:
                assert bscan_d(s)[0]!='unsafe',(s,e)
                ct['four_scan_energy_certificates']+=1
        print('energy length',length,ct['normalized_energy_transfer'],flush=True)
    # Independently test the binary threshold used by the rooted one-return
    # theorem; m has the three leading binary one bits required in the proof.
    for mm in range(7,200001):
        h=mm.bit_length()
        if mm>>(h-3)!=7:continue
        need=threshold3(chi(mm))
        assert 7*(need+6)<=6*mm,(mm,need)
        ct['energy_binary_thresholds']+=1
    return write_result('component_results_push.json',ct,start,random_seed=2026091613)


def reference_z_to_z(c,r,limit=200000):
    """Original base-linked block rules, from one specified Z to the next Z."""
    lt=list(reversed(c+('Z',)))+['L'];st='B';rt=['Y']*r+['R1']
    paid_return_seen=False;cost=0
    for step in range(limit):
        if step and st=='B' and rt==['Y','R1']:
            paid_return_seen=True
        if paid_return_seen and st=='B' and lt and lt[0]=='Z':
            assert lt[-1]=='L' and all(x in 'XZW' for x in lt[:-1])
            assert rt[-1]=='R1' and all(x=='Y' for x in rt[:-1])
            return tuple(reversed(lt[1:-1])),len(rt)-1,step,cost
        stride=ref.stride(lt) if st=='L' else None
        if stride:lt,k=stride;st='R'
        else:lt,st,rt,k=extended_bstep('0LB',lt,st,rt)
        cost+=k
    raise AssertionError('independent 0LB reference limit; not a conclusion')


def check_rooted():
    start=time.time();ct=Counter();candidate=Counter();examples=[]
    def check(c,r,category):
        a=value(c);e=energy(c);h=height(c);u=decode(c);q=u.count('V')
        F=energy(reset((),u));assert 7*F>=3*a+14
        if q:assert 2*F>=a+4*e+3
        else:assert F>=5*a-4*((1<<h)-1)
        tag,s=m.common_Z(c,r);assert tag=='B' and energy(s)>=0
        kind,cc,R=bscan_d(s);assert kind=='Z'
        cp=cc[:-1];assert good(cp) and energy(cp)>=0 and R>=4
        ct[category]+=1;ct['proved_one_return_instances']+=1
        if ct['proved_one_return_instances']%47==1:
            rc,rr,steps,cost=reference_z_to_z(c,r)
            assert (rc,rr)==(cp,R) and cost>0,(c,r,rc,rr,cp,R)
            ct['independent_0LB_Z_to_Z_endpoints']+=1
        # This next test is explicitly a conjecture probe, not a theorem.
        kind,n,out,RR=return_root(c,r,limit=2)
        assert kind in ('ok','spinout'),('conjecture counterexample',c,r,kind,n,out,RR)
        candidate[str(n)+'_cycles']+=1
        if not root(cp) and len(examples)<8:
            examples.append(dict(input=''.join(c),r=r,first_core=''.join(cp),first_r=R,
                                 repaired_core=''.join(out),repaired_r=RR))
    for length in range(3,13):
        for tail in product('XZW',repeat=length-3):
            c=('Z',)*3+tail
            if not root(c) or not good(c) or energy(c)<0:continue
            for r in (4,5,6,9):check(c,r,'exhaustive_rooted_inputs')
        print('root length',length,dict(ct),dict(candidate),flush=True)
    # A constructed case refutes the tempting claim that q>=2 eliminates
    # the need for a second rooted cycle.
    c=tuple('ZZZXXWZWXWWZW');r=4
    assert root(c) and good(c) and energy(c)==0 and decode(c).count('V')==2
    tag,s=m.common_Z(c,r);kind,cc,R=bscan_d(s)
    assert kind=='Z' and not root(cc[:-1])
    check(c,r,'constructed_q2_exception')
    return write_result('rooted_0LB_results.json',ct,start,
                        two_cycle_observations=dict(candidate),
                        two_cycle_status='conjecture only; no universal closure proof',
                        nonclosed_one_step_examples=examples)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--part',choices=('returns','components','rooted','all'),default='all')
    ap.add_argument('--max-length',type=int,default=12)
    ap.add_argument('--random',type=int,default=300)
    a=ap.parse_args()
    if not 2<=a.max_length<=14:ap.error('max-length must be in 2..14')
    if a.random<0:ap.error('random must be nonnegative')
    if a.part in ('returns','all'):check_returns(a.max_length,a.random)
    if a.part in ('components','all'):check_components()
    if a.part in ('rooted','all'):check_rooted()

if __name__=='__main__':main()
