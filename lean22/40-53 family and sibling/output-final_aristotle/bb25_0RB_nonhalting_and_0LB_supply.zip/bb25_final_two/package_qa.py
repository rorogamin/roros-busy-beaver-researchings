#!/usr/bin/env python3
"""Artifact integrity and clean-copy smoke tests, not a proof certificate."""
from pathlib import Path
import argparse,hashlib,json,py_compile,shutil,subprocess,sys,tarfile,tempfile

HERE=Path(__file__).resolve().parent

def digest(data):return hashlib.sha256(data).hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--original-archive',type=Path)
    args=ap.parse_args()
    newfiles=list(HERE.glob('*.py'))
    for p in newfiles:py_compile.compile(str(p),doraise=True)
    results={n:json.loads((HERE/n).read_text())['status'] for n in
             ('verification_push.json','component_results_push.json','rooted_0LB_results.json','random_roots.json')}
    refs=HERE/'dependencies/bb25_remaining_proofs/prior/previous/reference_tools'
    provenance={}
    if args.original_archive:
        with tarfile.open(args.original_archive) as tf:
            for name in ('blocksim.py','sim.py'):
                matches=[m for m in tf.getmembers() if m.isfile() and m.name.endswith('/'+name)]
                assert len(matches)==1
                original=tf.extractfile(matches[0]).read();included=(refs/name).read_bytes()
                assert original==included
                provenance[name]=dict(sha256=digest(included),identical_to_original=True)
    smoke=r'''
from core_0rb import *
from check_push import reference_z_to_z
from roots2 import root,return_root
from energy import energy
seen={}
for length in range(2,11):
    for p in product('XZW',repeat=length-1):
        s=p+('X',)
        if not normal_rb(s):continue
        tag,out,branch=successor_rb(s)
        if branch not in seen:
            rtag,rout,steps,cost=reference_one('0RB',s)
            assert (tag,out)==(rtag,rout) and cost>0
            seen[branch]=''.join(s)
    if len(seen)==7:break
assert len(seen)==7,seen
for text in ('ZZZ','ZZZX','ZZZXXWZWXWWZW','ZZZXZWXXXXXXXXWWWWWW'):
    c=tuple(text);assert root(c) and good(c) and energy(c)>=0
    for r in (4,7):
        tag,s=m.common_Z(c,r);k,cc,R=bscan_d(s)
        rc,rr,_,cost=reference_z_to_z(c,r)
        assert (rc,rr)==(cc[:-1],R) and cost>0
        assert energy(cc[:-1])>=0
        assert return_root(c,r,limit=2)[0]=='ok'
import json
print(json.dumps({'status':'passed','branch_representatives':seen,'0LB_smoke_endpoints':8}))
'''
    with tempfile.TemporaryDirectory(prefix='bb25_clean_') as td:
        destination=Path(td)/'package'
        shutil.copytree(HERE,destination,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        process=subprocess.run([sys.executable,'-c',smoke],cwd=destination,text=True,capture_output=True,timeout=30)
        assert process.returncode==0,(process.stdout,process.stderr)
        smoke_result=json.loads(process.stdout.strip().splitlines()[-1])
    report=dict(status='artifact QA passed',new_python_files_compiled=len(newfiles),
                result_statuses=results,reference_provenance=provenance,
                clean_copy_smoke=smoke_result,new_lean_compilation_performed=False,
                scope='artifact integrity and finite smoke tests, not mathematical or Lean certification')
    (HERE/'PACKAGE_QA.json').write_text(json.dumps(report,indent=2)+'\n')
    hashes={str(p.relative_to(HERE)):digest(p.read_bytes()) for p in sorted(HERE.rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name!='SHA256SUMS.json'}
    (HERE/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
