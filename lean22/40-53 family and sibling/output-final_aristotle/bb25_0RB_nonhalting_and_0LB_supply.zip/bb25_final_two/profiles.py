from research import *

def needed(w,target=0):
    # min nonnegative starting integer whose final value >= target
    for ch in reversed(w):
        if ch=='Y':target=target//2
        elif ch=='V':target=(target+1)//2
        elif ch=='X':target=2*target+2
        else: raise ValueError(ch)
    return max(0,target)

def profile(w,d=2,init_debt=0):
    clean=needed(w);threshold=max(clean,needed(w,init_debt));n=init_debt
    for i in range(len(w)-1,-1,-1):
        ch=w[i]
        if ch=='X':
            n=2*n+2+d
            threshold=max(threshold,needed(w[:i],n))
        elif ch=='Y':
            if n%2==0:return clean,threshold,'stop',i,n
            n//=2
        else:
            if n%2:return clean,threshold,'stop',i,n
            n//=2
    return clean,threshold,'escape',0,n

def gen_words(r,steps):
    start='Y'+prev.return_word(r)
    for ops in product('ab',repeat=steps):
        w=start
        for o in ops:
            w='Y'+w if o=='a' else 'Y'+right_marker_return(w)
        yield ''.join(ops),w

if __name__=='__main__':
    for r in range(2,7):
        print('r',r)
        for steps in range(0,4):
            for ops,w in gen_words(r,steps): print(ops or '-',w,profile(w), 'h',dyck_height(w))
