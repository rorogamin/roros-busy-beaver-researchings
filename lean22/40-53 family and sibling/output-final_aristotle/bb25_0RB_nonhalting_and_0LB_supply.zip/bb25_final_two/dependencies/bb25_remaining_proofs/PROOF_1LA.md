# A nonhalting return proof for the 1LA member

Date: 2026-09-16.

Machine:

```
1RB2LA0RB1LB---_1LA3RA1RA4LB1LA
```

## Status

This is a proposed complete mathematical proof. The NEW lemmas and their
composition have not been compiled or kernel-checked in Lean. The argument
uses the counter, pairing and block interface from the supplied Aristotle
project, and the Good/reset/common-Z lemmas in the previous proof packages.
Those earlier proposed proofs are included unchanged under `prior/`.
Finite simulator comparisons accompany this document, but are not the
justification for its universally quantified assertions.

The new point is a reset-to-B comparison lemma. It proves that the common Z
return produces a stack on which the entire subsequent 1LA B scan is safe.
The B scan is a bounded, finite operation on the left stack, NOT the entire
future machine trajectory. Its length is at most the number of left blocks.

This closes 1LA. This document does not claim to close 0LB or 0RB.

## 1. Established interface and notation

Stacks are written bottom first, without the permanent bottom L=^11. On the
left X=11 and Z=01 are bits, and W=03 is a pop:

    v(empty)=0
    v(sX)=2v(s)
    v(sZ)=2v(s)+1
    v(sW)=floor(v(s)/2).

A stack is admissible when every pop has a preceding unmatched bit. Match
pops with the latest unmatched bits. D decrements the final unmatched binary
numeral, leaves matched bits unchanged, and is defined when v(s)>0.

The paired decoder P sends either bit to right Y=22, a W matched to a zero
bit to right X=11, and a W matched to a one bit to right V=21. In particular,
P(D(s))=P(s), including at every decoded prefix. A zero-counter leftward
excursion deposits P(s) and reaches the left boundary.

Adjusted reset arithmetic, on integers, is

    Y: b -> 2b+1
    V: b -> 2b
    X: b -> floor(b/2)-1.

Let rho(w) be its value from zero. Let b(s)=rho(P(s)). Good(s) means
admissibility and b(p)>=v(p) for EVERY bottom-prefix p of s.

The previous interface proves:

1. D preserves Good and does not increase any prefix counter.
2. Bit append preserves Good.
3. If v(s)>=d>=2 and s is Good, D^d(s)W is Good.
4. A clean reset w produces its paid stack T(w), which is Good and satisfies
   v(T(w))=rho(w). Its operations are

       T(wY)=T(w)Z,
       T(wV)=T(w)X,
       T(wX)=D(T(w)W)=D^2(T(w))W.

   In the last equality the low bit that the W matches is frozen; the
   decrements on the two sides are precisely the same unmatched-bit change.
   Pending-1 debt is charged early. The endpoint assertion pays it at the
   next turn; it does not identify physical head positions at every prefix.
5. For Good(c), the common B-on-Z branch at

       L c Z <B1 Y^r R1

   has a finite return to Good, positive, X-ending B checkpoint with right
   suffix YR1, or the established left XY spinout. The previous proof gives
   both the direct case and its exact small-counter reset cases.

Here <B1 includes its extra right-hand one, R is the bare right end, and R1
is 1 followed by the right end.

## 2. The finite 1LA B scan

Until it encounters a Z, a 1LA B scan performs the following left operations:

* Remove a terminal X and prepend Y to the right word.
* On a terminal W, remove it. If the remaining counter is at least two, make
  two successful A excursions through F/G, then use the 1LA G rule to return
  to B, prepending one Y to the right word.

Thus its left operation is

    cW <B1 ...  -->  D^2(c) <B1 Y ...    if v(c)>=2.

When the supply is below two, the F/G path reaches the fatal phase-shift
configuration instead. Reaching the actual bottom in B is the known left
spinout, not a halting event.

Define Ready(s) to mean that this finite scan reaches a Z or the bottom
without encountering an undersupplied W. Each X or W operation deletes one
left block; D does not change length. Therefore Ready is a terminating,
decidable predicate requiring at most |s| scan operations.

Good is preserved during a successful scan, because suffix deletion and D
both preserve it. The right tail changes only by prepending Y's. We will
prove that every common Z return with r>=2 produces Ready again.

## 3. Reverse reset debt

Consider a B scan on D^n(T(w)). Read the reset word w from right to left,
carrying the number n of already charged A decrements. The following rules
are exact whenever their displayed debt is affordable:

    final reset X: n -> 2n+4;
    final reset Y: stop at Z if n is even;
                   otherwise remove the resulting zero bit and n -> (n-1)/2;
    final reset V: stop at Z if n is odd;
                   otherwise remove the resulting zero bit and n -> n/2.

For X, T(uX)=D^2(T(u))W. The extra n decrements above W are 2n decrements
below it. Removing W in a 1LA B scan adds two more, giving 2n+4 in total.
For Y and V the parity rules are ordinary binary subtraction from the
appended one or zero bit.

A stop at Z is a successful endpoint of this finite B scan. The complete
machine's subsequent Z excursion is handled separately by the return lemma.

## 4. New comparison lemma: dual reset credit

### Lemma 1

If c is Good and

    v(c) >= 2n+2,

then the B scan on

    D^n(T(P(c)))

is safe and reaches a Z.

### Proof

Induct on the length of c. Put a=v(c), b=rho(P(c)); Good gives b>=a.
The n charged decrements exist because b>=a>=2n+2.

First remove a maximal trailing run of j decoded X's in P(c). These are j
actual terminal W's, each matched to zero. Reversing the reset X operations
gives charged debt

    n_j = 2^j(n+4)-4.

Let b_j be the reset counter before those j letters. Reversing the adjusted
reset arithmetic gives

    b_j >= 2^j(b+2)-2,

and consequently

    b_j - n_j >= 2^j(b-n-2)+2 >= 2.

The same inequality holds after every shorter part of the run. Hence all of
these W removals and their two-decrement F/G passages are legal; the actual
remaining counter is at least two.

If j>0 and the preceding decoded letter is Y, n_j is even. The B scan stops
at that reset's one bit, so this case is finished.

If the preceding decoded letter is V, an odd debt stops immediately at Z.
For even debt, remove that reset zero bit and divide the debt by two. In the
original source c, reversing the j zero-colored pops and this one-colored
pop gives the shorter-prefix value

    a' = 2^(j+1)a+1.

The new debt is n'=n_j/2, and

    a'-(2n'+2) = 2^j(2a-n-4)+3 >= 0.

The shorter source prefix is Good, so apply induction. This formula also
covers j=0 when the last decoded letter is V and its debt is even.

Finally, when j=0 and the last letter is Y, even n stops at Z. For odd n,
remove that source bit. Its original prefix value is floor(a/2), while the
new debt is (n-1)/2. Since a>=2n+2,

    floor(a/2) >= n+1 = 2*((n-1)/2)+2.

Again apply induction. An empty source is impossible under a>=2n+2.
This proves the lemma. QED.

The prefix inequalities in Good are essential: induction uses Good at the
shorter source prefixes, not merely the inequality at the whole stack.

## 5. Exact word for a direct common Z return

For an integer m>=1 define chi(m) by taking the lower binary digits of m,
omitting its leading one, and reading them least significant first, with
zero encoded as X and one as V. In particular chi(1) is empty.

Let c be Good, a=v(c)>=2, r>=2, and set m=floor(a/2). Define d=X for even a
and d=V for odd a. The exact normal B-return stack from the common Z branch is

    T(P(c) d Y^r V X^(r-1) chi(m) V).                 (A)

### Derivation

The Z rule makes two decrements and appends a pop, giving z=D^2(c)W with
counter m-1 and decoder P(c)d. Its pending-2 tail produces

    z Z^r W A>R.

The first r-1 positive drain rounds turn its local suffix into

    X^(r-1) Z W^r,

a balanced transparent group with decoder Y^r V X^(r-1). The counter is now
m-1. Subsequent drain rounds change v to floor((v-1)/2), equivalently change
v+1 to floor((v+1)/2). Their appended pops are colored X when the current
v+1 is even and V when it is odd. Thus they emit chi(m), ending at counter
zero. The final overflow contributes the last V. Existing matched colors
are unchanged, which proves (A).

This argument is valid at m=1: the chi part and the latter drain are empty.

## 6. New lemma: every direct Z return is Ready

Start the reset in (A) after P(c), with counter b>=a. After its d, write the
counter as b0. In both parity cases,

    b0 >= m-1.

The next buffer Y^r V X^(r-1) has exact reset effect

    b0 -> 4b0+2 >= 4m-2.                             (B)

While reading chi(m), carry the remaining binary integer M, initially m.
A zero digit has reset map X and M->M/2; a one digit has map V and
M->floor(M/2). The inequality

    reset counter >= 4M-2

persists. For a zero, floor((4M-2)/2)-1=2M-2. For a one the counter doubles,
which is more than sufficient. At M=1 the counter is at least two, and the
final V gives a positive X-ending checkpoint.

Now perform the next B scan using reverse debt. The final V strips at debt
zero. While reading chi(m) backwards, reconstruct M from one and carry debt
n, initially zero. The backward transitions are

    X: (M,n) -> (2M,2n+4),
    V: stop if n is odd;
       otherwise (M,n) -> (2M+1,n/2).

They preserve

    n+4 <= 4M.                                      (C)

Combining the forward bound with (C) leaves an actual counter of at least
two throughout this part of the B scan. No W underflows here.

If the whole chi part is crossed, M=m. We also have the useful consequence

    n odd  ==>  2m-n >= 9.                          (D)

Indeed, an odd final n must have been obtained by a last backward V from an
even debt 2n congruent to 2 modulo 4. If its preceding integer was M0, (C)
gives 2n<=4M0-6. Nonnegative odd n implies M0>=2, and m=2M0+1. Hence
2m-n>=2M0+5>=9.

Reverse the X^(r-1) buffer. Its debt becomes

    n1=2^(r-1)(n+4)-4.

These removals remain legal: at the end of the buffer the counter minus debt
is at least two, and reversing each reset X and B removal preserves that
lower bound. Reverse the preceding V, obtaining

    n2=2^(r-2)(n+4)-2.

For r>=3 this is even, so the immediately preceding Y stops the B scan.
For r=2 it is n+2. Even n stops at the first Y. If n is 3 modulo 4, the
second Y stops it. The ONLY remaining case is

    r=2 and n=1 modulo 4.

Crossing both Y's then leaves debt k=(n-1)/4 at d.

* If a is even, d=X. Its removal leaves debt

      n* = 2k+4 = (n+7)/2

  on T(P(c)). By (D), 2n*+2=n+9<=2m=a. Lemma 1 applies. It also verifies
  the affordability of this last d removal.

* If a is odd, d=V. Odd k stops at Z. Even k leaves debt

      n* = k/2 = (n-1)/8.

  From (C), 2n*+2=(n+7)/4<=a=2m+1. Apply Lemma 1.

Every branch is safe and ends at Z. Thus the stack (A) is Ready. QED.

## 7. Small-counter Z returns

The previous common Z proof has only the following alternatives for a=0,1.

### A clean early reset

Its exact word is

    P(c0) e Y^r V,

where c0 is a zero counter and e is X or V. Its paid output has literal
suffix Z^r X. The next B scan strips the final X and immediately sees Z.
Thus it is Ready, independently of what lies below that suffix.

### The exceptional early reset

This requires a=0 and rho(P(c0)) in {0,1}. If P(c0) is empty, the established
XY spinout applies. Otherwise the previous proof constructs a Good zero
stack t and an odd-terminal reset which reaches

    s Z^(r+1) W A>R,  where s=T(P(t)) is Good.

The following drain has exact reset word

    P(s) Y^(r+1) V X^r chi(v(s)+1) V.

The argument (B)--(C) applies with m=v(s)+1, because rho(P(s))>=v(s).
Its buffer has r+1>=3 opening Y's. Therefore the backward B scan stops at
the first buffer Y; it never reaches P(s). This output is Ready as well.

We have now proved the complete new common-Z assertion:

> For every Good c and r>=2, the common Z excursion reaches a Good,
> positive, X-ending, Ready B checkpoint, or the known XY spinout.

## 8. Closed invariant and blank seed

Use the normal checkpoint invariant

    L s <B1 YR1,
    Good(s), v(s)>0, s ends in X, and Ready(s).

Starting here, the finite B scan is safe. A successful W branch is EXACTLY
D^2 below the removed W for 1LA, so the scan is the actual machine's scan,
not a hypothetical variant. Good persists. Since the initial stack ends in
X, at least one X is removed before the first Z, giving r>=2.

If the scan reaches the bottom, the machine enters the established B
spinout. Otherwise it reaches a Z with Good underlying c and r>=2. Sections
6--7 return to the invariant or the established XY spinout.

The blank tape reaches

    L ZZZXXX <B1 YR1

in exactly 156 base transitions. This has counter 56 and prefix (v,b) pairs

    (1,1), (3,3), (7,7), (14,15), (28,31), (56,63).

It is Good and X-ending. Its B scan strips three X's and stops at Z, so it
is Ready. The base prefix is replayed independently in the verifier.

Each normal return contains at least the initial X-stripping transition,
which takes six base steps. Thus infinitely many returns cover arbitrarily
many genuine base transitions; there is no zero-cost parsing loophole.
A spinout is already nonhalting. In either case:

    NOT Halts(1RB2LA0RB1LB---_1LA3RA1RA4LB1LA, blank).

## 9. Why this excludes the earlier counterexample

The nonblank stack ZXZWWX is Good, positive and X-ending, but it is NOT
Ready. Its scan strips X, consumes W using two decrements below it, then
faces another W with inadequate supply. It was a genuine obstruction to the
previous unrestricted theorem. The present proof does not ignore it: it
adds a bounded scan predicate and proves that all common Z returns regenerate
that predicate.

Nor does the proof assume that the counter remains half full. For example,
T(YYVXYV)=ZXXWZX is an admissible normal input. Its next normal checkpoint is
XXZWWZXXWX, whose leading bit is zero. It is nevertheless Ready; the new
comparison lemma proves its safety. Larger examples of this phenomenon are
included in the verifier.

## 10. What has been checked

`verify_last.py` compares each predicted complete return with the original
block simulator, using its original left stride. It also replays the blank
seed and checks unaccelerated base/block transitions. `check_components.py`
separately checks the debt interpreter, dual-credit lemma, exact Z word and
binary backward inequalities. Counts and outcomes are recorded in JSON.
The original simulator is copied unchanged under `prior/previous/reference_tools/`.

No successful finite test is used as a premise of the proof. Lean
formalization still needs the new reverse-debt, dual-credit, exact drain-word
and Ready-preservation lemmas and their connection to the sound block model.


### Recorded finite counts

The completed return run compared 90,392 exact endpoints: 90,135 exhaustive
Normal inputs through length twelve, 250 longer randomized inputs, and
seven constructed long-tail inputs. The largest observed number of W
consumptions in one scan was eight. All a=0, a=1, a=2, and a>=3 Z branches
were exercised. The blank seed used exactly 156 base transitions, and
3,000 unaccelerated reference block transitions were checked at base level.

The separate component run checked 33,175 reverse-debt/concrete-scan
comparisons, 179,181 dual-credit instances, 16,044 common-Z cases including
11,980 exact direct return words, and 1,036,827 binary reverse steps over
m=1,...,100,000. Every assertion in the recorded runs passed.

These counts are deliberately finite. The mathematical quantifiers are
justified by the preceding inductions, not by extrapolation from these runs.
