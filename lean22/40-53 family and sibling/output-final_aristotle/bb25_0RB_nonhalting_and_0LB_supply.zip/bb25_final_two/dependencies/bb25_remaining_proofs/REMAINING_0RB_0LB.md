# The remaining two members: exact reductions and unresolved invariants

Date: 2026-09-16.

This file DOES NOT assert nonhalting from blank for 0RB or 0LB. It records
new mathematical reductions, base-checked local identities, falsified
invariants, and clearly separated finite searches. The complete new
nonhalting argument in this package is for 1LA only.

Machines:

```
0RB: 1RB2LA0RB1LB---_1LA3RA1RA4LB0RB
0LB: 1RB2LA0RB1LB---_1LA3RA1RA4LB0LB
```

Notation is the same as PROOF_1LA.md. Stacks are bottom first; <B1 includes
the extra right-hand one. R is the bare right end, not R1.

## 1. An exact right-marker return for 0RB

Let w be any colored Dyck prefix: Y opens a pair; X and V close it. Let h
be its final height. Begin with an untouched marker immediately below an
empty ordinary counter and the head A> before wR.

### Theorem

The first return of the head to the marker, in state <A, has right word

    F(w) R = w X^h V R.                             (1)

The marker itself has not yet been consumed. The intervening run is finite
and never accesses anything below the marker.

### Proof

Decompose w into complete matched groups separated by its unmatched Y's.
Consuming a complete matched group never changes the counter below it:
its opening Y pushes a one bit; its interior recursively preserves that
bit; a V close pops the one, while an X close first turns that one into zero
and then pops it. Neither case borrows below the opening one.

Thus each unmatched Y leaves a one bit. At the end of w there are h unmatched
one bits, with value 2^h-1; every matched bit has exactly the color prescribed
by w. Equivalently the decoder of the complete rebuilt local stack is w.

At bare R, the successive positive drain rounds are D(s)W. On an all-ones
unmatched numeral each round changes its last one to zero and matches it
with the new W. Its decoder therefore gains X. Exactly h such rounds reach
zero. The final zero-counter excursion deposits the entire decoder and the
right-end V. This gives w X^h V. Every internal count decreases, so the
excursion is finite. QED.

The executable function `right_marker_return` uses (1). It is compared
against the original independent block simulator in `check_components.py`.

### Consequence: the whole even-aligned 0RB W branch

For any such w and v(c)>=2,

    c W <B1 wR  -->*  D^2(c) <B1 Y w X^h V R.        (2)

Indeed F/G uses two decrements and creates J0. Apply (1), then the existing
J0 <A -> <B1 Y rule. The new right word is balanced:

    height(Y w X^h V) = 0.

A B-on-X step simply removes X and replaces w by Yw, raising the right height
by one. Hence (2) does not conceal a numerical orbit conjecture: it is an
explicit finite word transformation.

### Connection to the original odd-terminal checkpoint

At a Good, positive, X-ending Ready checkpoint s <B1 YR1, strip k>=1 terminal
X's. Write r=k+1>=2. If the next block is W, the two decrements are available.
The first J0 return uses the earlier exact local clock, with word

    w_r = XYYV                         when r=2,
          YVYYV                        when r=3,
          Y^n VYYVX V^(n-1)            when r>=4, n=r-2.

After consuming J0 the B right word is Y w_r R, a colored Dyck prefix over
an EVEN terminal R. Subsequent W branches are exactly (2); X steps prepend
Y. The left scan is precisely the bounded two-decrement Ready scan from the
1LA proof. It therefore reaches an unmarked Z or the bottom safely.

`scan_0RB` computes this entire phase without an inner marker simulator.
Its complete configurations, not only their values, were compared against
9,830 original reference scans through input length ten. The scan reduction
is proved; the subsequent Z/reset preservation needed for nonhalting is not.

## 2. What still blocks a complete 0RB proof

One still has to show that the correlated pair (left stack, right word)
produced by the finite scan has a safe Z excursion and regenerates a closed
checkpoint class. Merely assuming that the right word is a clean Dyck word
is too weak. Its construction and its relation to the left debt matter.

For example, let

    u = YYXYYXXV,      height(u)=0,      rho_u(1)=2.

Then the marker transform is

    G(u)=Y F(u)=YYYXYYXXVV,

which is clean from zero with value four. Nevertheless

    T(G(u)) = XZZWXZWWXX

has an unsafe two-decrement B scan. Thus the implication

    "u is clean from one, ends in V, so T(G(u)) is Ready from zero"

is FALSE. This is not claimed to be a reachable right word in the blank
0RB run. It rules out throwing away the correlation with the left stack.

The 1LA checkpoint predicate by itself is also insufficient for 0RB. The
nonblank configuration

    L ZWZZXWX <B1 YR1

is Good, positive, X-ending and Ready for the two-decrement scan, but the
0RB base machine executes 1,560 defined transitions and then meets A4.
Its initial ZW already closes the bottommost bit. It is not an image of a
clean paid reset.

### Candidate restriction (NOT PROVED closed)

Call a stack strictly admissible if every nonempty bottom-prefix has positive
height: it never pops the bottommost unmatched bit. Every nonempty clean paid
reset is strictly admissible. To see this, a first pop down to height zero
would have to act at height one, whose counter is at most one; the reset X
requires at least two, a contradiction.

A candidate normal class is

    Good(s), v(s)>0, EndsInX(s), Ready(s), StrictAdmissible(s).

The blank seed belongs to it. The missing theorem is that the complete 0RB
excursion regenerates this class or reaches a known spinout. Equation (2)
settles the finite pre-Z scan, but not the final reset theorem.

`probe_remaining.py` tested every stack in this class through length twelve:
71,841 reached another class member and 332 reached a known spinout. None
exceeded the 30,000-reference-step search bound. This is evidence for the
candidate, NOT a proof of the missing theorem.

A separate search started with clean Dyck reset words ending in V through
length twelve whose paid outputs are Ready: 9,056 returned safely and one
spun out. However 987 returned outputs have inverse reset words that are NOT
Dyck prefixes. Therefore the narrower phrase "image of a clean Dyck reset"
must not be assumed invariant at every chosen B checkpoint. The larger
strict-admissibility candidate deliberately avoids that false shortcut.

The raw records retain output-image failure counts rather than hiding them.

## 3. The missing 0LB pending-N rules

Introduce the left block

    H=13.

The previously uncovered pending-P2/N1 and pending-P2/N2 cases have short,
exact reductions:

    A> P2 N1  -->  W H A>          4 base transitions,
    A> P2 N2  -->  Z H A>          4 base transitions,
    A> P1 Ni  -->  <A P2 Ni        1 base transition, i=1,2,
    H <A      -->  <B1 P2          4 base transitions.       (3)

These rules actually use only shared transitions and are uniform over all
thirteen members. They hold with arbitrary unchanged left/right contexts.

For the first two, the raw inputs are 2101 and 2201. The four writes are
respectively 0313 and 0113, followed by A facing right. These are WH and ZH.
For H <A, the four transitions are A3, B1, A1, A3, producing the displayed
B-boundary and pending digit without accessing the exterior context.

Combining H with the ordinary B rules gives

    W H <A  -->  <A F P2           6 base transitions,
    Z H <A  -->  <A X Y            8 base transitions.       (4)

The second uses the literal identity P2 P2 = Y; that re-parsing costs zero.
The first still creates F and therefore needs a left-supply argument.

`remaining_tools.py` extends the reference block interface with (3), without
modifying the original simulator. The component checker independently
replays all rules against the base transition tables for all thirteen
members and varied contexts: 1,625 instances of (3), and 650 instances of
(4), all exact.

### What these rules do NOT prove

For a B-on-W event with underlying counter A, 0LB consumes F/G using two
A decrements, then creates N1. If A>=4 the next two decrements consume N1/N2
and return B; the net operation is D^4 below the removed W.

If A=2 or 3, the early overflow occurs beside N1 or N2. Equations (3)--(4)
now describe the previously missing configurations, but a regenerated
safety invariant still has to be proved. In particular WH can recreate an
F whose supply is not automatically adequate.

An uncovered rule is not a halting certificate. Conversely, adding a correct
local rule does not establish global nonhalting.

## 4. Explicit obstructions to natural 0LB invariants

The nonblank checkpoint

    L ZXZX <B1 YR1

is Good, strictly admissible, X-ending, positive and Ready for the 1LA scan.
It is also a clean Dyck-reset image: ZXZX=T(YVYV). Nevertheless 0LB reaches
A4 after 225 defined base transitions.

Even imposing two leading one bits does not repair the general claim:

    L ZZXXWZX <B1 YR1,
    ZZXXWZX = T(YYYVXYV),

has those stronger properties and reaches A4 after 571 defined transitions.
The word YYYVXYV is a clean colored Dyck prefix. These are genuine direct
base-machine replays, not inferences from the incomplete old block table.

A still stronger top-three-one-bit trial also fails:

    T(YYYYYVXXYVXV)=ZZZXXXWWXXWX

reaches A4 after 40,225 defined base transitions. This was replayed directly
and is included in the component checker. No blank-tape halting claim is
made for any of these constructed inputs.

## 5. Saved boundary of the current result

* 1LA: a complete proposed mathematical nonhalting proof in PROOF_1LA.md,
  pending formal certification of the new lemmas and earlier dependencies.
* 0RB: exact finite marker and B-scan reductions; an experimentally supported
  strict-admissibility/Ready candidate, with the reset-preservation theorem
  still unproved.
* 0LB: the missing local interface is supplied; counterexamples show that a
  materially stronger reachability invariant is needed.

No finite simulation length is used as an infinite safety premise.
