# Formalization map for the 1LA return proof

Date: 2026-09-16.

## Status

This is an implementation plan, not a Lean certificate. No Lean toolchain was
available in this working environment, and none of the new lemmas below has
been compiled here. `PROOF_1LA.md` supplies the mathematical proofs. The
previous proof packages are included unchanged in `prior/`; their proposed
mathematical lemmas are dependencies, not newly certified facts.

The target machine is

```
1RB2LA0RB1LB---_1LA3RA1RA4LB1LA
```

The target conclusion is nonhalting from the blank tape. Neither the candidate
0RB invariant nor any unproved 0LB assertion is a dependency.

## 1. Connect to the existing project without changing conventions silently

The copied project is `prior/source_project/RequestProject/BB25/`.
Its block lists are nearest-to-head first. The mathematics and executable
checker use bottom-first lists with the bottom L omitted. Keep an explicit
conversion

```
encodeLeft s = s.reverse ++ [.L]
```

and prove its append/cons identities once. In particular, a bottom-prefix in
the mathematical invariant becomes a suffix adjacent to L in the original
block list. Do not replace the prefix condition by an inequality only at the
full stack.

Existing declarations worth reusing (names inspected in the supplied source):

* `Counter.lean`: `cval`, `CStack`, `cval_decrement`, `brun_F_consumed`,
  `brun_reset_step`, `brun_reset`, `brun_reset_end`, `brun_count_step`.
* `Overflow.lean`: `cdec`, `cdec_CStack`, `cdec_cval`, `brun_cdec_of`,
  `ofw`, `brun_overflow_of`, `cstackStep`, `cstackRun`, `brun_cstackRun`.
* `Pairing.lean`: the transparent-pair construction and its append/wrap lemmas.
* `Family.lean`: the member-specific G rule for 1LA.
* `Nonhalt.lean`: the B-at-bottom spinout and the existing left spinout.
* `Blocks.lean`: block-step soundness; `Reduction.lean`: the base-machine
  connection and the already addressed zero-cost re-parsing issue.

`cdec` and `ofw` do not by themselves state the new full-stack decoder
identities. Prove the bridges to the paired decoder and unmatched-bit
subtraction; do not substitute a counter-value equality for stack equality.

## 2. Common interface needed from the previous packages

Formalize or reuse the following results from the earlier prefix-safety work:

1. Admissibility and the paired decoder P.
2. The full-stack decrement D, with value decreased by one and matched bits
   unchanged; P(D(s))=P(s), including each decoded prefix.
3. The integer adjusted-reset map rho and the paid reset T.
4. `Good(s)`: every bottom-prefix p satisfies rho(P(p)) >= v(p).
5. Good preservation under D and bit append.
6. Good(D^d(s)W) when Good(s) and v(s)>=d>=2.
7. Every clean reset has paid output T(w), Good with value rho(w).
8. The complete common B-on-Z return, including the a=0,1 early resets and
   the established XY spinout; use the actual endpoint, not only its value.

Use integer arithmetic for rho. Its X map is floor(a/2)-1. Nat subtraction
would silently erase precisely the underflow behavior that must be excluded.
The physical reset and the paid reset differ in pending-1 phase: retain an
explicit pending-phase bridge until the debt has actually been paid.

## 3. Define the bounded scan, not a future nonhalting predicate

Define an executable finite scan on ordinary left stacks:

```
scan []        = bottomSpinout
scan (s ++ Z)  = stoppedAtZ(s)
scan (s ++ X)  = scan s
scan (s ++ W)  = if 2 <= v(s) then scan (D(D(s))) else unsafe
```

A result also records the number of consumed blocks / prepended right Y's.
The recursive argument has strictly smaller list length: D preserves length.
Fuel equal to the input length is an alternative implementation.

`Ready(s)` means that `scan s` is not `unsafe`. It is a finite predicate;
no call to the complete TM run belongs in its definition. First prove:

* termination and length accounting;
* Good is preserved by a successful scan;
* for member 1LA, each successful W clause is realized by the actual F/G
  passage and costs a positive number of base steps;
* the right word changes only by a prefix of Y's;
* X-ending input supplies r>=2 at the first Z.

The result must permit bottom spinout. It need not falsely demand that every
safe scan end at a Z.

## 4. Reverse-debt bridge

Prove a theorem relating a scan of D^n(T(w)) to these reverse rules:

```
X: n -> 2*n+4
Y: even n stops at Z; odd n -> (n-1)/2
V: odd n stops at Z; even n -> n/2
```

The X formula uses the full-stack identity

```
T(uX) = D(T(u)W) = D^2(T(u))W.
```

The final matched bit is frozen. An additional n decrements above W are
2*n decrements below W. A B removal adds the next two decrements. Supply
must be checked at the resulting prefix debt before using this formula.

A useful formal specification returns either `stoppedAtZ`, `bottom`, or a
particular unaffordable debt and prefix. The Python function
`reset_debt_scan` is an executable reference, not its proof.

## 5. Dual-credit lemma: the central new induction

Suggested statement, in mathematical pseudocode:

```
Good c -> 2*n+2 <= v(c) ->
  scan (D^n(T(P(c)))) stops safely at a Z.
```

Induct on the length of c, peeling a maximal final run of j decoder X's.
The exact quantities are

```
n_j = 2^j*(n+4)-4
b_j >= 2^j*(b+2)-2
b_j-n_j >= 2^j*(b-n-2)+2 >= 2.
```

All shorter portions of the run obey the same bound, so the induction is
about legal runs, not only their hypothetical final values.

If j>0 and the preceding letter is Y, n_j is even and the scan stops.
For a preceding V and even debt, the source prefix has

```
a' = 2^(j+1)*a+1
n' = n_j/2
a'-(2*n'+2) = 2^j*(2*a-n-4)+3 >= 0.
```

Apply the shorter-prefix induction. An odd debt at V already stops at Z.
For j=0 and Y with odd n, use floor(a/2)>=n+1. Every recursive call uses the
prefix instance of Good; the final-stack inequality alone is insufficient.

## 6. Exact common-Z word

Define `chi(m)` recursively for m>=1:

```
chi(1) = []
chi(m) = (if Even m then X else V) :: chi(m/2)   when m>=2
```

It lists the lower bits least significant first. This ordering is important.
For a=v(c)>=2, m=a/2, and r>=2, prove exact return stack equality

```
T(P(c) ++ [d] ++ Y^r ++ [V] ++ X^(r-1) ++ chi(m) ++ [V])
```

where d is X for even a and V for odd a. The intermediate local suffix after
r-1 drain rounds is exactly `X^(r-1) Z W^r`, with decoder `Y^r V X^(r-1)`.
Afterward the counter-plus-one halves, producing chi(m). At m=1 this latter
part is empty; avoid introducing a spurious last bit or division step.

## 7. Ready regeneration

The forward reset bound through chi is `resetCounter >= 4*M-2`.
The reverse scan reconstructs M from one and preserves `n+4 <= 4*M`:

```
X: (M,n) -> (2*M,2*n+4)
V: stop if n odd; otherwise (M,n) -> (2*M+1,n/2).
```

Prove the odd-debt consequence `Odd n -> 2*m-n >= 9` at the beginning of
chi, when the scan traverses the entire chi suffix.

After reversing the X buffer and V, the debt is

```
2^(r-2)*(n+4)-2.
```

For r>=3 the next Y stops the scan. For r=2, only n=1 modulo 4 can cross both
Y's. At d, split the original a parity:

* even a: new debt (n+7)/2; the odd-debt bound gives 2*newDebt+2<=a;
* odd a: stop at V if appropriate, otherwise new debt (n-1)/8, again with
  2*newDebt+2<=a.

Invoke the dual-credit lemma. This proves Ready for every direct return.

For a=0,1 use the previous complete common-Z case split. Clean early resets
have literal suffix Z^r X. The exceptional nonempty case has the same clock
with r+1>=3 opening Y's, so its next B scan stops inside the buffer. The
empty case is the existing XY spinout.

## 8. Final theorem and liveness accounting

Define

```
Normal(s) := Good(s) and 0<v(s) and EndsInX(s) and Ready(s).
```

Prove the actual return theorem: every Normal B checkpoint with right YR1
has a finite positive-cost return to Normal, or reaches a proved spinout.
The first X removal alone costs six base steps. This supplies a uniform
positive lower bound and excludes an infinite loop of zero-cost re-parsings.

Replay the blank seed, exactly 156 defined base transitions to ZZZXXX at B
with right YR1. Its prefix values are in PROOF_1LA.md. Iterate the return
relation, or contradict the finite length of a purported halting run.

No claim about eventual numerical growth, permanent leading-one bits, or
the behavior of 0RB/0LB is required.

## 9. Separate optional work, not dependencies

`REMAINING_0RB_0LB.md` contains exact marker and H-block reductions. These can
be formalized separately. The proposed 0RB strict-admissibility invariant
there is explicitly NOT proved. The 0LB counterexamples refute several
natural extensions; do not ask the formalizer to prove those false claims.
