#!/usr/bin/env python3
"""Finite candidate-invariant experiments for 0RB; NOT a nonhalting proof.

A reference step limit is an experiment bound, not an assumed return theorem.
The mathematical 1LA proof does not depend on anything in this file.
"""
from last_core import *
from remaining_tools import *
from itertools import product
from collections import Counter
import argparse,json,time

def reference_0RB(s:Stack,limit:int=30000):
    lt=list(reversed(s))+['L'];st='B';rt=['Y','R1'];cost=0
    for i in range(limit):
        if st=='B' and lt==['L']:return 'spinout',(),i,cost
        if st=='L' and lt==['L'] and ref.denote(lt,st,rt)[3][:4]==[1,1,2,2]:
            return 'spinout',(),i,cost
        if i and st=='B' and rt==['Y','R1'] and all(ch in 'XZW' for ch in lt[:-1]):
            t=tuple(reversed(lt[:-1]))
            if normal(t):return 'B',t,i,cost
        stride=ref.stride(lt) if st=='L' else None
        if stride:lt,k=stride;st='R'
        else:
            try:lt,st,rt,k=ref.bstep('0RB',lt,st,rt)
            except ref.Stuck as e:return 'uncovered_or_fatal',(lt,st,rt,str(e)),i,cost
        cost+=k
    return 'step_limit',(lt,st,rt),limit,cost

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--max-length',type=int,default=12)
    args=ap.parse_args()
    if not 2<=args.max_length<=13:ap.error('max-length must be 2..13')
    start=time.time();ct=Counter();maxsteps=0;bad=[]
    def check(s,category):
        nonlocal maxsteps
        ans,t,steps,cost=reference_0RB(s);ct[category+'_'+ans]+=1
        maxsteps=max(maxsteps,steps)
        if ans=='B':
            if not strict_admissible(t):bad.append((category,'lost_strict',s,t))
            w=inverse_reset(t)
            if w is None:ct[category+'_output_not_reset_image']+=1
            else:
                try:dyck_height(w)
                except ValueError:ct[category+'_output_reset_not_Dyck']+=1
        elif ans!='spinout':bad.append((category,ans,s,t))
    for length in range(2,args.max_length+1):
        for p in product('XZW',repeat=length-1):
            s=p+('X',)
            if strict_admissible(s) and normal(s):check(s,'strict_ready')
        print('left length',length,dict(ct),flush=True)
    for length in range(2,args.max_length+1):
        for w in dyck_words(length):
            if w[-1]!='V' or adjusted(w)<=0:continue
            s=reset((),w)
            if normal(s):check(s,'Dyck_reset_ready')
        print('reset length',length,dict(ct),flush=True)
    out={'status':'no counterexamples found' if not bad else 'counterexamples found',
         'scope':'finite candidate-invariant search; no universal return theorem is claimed',
         'member':'0RB','max_input_length':args.max_length,'reference_step_limit_per_case':30000,
         'max_reference_steps_observed':maxsteps,'counts':dict(ct),'counterexamples':bad[:20],
         'elapsed_seconds':round(time.time()-start,3)}
    (HERE/'remaining_probe_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':main()
