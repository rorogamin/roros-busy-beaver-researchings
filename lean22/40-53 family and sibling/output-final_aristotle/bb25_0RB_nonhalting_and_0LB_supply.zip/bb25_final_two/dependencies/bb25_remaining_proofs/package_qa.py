#!/usr/bin/env python3
"""Packaging QA; finite smoke tests only, never a Lean certification claim."""
from pathlib import Path
import hashlib,json,py_compile,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    checks={}
    for name in ('last_core.py','verify_last.py','remaining_tools.py','check_components.py',
                 'probe_remaining.py','check_0RB_scan.py','package_qa.py'):
        py_compile.compile(str(HERE/name),doraise=True)
    checks['new_python_syntax']='passed'
    results={}
    for name in ('verification_last.json','component_results_last.json','scan_0RB_results.json',
                 'remaining_probe_results.json'):
        data=json.loads((HERE/name).read_text());results[name]=data['status']
        assert data['status'] in ('all assertions passed','all exact scan endpoints agree','no counterexamples found')
    checks['recorded_result_statuses']=results
    checks['lean_executable_found']=shutil.which('lean') is not None
    checks['new_lean_compilation_performed']=False
    # A fresh directory checks that the new code does not depend on exploratory
    # absolute paths. Avoid bytecode and this QA file's result in the copy.
    with tempfile.TemporaryDirectory(prefix='bb25_last_clean_') as td:
        dest=Path(td)/'package';shutil.copytree(HERE,dest,ignore=shutil.ignore_patterns('__pycache__'))
        cmd=[sys.executable,'verify_last.py','--max-length','4','--random','0','--output',str(Path(td)/'smoke.json')]
        ans=subprocess.run(cmd,cwd=dest,text=True,capture_output=True,timeout=45)
        assert ans.returncode==0,ans.stdout+'\n'+ans.stderr
        d=json.loads((Path(td)/'smoke.json').read_text())
        checks['clean_copy_smoke']={'status':d['status'],'exact_returns':d['counts']['exact_returns']}
        ans=subprocess.run([sys.executable,'check_0RB_scan.py'],cwd=dest,text=True,capture_output=True,timeout=45)
        assert ans.returncode==0,ans.stdout+'\n'+ans.stderr
        checks['clean_copy_0RB_scan']='passed'
    original=Path('/mnt/data/bb25_last_work/output-final_aristotle/tools')
    provenance={}
    for name in ('blocksim.py','sim.py'):
        included=HERE/'prior'/'previous'/'reference_tools'/name
        item={'included_sha256':sha(included)}
        if (original/name).exists():
            item['original_sha256']=sha(original/name)
            item['identical_to_original']=sha(included)==sha(original/name)
            assert item['identical_to_original']
        provenance[name]=item
    checks['reference_provenance']=provenance
    checks['scope']='artifact QA and finite smoke tests; not a formal proof certificate'
    (HERE/'PACKAGE_QA.json').write_text(json.dumps(checks,indent=2)+'\n')
    sums={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*'))
          if p.is_file() and '__pycache__' not in p.parts and p!=HERE/'SHA256SUMS.json'}
    (HERE/'SHA256SUMS.json').write_text(json.dumps(sums,indent=2)+'\n')
    print(json.dumps(checks,indent=2))
if __name__=='__main__':main()
