#!/usr/bin/env python3
"""Finite verification of the proved 0RB scan reduction; not nonhalting."""
from remaining_tools import *
from itertools import product
from collections import Counter
import json,time
start=time.time();ct=Counter()
for length in range(2,11):
    for p in product('XZW',repeat=length-1):
        s=p+('X',)
        if not normal(s):continue
        kind,t,rt,q=scan_0RB(s);rk,c,i,k=scan_0RB_reference(s)
        assert kind==rk
        if kind=='Z':assert c==ref.denote(list(reversed(t))+['L'],'B',rt)
        ct[kind]+=1;ct['W_events_'+str(q)]+=1
    print(length,dict(ct),flush=True)
ans={'status':'all exact scan endpoints agree',
     'scope':'finite checks of the proved finite scan macro, not a complete 0RB nonhalting proof',
     'max_length':10,'counts':dict(ct),'elapsed_seconds':round(time.time()-start,3)}
(HERE/'scan_0RB_results.json').write_text(json.dumps(ans,indent=2)+'\n')
print(json.dumps(ans,indent=2))
