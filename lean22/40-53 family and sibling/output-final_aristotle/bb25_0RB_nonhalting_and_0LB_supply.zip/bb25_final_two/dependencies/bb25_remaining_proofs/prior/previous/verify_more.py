#!/usr/bin/env python3
"""Constructive nonhalting-return checks for 1RA, 0LA and 2LB.

Universal arguments are in PROOF_MORE.md. This is finite validation only.
All stacks are bottom-first; X/Z are bits, W is a matched pop.
"""
from __future__ import annotations
import argparse
from collections import Counter
from dataclasses import dataclass
from itertools import product
import json
from pathlib import Path
import random
import sys
from typing import Iterable

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'previous'))
import verify_prefix_safety as old
sys.path.insert(0, str(HERE / 'reference_tools'))
import blocksim as ref

Stack=tuple[str,...]
value=old.value
decode=old.decode
adjusted=old.adjusted
reset_paid=old.reset_paid
dec=old.dec
good=old.good


def clean(s: Stack) -> bool:
    try: return adjusted(decode(s)) >= 0
    except ValueError: return False


def drain3(s: Stack) -> Stack:
    """A> R: only clean decoder + b+2 >= 3(v+1), not prefix Good."""
    assert clean(s)
    assert adjusted(decode(s))+2 >= 3*(value(s)+1), ('drain entry',s)
    while value(s):
        v=value(s)
        s=dec(s)+('W',)
        assert value(s)==(v-1)//2
        assert clean(s) and adjusted(decode(s))+2 >= 3*(value(s)+1)
    w=decode(s)+'V'
    assert adjusted(w)>=2
    s=reset_paid(w)
    assert good(s) and value(s)>0
    return s


def pending2(s:Stack,r:int) -> Stack:
    assert r>=1
    s=s+('Z',)*r+('W',)
    return drain3(s)


def common_Z(core:Stack,r:int) -> tuple[str,Stack]:
    """Previously proved Z branch, including its exceptional early reset."""
    assert good(core)
    a=value(core)
    if a>=2:
        s=dec(dec(core))+('W',)
        assert good(s)
        return 'B',pending2(s,r)
    for _ in range(a):core=dec(core)
    d='X' if a==0 else 'V'
    u=decode(core)
    w=u+d+'Y'*r+'V'
    if adjusted(w)>=1:
        return 'B',reset_paid(w)
    assert d=='X' and adjusted(u) in (0,1)
    if not u:return 'spinout',()
    t=reset_paid(u)+('W',)
    assert good(t) and value(t)==0
    t=reset_paid(decode(t)+'Y'*(r+1))+('W',)
    return 'B',drain3(t)


def expansion_count(word:str) -> int:
    a=0;q=0
    for c in word:
        if c=='V' or (c=='X' and a%2):q+=1
        a=old.adjusted_step(a,c)
    return q


def q_constraints(u:str) -> tuple[Stack,int,int,int]:
    t=reset_paid(u)
    a=adjusted(u);b=adjusted(decode(t));h=u.count('Y')-u.count('V')-u.count('X')
    q=expansion_count(u)
    assert h>=2 and b>=a
    assert 3*(b+1)>=2**h*(2*4**q+1)
    if a%4==0:
        assert q>=2 and b>=43
    return t,a,b,q


def temporary_zero_late(t:Stack,r:int) -> Stack:
    """Repair S=t X W Z^(r-1) X for 0LA or the 1LB a=3 subcase."""
    b=value(t);B=adjusted(decode(t))
    assert good(t) and b>=4 and B>=b
    s=t+('X','W')+('Z',)*(r-1)+('X',)
    assert value(s)>0 and clean(s)
    if good(s):return s
    assert B==b
    if r==1:
        # B removes X W. 0LA now has underlying good stack t X >= 8.
        core=t+('X',)
        for _ in range(3):core=dec(core)
        core+=('W',)
        assert good(core) and value(core)>0
        core=dec(core)
        return pending2(core,2)
    # B removes X Z; two decrements, pop, and a pending-2 tail of length 2.
    core=t+('X','W')+('Z',)*(r-2)
    assert value(core)>=2
    core=dec(dec(core))+('W',)
    assert clean(core)
    assert 4*(adjusted(decode(core))+1)>=3*(value(core)+1)
    return pending2(core,2)


def temporary_double_pop(t:Stack,r:int) -> Stack:
    """Repair S=t W W Z^(r-1) X for 2LB."""
    b=value(t);B=adjusted(decode(t))
    assert good(t) and b>=4 and B>=b
    if b%4==0:assert B>=43
    z=t+('W','W')
    s=z+('Z',)*(r-1)+('X',)
    assert clean(s) and value(s)>0
    if good(s):return s
    A=value(z);H=adjusted(decode(z))
    if b%4==2:
        assert A>=1 and H>=4*A
    else:
        assert b%4==0 and b>=40 and A>=10 and H>=A-2
    if r==1:
        core=t+('W',)
        a=value(core)
        assert a>=3
        core=dec(dec(core))
        assert good(core)
        if a>=4:
            core=dec(dec(core))+('Z',)
            assert good(core)
            core=dec(core) # Pay pending-1 at the following Y.
            return pending2(core,2)
        assert b==6 and a==3
        core=dec(core)
        assert value(core)==0 and good(core)
        t2=reset_paid(decode(core))
        out=t2+('Z','W','Z','X')
        assert good(out) and value(out)>0
        return out
    core=z+('Z',)*(r-2)
    a=value(core)
    if a==1:
        core=dec(core)
        out=reset_paid(decode(core)+'V'+'YY'+'V')
        assert good(out) and value(out)>0
        return out
    assert a>=2
    core=dec(dec(core))+('W',)
    assert clean(core)
    assert 4*(adjusted(decode(core))+1)>=3*(value(core)+1)
    return pending2(core,2)


@dataclass(frozen=True)
class Return:
    kind:str
    stack:Stack=()
    branch:str=''
    boundaries:int=1


def successor(member:str,s:Stack)->Return:
    assert member in ('1RA','0LA','2LB')
    assert good(s) and value(s)>0
    k=0
    while s[-1]=='X':s=s[:-1];k+=1
    top,core=s[-1],s[:-1]
    r=k+1
    if top=='Z':
        kind,out=common_Z(core,r)
        return Return(kind,out,'Z-common')
    assert top=='W'
    a=value(core)
    assert a>=2 and good(core)
    t=dec(dec(core))
    assert good(t)
    if member=='1RA':
        t+=('X',)
        return Return('B',pending2(t,r),'W-push-zero')
    if member=='0LA':
        if a>=3:
            t=dec(t)+('W',)
            assert good(t)
            if value(t):
                t=dec(t)
                return Return('B',pending2(t,r),'W-direct')
            out=reset_paid(decode(t)+'Y'*r+'V')
            return Return('B',out,'W-pending-1-overflow')
        assert a==2
        u=decode(t)
        paid,b,B,q=q_constraints(u)
        assert b>=4
        first=paid+('X','W')+('Z',)*(r-1)+('X',)
        out=temporary_zero_late(paid,r)
        return Return('B',out,'W-early-V-repair',1 if good(first) else 2)
    assert member=='2LB'
    if a>=4:
        t=dec(dec(t))+('Z',)
        assert good(t)
        t=dec(t)
        return Return('B',pending2(t,r),'W-direct')
    if a==3:
        t=dec(t)
        paid=reset_paid(decode(t))
        out=paid+('Z','W')+('Z',)*(r-1)+('X',)
        assert good(out) and value(out)>0
        return Return('B',out,'W-early-Y')
    assert a==2
    paid,b,B,q=q_constraints(decode(t))
    assert b>=4
    first=paid+('W','W')+('Z',)*(r-1)+('X',)
    out=temporary_double_pop(paid,r)
    return Return('B',out,'W-early-U-repair',1 if good(first) else 2)


def reference_return(member:str,s:Stack,limit:int=20000)->Return:
    lt,st,rt=list(reversed(s))+['L'],'B',['Y','R1']
    boundaries=0
    for i in range(limit):
        if st=='L' and lt==['L']:
            raw=ref.denote(lt,st,rt)[3]
            if raw[:4]==[1,1,2,2]:return Return('spinout',(),boundaries=boundaries+1)
        if i and st=='B' and rt==['Y','R1']:
            boundaries+=1
            out=tuple(reversed(lt[:-1]))
            if good(out) and value(out)>0:
                return Return('B',out,boundaries=boundaries)
            assert boundaries<3,('too many boundaries',member,s,out)
        stride=ref.stride(lt) if st=='L' else None
        if stride is not None:lt,_=stride;st='R'
        else:lt,st,rt,_=ref.bstep(member,lt,st,rt)
    raise AssertionError(('reference limit',member,s))


def main()->None:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--max-length',type=int,default=10)
    ap.add_argument('--random',type=int,default=200)
    ap.add_argument('--output',type=Path,default=HERE/'verification_results_more.json')
    args=ap.parse_args()
    counts=Counter();branches=Counter()
    def check(s:Stack)->None:
        for member in ('1RA','0LA','2LB'):
            ans=successor(member,s)
            actual=reference_return(member,s)
            assert (ans.kind,ans.stack,ans.boundaries)==(actual.kind,actual.stack,actual.boundaries),(member,s,ans,actual)
            if ans.kind=='B':assert good(ans.stack) and value(ans.stack)>0
            counts[member+'_exact_returns']+=1
            branches[member+':'+ans.branch+':'+str(ans.boundaries)]+=1
    for n in range(1,args.max_length+1):
        for s in product('XZW',repeat=n):
            if not good(s) or value(s)==0:continue
            counts['exhaustive_initial_stacks']+=1
            check(s)
        print('length',n,dict(counts),flush=True)
    rng=random.Random(20260916)
    for i in range(args.random):
        s:Stack=()
        for _ in range(rng.randrange(20,160)):
            if value(s)>=2 and rng.random()<.4:s=dec(dec(s))+('W',)
            else:s+=('Z' if rng.random()<.55 else 'X',)
        if value(s)==0:s+=('Z',)
        assert good(s)
        check(s);counts['random_initial_stacks']+=1
    # The shared 156-base-step seed, independently against the base simulator.
    import sim as base
    seed=tuple('ZZZXXX')
    for member in ('1RA','0LA','2LB'):
        machine=base.machine(ref.machineB4(member))
        c=([],base.A,'R',[])
        for _ in range(156):
            c=base.step(machine,c)
            assert c is not None
        target=ref.denote(list(reversed(seed))+['L'],'B',['Y','R1'])
        assert c==target,(member,c,target)
        counts[member+'_seed_checks']+=1
    result={'status':'all assertions passed','counts':dict(counts),'branches':dict(branches),
            'scope':'finite validation; the universal proof is separate',
            'random_seed':20260916,'max_length':args.max_length}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
