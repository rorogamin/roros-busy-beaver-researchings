/-
# Sweeps: where `F = 141` comes from, and when it kills the machine

This file analyses, inside the (sound) block system of `Blocks.lean`, the three
sweeps that make up the dynamics of the family:

* the `<B1` sweep, which is the *only* source of the dangerous block
  `F = 141`.  A `<B1` head walks left through a run of `11` blocks and its fate
  is decided by the first block that is not an `11`:  a `03` creates the `F`,
  a `01` defuses the `<B1` into a harmless `<A 11 2>`, and the left end `^11`
  sends the machine into the spinout (so it never halts).
* the `<A` sweep, which walks left through a run of `03`/`11` blocks and stops
  at the first `01` (turning it into an `11`) or, if there is none, at the left
  end `^11` -- where a pending digit `2>` is created.
* the rightward sweep of a pending digit `2>`, which crosses `22` and `12`
  blocks unharmed.

Putting the last two together gives a halting criterion strictly stronger than
`BB25.halt_leftend_F`: it is enough that the `141`/`241` block be separated
from the left end by `22`/`12` blocks only.

The same lemmas give the "counter step" of the notes: a round trip of the head
turns the lowest `01` into an `11` and the `11`s above it into `01`s
(`BB25.brun_round_trip`).
-/
import RequestProject.BB25.Reduction
import RequestProject.BB25.Halting
import RequestProject.BB25.Nonhalt

namespace BB25

variable {b4 : Option (Sym × Dir × St)}

/-! ## Multi-step block runs -/

/-- `BRun b4 c c' k`: the block simulation gets from `c` to `c'` in some number
of block steps, costing exactly `k` base steps of the Turing machine. -/
def BRun (b4 : Option (Sym × Dir × St)) (c c' : BCfg) (k : ℕ) : Prop :=
  ∃ n, bsteps b4 n c = some (c', k)

theorem BRun.refl (c : BCfg) : BRun b4 c c 0 := ⟨0, rfl⟩

theorem BRun.of_step {c c' : BCfg} {k : ℕ} (h : bstep b4 c = some (c', k)) :
    BRun b4 c c' k :=
  ⟨1, by rw [bsteps, h]; simp [bsteps]⟩

theorem BRun.trans {c c₁ c₂ : BCfg} {k₁ k₂ : ℕ}
    (h₁ : BRun b4 c c₁ k₁) (h₂ : BRun b4 c₁ c₂ k₂) : BRun b4 c c₂ (k₁ + k₂) := by
  obtain ⟨n, h₁⟩ := h₁
  obtain ⟨m, h₂⟩ := h₂
  exact ⟨n + m, bsteps_comp h₁ h₂⟩

theorem BRun.head {c c₁ c₂ : BCfg} {k₁ k₂ : ℕ} (h : bstep b4 c = some (c₁, k₁))
    (h₂ : BRun b4 c₁ c₂ k₂) : BRun b4 c c₂ (k₁ + k₂) :=
  (BRun.of_step h).trans h₂

/-- A block run is a run of the Turing machine. -/
theorem BRun.sound {c c' : BCfg} {k : ℕ} (h : BRun b4 c c' k) :
    steps (M b4) k c.den = some c'.den := by
  obtain ⟨n, h⟩ := h
  exact bsteps_sound b4 n c c' k h

/-- If the machine halts from the end of a block run, it halts from its
beginning. -/
theorem BRun.halts {c c' : BCfg} {k : ℕ} (h : BRun b4 c c' k)
    (hc : Halts (M b4) c'.den) : Halts (M b4) c.den := by
  obtain ⟨j, hj⟩ := hc
  exact ⟨k + j, by rw [steps_add, h.sound]; simpa using hj⟩

/-- If the machine does not halt from the end of a block run, it does not halt
from its beginning either. -/
theorem BRun.not_halts {c c' : BCfg} {k : ℕ} (h : BRun b4 c c' k)
    (hc : ¬ Halts (M b4) c'.den) : ¬ Halts (M b4) c.den :=
  fun hh => hc (hh.of_run h.sound)

/-! ## The `<B1` sweep

`11 <B1 → <B1 22` (6 steps), so the `<B1` head walks left through a run of
`11` blocks, leaving `22` blocks behind. -/

theorem brun_Bt_Xrun (n : ℕ) (lt : List LB) (rt : List RB) :
    BRun b4 ⟨List.replicate n .X ++ lt, .Bt, rt⟩
      ⟨lt, .Bt, List.replicate n .Y ++ rt⟩ (6 * n) := by
  induction n generalizing rt with
  | zero => simpa using BRun.refl (b4 := b4) _
  | succ n ih =>
      have h0 : bstep b4 ⟨List.replicate (n + 1) .X ++ lt, .Bt, rt⟩
          = some (⟨List.replicate n .X ++ lt, .Bt, .Y :: rt⟩, 6) := by
        rw [List.replicate_succ]; rfl
      have h := BRun.head h0 (ih (rt := .Y :: rt))
      rw [show 6 + 6 * n = 6 * (n + 1) by ring] at h
      have heq : List.replicate (n + 1) (RB.Y) ++ rt = List.replicate n .Y ++ .Y :: rt := by
        rw [List.replicate_succ']; simp
      rw [heq]
      exact h

/-- `03` first: the `<B1` head creates the dangerous block `F = 141`. -/
theorem brun_Bt_W (n : ℕ) (lt : List LB) (rt : List RB) :
    BRun b4 ⟨List.replicate n .X ++ .W :: lt, .Bt, rt⟩
      ⟨lt, .Lt, .F :: (List.replicate n .Y ++ rt)⟩ (6 * n + 2) :=
  (brun_Bt_Xrun n (.W :: lt) rt).trans (BRun.of_step rfl)

/-- `01` first: the `<B1` head is defused, no `F` block is created. -/
theorem brun_Bt_Z (n : ℕ) (lt : List LB) (rt : List RB) :
    BRun b4 ⟨List.replicate n .X ++ .Z :: lt, .Bt, rt⟩
      ⟨lt, .Lt, .X :: .P2 :: (List.replicate n .Y ++ rt)⟩ (6 * n + 4) :=
  (brun_Bt_Xrun n (.Z :: lt) rt).trans (BRun.of_step rfl)

/-- Nothing but `11` blocks: the `<B1` head reaches the left end of the tape,
and the machine spins out. -/
theorem brun_Bt_L (n : ℕ) (rt : List RB) :
    BRun b4 ⟨List.replicate n .X ++ [.L], .Bt, rt⟩
      ⟨[.L], .Bt, List.replicate n .Y ++ rt⟩ (6 * n) :=
  brun_Bt_Xrun n [.L] rt

/-- The `<B1` head at the left end: the machine never halts. -/
theorem not_halts_Bt_L (rt : List RB) :
    ¬ Halts (M b4) (BCfg.den ⟨[.L], .Bt, rt⟩) :=
  not_halts_leftend_B1 (denR rt)

theorem not_halts_Bt_Xrun_L (n : ℕ) (rt : List RB) :
    ¬ Halts (M b4) (BCfg.den ⟨List.replicate n .X ++ [.L], .Bt, rt⟩) :=
  (brun_Bt_L n rt).not_halts (not_halts_Bt_L _)

/-! ### The first non-`11` block decides

`dropX` is the left stack with its leading run of `11` blocks removed, and
`numX` is the length of that run. -/

/-- The left stack with its leading run of `11 = X` blocks removed. -/
def dropX : List LB → List LB
  | .X :: bs => dropX bs
  | bs => bs

/-- The length of the leading run of `11 = X` blocks of the left stack. -/
def numX : List LB → ℕ
  | .X :: bs => numX bs + 1
  | _ => 0

theorem replicate_numX_dropX : ∀ l : List LB, List.replicate (numX l) .X ++ dropX l = l
  | [] => rfl
  | .X :: bs => by
      rw [numX, dropX, List.replicate_succ, List.cons_append, replicate_numX_dropX bs]
  | .L :: _ | .W :: _ | .Z :: _ | .J :: _ | .J1 :: _ | .J0 :: _ | .K0 :: _
  | .K1 :: _ => rfl

/-- **`F` is created exactly at a `03`.**  If the first non-`11` block of the
left stack is a `03`, the `<B1` sweep creates the block `F = 141`. -/
theorem brun_Bt_of_dropX_W {lt rest : List LB} (h : dropX lt = .W :: rest)
    (rt : List RB) :
    BRun b4 ⟨lt, .Bt, rt⟩
      ⟨rest, .Lt, .F :: (List.replicate (numX lt) .Y ++ rt)⟩ (6 * numX lt + 2) := by
  have := brun_Bt_W (b4 := b4) (numX lt) rest rt
  rwa [← h, replicate_numX_dropX] at this

/-- If the first non-`11` block of the left stack is a `01`, the `<B1` sweep
creates no `F`. -/
theorem brun_Bt_of_dropX_Z {lt rest : List LB} (h : dropX lt = .Z :: rest)
    (rt : List RB) :
    BRun b4 ⟨lt, .Bt, rt⟩
      ⟨rest, .Lt, .X :: .P2 :: (List.replicate (numX lt) .Y ++ rt)⟩
      (6 * numX lt + 4) := by
  have := brun_Bt_Z (b4 := b4) (numX lt) rest rt
  rwa [← h, replicate_numX_dropX] at this

/-- If the left stack consists of `11` blocks only, the `<B1` head reaches the
left end and the machine never halts. -/
theorem not_halts_Bt_of_dropX_L {lt : List LB} (h : dropX lt = [.L]) (rt : List RB) :
    ¬ Halts (M b4) (BCfg.den ⟨lt, .Bt, rt⟩) := by
  have := not_halts_Bt_Xrun_L (b4 := b4) (numX lt) rt
  rwa [← h, replicate_numX_dropX] at this

/-- If the first non-`11` block of the left stack is one of the extra blocks
`023`, `013`, `003`, the `<B1` sweep kills the machine. -/
theorem halts_Bt_of_dropX_J {lt rest : List LB} (h : dropX lt = .J :: rest)
    (rt : List RB) : Halts (M b4) (BCfg.den ⟨lt, .Bt, rt⟩) := by
  have hr := brun_Bt_Xrun (b4 := b4) (numX lt) (dropX lt) rt
  rw [replicate_numX_dropX, h] at hr
  exact hr.halts ⟨3, bhalt_J_Bt b4 rest _⟩

theorem halts_Bt_of_dropX_J1 {lt rest : List LB} (h : dropX lt = .J1 :: rest)
    (rt : List RB) : Halts (M b4) (BCfg.den ⟨lt, .Bt, rt⟩) := by
  have hr := brun_Bt_Xrun (b4 := b4) (numX lt) (dropX lt) rt
  rw [replicate_numX_dropX, h] at hr
  exact hr.halts ⟨3, bhalt_J1_Bt b4 rest _⟩

theorem halts_Bt_of_dropX_J0 {lt rest : List LB} (h : dropX lt = .J0 :: rest)
    (rt : List RB) : Halts (M b4) (BCfg.den ⟨lt, .Bt, rt⟩) := by
  have hr := brun_Bt_Xrun (b4 := b4) (numX lt) (dropX lt) rt
  rw [replicate_numX_dropX, h] at hr
  exact hr.halts ⟨5, bhalt_J0_Bt b4 rest _⟩

/-! ## The `<A` sweep

`03 <A → <A 11` and `11 <A → <A 22` (2 steps each), so an `<A` head walks left
through a run of `03`/`11` blocks; `01 <A → 11 A>` turns it around, and at the
left end `^11 <A → ^11 A> 2>` creates a pending digit. -/

/-- The left blocks an `<A` head walks through. -/
def isWX : LB → Bool
  | .W | .X => true
  | _ => false

/-- The right block that an `<A` head leaves behind: `03 ↦ 11`, `11 ↦ 22`. -/
def wxImg : LB → RB
  | .W => .X
  | _ => .Y

/-- The image of a run of `03`/`11` blocks: it ends up reversed on the right of
the head. -/
def wxImgs (l : List LB) : List RB := (l.map wxImg).reverse

@[simp] theorem wxImgs_nil : wxImgs [] = [] := rfl

theorem wxImgs_cons (b : LB) (l : List LB) :
    wxImgs (b :: l) = wxImgs l ++ [wxImg b] := by
  simp [wxImgs]

/-- The `<A` head walks left through a run of `03`/`11` blocks. -/
theorem brun_Lt_WXrun : ∀ (pre : List LB), (∀ b ∈ pre, isWX b) →
    ∀ (lt : List LB) (rt : List RB),
      BRun b4 ⟨pre ++ lt, .Lt, rt⟩ ⟨lt, .Lt, wxImgs pre ++ rt⟩ (2 * pre.length)
  | [], _, lt, rt => by simpa using BRun.refl (b4 := b4) _
  | b :: pre, h, lt, rt => by
      have hb : isWX b := h b (by simp)
      have hpre : ∀ x ∈ pre, isWX x := fun x hx => h x (by simp [hx])
      have h0 : bstep b4 ⟨(b :: pre) ++ lt, .Lt, rt⟩
          = some (⟨pre ++ lt, .Lt, wxImg b :: rt⟩, 2) := by
        cases b <;> simp [isWX] at hb ⊢ <;> rfl
      have h1 := BRun.head h0 (brun_Lt_WXrun pre hpre lt (wxImg b :: rt))
      rw [wxImgs_cons]
      have : 2 + 2 * pre.length = 2 * (b :: pre).length := by simp; ring
      rw [← this]
      simpa using h1

/-- The `<A` head turns around at the first `01` block, which becomes an `11`. -/
theorem brun_Lt_turn_Z (pre : List LB) (h : ∀ b ∈ pre, isWX b) (rest : List LB)
    (rt : List RB) :
    BRun b4 ⟨pre ++ .Z :: rest, .Lt, rt⟩ ⟨.X :: rest, .Rt, wxImgs pre ++ rt⟩
      (2 * pre.length + 3) :=
  (brun_Lt_WXrun pre h (.Z :: rest) rt).trans (BRun.of_step rfl)

/-- If there is no `01` block left, the `<A` head reaches the left end of the
tape and a pending digit `2>` is created. -/
theorem brun_Lt_reach_L (pre : List LB) (h : ∀ b ∈ pre, isWX b) (rt : List RB) :
    BRun b4 ⟨pre ++ [.L], .Lt, rt⟩ ⟨[.L], .Rt, .P2 :: (wxImgs pre ++ rt)⟩
      (2 * pre.length + 4) :=
  (brun_Lt_WXrun pre h [.L] rt).trans (BRun.of_step rfl)

/-! ## Rightward sweeps -/

/-- The head moving right crosses `22` blocks, pushing `01` blocks onto the left
stack. -/
theorem brun_Rt_Yrun (m : ℕ) (lt : List LB) (rt : List RB) :
    BRun b4 ⟨lt, .Rt, List.replicate m .Y ++ rt⟩
      ⟨List.replicate m .Z ++ lt, .Rt, rt⟩ (2 * m) := by
  induction m generalizing lt with
  | zero => simpa using BRun.refl (b4 := b4) _
  | succ m ih =>
      have h0 : bstep b4 ⟨lt, .Rt, List.replicate (m + 1) .Y ++ rt⟩
          = some (⟨.Z :: lt, .Rt, List.replicate m .Y ++ rt⟩, 2) := by
        rw [List.replicate_succ]; rfl
      have h := BRun.head h0 (ih (lt := .Z :: lt))
      rw [show 2 + 2 * m = 2 * (m + 1) by ring] at h
      have heq : List.replicate (m + 1) (LB.Z) ++ lt = List.replicate m .Z ++ .Z :: lt := by
        rw [List.replicate_succ']; simp
      rw [heq]
      exact h

/-- The right blocks a pending digit `2>` crosses unharmed. -/
def isYU : RB → Bool
  | .Y | .U => true
  | _ => false

/-- The left block pushed when a pending `2>` crosses: `22 ↦ 01`, `12 ↦ 03`. -/
def yuImg : RB → LB
  | .U => .W
  | _ => .Z

/-- The image of a run of `22`/`12` blocks crossed by a pending `2>`. -/
def yuImgs (l : List RB) : List LB := (l.map yuImg).reverse

theorem yuImgs_cons (b : RB) (l : List RB) :
    yuImgs (b :: l) = yuImgs l ++ [yuImg b] := by
  simp [yuImgs]

/-- **A pending `2>` crosses `22` and `12` blocks.**  The digit stays a `2`, so
it is still pending when the run is over. -/
theorem brun_P2_cross : ∀ (pre : List RB), (∀ b ∈ pre, isYU b) →
    ∀ (lt : List LB) (rest : List RB),
      BRun b4 ⟨lt, .Rt, .P2 :: (pre ++ rest)⟩
        ⟨yuImgs pre ++ lt, .Rt, .P2 :: rest⟩ (2 * pre.length)
  | [], _, lt, rest => by simpa [yuImgs] using BRun.refl (b4 := b4) _
  | b :: pre, h, lt, rest => by
      have hb : isYU b := h b (by simp)
      have hpre : ∀ x ∈ pre, isYU x := fun x hx => h x (by simp [hx])
      have h0 : BRun b4 ⟨lt, .Rt, .P2 :: ((b :: pre) ++ rest)⟩
          ⟨yuImg b :: lt, .Rt, .P2 :: (pre ++ rest)⟩ 2 := by
        cases b <;>
          first
            | exact BRun.head (k₁ := 0) (k₂ := 2) rfl (BRun.of_step rfl)
            | simp [isYU] at hb
      have h1 := h0.trans (brun_P2_cross pre hpre (yuImg b :: lt) rest)
      rw [yuImgs_cons]
      have : 2 + 2 * pre.length = 2 * (b :: pre).length := by simp; ring
      rw [← this]
      simpa using h1

/-! ## A halting criterion

The `141`/`241` block need not sit right next to the left end: it is enough
that only `22`/`12` blocks separate it from the head. -/

/-- **Halting criterion.**  If the head reaches the left end of the tape in
state `<A` while a `141` block sits to its right, separated from it by `22` and
`12` blocks only, the machine halts. -/
theorem halts_leftend_YU_F (pre : List RB) (h : ∀ b ∈ pre, isYU b) (rest : List RB) :
    Halts (M b4) (BCfg.den ⟨[.L], .Lt, pre ++ .F :: rest⟩) := by
  refine (BRun.head (k₁ := 4) rfl (brun_P2_cross pre h [.L] (.F :: rest))).halts ?_
  exact ⟨3, bhalt_P2_F b4 _ _⟩

/-- The same with a `241` block. -/
theorem halts_leftend_YU_G (pre : List RB) (h : ∀ b ∈ pre, isYU b) (rest : List RB) :
    Halts (M b4) (BCfg.den ⟨[.L], .Lt, pre ++ .G :: rest⟩) := by
  refine (BRun.head (k₁ := 4) rfl (brun_P2_cross pre h [.L] (.G :: rest))).halts ?_
  exact ⟨3, bhalt_P2_G b4 _ _⟩

/-! ## `F` created above nothing but `11` blocks is fatal -/

/-- If the left stack consists of `11` blocks only and a `141` block sits to
the right of the head, separated from it by `22`/`12` blocks only, the machine
halts: the `<A` head walks down to the left end, turning those `11`s into
`22`s, and `halts_leftend_YU_F` applies. -/
theorem halts_Lt_Xrun_F (a : ℕ) (pre : List RB) (h : ∀ b ∈ pre, isYU b)
    (rest : List RB) :
    Halts (M b4) (BCfg.den ⟨List.replicate a .X ++ [.L], .Lt, pre ++ .F :: rest⟩) := by
  have hpre : ∀ b ∈ List.replicate a (LB.X), isWX b := by
    intro b hb
    rw [List.eq_of_mem_replicate hb]
    rfl
  have hrun := brun_Lt_WXrun (b4 := b4) (List.replicate a .X) hpre [.L] (pre ++ .F :: rest)
  have himg : wxImgs (List.replicate a (LB.X)) = List.replicate a .Y := by
    simp [wxImgs, wxImg]
  rw [himg] at hrun
  refine hrun.halts ?_
  have hall : ∀ b ∈ List.replicate a (RB.Y) ++ pre, isYU b := by
    intro b hb
    rcases List.mem_append.mp hb with hb | hb
    · rw [List.eq_of_mem_replicate hb]; rfl
    · exact h b hb
  have := halts_leftend_YU_F (b4 := b4) (List.replicate a .Y ++ pre) hall rest
  rwa [List.append_assoc] at this

/--
**A halting criterion.**  If a `<B1` sweep starts when the left stack has the
form `11^n 03 11^a ^11` -- that is, when the `03` that will create the `F`
block has nothing but `11` blocks below it -- then the machine halts.

Indeed the sweep creates the `F` and turns the head around as `<A`; the `<A`
head then finds no `01` to turn around at, walks all the way down to the left
end, and the pending `2>` created there crosses the `22`s it has just deposited
and reads the `4`.
-/
theorem halts_Bt_of_no_Z_below_W (n a : ℕ) (rt : List RB) :
    Halts (M b4)
      (BCfg.den ⟨List.replicate n .X ++ .W :: (List.replicate a .X ++ [.L]), .Bt, rt⟩) := by
  refine (brun_Bt_W (b4 := b4) n (List.replicate a .X ++ [.L]) rt).halts ?_
  have := halts_Lt_Xrun_F (b4 := b4) a [] (by simp) (List.replicate n .Y ++ rt)
  simpa using this

/-! ## The counter step

A full round trip of the head: it turns around at the lowest `01`, which
becomes an `11`, and on the way back it crosses the `22`s it has just deposited,
turning every `11` that was above that `01` into a `01`; it stops at the first
`11` on the right, which becomes a `21`. -/

/-- **One counter step.**  `11^m 01 <A 11 ⟶ 01^m 11 <A 21`. -/
theorem brun_round_trip (m : ℕ) (rest : List LB) (rt : List RB) :
    BRun b4 ⟨List.replicate m .X ++ .Z :: rest, .Lt, .X :: rt⟩
      ⟨List.replicate m .Z ++ .X :: rest, .Lt, .V :: rt⟩ (4 * m + 4) := by
  have hpre : ∀ b ∈ List.replicate m (LB.X), isWX b := by
    intro b hb
    rw [List.eq_of_mem_replicate hb]
    rfl
  have h1 := brun_Lt_turn_Z (b4 := b4) (List.replicate m .X) hpre rest (.X :: rt)
  have himg : wxImgs (List.replicate m (LB.X)) = List.replicate m .Y := by
    simp [wxImgs, wxImg]
  rw [himg, List.length_replicate] at h1
  have h2 := brun_Rt_Yrun (b4 := b4) m (.X :: rest) (.X :: rt)
  have h3 : BRun b4 ⟨List.replicate m .Z ++ .X :: rest, .Rt, .X :: rt⟩
      ⟨List.replicate m .Z ++ .X :: rest, .Lt, .V :: rt⟩ 1 := BRun.of_step rfl
  have := (h1.trans h2).trans h3
  rw [show 2 * m + 3 + 2 * m + 1 = 4 * m + 4 by ring] at this
  exact this

end BB25
