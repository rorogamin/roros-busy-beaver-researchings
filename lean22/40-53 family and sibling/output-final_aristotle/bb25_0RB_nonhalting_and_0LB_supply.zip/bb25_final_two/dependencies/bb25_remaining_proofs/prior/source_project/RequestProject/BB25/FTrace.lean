/-
# The overflows the members actually reach, and the counter they rebuild there

`FValue.lean` proves the general criterion: for a member whose `A> 241` merely
bounces (`Bounces b4`), a reset phase that reads a word `w` with no borrow
(`c = 0`) and rebuilds a counter `f ≥ 2` survives the whole cycle
(`reset_cycle_of_f_ge_two`), and the top-bit invariant `2^(e-1) ≤ f + 1` is what
guarantees `f ≥ 2` once the counter has at least two digits.

This file *checks the criterion on the runs themselves*, inside the kernel.
`ovCfgs` collects the configurations at which the accelerated block simulator of
`Blocks.lean` finds the head at the left end with the counter exhausted — the
overflow events — and `ovSafeCfg` tests, for such a configuration, that

* the tape to the right of the head is a word of digit blocks followed by the
  right end marker (so the criterion applies to it verbatim),
* the shift map of that word has `c = 0` (no borrow),
* the word is **cheap**: its cost is at most `1/2` of normalised value, checked
  in the decidable integer form `2 * rncost 256 w ≤ 2 ^ 256`, and
* it builds at least three digits.

These are exactly the hypotheses of the criterion `reset_cycle_of_ncost`, so the
rebuilt counter has its top bit set (`overflow_top_bit`, hence `f ≥ 3`) and the
cycle is survived — nothing about `f` is checked directly.

`overflow_words_safe` checks this for all 13 members at every overflow from the
fourth on (the first three are the degenerate small ones: `f = 0`, `f = 1`, and
a word that ends in a `1>` pending block), within 4000 accelerated block steps —
at least nine overflows for every member.  `tame_overflows_survived` then
combines it with the criterion: for the five members whose `A> 241` bounces,
**every one of those overflow events is provably survived**, and each of the
configurations really occurs in the run from the blank tape
(`ovCfgs_reachable`).

This does not decide any member: it certifies an initial stretch of each run,
and it is the stretch on which the closed-form cycle of `Counter.lean` applies.
-/
import RequestProject.BB25.FValue
import RequestProject.BB25.Trace

namespace BB25

variable {b4 : Option (Sym × Dir × St)}

/-- The configurations at which the accelerated simulator is at an overflow
(head at the left end, counter exhausted), in the order they occur. -/
def ovCfgs (b4 : Option (Sym × Dir × St)) : ℕ → BCfg → List BCfg
  | 0, _ => []
  | n + 1, c =>
      let rest :=
        match bstepFast b4 c with
        | some (c', _) => ovCfgs b4 n c'
        | none => []
      if atOverflow c then c :: rest else rest

/-- Every configuration `ovCfgs` records really occurs in the run. -/
theorem ovCfgs_reachable (n : ℕ) (c : BCfg) :
    ∀ c' ∈ ovCfgs b4 n c, ∃ (m k : ℕ), bstepsFast b4 m c = some (c', k) := by
  induction n generalizing c with
  | zero => simp [ovCfgs]
  | succ n ih =>
      intro c' hmem
      have hstep : ∀ c₁ k₁, bstepFast b4 c = some (c₁, k₁) →
          ∀ c'' ∈ ovCfgs b4 n c₁, ∃ (m k : ℕ), bstepsFast b4 m c = some (c'', k) := by
        intro c₁ k₁ hb c'' hc''
        obtain ⟨m, k, hm⟩ := ih c₁ c'' hc''
        exact ⟨m + 1, k₁ + k, by simp [bstepsFast, hb, hm]⟩
      simp only [ovCfgs] at hmem
      split at hmem
      · rcases List.mem_cons.mp hmem with rfl | hmem
        · exact ⟨0, 0, rfl⟩
        · revert hmem
          cases hb : bstepFast b4 c with
          | none => simp
          | some p => obtain ⟨c₁, k₁⟩ := p; exact fun h => hstep c₁ k₁ hb c' h
      · revert hmem
        cases hb : bstepFast b4 c with
        | none => simp
        | some p => obtain ⟨c₁, k₁⟩ := p; exact fun h => hstep c₁ k₁ hb c' h

/-- An overflow configuration is at the left end in state `<A`. -/
theorem atOverflow_eq {c : BCfg} (h : atOverflow c = true) : c = ⟨[.L], .Lt, c.rt⟩ := by
  obtain ⟨lt, st, rt⟩ := c
  cases lt with
  | nil => simp [atOverflow] at h
  | cons b lt =>
      cases lt with
      | nil => cases b <;> cases st <;> simp_all [atOverflow]
      | cons b' lt => cases b <;> cases st <;> simp [atOverflow] at h

/-- The test on an overflow configuration: the tape ahead of the head is a word
of digit blocks followed by the end marker, the word needs no borrow, its cost
is at most `1/2` (in the decidable integer form of `FValue.lean`, at the scale
`2 ^ 256`), and it builds at least three digits.  These are exactly the
hypotheses of `reset_cycle_of_ncost`. -/
def ovSafeCfg (c : BCfg) : Bool :=
  atOverflow c && (c.rt == digitPrefix c.rt ++ [RB.R]) &&
    ((rmap true (digitPrefix c.rt)).2.c == 0) &&
    decide (2 * rncost 256 (digitPrefix c.rt) ≤ 2 ^ 256) &&
    decide (3 ≤ (rmap true (digitPrefix c.rt)).2.e)

/-- The five conjuncts of the test. -/
theorem ovSafeCfg_parts {c : BCfg} (h : ovSafeCfg c = true) :
    atOverflow c = true ∧ c.rt = digitPrefix c.rt ++ [RB.R] ∧
      (rmap true (digitPrefix c.rt)).2.c = 0 ∧
      2 * rncost 256 (digitPrefix c.rt) ≤ 2 ^ 256 ∧
      3 ≤ (rmap true (digitPrefix c.rt)).2.e := by
  simp only [ovSafeCfg, Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at h
  obtain ⟨⟨⟨⟨hov, hrt⟩, hc⟩, hcost⟩, he⟩ := h
  exact ⟨hov, hrt, hc, hcost, he⟩

/-- **The top bit of the rebuilt counter is set** at a safe overflow: the
counter the reset hands back has exactly `e` binary digits, and in particular
`f ≥ 3`.  This is `rmap_f_lower` applied to the checked cost. -/
theorem ovSafeCfg_top_bit {c : BCfg} (h : ovSafeCfg c = true) :
    2 ^ ((rmap true (digitPrefix c.rt)).2.e - 1) ≤ (rmap true (digitPrefix c.rt)).2.f + 1 ∧
      3 ≤ (rmap true (digitPrefix c.rt)).2.f := by
  obtain ⟨-, -, -, hcost, he⟩ := ovSafeCfg_parts h
  exact ⟨rmap_f_lower (rcost_le_half_of_nat hcost),
    rmap_f_ge_two (rcost_le_half_of_nat hcost) he⟩

/--
**A safe overflow is survived.**  For a member whose `A> 241` bounces, an
overflow configuration passing `ovSafeCfg` is left in a configuration that again
has a well-formed counter stack on the left and no `141`/`241` block anywhere.
-/
theorem ovSafeCfg_survives (hb : Bounces b4) {c : BCfg} (h : ovSafeCfg c = true) :
    ∃ (s : List LB) (pre : List RB) (k : ℕ),
      BRun b4 c ⟨s, .Lt, pre ++ [.Y, .R1]⟩ k ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G := by
  obtain ⟨hov, hrt, hc, hcost, he⟩ := ovSafeCfg_parts h
  have hcfg : c = ⟨[.L], .Lt, digitPrefix c.rt ++ [RB.R]⟩ := by
    rw [atOverflow_eq hov, ← hrt]
  rw [hcfg]
  exact reset_cycle_of_ncost hb (digitPrefix_CWord c.rt) hc hcost he

/-- The check run on a member: it reaches at least seven overflows within `n`
accelerated block steps, and every overflow from the fourth on is safe. -/
def ovSafeLate (b4 : Option (Sym × Dir × St)) (n : ℕ) : Bool :=
  let t := ovCfgs b4 n binit
  decide (7 ≤ t.length) && ((t.drop 3).all ovSafeCfg)

set_option maxRecDepth 40000
set_option maxHeartbeats 4000000

/--
**Every overflow of every member, from the fourth on, re-parses a cheap
word.**  Running the accelerated block simulator from the blank tape for 4000
block steps, each of the 13 members reaches at least seven overflows (in fact
nine to twelve), and at every one of them from the fourth onwards the word the
reset re-parses is a plain word of digit blocks, needs no borrow, builds at
least three digits, and costs at most `1/2` of normalised value.

By `overflow_top_bit` the counter rebuilt at each of these overflows therefore
has its top bit set, and by `bouncing_overflows_survived` the five bouncing
members survive every one of them.
-/
theorem overflow_words_safe :
    ovSafeLate b4_2LB 4000 = true ∧ ovSafeLate b4_2RB 4000 = true ∧
    ovSafeLate b4_1LB 4000 = true ∧ ovSafeLate b4_1RB 4000 = true ∧
    ovSafeLate b4_0LB 4000 = true ∧ ovSafeLate b4_0RB 4000 = true ∧
    ovSafeLate b4_3RA 4000 = true ∧ ovSafeLate b4_2LA 4000 = true ∧
    ovSafeLate b4_2RA 4000 = true ∧ ovSafeLate b4_1LA 4000 = true ∧
    ovSafeLate b4_1RA 4000 = true ∧ ovSafeLate b4_0LA 4000 = true ∧
    ovSafeLate b4_0RA 4000 = true := by
  refine ⟨by decide, by decide, by decide, by decide, by decide, by decide, by decide,
    by decide, by decide, by decide, by decide, by decide, by decide⟩

/--
**The overflows are survived.**  For a member whose `A> 241` bounces and which
passes the check, every overflow event from the fourth on really occurs in the
run from `binit`, and the machine comes out of it at the left end with a
well-formed counter stack and no `141`/`241` block on the tape.
-/
theorem tame_overflows_survived (hb : Bounces b4) {n : ℕ} (hsafe : ovSafeLate b4 n = true) :
    ∀ c ∈ (ovCfgs b4 n binit).drop 3,
      (∃ (m k : ℕ), bstepsFast b4 m binit = some (c, k)) ∧
      ∃ (s : List LB) (pre : List RB) (j : ℕ),
        BRun b4 c ⟨s, .Lt, pre ++ [.Y, .R1]⟩ j ∧ CStack s ∧
          ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G := by
  intro c hc
  have hall : ∀ c' ∈ (ovCfgs b4 n binit).drop 3, ovSafeCfg c' = true := by
    have := (Bool.and_eq_true _ _).mp hsafe
    exact fun c' hc' => List.all_eq_true.mp this.2 c' hc'
  refine ⟨ovCfgs_reachable n binit c (List.mem_of_mem_drop hc), ovSafeCfg_survives hb (hall c hc)⟩

/-- **The rebuilt counter always has its top bit set.**  For every member, at
every overflow from the fourth on inside the checked stretch, the counter the
reset rebuilds satisfies `2 ^ (e - 1) ≤ f + 1` (and hence `f ≥ 3`) — derived
from the checked cost of the word, not observed. -/
theorem overflow_top_bit {b4 : Option (Sym × Dir × St)} {n : ℕ}
    (hsafe : ovSafeLate b4 n = true) :
    ∀ c ∈ (ovCfgs b4 n binit).drop 3,
      2 ^ ((rmap true (digitPrefix c.rt)).2.e - 1) ≤ (rmap true (digitPrefix c.rt)).2.f + 1 ∧
        3 ≤ (rmap true (digitPrefix c.rt)).2.f := by
  intro c hc
  have hall := (Bool.and_eq_true _ _).mp hsafe
  exact ovSafeCfg_top_bit (List.all_eq_true.mp hall.2 c hc)

/-- The five members whose `A> 241` bounces survive every overflow of the first
4000 accelerated block steps. -/
theorem bouncing_overflows_survived :
    (∀ c ∈ (ovCfgs b4_2LB 4000 binit).drop 3, ∃ (s : List LB) (pre : List RB) (j : ℕ),
      BRun b4_2LB c ⟨s, .Lt, pre ++ [.Y, .R1]⟩ j ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G) ∧
    (∀ c ∈ (ovCfgs b4_1LB 4000 binit).drop 3, ∃ (s : List LB) (pre : List RB) (j : ℕ),
      BRun b4_1LB c ⟨s, .Lt, pre ++ [.Y, .R1]⟩ j ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G) ∧
    (∀ c ∈ (ovCfgs b4_3RA 4000 binit).drop 3, ∃ (s : List LB) (pre : List RB) (j : ℕ),
      BRun b4_3RA c ⟨s, .Lt, pre ++ [.Y, .R1]⟩ j ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G) ∧
    (∀ c ∈ (ovCfgs b4_2LA 4000 binit).drop 3, ∃ (s : List LB) (pre : List RB) (j : ℕ),
      BRun b4_2LA c ⟨s, .Lt, pre ++ [.Y, .R1]⟩ j ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G) ∧
    (∀ c ∈ (ovCfgs b4_0LA 4000 binit).drop 3, ∃ (s : List LB) (pre : List RB) (j : ℕ),
      BRun b4_0LA c ⟨s, .Lt, pre ++ [.Y, .R1]⟩ j ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G) := by
  obtain ⟨h2LB, -, h1LB, -, -, -, h3RA, h2LA, -, -, -, h0LA, -⟩ := overflow_words_safe
  exact ⟨fun c hc => (tame_overflows_survived bounces_2LB h2LB c hc).2,
    fun c hc => (tame_overflows_survived bounces_1LB h1LB c hc).2,
    fun c hc => (tame_overflows_survived bounces_3RA h3RA c hc).2,
    fun c hc => (tame_overflows_survived bounces_2LA h2LA c hc).2,
    fun c hc => (tame_overflows_survived bounces_0LA h0LA c hc).2⟩

end BB25
