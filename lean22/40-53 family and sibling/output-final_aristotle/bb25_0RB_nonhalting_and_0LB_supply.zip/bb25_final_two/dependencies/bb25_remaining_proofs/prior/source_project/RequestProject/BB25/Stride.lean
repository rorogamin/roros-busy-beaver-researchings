/-
# The left stride ("longitudinal") theorem

On the left of the head the tape of every member of the family is a word in
the three blocks

```
  W = 03      X = 11      Z = 01
```

and, as long as the head stays in state `A`, the only thing it does there is
the following bouncing process, described in the family notes as

```
  03 ↪xn        11 ↪x(2n)      11 ↪x(2n+1)     01 ↪x(2n)      01 ↪x(2n+1)
  ↪x(2n) 03 >   ↪xn 11 >       ↪x(n+1) 01 >    ↪xn 01 >       ↪xn 11 >
```

Here `↪xn` means "the head crosses this boundary `n` times, from the right".
This file makes that precise (`Visit`, `MVisit`), proves the five rules above
from the local rules of `RequestProject.BB25.Rules`, and derives the closed
form `strideN` -- the accelerated "left stride" used by the block simulator.
-/
import RequestProject.BB25.Rules

namespace BB25

/-- The three blocks that occur on the left of the head. -/
inductive LBlk | W | X | Z
deriving DecidableEq, Repr

namespace LBlk

/-- The two tape cells of a block, *nearest to the head first*. -/
def den : LBlk → List Sym
  | W => [3, 0]
  | X => [1, 1]
  | Z => [1, 0]

end LBlk

/-- A left tape, given as a list of blocks nearest to the head first. -/
def den : List LBlk → List Sym
  | [] => []
  | b :: bs => b.den ++ den bs

@[simp] theorem den_nil : den [] = [] := rfl

@[simp] theorem den_cons (b : LBlk) (bs : List LBlk) : den (b :: bs) = b.den ++ den bs := rfl

/--
`Visit m bs bs' k` : whenever the head arrives in state `<A` at the right end
of the left-tape segment `bs`, then after exactly `k` steps it leaves the
segment again to the right, in state `A>`, and the segment has become `bs'`.

The statement is quantified over the surrounding tape, so a visit may be used
in any context.
-/
def Visit (m : Machine) (bs bs' : List LBlk) (k : ℕ) : Prop :=
  ∀ l r : List Sym, steps m k ⟨den bs ++ l, .A, .L, r⟩ = some ⟨den bs' ++ l, .A, .R, r⟩

/-- `MVisit m n bs bs' k` : `n` successive visits (in arbitrary contexts) turn
the segment `bs` into `bs'` and take `k` steps in total. -/
inductive MVisit (m : Machine) : ℕ → List LBlk → List LBlk → ℕ → Prop
  | zero (bs : List LBlk) : MVisit m 0 bs bs 0
  | succ {n : ℕ} {bs bs' bs'' : List LBlk} {k₁ k₂ : ℕ} :
      Visit m bs bs' k₁ → MVisit m n bs' bs'' k₂ → MVisit m (n + 1) bs bs'' (k₁ + k₂)

theorem MVisit_one {m : Machine} {bs bs' : List LBlk} {k : ℕ} (h : Visit m bs bs' k) :
    MVisit m 1 bs bs' k := by
  simpa using MVisit.succ h (MVisit.zero bs')

theorem MVisit.of_one {m : Machine} {bs bs' : List LBlk} {k : ℕ} (h : MVisit m 1 bs bs' k) :
    Visit m bs bs' k := by
  cases h with
  | succ hv hm => cases hm with | zero => simpa using hv

theorem MVisit.of_two {m : Machine} {bs bs' : List LBlk} {k : ℕ} (h : MVisit m 2 bs bs' k) :
    ∃ bs₁ k₁ k₂, Visit m bs bs₁ k₁ ∧ Visit m bs₁ bs' k₂ ∧ k = k₁ + k₂ := by
  cases h with
  | succ hv hm => exact ⟨_, _, _, hv, hm.of_one, rfl⟩

/-- Visits compose. -/
theorem MVisit_append {m : Machine} {a b : ℕ} {bs bs₁ bs₂ : List LBlk} {k₁ k₂ : ℕ}
    (h₁ : MVisit m a bs bs₁ k₁) (h₂ : MVisit m b bs₁ bs₂ k₂) :
    MVisit m (a + b) bs bs₂ (k₁ + k₂) := by
  induction h₁ with
  | zero => simpa using h₂
  | @succ n bs bs' bs'' j₁ j₂ hv _ ih =>
      have := MVisit.succ hv (ih h₂)
      simpa [show n + 1 + b = (n + b) + 1 by omega, show j₁ + (j₂ + k₂) = j₁ + j₂ + k₂ by omega]
        using this

/-- Visits split. -/
theorem MVisit_split {m : Machine} : ∀ (a : ℕ) {b : ℕ} {bs bs₂ : List LBlk} {k : ℕ},
    MVisit m (a + b) bs bs₂ k →
      ∃ bs₁ k₁ k₂, MVisit m a bs bs₁ k₁ ∧ MVisit m b bs₁ bs₂ k₂ ∧ k = k₁ + k₂ := by
  intro a
  induction a with
  | zero => intro b bs bs₂ k h; exact ⟨bs, 0, k, MVisit.zero bs, by simpa using h, by omega⟩
  | succ a ih =>
      intro b bs bs₂ k h
      rw [show a + 1 + b = (a + b) + 1 by omega] at h
      cases h with
      | @succ n bsx bs' bs'' j₁ j₂ hv hm =>
          obtain ⟨bs₁, k₁, k₂, h₁, h₂, rfl⟩ := ih hm
          exact ⟨bs₁, j₁ + k₁, k₂, by simpa using MVisit.succ hv h₁, h₂, by omega⟩

/-! ## The three single-block visits -/

variable {b4 : Option (Sym × Dir × St)}

/-- `01 <A → 11 A>`: a visit to a `Z` block turns it into `X` and bounces the
head straight back; the rest of the tape is untouched.  3 steps. -/
theorem visit_Z (bs : List LBlk) : Visit (M b4) (.Z :: bs) (.X :: bs) 3 := by
  intro l r
  simpa [LBlk.den] using rule_Z_A b4 (den bs ++ l) r

/-- A visit to an `X` block turns it into `Z` and costs one visit of the rest
of the tape, plus 4 steps (`11 <A → <A 22` and `A> 22 → 01 A>`). -/
theorem visit_X {bs bs' : List LBlk} {k : ℕ} (h : Visit (M b4) bs bs' k) :
    Visit (M b4) (.X :: bs) (.Z :: bs') (k + 4) := by
  intro l r
  have h1 := rule_X_A b4 (den bs ++ l) r
  have h2 := h l (2 :: 2 :: r)
  have h3 := rule_A_Y b4 (den bs' ++ l) r
  have := steps_trans (steps_trans h1 h2) h3
  simpa [LBlk.den, show 2 + k + 2 = k + 4 by omega] using this

/-- A visit to a `W` block leaves it unchanged and costs *two* visits of the
rest of the tape, plus 5 steps (`03 <A → <A 11`, `A> 11 → <A 21`,
`A> 21 → 03 A>`). -/
theorem visit_W {bs bs₁ bs₂ : List LBlk} {k₁ k₂ : ℕ}
    (h₁ : Visit (M b4) bs bs₁ k₁) (h₂ : Visit (M b4) bs₁ bs₂ k₂) :
    Visit (M b4) (.W :: bs) (.W :: bs₂) (k₁ + k₂ + 5) := by
  intro l r
  have e1 := rule_W_A b4 (den bs ++ l) r
  have e2 := h₁ l (1 :: 1 :: r)
  have e3 := rule_A_X b4 (den bs₁ ++ l) r
  have e4 := h₂ l (2 :: 1 :: r)
  have e5 := rule_A_V b4 (den bs₂ ++ l) r
  have := steps_trans (steps_trans (steps_trans (steps_trans e1 e2) e3) e4) e5
  simpa [LBlk.den, show 2 + k₁ + 1 + k₂ + 2 = k₁ + k₂ + 5 by omega] using this

/-! ## The multi-visit rules of the family notes -/

/-- `03 ↪xn → ↪x(2n) 03 >` : `n` visits of a `W` block cost `2n` visits of the
tape to its left and `5n` steps, and leave the block unchanged. -/
theorem mvisit_W : ∀ (n : ℕ) {bs bs' : List LBlk} {k : ℕ},
    MVisit (M b4) (2 * n) bs bs' k → MVisit (M b4) n (.W :: bs) (.W :: bs') (k + 5 * n) := by
  intro n
  induction n with
  | zero =>
      intro bs bs' k h
      cases h
      simpa using MVisit.zero _
  | succ n ih =>
      intro bs bs' k h
      rw [show 2 * (n + 1) = 2 + 2 * n by omega] at h
      obtain ⟨bs₁, k₁, k₂, h₁, h₂, rfl⟩ := MVisit_split 2 h
      obtain ⟨bsa, j₁, j₂, hv₁, hv₂, rfl⟩ := h₁.of_two
      have hW : Visit (M b4) (.W :: bs) (.W :: bs₁) (j₁ + j₂ + 5) := visit_W hv₁ hv₂
      have := MVisit_append (MVisit_one hW) (ih h₂)
      simpa [show 1 + n = n + 1 by omega,
        show j₁ + j₂ + 5 + (k₂ + 5 * n) = j₁ + j₂ + k₂ + 5 * (n + 1) by ring] using this

/-- `11 ↪x(2n) → ↪xn 11 >` : an even number `2n` of visits of an `X` block
costs `n` visits of the tape to its left and `7n` steps, and leaves the block
unchanged. -/
theorem mvisit_X_even : ∀ (n : ℕ) {bs bs' : List LBlk} {k : ℕ},
    MVisit (M b4) n bs bs' k →
      MVisit (M b4) (2 * n) (.X :: bs) (.X :: bs') (k + 7 * n) := by
  intro n
  induction n with
  | zero =>
      intro bs bs' k h
      cases h
      simpa using MVisit.zero _
  | succ n ih =>
      intro bs bs' k h
      rw [show n + 1 = 1 + n by omega] at h
      obtain ⟨bs₁, k₁, k₂, h₁, h₂, rfl⟩ := MVisit_split 1 h
      have v1 : Visit (M b4) (.X :: bs) (.Z :: bs₁) (k₁ + 4) := visit_X h₁.of_one
      have v2 : Visit (M b4) (.Z :: bs₁) (.X :: bs₁) 3 := visit_Z bs₁
      have hc := MVisit_append (MVisit_append (MVisit_one v1) (MVisit_one v2)) (ih h₂)
      rw [show 1 + 1 + 2 * n = 2 * (n + 1) by omega,
        show k₁ + 4 + 3 + (k₂ + 7 * n) = k₁ + k₂ + 7 * (n + 1) by ring] at hc
      exact hc

/-- `11 ↪x(2n+1) → ↪x(n+1) 01 >` : an odd number `2n+1` of visits of an `X`
block costs `n+1` visits of the tape to its left and turns the block into
`Z = 01`. -/
theorem mvisit_X_odd (n : ℕ) {bs bs' : List LBlk} {k : ℕ}
    (h : MVisit (M b4) (n + 1) bs bs' k) :
    MVisit (M b4) (2 * n + 1) (.X :: bs) (.Z :: bs') (k + 7 * n + 4) := by
  obtain ⟨bs₁, k₁, k₂, h₁, h₂, rfl⟩ := MVisit_split n h
  have hev := mvisit_X_even n h₁
  have v := visit_X h₂.of_one
  have hc := MVisit_append hev (MVisit_one v)
  rw [show k₁ + 7 * n + (k₂ + 4) = k₁ + k₂ + 7 * n + 4 by ring] at hc
  exact hc

/-- `01 ↪x(2n+1) → ↪xn 11 >` : an odd number `2n+1` of visits of a `Z` block
costs `n` visits of the tape to its left and turns the block into `X = 11`. -/
theorem mvisit_Z_odd (n : ℕ) {bs bs' : List LBlk} {k : ℕ}
    (h : MVisit (M b4) n bs bs' k) :
    MVisit (M b4) (2 * n + 1) (.Z :: bs) (.X :: bs') (k + 7 * n + 3) := by
  have hc := MVisit_append (MVisit_one (visit_Z (b4 := b4) bs)) (mvisit_X_even n h)
  rw [show 1 + 2 * n = 2 * n + 1 by omega, show 3 + (k + 7 * n) = k + 7 * n + 3 by ring] at hc
  exact hc

/-- `01 ↪x(2n) → ↪xn 01 >` : an even number `2n` of visits of a `Z` block
costs `n` visits of the tape to its left and leaves the block unchanged. -/
theorem mvisit_Z_even : ∀ (n : ℕ) {bs bs' : List LBlk} {k : ℕ},
    MVisit (M b4) n bs bs' k →
      MVisit (M b4) (2 * n) (.Z :: bs) (.Z :: bs') (k + 7 * n) := by
  intro n
  match n with
  | 0 =>
      intro bs bs' k h
      cases h
      simpa using MVisit.zero _
  | (m + 1) =>
      intro bs bs' k h
      have hc := MVisit_append (MVisit_one (visit_Z (b4 := b4) bs)) (mvisit_X_odd m h)
      rw [show 1 + (2 * m + 1) = 2 * (m + 1) by omega,
        show 3 + (k + 7 * m + 4) = k + 7 * (m + 1) by ring] at hc
      exact hc

/-- The four rules above, packaged for an arbitrary number of visits of an
`X` block. -/
theorem mvisit_X (n : ℕ) {bs bs' : List LBlk} {k : ℕ}
    (h : MVisit (M b4) ((n + 1) / 2) bs bs' k) :
    MVisit (M b4) n (.X :: bs) ((if n % 2 = 0 then LBlk.X else LBlk.Z) :: bs')
      (k + 7 * (n / 2) + (if n % 2 = 0 then 0 else 4)) := by
  rcases Nat.even_or_odd n with he | ho
  · obtain ⟨m, rfl⟩ := he
    have e1 : (m + m + 1) / 2 = m := by omega
    have e2 : (m + m) % 2 = 0 := by omega
    have e3 : (m + m) / 2 = m := by omega
    rw [e1] at h
    rw [e2, e3]
    have hif1 : (if (0 : ℕ) = 0 then LBlk.X else LBlk.Z) = LBlk.X := rfl
    have hif2 : (if (0 : ℕ) = 0 then 0 else 4) = 0 := rfl
    rw [hif1, hif2, Nat.add_zero]
    have := mvisit_X_even (b4 := b4) m h
    rwa [show 2 * m = m + m by ring] at this
  · obtain ⟨m, rfl⟩ := ho
    have e1 : (2 * m + 1 + 1) / 2 = m + 1 := by omega
    have e2 : (2 * m + 1) % 2 = 1 := by omega
    have e3 : (2 * m + 1) / 2 = m := by omega
    rw [e1] at h
    rw [e2, e3]
    have hif1 : (if (1 : ℕ) = 0 then LBlk.X else LBlk.Z) = LBlk.Z := rfl
    have hif2 : (if (1 : ℕ) = 0 then 0 else 4) = 4 := rfl
    rw [hif1, hif2]
    exact mvisit_X_odd m h

/-- The four rules above, packaged for an arbitrary number of visits of a
`Z` block. -/
theorem mvisit_Z (n : ℕ) {bs bs' : List LBlk} {k : ℕ}
    (h : MVisit (M b4) (n / 2) bs bs' k) :
    MVisit (M b4) n (.Z :: bs) ((if n % 2 = 0 then LBlk.Z else LBlk.X) :: bs')
      (k + 7 * (n / 2) + (if n % 2 = 0 then 0 else 3)) := by
  rcases Nat.even_or_odd n with he | ho
  · obtain ⟨m, rfl⟩ := he
    have e2 : (m + m) % 2 = 0 := by omega
    have e3 : (m + m) / 2 = m := by omega
    rw [e3] at h
    rw [e2, e3]
    have hif1 : (if (0 : ℕ) = 0 then LBlk.Z else LBlk.X) = LBlk.Z := rfl
    have hif2 : (if (0 : ℕ) = 0 then 0 else 3) = 0 := rfl
    rw [hif1, hif2, Nat.add_zero]
    have := mvisit_Z_even (b4 := b4) m h
    rwa [show 2 * m = m + m by ring] at this
  · obtain ⟨m, rfl⟩ := ho
    have e2 : (2 * m + 1) % 2 = 1 := by omega
    have e3 : (2 * m + 1) / 2 = m := by omega
    rw [e3] at h
    rw [e2, e3]
    have hif1 : (if (1 : ℕ) = 0 then LBlk.Z else LBlk.X) = LBlk.X := rfl
    have hif2 : (if (1 : ℕ) = 0 then 0 else 3) = 3 := rfl
    rw [hif1, hif2]
    exact mvisit_Z_odd m h

/-! ## The accelerated left stride -/

/--
`strideN bs n` : the effect of `n` visits at the right end of the left-tape
segment `bs`, computed in closed form -- the new segment and the exact number
of base steps.  `none` means that the head runs off the left end of `bs`, in
which case the visits are not determined by `bs` alone.

This is exactly the `try_stride` routine of the accelerated simulator.
-/
def strideN : List LBlk → ℕ → Option (List LBlk × ℕ)
  | bs, 0 => some (bs, 0)
  | [], _ + 1 => none
  | .W :: bs, n + 1 => (strideN bs (2 * (n + 1))).map fun p => (.W :: p.1, p.2 + 5 * (n + 1))
  | .X :: bs, n + 1 =>
      (strideN bs ((n + 2) / 2)).map fun p =>
        ((if (n + 1) % 2 = 0 then LBlk.X else LBlk.Z) :: p.1,
          p.2 + 7 * ((n + 1) / 2) + (if (n + 1) % 2 = 0 then 0 else 4))
  | .Z :: bs, n + 1 =>
      (strideN bs ((n + 1) / 2)).map fun p =>
        ((if (n + 1) % 2 = 0 then LBlk.Z else LBlk.X) :: p.1,
          p.2 + 7 * ((n + 1) / 2) + (if (n + 1) % 2 = 0 then 0 else 3))

/-- **Left stride theorem.**  The closed form `strideN` is correct: it really
describes `n` visits of the head to the left-tape segment `bs`. -/
theorem strideN_sound : ∀ (bs : List LBlk) (n : ℕ) (bs' : List LBlk) (k : ℕ),
    strideN bs n = some (bs', k) → MVisit (M b4) n bs bs' k
  | bs, 0, bs', k, h => by
      simp only [strideN, Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, rfl⟩ := h
      exact MVisit.zero bs
  | [], n + 1, bs', k, h => by simp [strideN] at h
  | .W :: bs, n + 1, bs', k, h => by
      simp only [strideN, Option.map_eq_some_iff] at h
      obtain ⟨⟨bs₁, k₁⟩, hs, he⟩ := h
      simp only [Prod.mk.injEq] at he
      obtain ⟨rfl, rfl⟩ := he
      exact mvisit_W (n + 1) (strideN_sound bs (2 * (n + 1)) bs₁ k₁ hs)
  | .X :: bs, n + 1, bs', k, h => by
      simp only [strideN, Option.map_eq_some_iff] at h
      obtain ⟨⟨bs₁, k₁⟩, hs, he⟩ := h
      simp only [Prod.mk.injEq] at he
      obtain ⟨rfl, rfl⟩ := he
      exact mvisit_X (n + 1) (strideN_sound bs ((n + 2) / 2) bs₁ k₁ hs)
  | .Z :: bs, n + 1, bs', k, h => by
      simp only [strideN, Option.map_eq_some_iff] at h
      obtain ⟨⟨bs₁, k₁⟩, hs, he⟩ := h
      simp only [Prod.mk.injEq] at he
      obtain ⟨rfl, rfl⟩ := he
      exact mvisit_Z (n + 1) (strideN_sound bs ((n + 1) / 2) bs₁ k₁ hs)

/-- The head arriving once at the right end of the left tape: if `strideN`
succeeds with one visit, the head comes back out after exactly `k` steps. -/
theorem stride_visit {bs bs' : List LBlk} {k : ℕ} (h : strideN bs 1 = some (bs', k)) :
    ∀ l r : List Sym,
      steps (M b4) k ⟨den bs ++ l, .A, .L, r⟩ = some ⟨den bs' ++ l, .A, .R, r⟩ :=
  (strideN_sound bs 1 bs' k h).of_one

/-! ## A worked example

The example from the family notes: at step 268 the machine
`1RB2LA0RB1LB---_1LA3RA1RA4LB2RB` is in the configuration

```
  1111010301111101030303 <A 21
```

and at step 355 it is in the configuration

```
  1111010311111101030303 A> 21
```

-- one left stride of 87 = 355 - 268 steps. -/

example : strideN [.W, .W, .W, .Z, .X, .X, .Z, .W, .Z, .X, .X] 1
    = some ([.W, .W, .W, .Z, .X, .X, .X, .W, .Z, .X, .X], 87) := by decide

/-- The worked example of the notes, as a statement about the base machine:
`1111010301111101030303 <A 21` becomes `1111010311111101030303 A> 21`
after exactly 87 steps. -/
theorem worked_example (r : List Sym) :
    steps (M b4) 87 ⟨[3, 0, 3, 0, 3, 0, 1, 0, 1, 1, 1, 1, 1, 0, 3, 0, 1, 0, 1, 1, 1, 1], .A, .L, r⟩
      = some ⟨[3, 0, 3, 0, 3, 0, 1, 0, 1, 1, 1, 1, 1, 1, 3, 0, 1, 0, 1, 1, 1, 1], .A, .R, r⟩ := by
  have h := stride_visit (b4 := b4)
    (bs := [.W, .W, .W, .Z, .X, .X, .Z, .W, .Z, .X, .X])
    (bs' := [.W, .W, .W, .Z, .X, .X, .X, .W, .Z, .X, .X]) (k := 87) (by decide) [] r
  simpa [den, LBlk.den] using h

end BB25
