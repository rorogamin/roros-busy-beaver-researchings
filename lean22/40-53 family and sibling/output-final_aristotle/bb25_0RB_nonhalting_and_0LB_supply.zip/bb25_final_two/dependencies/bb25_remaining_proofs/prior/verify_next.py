#!/usr/bin/env python3
"""Constructive return operations; finite verification is separate from proof."""
from __future__ import annotations
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'previous'))
import verify_more as m
old=m.old
value=m.value;decode=m.decode;good=m.good;dec=m.dec;adjusted=m.adjusted
Stack=tuple[str,...]

def reset_from(s:Stack,w:str)->Stack:
    """A pending-2 reset with its next pending-1 debt charged."""
    assert good(s),(s,w)
    for c in w:
        if c=='Y':s+=('Z',)
        elif c=='V':s+=('X',)
        elif c=='X':
            assert value(s)>=2,(s,w)
            s=dec(s+('W',))
        else:raise ValueError(c)
        assert good(s),(s,w)
    return s

def decn(s:Stack,n:int)->Stack:
    for _ in range(n):s=dec(s)
    return s

def odd_tail(s:Stack,r:int)->Stack:
    """A clean reset of P(s) Y^r R1, r>=1, from the left end."""
    assert good(s) and r>=1
    out=reset_from((),decode(s)+'Y'*r)+('W',)
    assert good(out)
    return m.drain3(out)

def return_word(r:int)->str:
    assert r>=2
    if r==2:return 'XYYV'
    if r==3:return 'YVYYV'
    n=r-2
    return 'Y'*n+'VYYVX'+'V'*(n-1)

def marker_zero(c:Stack,r:int)->Stack:
    """0RA / 2RB: one-use marker."""
    if r==2 and value(c)==0:
        assert adjusted(decode(c))>=4
        return odd_tail(c+('X','W'),3)
    out=reset_from(c+('X',),return_word(r))
    assert good(out) and value(out)>0 and out[-1]=='X'
    return out

def marker_two(c:Stack,r:int)->Stack:
    """2RA: first marker visit only changes K0 to K1."""
    if r==2:w='VYYV'
    else:
        n=r-1
        w='Y'*(n-1)+'VYYVX'+'V'*(n-1)
    out=reset_from(c+('X',),w)
    assert good(out) and value(out)>0 and out[-1]=='X'
    return out

def early_parameters(c:Stack)->tuple[Stack,int,int,int]:
    u=decode(c);t=reset_from((),u)
    f=value(t);B=adjusted(decode(t));h=u.count('Y')-u.count('X')-u.count('V')
    q=m.expansion_count(u)
    assert h>=2
    assert 3*(B+1)>=2**h*(2*4**q+1)
    if f%2==0:assert q>=1 and B>=11
    if f>=4 and f%8 in (0,2,4):assert q>=2 and B>=43
    return t,f,B,q

def marker_one(c:Stack,r:int)->Stack:
    """1RB: J1 erasure adds a fresh two-decrement/pop prefix."""
    a=value(c);b=adjusted(decode(c))
    assert b>=a+2
    if a%2==0:assert b>=a+4
    if a>=2:
        t=decn(c,2)+('W',)
        assert good(t)
        if r==2 and value(t)<2:
            z=t+('W',)
            assert good(z) and value(z)==0
            return odd_tail(z,3)
        out=reset_from(t,return_word(r))
        assert good(out) and value(out)>0 and out[-1]=='X'
        return out
    # An overflow before the extra two-decrement/pop completes.
    z=decn(c,a)
    t,f,B,q=early_parameters(z)
    assert f>=(4 if a==0 else 3)
    return marker_one_small(t,a,r)

def marker_one_small(t:Stack,a:int,r:int)->Stack:
    """1RB early-overflow repair, t=T(u) for a qualifying reset u."""
    assert a in (0,1) and r>=2
    d='X' if a==0 else 'V'
    t=reset_from(t,d)
    x=value(t);b=adjusted(decode(t))
    assert good(t) and x>=1
    if r==2:
        z=t+('X','W','Z','Z','W')
        assert m.clean(z)
        assert adjusted(decode(z))+2>=3*(value(z)+1)
        return m.drain3(z)
    if r==3:
        z=t+('Z','Z','W','Z','Z','W')
        assert m.clean(z)
        assert adjusted(decode(z))+2>=3*(value(z)+1)
        return m.drain3(z)
    n=r-2
    z=t+('Z',)*(n+1)+('W','X','Z')+('W',)*(n+1)
    assert m.clean(z)
    assert value(z)==2*x+1
    assert adjusted(decode(z))==2**(2*n+3)*(b+1)-3*2**n
    return m.drain3(z)

def one_deficit_repair(K:Stack,A:int,C:int,j:int)->Stack:
    """A non-Good K with clean decoder, followed by Z^(j+1) X."""
    assert value(K)==A and adjusted(decode(K))==C and C==A-1
    assert m.clean(K) and A>=3
    if A%2==0:assert A>=8
    core=K+('Z',)*j
    assert value(core)>=3
    t=decn(core,2)+('W',)
    assert m.clean(t)
    assert 4*(adjusted(decode(t))+1)>=3*(value(t)+1)
    return m.pending2(t,2)

def bounce_one(core:Stack,r:int)->Stack:
    """1LB. The input r>=2 is essential."""
    assert r>=2 and good(core)
    A=value(core)
    assert A>=2
    if A>=4:
        t=decn(core,4)+('W',)
        assert good(t)
        if value(t)>0:
            return m.pending2(dec(t),r)
        return reset_from((),decode(t)+'Y'*r+'V')
    c=decn(core,A)
    t,f,B,q=early_parameters(c)
    return bounce_one_small(t,r,A)

def bounce_one_small(t:Stack,r:int,A:int)->Stack:
    """1LB exceptional B-stack repair; t is a paid Dyck-prefix reset."""
    f=value(t);B=adjusted(decode(t))
    assert good(t) and r>=2 and A in (2,3)
    if A==3:
        assert f>=3
        K=t+('X','W')
    else:
        assert A==2 and f>=4
        K=dec(t+('W',))+('W',)
    out=K+('Z',)*(r-1)+('X',)
    assert m.clean(out) and value(out)>0
    if good(out):return out
    a=value(K);b=adjusted(decode(K))
    assert b==a-1
    if A==3:
        assert B==f and a==f
        if a%2==0:assert a>=12
    else:
        assert f%4==2 and f<=B<=f+3
        if a%2==0:assert f%8==2 and B>=43 and a>=10
        else:assert a>=3
    return one_deficit_repair(K,a,b,r-2)

def successor(member:str,s:Stack)->tuple[str,Stack,str]:
    assert member in ('0RA','2RB','2RA','1RB','1LB')
    assert good(s) and value(s)>0 and s[-1]=='X'
    k=0
    while s[-1]=='X':s=s[:-1];k+=1
    top,core=s[-1],s[:-1];r=k+1
    assert r>=2
    if top=='Z':
        kind,out=m.common_Z(core,r)
        assert kind!='B' or out[-1]=='X'
        return kind,out,'Z'
    assert top=='W' and value(core)>=2
    if member=='1LB':out=bounce_one(core,r)
    else:
        c=decn(core,2)
        if member in ('0RA','2RB'):out=marker_zero(c,r)
        elif member=='2RA':out=marker_two(c,r)
        else:out=marker_one(c,r)
    assert good(out) and value(out)>0 and out[-1]=='X'
    return 'B',out,'W'
