/-
# Halting criteria

The only halting transition of the family is `A4`, so a member halts exactly
when the head reads a `4` in state `A`; and a `4` only ever occurs inside a
block `F = 141` or `G = 241`.  The head always enters such a block on its
first symbol, and `A> 141 → <A 241`, `A> 241 → …` are perfectly harmless.
The machine dies only when the *phase* of the block decomposition has been
shifted by a pending digit `2>`, so that the head enters the block on its
second symbol.

This file records the resulting halting criteria; each of them holds for all
13 members of the family.
-/
import RequestProject.BB25.Blocks

namespace BB25

variable (b4 : Option (Sym × Dir × St))

/-! ## A pending digit in front of a `141`/`241` block -/

/-- `A> 2> 141`: a pending `2` in front of an `F` block kills the machine in
three steps. -/
theorem bhalt_P2_F (lt : List LB) (rt : List RB) :
    steps (M b4) 3 (BCfg.den ⟨lt, .Rt, .P2 :: .F :: rt⟩) = none := rfl

/-- `A> 2> 241`: a pending `2` in front of a `G` block kills the machine in
three steps. -/
theorem bhalt_P2_G (lt : List LB) (rt : List RB) :
    steps (M b4) 3 (BCfg.den ⟨lt, .Rt, .P2 :: .G :: rt⟩) = none := rfl

/-! ## Reaching the left end with a `141`/`241` block waiting

At the left end the machine performs `^11 <A → ^11 A> 2>`, creating a pending
digit.  If the block immediately to the right of the head is an `F` or a `G`,
this is fatal. -/

/-- `^11 <A 141`: the head arriving at the left end of the tape with an `F`
block waiting halts within 7 steps. -/
theorem halt_leftend_F (r : List Sym) :
    steps (M b4) 7 ⟨[1, 1], .A, .L, 1 :: 4 :: 1 :: r⟩ = none := rfl

/-- `^11 <A 241`: the head arriving at the left end of the tape with a `G`
block waiting halts within 7 steps. -/
theorem halt_leftend_G (r : List Sym) :
    steps (M b4) 7 ⟨[1, 1], .A, .L, 2 :: 4 :: 1 :: r⟩ = none := rfl

/--
`^11 03 <B1`: the state-`<B1` head reaching the block `03` that sits directly
on the left end of the tape halts within 9 steps.  Indeed `03 <B1 → <A 141`
creates the `F` block right at the left end, and `halt_leftend_F` applies.

This is the shortest description of the *only* way these machines are known
to be able to die: the `<B1` head must come back to the very bottom of the
left-hand counter.
-/
theorem halt_leftend_03_B1 (r : List Sym) :
    steps (M b4) 9 ⟨[3, 0, 1, 1], .B, .L, 1 :: r⟩ = none := rfl

/-! ## Block-level restatements -/

theorem bhalt_leftend_F (rt : List RB) :
    steps (M b4) 7 (BCfg.den ⟨[.L], .Lt, .F :: rt⟩) = none :=
  halt_leftend_F b4 (denR rt)

theorem bhalt_leftend_G (rt : List RB) :
    steps (M b4) 7 (BCfg.den ⟨[.L], .Lt, .G :: rt⟩) = none :=
  halt_leftend_G b4 (denR rt)

theorem bhalt_leftend_W_Bt (rt : List RB) :
    steps (M b4) 9 (BCfg.den ⟨[.W, .L], .Bt, rt⟩) = none :=
  halt_leftend_03_B1 b4 (denR rt)

/-! ## The `<B1` head meeting one of the extra left blocks

The members that push a `023`, `013` or `003` block onto the left stack die if
a later `<B1` sweep ever reaches that block: the `<B1` head reads the `3`,
writes the fatal `4` next to it (`B3 = 4LB`) and then bounces straight back
onto it in state `A`. -/

/-- `023 <B1` halts in 3 steps. -/
theorem halt_J_B1 (l r : List Sym) :
    steps (M b4) 3 ⟨3 :: 2 :: 0 :: l, .B, .L, 1 :: r⟩ = none := rfl

/-- `013 <B1` halts in 3 steps. -/
theorem halt_J1_B1 (l r : List Sym) :
    steps (M b4) 3 ⟨3 :: 1 :: 0 :: l, .B, .L, 1 :: r⟩ = none := rfl

/-- `003 <B1` halts in 5 steps. -/
theorem halt_J0_B1 (l r : List Sym) :
    steps (M b4) 5 ⟨3 :: 0 :: 0 :: l, .B, .L, 1 :: r⟩ = none := rfl

theorem bhalt_J_Bt (lt : List LB) (rt : List RB) :
    steps (M b4) 3 (BCfg.den ⟨.J :: lt, .Bt, rt⟩) = none :=
  halt_J_B1 b4 (denL lt) (denR rt)

theorem bhalt_J1_Bt (lt : List LB) (rt : List RB) :
    steps (M b4) 3 (BCfg.den ⟨.J1 :: lt, .Bt, rt⟩) = none :=
  halt_J1_B1 b4 (denL lt) (denR rt)

theorem bhalt_J0_Bt (lt : List LB) (rt : List RB) :
    steps (M b4) 5 (BCfg.den ⟨.J0 :: lt, .Bt, rt⟩) = none :=
  halt_J0_B1 b4 (denL lt) (denR rt)

/-! ## `Halts` corollaries -/

theorem halts_leftend_F (r : List Sym) : Halts (M b4) ⟨[1, 1], .A, .L, 1 :: 4 :: 1 :: r⟩ :=
  ⟨7, halt_leftend_F b4 r⟩

theorem halts_leftend_G (r : List Sym) : Halts (M b4) ⟨[1, 1], .A, .L, 2 :: 4 :: 1 :: r⟩ :=
  ⟨7, halt_leftend_G b4 r⟩

theorem halts_leftend_03_B1 (r : List Sym) : Halts (M b4) ⟨[3, 0, 1, 1], .B, .L, 1 :: r⟩ :=
  ⟨9, halt_leftend_03_B1 b4 r⟩

end BB25
