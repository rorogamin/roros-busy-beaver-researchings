# Formalization map: 0RA, 2RB, 2RA, 1RB, 1LB

## Status

This is a specification for a future Lean development, not a compiled Lean
proof. None of the new statements in PROOF_NEXT.md has been kernel-checked
here. The source project specifies `leanprover/lean4:v4.28.0`. Its Lean
files are included unchanged under `source_project/`.

Do not add the mathematical interface from the two previous packages as
axioms. It must be proved or imported from its eventual formalization.
The new results depend on that interface, especially prefix Good, paid
reset soundness, the common Z branch, and the counted-expansion lemma.

All names suggested below are NEW names, not claims that declarations with
those names already exist in the archive.

## 1. Source rules and representation bridges

The exact source declarations used are in `RequestProject/BB25/Family.lean`:

```
G_0RA  G_2RB  G_2RA  G_1RB  G_1LB
rule_011_A  rule_J_A  rule_001_A  rule_013_A
```

Useful existing counter interfaces include:

```
Counter.lean:
  cval_decrement, cval_overflow, brun_F_consumed,
  resetStep, brun_reset_step, resetRun, brun_reset, brun_reset_end,
  brun_count_step, brun_count_overflow, brun_reset_overflow
Overflow.lean:
  cdec, cdec_cval, brun_cdec_of, ofw, brun_overflow_of,
  cstackRun, brun_cstackRun
```

Inspect precise hypotheses rather than applying a counter theorem to a
non-counter stack. In particular, **a stack containing J, J1, K0, or K1
is not a pure CStack**. The proof avoids inventing values for those blocks.
It computes the ordinary suffix above a marker until the marker is read.

The proof/Python use bottom-first stacks, while the source block semantics
and `blocksim.py` use nearest-to-head first. Use an explicit adapter such as
`reverse s ++ [.L]`. A local suffix above an arbitrary base is similarly
reversed before concatenation. The permanent L is not an ordinary bit.
`<B1` includes a right-hand symbol 1 in its base-machine denotation.

## 2. Strengthen checkpoints rather than Good itself

Suggested predicate:

```
Normal s := Good s /\ 0 < value s /\ exists p, s = p ++ [X]
```

Its configuration is `L s <B1 Y R1`. Prove explicitly that the common Z
return and the protected drain have X-ending outputs. This follows from
their final clean reset ending in V, but was not part of the old checkpoint
statement and must not be omitted.

When stripping trailing X's, Normal gives k>=1 and r=k+1>=2. In a W branch
write the stack as C W X^k. Set c=D^2(C), a=value(c), b=decoderValue(c), and
prove the two margins

```
b >= a+2
Even a -> b >= a+4.
```

The second uses Good at C W, not just at C. A zero-bit closing pop decodes
to X and requires `b(C)/2 - 1 >= value(C)/2`.

## 3. Contextual counter lemmas above markers

A key formalization bridge is a context-parametric finite excursion theorem:
when an ordinary suffix has positive local counter, a left excursion
finishes inside that suffix and does not inspect its arbitrary left base.
When its counter is zero, it traverses the suffix, deposits its paired
word, and reaches the base. Build this from the contextual multi-visit or
transparent-pair relations in Stride.lean and Pairing.lean.

Do not apply the whole-stack CStack theorem with a marker silently treated
as L. The contextual version is what licenses the shadow calculation in
PROOF_NEXT.md Sections 3-6.

For the K0/K1 calculation in 2RA, prove an explicit shadow correspondence:
K0 behaves as the leading one bit until its first visit, where it becomes
K1; the leading bit remains unmatched throughout the finite drain; at the
final visit K1 supplies X P2 rather than emitting the leading decoder Y.
No rule for a hypothetical matched K0/K1 is needed.

## 4. Reset above a Good base and phase debt

Suggested construction `paidResetFrom s w`, recursively:

```
Y: append Z
V: append X
X: append W, then D
```

It agrees with the original paid reset when s is empty. Prove Good
preservation and its value law, conditional on cleanliness from value(s).
Use integer reset arithmetic (division by positive two), not a Nat fold
with truncated subtraction on dirty words.

Prove the endpoint theorem at A>P2 w R, with w ending in V and positive
adjusted final value: the physical run completes at a B checkpoint whose
stack is exactly paidResetFrom s w and whose last block is X.

A paid stack is not necessarily the physical stack at the moment a word
prefix finishes. The pending-1 debt may be discharged by the next turn.
The endpoint theorem must track this phase explicitly. In the exceptional
cases, the source stack before an unpaid debt really has counter zero;
these are not interchangeable descriptions.

For U, use the existing resetStep branch: the paid stack effect is an
uncharged W append. It is legal in the new uses because each has enough
unmatched bits. It need not preserve Good.

## 5. Explicit local drain

Define

```
Omega n = X Z^(n-1) W X Z W^n,  n>=2.
```

Prove the complete-stack formula after j positive drain rounds,
1<=j<=n-1:

```
D^2(Z^n) W Z Z W
  -> Z^(n-j-1) X Z^j W X Z W^(j+1).
```

Its value is `2^(n-j)-2` and its unmatched bits are `Z^(n-j-1) X`.
The induction is a direct borrow on the last unmatched ZX. At j=n-1,
only the first X remains unmatched. Therefore no W consumes the leading
bit, a fact essential to the 2RA shadow correspondence.

Then prove

```
P(Omega n) = Y^n V Y Y V X V^(n-2).
```

The two clean reset polynomials are equations (12)-(13) in PROOF_NEXT.md.
They can be established by explicit folds of the four reset maps, with
powers-of-two identities, rather than by base-machine simulation.

## 6. One-use marker and member return lemmas

For r>=2 prove the context-parametric marker visit word

```
r=2: X Y Y V
r=3: Y V Y Y V
r>=4: Y^(r-2) V Y Y V X V^(r-3).
```

The intermediate B checkpoint is `c M Z^(r-1) X <B1 YR1`. Its B sweep
reads Z, never M. This fact, not a conjecture about avoiding unusual
blocks, protects the marker. The finite run then reaches `c M <A w R`.

For 0RA/2RB apply rule_011_A/rule_J_A and the reset-from-base lemma.
The only exception is r=2,value(c)=0; prove Good(c X W) using b(c)>=4,
then the exact odd-terminal overflow `P(c X W) Y^3 R1`.

For 2RA use the K0/K1 shadow lemma. The final words after cX A>P2 are

```
r=2: V Y Y V
r>=3: Y^(r-2) V Y Y V X V^(r-2).
```

These are all clean from zero and positive, so there is no exceptional
reset branch. This gives a short member proof after the contextual lemmas.

The 0RA/2RB twin isomorphism is in Twins.lean (`bstep_twin`,
`neverStuck_twin`). Be careful: `not_halts_twins` takes a NeverStuck
hypothesis, not an arbitrary nonhalting theorem. Our return theorem also
allows a certified spinout, which may leave the block simulator's domain.
Either give the direct shared proof for both members, or transport the
finite runs and their spinout endpoints explicitly. Do not replace this
obligation by an unsupported invocation of `not_halts_twins`.

## 7. Strengthen the counted-expansion corollary

Reuse the previous stateful Q transducer and expansion count q. The first
counter that determines X parity must be threaded through concatenations.
The existing mathematical bound is

```
3*(B+1) >= 2^h*(2*4^q+1), h>=2.
```

Add:

```
Even f -> B>=11
f>=4 /\ f % 8 in {0,2,4} -> B>=43.
```

For q=1, the chain normal form from the previous formalization map gives
f=2^h-2 or 2^(h+2)-2 whenever f is even. These are 6 modulo 8, except
h=2,f=2. Thus the new implication is a small extension of an already
required structural argument, not a new simulation lemma.

## 8. Generic one-unit repair

For a decoder-clean K with value A>=3 and decoderValue A-1, assume
`Even A -> A>=8`. Prove a finite normal return from

```
K Z^(j+1) X <B1 Y R1, j>=0.
```

The Z branch spends two decrements and a pop on K Z^j. Its values are
computed in Section 8 of the proof. In the odd case the tail condition
reduces to `2^j*(13*A-3)-2 >= 0`; in the even case j=0 and it reduces to
A>=8. Use decoder-cleanliness, not Good, during this repair. The output
comes from the protected drain and is Good and X-ending.

## 9. 1LB low-counter repair

For a W source C W X^k, let A=value(C), r=k+1>=2.

A>=4: use four decrements and a pop, then either pay pending 1 or overflow
at zero. These are the direct cases.

A=3: first B checkpoint has core K=t X W, where t=T(u), f>=3. Only its
last prefix can fail Good, and failure means B=f and decoderValue(K)=f-1.
If f is even, the earlier expansion bound gives f>=12.

A=2: first B checkpoint has core K=D(t W) W, where f>=4. The table by
f modulo four in PROOF_NEXT.md is exhaustive. The only failing row is
f=4q+2, with B in [f,f+3], value(K)=q and decoderValue(K)=q-1.
Odd q must be at least three (q=1 contradicts B>=11); even q must be at
least ten (the new mod-8 barrier gives B>=43). Apply the generic repair.

Both first checkpoints end in Z^(r-1)X with r>=2. There is no need to
handle r=1; allowing it would invalidate the theorem.

## 10. 1RB early reset and odd terminal

At J1's first visit apply rule_013_A, giving c <A X P2 w_r R.
For value(c)>=2, spend two decrements and a pop, then reset w_r above the
resulting Good stack. The r=2, value(c) in {2,3,4,5} failures all leave a
Good zero stack z and the odd-terminal reset P(z)Y^3R1.

For value(c) in {0,1}, use the exact phase-sensitive word identity

```
P2 w_r R = h_r R1,
h_2 = V U Y Y,
h_3 = Y Y U Y Y,
h_r = Y^(r-1) U Y Y X U^(r-3), r>=4.
```

The total left-end reset is u d h_r R1, with d=X or V. These are literal
base-tape identities, not necessarily bstep shifts available in a
left-facing configuration. Prove equality of denotations explicitly.

After resetting u d, the three stack formulas and decoder values at A>R
are in Section 10's table. Prove their legality, matching, and cleanliness.
For r>=4 the paid decrement at X changes the last freshly pushed one to
zero, without borrowing into the initial stack s.

The r=2 drain inequality is `4*b_s >= 3*(x+1)`. Split f into odd, even
>=8, f=4, and f=6. The barriers 43 and 11 settle the two small even
values. The other r cases satisfy Protected3 directly.

## 11. Final induction and checks

State a finite-return theorem from Normal, allowing either another Normal
checkpoint or a previously certified spinout. Every return includes at
least one `X <B1` transition costing six base steps, so there is a uniform
positive cost. Iterate returns to exclude a finite halting time; handle
the spinout alternative using its machine-level theorem.

Replay the 156-step blank seed for each member or prove it once with B4
unused. Do not use a finite survival certificate as the induction step.

Before claiming completion, build the actual Lean project and inspect the
new nonhalting theorems with `#print axioms`. The included Python checks
and source copies do not establish Lean compilation. No new `.lean`
nonhalting theorem is supplied in this package.
