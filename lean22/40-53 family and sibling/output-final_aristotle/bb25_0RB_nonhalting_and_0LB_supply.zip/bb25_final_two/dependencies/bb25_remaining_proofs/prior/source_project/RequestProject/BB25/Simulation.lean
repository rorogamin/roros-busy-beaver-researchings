/-
# Certified lower bounds on the running time of the 13 members

`Blocks.lean` provides a *sound* accelerated simulator: every block step is a
known number of base steps of the Turing machine.  Running it inside the Lean
kernel therefore certifies that a member of the family has not halted within
a given (astronomically large) number of steps.

The simulator used here, `bloop`, is a tail-recursive variant of
`BB25.bstepsFast` which the kernel can evaluate without exhausting its stack.
-/
import RequestProject.BB25.Blocks

namespace BB25

/-- Tail-recursive iteration of the accelerated block simulator, accumulating
the number of base steps in `acc`. -/
def bloop (b4 : Option (Sym × Dir × St)) : ℕ → BCfg → ℕ → Option (BCfg × ℕ)
  | 0, c, acc => some (c, acc)
  | n + 1, c, acc =>
      match bstepFast b4 c with
      | some (c', k) => bloop b4 n c' (acc + k)
      | none => none

theorem bloop_sound (b4 : Option (Sym × Dir × St)) :
    ∀ (n : ℕ) (c : BCfg) (acc : ℕ) (c' : BCfg) (k : ℕ),
      bloop b4 n c acc = some (c', k) →
        ∃ m, k = acc + m ∧ steps (M b4) m c.den = some c'.den := by
  intro n
  induction n with
  | zero =>
      intro c acc c' k h
      simp only [bloop, Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, rfl⟩ := h
      exact ⟨0, by simp⟩
  | succ n ih =>
      intro c acc c' k h
      rw [bloop] at h
      cases hb : bstepFast b4 c with
      | none => rw [hb] at h; exact absurd h (by simp)
      | some p =>
          obtain ⟨c₁, k₁⟩ := p
          rw [hb] at h
          obtain ⟨m, hm, hs⟩ := ih c₁ (acc + k₁) c' k h
          refine ⟨k₁ + m, by omega, ?_⟩
          exact steps_trans (bstepFast_sound b4 c c₁ k₁ hb) hs

/-- `checkSim b4 n m` runs the accelerated simulator for `n` block steps from
the initial configuration and checks that this covers at least `m` base steps
of the Turing machine. -/
def checkSim (b4 : Option (Sym × Dir × St)) (n m : ℕ) : Bool :=
  match bloop b4 n binit 0 with
  | some (_, k) => m ≤ k
  | none => false

/--
**Certified lower bound.**  If `checkSim b4 n m` succeeds then the member `b4`
of the family has not halted after `m + 5` steps (the `5` are the steps that
lead from the blank tape to the block configuration `^11 A> 1$`).
-/
theorem not_halts_of_checkSim {b4 : Option (Sym × Dir × St)} {n m : ℕ}
    (h : checkSim b4 n m = true) (j : ℕ) (hj : j ≤ m + 5) :
    steps (M b4) j init ≠ none := by
  rw [checkSim] at h
  cases hb : bloop b4 n binit 0 with
  | none => rw [hb] at h; simp at h
  | some p =>
      obtain ⟨c', k⟩ := p
      rw [hb] at h
      simp only [decide_eq_true_eq] at h
      obtain ⟨m', hm', hs⟩ := bloop_sound b4 n binit 0 c' k hb
      subst hm'
      simp only [Nat.zero_add] at h hs ⊢
      exact not_halts_within (steps_trans (init_five b4) hs) j (by omega)

/-! ## The 13 members

Each bound below is obtained by running the accelerated simulator for 2000
block steps inside the kernel. -/

set_option maxRecDepth 10000
set_option maxHeartbeats 1000000

theorem long_run_2LB (j : ℕ) (hj : j ≤ 2 ^ 54) : steps (M b4_2LB) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 54) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_2RB (j : ℕ) (hj : j ≤ 2 ^ 79) : steps (M b4_2RB) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 79) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_1LB (j : ℕ) (hj : j ≤ 2 ^ 54) : steps (M b4_1LB) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 54) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_1RB (j : ℕ) (hj : j ≤ 2 ^ 46) : steps (M b4_1RB) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 46) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_0LB (j : ℕ) (hj : j ≤ 2 ^ 29) : steps (M b4_0LB) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 29) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_0RB (j : ℕ) (hj : j ≤ 2 ^ 55) : steps (M b4_0RB) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 55) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_3RA (j : ℕ) (hj : j ≤ 2 ^ 54) : steps (M b4_3RA) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 54) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_2LA (j : ℕ) (hj : j ≤ 2 ^ 39) : steps (M b4_2LA) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 39) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_2RA (j : ℕ) (hj : j ≤ 2 ^ 55) : steps (M b4_2RA) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 55) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_1LA (j : ℕ) (hj : j ≤ 2 ^ 66) : steps (M b4_1LA) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 66) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_1RA (j : ℕ) (hj : j ≤ 2 ^ 52) : steps (M b4_1RA) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 52) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_0LA (j : ℕ) (hj : j ≤ 2 ^ 52) : steps (M b4_0LA) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 52) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

theorem long_run_0RA (j : ℕ) (hj : j ≤ 2 ^ 79) : steps (M b4_0RA) j init ≠ none :=
  not_halts_of_checkSim (n := 2000) (m := 2 ^ 79) (by decide) j (le_trans hj (Nat.le_add_right _ 5))

end BB25
