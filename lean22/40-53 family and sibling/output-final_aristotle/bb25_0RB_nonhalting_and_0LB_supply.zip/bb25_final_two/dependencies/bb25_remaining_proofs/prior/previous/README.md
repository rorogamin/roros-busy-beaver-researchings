# Additional BB(2,5) prefix-safety proofs

## Results

`PROOF_MORE.md` gives mathematical nonhalting arguments for three additional
members of the user's family: **1RA, 0LA, 2LB**. Together with the previous
proposed arguments for 3RA and 2LA, these cover five members.

The new results are **not Lean-certified**. Their dependency on the previous
common Z-branch proof and the supplied Aristotle counter/block theorems is
stated explicitly. No claim is made for the remaining eight members.

## Files

- `PROOF_MORE.md`: complete new derivation, including low-counter repairs.
- `FORMALIZATION_MORE.md`: precise formalization dependencies and cautions.
- `verify_more.py`: constructive return calculation and exact comparisons.
- `check_more_components.py`: independent component and base-machine checks.
- `verification_results_more.json`, `component_results_more.json`: recorded
  completed finite checks; all assertions passed.
- `verification_log_more.txt`: log of the completed main verification run.
- `previous/`: unchanged prior proof, formalization map and helper code.
- `reference_tools/`: three unchanged Python files from the Aristotle archive.
- `reference_lean/Family.lean`: unchanged original G-rule theorem source;
  this isolated reference copy is not a standalone Lean project.
- `PROVENANCE.json` and `SHA256SUMS.json`: input and output integrity records.

## Reproduce

Use Python 3.10 or newer and its standard library, from this directory:

```sh
python verify_more.py --max-length 10 --random 200
python check_more_components.py
```

The first recorded run compares 31,259 exhaustive Good positive stacks and
200 larger randomized stacks, for each of three members: 94,377 exact
member-specific return comparisons. It also checks all three shared blank
seeds directly on the base machines.

The component run includes 1,377,307 Dyck-prefix bound checks, 5,880 repair
instances, 3,285 weaker-drain instances, and 3,000 direct block-to-base
transition comparisons.

These finite computations are validation, not the infinite-run proof.
The latter is the quantified argument in `PROOF_MORE.md`.

## Important negative control

For 1LB the nonblank Good checkpoint `L XZXWXW <B1 YR1` halts. This
refutes extending the same universal checkpoint theorem to 1LB unchanged.
It is NOT a claim that 1LB halts from blank tape.
