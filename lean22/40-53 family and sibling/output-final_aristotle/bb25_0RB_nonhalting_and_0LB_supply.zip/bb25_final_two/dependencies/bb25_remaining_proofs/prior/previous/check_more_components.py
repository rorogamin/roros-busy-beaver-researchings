#!/usr/bin/env python3
"""Additional finite checks for the pair-expansion and repair lemmas."""
from __future__ import annotations
from collections import Counter
import json
from pathlib import Path
import sys
from verify_more import *

counts=Counter()

# Count the expanding closes while maintaining both reset values.
def words(w:str,h:int,a:int,b:int,q:int,limit:int)->None:
    assert 3*(b+1)>=2**h*(2*4**q+1),(w,h,a,b,q)
    counts['clean_Dyck_prefix_bound_checks']+=1
    if h>=2 and a%4==0:
        # a=0 also cannot arise with q<=1 and h>=2.
        assert q>=2 and b>=43,(w,h,a,b,q)
        counts['divisible_by_four_barrier_checks']+=1
    if h>=2 and a==b and a%2==0:
        assert b>=12,(w,h,a,b,q)
        counts['even_equality_barrier_checks']+=1
    if h>=2 and a>=4 and len(w)<=9:
        t=reset_paid(w)
        assert adjusted(decode(t))==b
        for r in range(1,5):
            for member,first,repair in (
                ('0LA',t+('X','W')+('Z',)*(r-1)+('X',),temporary_zero_late),
                ('2LB',t+('W','W')+('Z',)*(r-1)+('X',),temporary_double_pop)):
                out=repair(t,r)
                if good(first):assert out==first
                else:
                    ans=reference_return(member,first)
                    assert ans.kind=='B' and ans.stack==out and ans.boundaries==1
                    counts['independent_repair_reference_checks']+=1
                assert good(out) and value(out)>0
                counts['repair_lemma_instances']+=1
    if len(w)==limit:return
    words(w+'Y',h+1,2*a+1,2*b+1,q,limit)
    if h:
        words(w+'V',h-1,2*a,2*b+1,q+1,limit)
        if a>=2:words(w+'X',h-1,a//2-1,2*b if a%2 else b//2-1,q+(a%2),limit)

words('',0,0,0,0,16)

# Check the weaker drain lemma on clean (not necessarily Good) stacks.
for n in range(1,9):
    for s in product('XZW',repeat=n):
        if not clean(s):continue
        if adjusted(decode(s))+2<3*(value(s)+1):continue
        out=drain3(s)
        assert good(out) and value(out)>0
        counts['weaker_drain_stack_instances']+=1
        if not good(s):counts['weaker_drain_nonGood_instances']+=1

# Base-machine cross-checks of the archive's transition rules.
for member in ('1RA','0LA','2LB'):
    assert ref.crosscheck(member,1000)=='ok'
    counts['base_block_transition_checks']+=1000

# A genuine halting configuration refutes the unqualified Good return claim
# for 1LB. This is NOT a blank-tape halting assertion.
import sim as base
bad=tuple('XZXWXW')
assert good(bad) and value(bad)>0
c=ref.denote(list(reversed(bad))+['L'],'B',['Y','R1'])
m=base.machine(ref.machineB4('1LB'))
halt_at=None
for i in range(1,10001):
    c=base.step(m,c)
    if c is None:
        halt_at=i;break
assert halt_at is not None
result={'status':'all assertions passed','counts':dict(counts),
    'word_max_length':16,'repair_word_max_length':9,
    '1LB_counterexample':{'bottom_first_stack':''.join(bad),
      'value':value(bad),'good':True,'base_step_call_returning_none':halt_at,
      'scope':'specified nonblank B checkpoint, NOT the blank run'},
    'scope':'finite component validation; universal proofs are in PROOF_MORE.md'}
(HERE/'component_results_more.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
