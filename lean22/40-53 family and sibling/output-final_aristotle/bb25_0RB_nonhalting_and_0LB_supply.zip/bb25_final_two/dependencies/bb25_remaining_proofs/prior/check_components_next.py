#!/usr/bin/env python3
"""Finite tests of new structural barriers, symbolic drains, and repairs."""
from verify_next import *
from check_next import reference,reference_cfg
from collections import Counter
import json,time
counts=Counter();start=time.time()

def shifted_return_word(r):
    if r==2:return 'VUYY'
    if r==3:return 'YYUYY'
    n=r-2
    return 'Y'*(n+1)+'UYYX'+'U'*(n-1)

def words(w,h,a,b,q,limit):
    assert 3*(b+1)>=2**h*(2*4**q+1)
    counts['clean_Dyck_prefixes_checked']+=1
    if h>=2 and a%2==0:
        assert q>=1 and b>=11
        counts['even_value_barrier_checks']+=1
    if h>=2 and a>=4 and a%8 in (0,2,4):
        assert q>=2 and b>=43
        counts['new_mod8_barrier_checks']+=1
    if h>=2 and a==b and a%2==0:
        assert a>=12
        counts['even_equality_barrier_checks']+=1
    if h>=2 and a>=3 and len(w)<=9:
        t=reset_from((),w)
        assert value(t)==a and adjusted(decode(t))==b
        for r in range(2,7):
            for A in (2,3):
                if A==2 and a<4:continue
                K=t+('X','W') if A==3 else dec(t+('W',))+('W',)
                first=K+('Z',)*(r-1)+('X',)
                out=bounce_one_small(t,r,A)
                assert good(out) and value(out)>0 and out[-1]=='X'
                if good(first):assert first==out
                else:
                    rk,rs,_=reference('1LB',first)
                    assert (rk,rs)==('B',out),(w,r,A,first,out,(rk,rs))
                    counts['1LB_nonGood_repair_exact_comparisons']+=1
                counts['1LB_exceptional_stack_instances']+=1
            for low in (0,1):
                if low==0 and a<4:continue
                d='X' if low==0 else 'V'
                out=marker_one_small(t,low,r)
                rt=['P2']+list(w+d+shifted_return_word(r))+['R1']
                rk,rs,_=reference_cfg('1RB',['L'],'R',rt)
                assert (rk,rs)==('B',out),(w,r,low,out,(rk,rs))
                counts['1RB_early_reset_exact_comparisons']+=1
    if len(w)==limit:return
    words(w+'Y',h+1,2*a+1,2*b+1,q,limit)
    if h:
        words(w+'V',h-1,2*a,2*b+1,q+1,limit)
        if a>=2:words(w+'X',h-1,a//2-1,2*b if a%2 else b//2-1,q+a%2,limit)

words('',0,0,0,0,16)
print('word checks done',dict(counts),'seconds',round(time.time()-start,2),flush=True)
for n in range(2,129):
    s=decn(('Z',)*n,2)+tuple('WZZW')
    assert value(s)==2**n-3
    for j in range(1,n):
        assert value(s)>0
        s=dec(s)+('W',)
        assert value(s)==2**(n-j)-2
        counts['symbolic_drain_round_instances']+=1
    assert s==('X',)+('Z',)*(n-1)+('W','X','Z')+('W',)*n
    assert decode(s)=='Y'*n+'VYYVX'+'V'*(n-2)
    for a in range(10):
        w=decode(s)+'V'
        assert adjusted(w,a)==2**(2*n+2)*(a+1)-3*2**n
        w=w[1:]
        assert adjusted(w,a)==2**(2*n+1)*(a+1)-3*2**n
        counts['closed_reset_polynomial_instances']+=2
    counts['symbolic_drain_stack_instances']+=1
# New invariant counterexamples for the three still-unsettled members.
import sim as base
obstructions={}
s=tuple('ZXZWWX')
assert good(s) and value(s)>0 and s[-1]=='X'
for member in ('1LA','0RB'):
    machine=base.machine(m.ref.machineB4(member))
    c=m.ref.denote(list(reversed(s))+['L'],'B',['Y','R1'])
    for i in range(1,10001):
        c=base.step(machine,c)
        if c is None:break
    assert c is None
    obstructions[member]={'stack_bottom_first':''.join(s),'value':value(s),
          'defined_base_transitions':i-1,'first_step_call_returning_none':i,
          'not_a_blank_tape_halting_claim':True}
result={'status':'all assertions passed','scope':'finite component checks, not a Lean certificate',
        'counts':dict(counts),'word_max_length':16,'repair_word_max_length':9,
        'symbolic_drain_max_n':128,'obstructions':obstructions,
        'elapsed_seconds':round(time.time()-start,3)}
(HERE/'component_results_next.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
