#!/usr/bin/env python3
"""Exact finite comparisons of constructive returns and archive simulation."""
from verify_next import *
from itertools import product
from collections import Counter
import argparse,json,random,time
ref=m.ref
MEMBERS=('0RA','2RB','2RA','1RB','1LB')

def reference_cfg(member,lt,st,rt,limit=200000):
    for i in range(limit):
        if st=='L' and lt==['L']:
            raw=ref.denote(lt,st,rt)[3]
            if raw[:4]==[1,1,2,2]:return 'spinout',(),i
        if i and st=='B' and rt==['Y','R1']:
            t=tuple(reversed(lt[:-1]))
            if good(t) and value(t)>0 and t[-1]=='X':return 'B',t,i
        stride=ref.stride(lt) if st=='L' else None
        if stride is not None:lt,_=stride;st='R'
        else:lt,st,rt,_=ref.bstep(member,lt,st,rt)
    raise AssertionError(('reference limit',member,lt,st,rt))

def reference(member,s,limit=200000):
    return reference_cfg(member,list(reversed(s))+['L'],'B',['Y','R1'],limit)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--max-length',type=int,default=11)
    ap.add_argument('--random',type=int,default=100)
    ap.add_argument('--output',type=Path,default=HERE/'verification_results_next.json')
    args=ap.parse_args()
    if not 2<=args.max_length<=13:ap.error('max-length must be in 2..13')
    if args.random<0:ap.error('random must be nonnegative')
    counts=Counter();branches=Counter();start=time.time();maxsteps=0
    def check(s,category):
        nonlocal maxsteps
        assert good(s) and value(s)>0 and s[-1]=='X'
        core=s;k=0
        while core[-1]=='X':core=core[:-1];k+=1
        for mem in MEMBERS:
            kind,out,branch=successor(mem,s)
            rk,rs,steps=reference(mem,s)
            assert (kind,out)==(rk,rs),(mem,s,(kind,out),(rk,rs))
            maxsteps=max(maxsteps,steps)
            counts[mem+'_exact_returns']+=1
            branches[mem+':'+branch]+=1
            if branch=='W':
                a=value(core[:-1]);r=k+1
                branches[mem+':W:counter_'+(str(a) if a<=7 else '8+')+':r_'+(str(r) if r<=3 else '4+')]+=1
        counts[category+'_initial_stacks']+=1
    for n in range(2,args.max_length+1):
        for p in product('XZW',repeat=n-1):
            s=p+('X',)
            if not good(s) or value(s)==0:continue
            check(s,'exhaustive')
        print('length',n,dict(counts),'seconds',round(time.time()-start,2),flush=True)
    rng=random.Random(2026091603)
    for ri in range(args.random):
        s=()
        for _ in range(rng.randrange(20,181)):
            if value(s)>=2 and rng.random()<.4:s=dec(dec(s))+('W',)
            else:s+=(rng.choice(('X','Z')),)
        if value(s)==0:s+=('Z',)
        s+=('X',)
        check(s,'random')
        if ri%10==9:print('random',ri+1,'seconds',round(time.time()-start,2),flush=True)
    for a in (*range(2,18),33,65):
        C=tuple('XX'+''.join('Z' if b=='1' else 'X' for b in bin(a)[2:]))
        assert good(C+('W',))
        for r in (2,3,4,8,16,32):
            s=C+('W',)+('X',)*(r-1)
            check(s,'long_tail')
        print('long-tail core',a,'seconds',round(time.time()-start,2),flush=True)
    import sim as base
    seed=tuple('ZZZXXX')
    for mem in MEMBERS:
        machine=base.machine(ref.machineB4(mem));c=([],base.A,'R',[])
        for _ in range(156):
            c=base.step(machine,c)
            assert c is not None
        assert c==ref.denote(list(reversed(seed))+['L'],'B',['Y','R1'])
        assert ref.crosscheck(mem,1000)=='ok'
        counts[mem+'_base_block_rules_checked']+=1000
        counts[mem+'_blank_seed_checked']+=1
    results={'status':'all assertions passed','scope':'finite validation, not a Lean certificate',
             'max_exhaustive_stack_length':args.max_length,'random_seed':2026091603,
             'counts':dict(counts),'branches':dict(branches),'max_reference_steps':maxsteps,
             'elapsed_seconds':round(time.time()-start,3)}
    args.output.write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2),flush=True)
if __name__=='__main__':main()
