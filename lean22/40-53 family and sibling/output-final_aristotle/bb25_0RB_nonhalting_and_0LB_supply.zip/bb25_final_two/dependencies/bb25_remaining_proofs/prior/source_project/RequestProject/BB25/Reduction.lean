/-
# Reducing non-halting to the block system

The block simulator of `Blocks.lean` is sound, so running it certifies lower
bounds on the running time (`Simulation.lean`).  This file proves the
qualitative counterpart:

> if the block simulation never gets stuck, the Turing machine never halts.

This is not completely obvious, because some block steps cost `0` base steps:
the *pending digit* rules `1>`, `2>` are pure re-parsings of the tape.  The
proof therefore exhibits a measure (`BB25.pmeasure`) which strictly decreases
along every zero-cost block step, so that positive progress is always made
after finitely many block steps.

Combined with `BB25.bstep`, this turns the halting problem for the 13 members
into the purely combinatorial question of whether the block simulation ever
reaches one of the finitely many undefined patterns -- a pending digit meeting
a `141`/`241` block, or the head reaching the left end of the tape in state
`<B1` (in which case the machine in fact spins out and does not halt either,
see `BB25.not_halts_leftend_B1`).
-/
import RequestProject.BB25.Blocks

namespace BB25

/-! ## A measure for the zero-cost (pending digit) steps -/

/-- The position of the first pending digit in a list of right blocks
(`0` if the list is empty). -/
def pidx : List RB → ℕ
  | [] => 0
  | .P1 :: _ => 0
  | .P2 :: _ => 0
  | _ :: bs => pidx bs + 1

theorem pidx_le : ∀ rt : List RB, pidx rt ≤ rt.length
  | [] => Nat.le_refl 0
  | .P1 :: _ => Nat.zero_le _
  | .P2 :: _ => Nat.zero_le _
  | .R :: bs | .R1 :: bs | .R2 :: bs | .U :: bs | .V :: bs | .X :: bs
  | .Y :: bs | .F :: bs | .G :: bs | .N1 :: bs | .N2 :: bs => by
      simpa [pidx] using pidx_le bs

/-- The measure that decreases along zero-cost block steps. -/
def pmeasure (c : BCfg) : ℕ := 2 * c.rt.length - pidx c.rt

/-- The family-specific `A> 241` step always costs at least one base step. -/
theorem gStep_pos {b4 : Option (Sym × Dir × St)} {lt : List LB} {rest : List RB}
    {c' : BCfg} {k : ℕ} (h : gStep b4 lt rest = some (c', k)) : 0 < k := by
  rcases b4 with _ | ⟨w, d, q⟩
  · simp [gStep] at h
  · fin_cases w <;> cases d <;> cases q <;>
      first
        | (simp only [gStep, Option.some.injEq, Prod.mk.injEq] at h
           obtain ⟨-, rfl⟩ := h
           omega)
        | simp [gStep] at h

/-- Every zero-cost block step strictly decreases `pmeasure`. -/
theorem pmeasure_lt_of_zero {b4 : Option (Sym × Dir × St)} {c c' : BCfg}
    (h : bstep b4 c = some (c', 0)) : pmeasure c' < pmeasure c := by
  unfold bstep at h
  split at h <;>
    first
      | (exact absurd (gStep_pos h) (by omega))
      | (rw [Option.some.injEq, Prod.mk.injEq] at h
         obtain ⟨rfl, -⟩ := h
         simp only [pmeasure, pidx, List.length_cons, List.length_nil]
         omega)
      | simp at h

/-! ## Never getting stuck -/

/-- The block simulation from `c` survives any number of steps. -/
def NeverStuck (b4 : Option (Sym × Dir × St)) (c : BCfg) : Prop :=
  ∀ n, (bsteps b4 n c).isSome

theorem NeverStuck.step {b4 : Option (Sym × Dir × St)} {c : BCfg}
    (h : NeverStuck b4 c) : ∃ c' k, bstep b4 c = some (c', k) := by
  have := h 1
  rw [bsteps] at this
  cases hb : bstep b4 c with
  | none => rw [hb] at this; simp at this
  | some p => obtain ⟨d, j⟩ := p; exact ⟨d, j, rfl⟩

theorem NeverStuck.tail {b4 : Option (Sym × Dir × St)} {c c' : BCfg} {k : ℕ}
    (h : NeverStuck b4 c) (hb : bstep b4 c = some (c', k)) : NeverStuck b4 c' := by
  intro n
  have := h (n + 1)
  rw [bsteps, hb] at this
  simpa using this

/-- Composition of block runs. -/
theorem bsteps_comp {b4 : Option (Sym × Dir × St)} :
    ∀ {m n : ℕ} {c c₁ c₂ : BCfg} {k₁ k₂ : ℕ},
      bsteps b4 m c = some (c₁, k₁) → bsteps b4 n c₁ = some (c₂, k₂) →
        bsteps b4 (m + n) c = some (c₂, k₁ + k₂) := by
  intro m
  induction m with
  | zero =>
      intro n c c₁ c₂ k₁ k₂ h1 h2
      simp only [bsteps, Option.some.injEq, Prod.mk.injEq] at h1
      obtain ⟨rfl, rfl⟩ := h1
      simpa using h2
  | succ m ih =>
      intro n c c₁ c₂ k₁ k₂ h1 h2
      rw [bsteps, Option.bind_eq_some_iff] at h1
      obtain ⟨⟨d, j⟩, hb, h1⟩ := h1
      rw [Option.map_eq_some_iff] at h1
      obtain ⟨⟨d', j'⟩, hr, he⟩ := h1
      simp only [Prod.mk.injEq] at he
      obtain ⟨rfl, rfl⟩ := he
      have : bsteps b4 (m + n) d = some (c₂, j' + k₂) := ih hr h2
      rw [show m + 1 + n = (m + n) + 1 by omega, bsteps, hb]
      simp only [Option.bind_some, this, Option.map_some]
      exact congrArg some (by simp [Prod.ext_iff]; omega)

/-- From a configuration whose simulation never gets stuck, some finite number
of block steps makes genuine progress. -/
theorem exists_pos_cost {b4 : Option (Sym × Dir × St)} :
    ∀ (c : BCfg), NeverStuck b4 c → ∃ n c' k, bsteps b4 n c = some (c', k) ∧ 0 < k := by
  intro c
  induction hm : pmeasure c using Nat.strong_induction_on generalizing c with
  | _ m ih =>
    intro hns
    obtain ⟨c₁, k₁, hb⟩ := hns.step
    rcases Nat.eq_zero_or_pos k₁ with rfl | hk
    · have hlt : pmeasure c₁ < pmeasure c := pmeasure_lt_of_zero hb
      obtain ⟨n, c', k, hrun, hkpos⟩ :=
        ih (pmeasure c₁) (hm ▸ hlt) c₁ rfl (hns.tail hb)
      refine ⟨n + 1, c', k, ?_, hkpos⟩
      rw [show n + 1 = 1 + n by omega]
      have h1 : bsteps b4 1 c = some (c₁, 0) := by
        rw [bsteps, hb]
        simp [bsteps]
      simpa using bsteps_comp h1 hrun
    · refine ⟨1, c₁, k₁, ?_, hk⟩
      rw [bsteps, hb]
      simp [bsteps]

/-- `NeverStuck` propagates along a block run. -/
theorem NeverStuck.run {b4 : Option (Sym × Dir × St)} :
    ∀ {n : ℕ} {c c' : BCfg} {k : ℕ}, NeverStuck b4 c → bsteps b4 n c = some (c', k) →
      NeverStuck b4 c' := by
  intro n
  induction n with
  | zero =>
      intro c c' k h hrun
      simp only [bsteps, Option.some.injEq, Prod.mk.injEq] at hrun
      obtain ⟨rfl, -⟩ := hrun
      exact h
  | succ n ih =>
      intro c c' k h hrun
      rw [bsteps, Option.bind_eq_some_iff] at hrun
      obtain ⟨⟨c₁, k₁⟩, hb, hrun⟩ := hrun
      rw [Option.map_eq_some_iff] at hrun
      obtain ⟨⟨c₂, k₂⟩, hr, he⟩ := hrun
      simp only [Prod.mk.injEq] at he
      obtain ⟨rfl, -⟩ := he
      exact ih (h.tail hb) hr

/-- A never-stuck block simulation covers arbitrarily many base steps. -/
theorem exists_cost_ge {b4 : Option (Sym × Dir × St)} :
    ∀ (N : ℕ) (c : BCfg), NeverStuck b4 c →
      ∃ n c' k, bsteps b4 n c = some (c', k) ∧ N ≤ k := by
  intro N
  induction N with
  | zero => intro c _; exact ⟨0, c, 0, rfl, Nat.zero_le _⟩
  | succ N ih =>
      intro c hns
      obtain ⟨n₁, c₁, k₁, h1, hk₁⟩ := exists_pos_cost c hns
      obtain ⟨n₂, c₂, k₂, h2, hk₂⟩ := ih c₁ (hns.run h1)
      exact ⟨n₁ + n₂, c₂, k₁ + k₂, bsteps_comp h1 h2, by omega⟩

/--
**The reduction.**  If the block simulation of a member of the family never
gets stuck, that member never halts.
-/
theorem not_halts_of_neverStuck {b4 : Option (Sym × Dir × St)}
    (h : NeverStuck b4 binit) : ¬ Halts (M b4) init := by
  rintro ⟨T, hT⟩
  obtain ⟨n, c', k, hrun, hk⟩ := exists_cost_ge T binit h
  have h5 : steps (M b4) 5 init = some binit.den := init_five b4
  have := steps_trans h5 (bsteps_sound b4 n binit c' k hrun)
  exact not_halts_within this T (by omega) hT

end BB25
