/-
# The shift-overflow counter

The machines of the family are *shift-overflow mixed-digit counters*.  This
file makes that statement precise, inside the (sound) block system of
`Blocks.lean`, and derives from it the exact criterion for the dangerous block
`F = 141` to be harmless.

The left-hand stack of blocks is the counter.  Read it from the **bottom**
(the left end `L = ^11`) to the **top** (the block nearest the head) and build
a natural number `v`, starting from `v = 0`:

```
      X = 11  ↦  v := 2 * v          (append the bit 0)
      Z = 01  ↦  v := 2 * v + 1      (append the bit 1)
      W = 03  ↦  v := v / 2          (shift: delete the last bit)
```

This is `BB25.cval` (defined by the equivalent top-down recursion).  The two
theorems that justify the name are

* `BB25.cval_decrement` — a complete excursion of the head into the left stack
  *decrements the counter by one* and returns the head to the top of the stack;
* `BB25.cval_overflow` — when the counter is `0` the excursion instead runs off
  the bottom: the head reaches the left end `^11`, which is exactly the
  *overflow* of the counter (and where a pending digit `2>` is created).

Since the head enters the left stack once per round trip, the counter predicts
exactly when the next overflow happens: after `cval` further round trips.

The payoff is `BB25.brun_Bt_safe`: **a `<B1` sweep is harmless as soon as the
counter is nonzero.**  The `<B1` sweep is the only source of the block
`F = 141`, and `F` kills the machine only if the head reaches the left end
before consuming it (a pending digit then walks into the `141` and the machine
halts three steps later).  If `1 ≤ cval` the head has enough excursions left to
come back and eat the `F` first.  `BB25.brun_F_fatal` is the converse for the
simplest overflow case.
-/
import RequestProject.BB25.Sweep

namespace BB25

variable {b4 : Option (Sym × Dir × St)}

/-! ## The counter -/

/-- The value of the shift-overflow counter carried by the left stack.
Written as a recursion from the top of the stack (`lt` starts next to the
head), it is the number of further round trips the head can make before it
reaches the left end. -/
def cval : List LB → ℕ
  | .X :: s => 2 * cval s
  | .Z :: s => 2 * cval s + 1
  | .W :: s => cval s / 2
  | _ => 0

@[simp] theorem cval_X (s : List LB) : cval (.X :: s) = 2 * cval s := rfl
@[simp] theorem cval_Z (s : List LB) : cval (.Z :: s) = 2 * cval s + 1 := rfl
@[simp] theorem cval_W (s : List LB) : cval (.W :: s) = cval s / 2 := rfl
@[simp] theorem cval_L (s : List LB) : cval (.L :: s) = 0 := rfl
@[simp] theorem cval_nil : cval [] = 0 := rfl

/-- A well-formed counter stack: `03`, `11`, `01` blocks resting on the left
end `^11`. -/
inductive CStack : List LB → Prop
  | base : CStack [.L]
  | consW {s : List LB} : CStack s → CStack (.W :: s)
  | consX {s : List LB} : CStack s → CStack (.X :: s)
  | consZ {s : List LB} : CStack s → CStack (.Z :: s)

theorem CStack.ne_nil {s : List LB} (h : CStack s) : s ≠ [] := by
  cases h <;> simp

/-! ## One excursion of the head = one decrement of the counter -/

/-- The joint induction behind `cval_decrement` and `cval_overflow`. -/
private theorem cval_run (n : ℕ) :
    ∀ lt : List LB, lt.length ≤ n → CStack lt → ∀ rt : List RB,
      (1 ≤ cval lt →
        ∃ lt' k, BRun b4 ⟨lt, .Lt, rt⟩ ⟨lt', .Rt, rt⟩ k ∧ CStack lt' ∧
          lt'.length = lt.length ∧ cval lt' = cval lt - 1)
      ∧ (cval lt = 0 → ∃ rt' k, BRun b4 ⟨lt, .Lt, rt⟩ ⟨[.L], .Lt, rt'⟩ k) := by
  induction n with
  | zero =>
      intro lt hlen hst rt
      exact absurd (List.length_eq_zero_iff.mp (Nat.le_zero.mp hlen)) hst.ne_nil
  | succ n ih =>
      intro lt hlen hst rt
      cases hst with
      | base =>
          refine ⟨fun h => absurd h (by simp), fun _ => ⟨rt, 0, BRun.refl _⟩⟩
      | @consX s hs =>
          have hlen' : s.length ≤ n := by simpa using hlen
          have h0 : bstep b4 ⟨.X :: s, .Lt, rt⟩ = some (⟨s, .Lt, .Y :: rt⟩, 2) := rfl
          constructor
          · intro h
            have hs1 : 1 ≤ cval s := by simp at h; omega
            obtain ⟨s', k, hrun, hst', hl', hv'⟩ := ((ih s hlen' hs (.Y :: rt)).1 hs1)
            have h1 : bstep b4 ⟨s', .Rt, .Y :: rt⟩ = some (⟨.Z :: s', .Rt, rt⟩, 2) := rfl
            refine ⟨.Z :: s', 2 + (k + 2), ?_, hst'.consZ, by simp [hl'], ?_⟩
            · exact BRun.head h0 (hrun.trans (BRun.of_step h1))
            · simp only [cval_Z, cval_X, hv']; omega
          · intro h
            have hs0 : cval s = 0 := by simp at h; omega
            obtain ⟨rt', k, hrun⟩ := ((ih s hlen' hs (.Y :: rt)).2 hs0)
            exact ⟨rt', 2 + k, BRun.head h0 hrun⟩
      | @consZ s hs =>
          have h0 : bstep b4 ⟨.Z :: s, .Lt, rt⟩ = some (⟨.X :: s, .Rt, rt⟩, 3) := rfl
          refine ⟨fun _ => ⟨.X :: s, 3, BRun.of_step h0, hs.consX, by simp, ?_⟩, ?_⟩
          · simp
          · intro h; simp at h
      | @consW s hs =>
          have hlen' : s.length ≤ n := by simpa using hlen
          have h0 : bstep b4 ⟨.W :: s, .Lt, rt⟩ = some (⟨s, .Lt, .X :: rt⟩, 2) := rfl
          constructor
          · intro h
            have hs2 : 2 ≤ cval s := by simp at h; omega
            obtain ⟨s', k, hrun, hst', hl', hv'⟩ := ((ih s hlen' hs (.X :: rt)).1 (by omega))
            have h1 : bstep b4 ⟨s', .Rt, .X :: rt⟩ = some (⟨s', .Lt, .V :: rt⟩, 1) := rfl
            have hs1' : 1 ≤ cval s' := by omega
            have hlen'' : s'.length ≤ n := by omega
            obtain ⟨s'', k2, hrun2, hst'', hl'', hv''⟩ :=
              ((ih s' hlen'' hst' (.V :: rt)).1 hs1')
            have h2 : bstep b4 ⟨s'', .Rt, .V :: rt⟩ = some (⟨.W :: s'', .Rt, rt⟩, 2) := rfl
            refine ⟨.W :: s'', 2 + (k + (1 + (k2 + 2))), ?_, hst''.consW, by simp [hl'', hl'], ?_⟩
            · exact BRun.head h0
                (hrun.trans ((BRun.of_step h1).trans (hrun2.trans (BRun.of_step h2))))
            · simp only [cval_W, hv'', hv']
              omega
          · intro h
            have hs1 : cval s ≤ 1 := by simp at h; omega
            rcases Nat.eq_zero_or_pos (cval s) with h0' | h0'
            · obtain ⟨rt', k, hrun⟩ := ((ih s hlen' hs (.X :: rt)).2 h0')
              exact ⟨rt', 2 + k, BRun.head h0 hrun⟩
            · obtain ⟨s', k, hrun, hst', hl', hv'⟩ := ((ih s hlen' hs (.X :: rt)).1 h0')
              have h1 : bstep b4 ⟨s', .Rt, .X :: rt⟩ = some (⟨s', .Lt, .V :: rt⟩, 1) := rfl
              have hv0 : cval s' = 0 := by omega
              have hlen'' : s'.length ≤ n := by omega
              obtain ⟨rt', k2, hrun2⟩ := ((ih s' hlen'' hst' (.V :: rt)).2 hv0)
              exact ⟨rt', 2 + (k + (1 + k2)),
                BRun.head h0 (hrun.trans ((BRun.of_step h1).trans hrun2))⟩

/--
**One excursion of the head decrements the counter.**  If the counter is
nonzero, the head that has just entered the left stack in state `<A` comes back
out of it in state `A>`, with the right-hand tape untouched, the stack still
well formed and of the same length, and the counter one smaller.
-/
theorem cval_decrement {lt : List LB} (hst : CStack lt) (h : 1 ≤ cval lt) (rt : List RB) :
    ∃ lt' k, BRun b4 ⟨lt, .Lt, rt⟩ ⟨lt', .Rt, rt⟩ k ∧ CStack lt' ∧
      lt'.length = lt.length ∧ cval lt' = cval lt - 1 :=
  ((cval_run lt.length lt le_rfl hst rt).1 h)

/--
**Overflow.**  If the counter is `0`, the head that enters the left stack in
state `<A` runs off its bottom: it reaches the left end `^11`.
-/
theorem cval_overflow {lt : List LB} (hst : CStack lt) (h : cval lt = 0) (rt : List RB) :
    ∃ rt' k, BRun (b4 := b4) ⟨lt, .Lt, rt⟩ ⟨[.L], .Lt, rt'⟩ k :=
  ((cval_run lt.length lt le_rfl hst rt).2 h)

/-! ## The `F = 141` block is harmless while the counter is nonzero -/

/--
**The `F` block is eaten when the counter is at least two.**  After
`03 <B1 → <A 141` the head stands in state `<A` on top of the remaining stack
with the `141` immediately on its right.  Two excursions bring it back twice:
the first turns `141` into `241`, the second puts the head in front of the
`241`, where the member-specific rule `A> 241` consumes it.  No pending digit
is created in between, so the machine cannot halt here.
-/
theorem brun_F_consumed {s : List LB} (hst : CStack s) (h : 2 ≤ cval s) (rt : List RB) :
    ∃ s' k, BRun b4 ⟨s, .Lt, .F :: rt⟩ ⟨s', .Rt, .G :: rt⟩ k ∧ CStack s' ∧
      cval s' = cval s - 2 := by
  obtain ⟨s₁, k₁, hrun₁, hst₁, _, hv₁⟩ := cval_decrement (b4 := b4) hst (by omega) (.F :: rt)
  have h1 : bstep b4 ⟨s₁, .Rt, .F :: rt⟩ = some (⟨s₁, .Lt, .G :: rt⟩, 1) := rfl
  obtain ⟨s₂, k₂, hrun₂, hst₂, _, hv₂⟩ :=
    cval_decrement (b4 := b4) hst₁ (by omega) (.G :: rt)
  exact ⟨s₂, k₁ + (1 + k₂), hrun₁.trans ((BRun.of_step h1).trans hrun₂), hst₂, by omega⟩

/-! ## The `<B1` sweep is safe while the counter is nonzero -/

/--
**The counter decides the `<B1` sweep.**  A `<B1` head on top of a well-formed
counter stack whose value is nonzero either

* is defused into `<A 11 2>` (the sweep met a `01` block), or
* creates the `141` block and eats it again, ending in front of the `241`
  block, where the member-specific rule applies.

In both cases the block run reaches a configuration whose left stack is again a
well-formed counter stack, and only `22` blocks have been added to the right of
the old right-hand tape, so no pending digit is ever created in front of a
`141`/`241` block and the machine cannot halt on the way.  (The third
possibility for a `<B1` sweep, running off the left end into the spinout, needs
counter value `0` and is excluded here.)
-/
theorem brun_Bt_safe {lt : List LB} (hst : CStack lt) (h : 1 ≤ cval lt) (rt : List RB) :
    ∃ (s : List LB) (n k : ℕ), CStack s ∧
      (BRun b4 ⟨lt, .Bt, rt⟩ ⟨s, .Lt, .X :: .P2 :: (List.replicate n .Y ++ rt)⟩ k ∨
       BRun b4 ⟨lt, .Bt, rt⟩ ⟨s, .Rt, .G :: (List.replicate n .Y ++ rt)⟩ k) := by
  induction hst generalizing rt with
  | base => exact absurd h (by simp)
  | @consX s hs ih =>
      have h0 : bstep b4 ⟨.X :: s, .Bt, rt⟩ = some (⟨s, .Bt, .Y :: rt⟩, 6) := rfl
      have hs1 : 1 ≤ cval s := by simp at h; omega
      obtain ⟨s', n, k, hst', hrun⟩ := ih hs1 (.Y :: rt)
      have hre : List.replicate n .Y ++ (RB.Y :: rt) = List.replicate (n + 1) .Y ++ rt := by
        rw [List.replicate_succ']; simp
      rw [hre] at hrun
      exact ⟨s', n + 1, 6 + k, hst',
        hrun.imp (fun hr => BRun.head h0 hr) (fun hr => BRun.head h0 hr)⟩
  | @consZ s hs _ =>
      have h0 : bstep b4 ⟨.Z :: s, .Bt, rt⟩ = some (⟨s, .Lt, .X :: .P2 :: rt⟩, 4) := rfl
      exact ⟨s, 0, 4, hs, Or.inl (by simpa using BRun.of_step h0)⟩
  | @consW s hs _ =>
      have h0 : bstep b4 ⟨.W :: s, .Bt, rt⟩ = some (⟨s, .Lt, .F :: rt⟩, 2) := rfl
      have hs2 : 2 ≤ cval s := by simp at h; omega
      obtain ⟨s', k, hrun, hst', _⟩ := brun_F_consumed (b4 := b4) hs hs2 rt
      exact ⟨s', 0, 2 + k, hst', Or.inr (by simpa using BRun.head h0 hrun)⟩

/-! ## The whole `<B1` event is survived, for the members that bounce -/

/-- The members whose `A> 241` rule turns the head around and leaves harmless
blocks behind: `2LB`, `1LB`, `3RA`, `2LA`, `0LA`. -/
def Bounces (b4 : Option (Sym × Dir × St)) : Prop :=
  ∃ (pre : List RB) (cost : ℕ), (∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G) ∧
    ∀ (lt : List LB) (rest : List RB),
      gStep b4 lt rest = some (⟨lt, .Lt, pre ++ rest⟩, cost)

theorem bounces_2LB : Bounces b4_2LB := ⟨[.U, .P1], 3, by decide, fun _ _ => rfl⟩
theorem bounces_1LB : Bounces b4_1LB := ⟨[.X, .P1], 3, by decide, fun _ _ => rfl⟩
theorem bounces_3RA : Bounces b4_3RA := ⟨[.X, .P2], 5, by decide, fun _ _ => rfl⟩
theorem bounces_2LA : Bounces b4_2LA := ⟨[.Y, .P2], 7, by decide, fun _ _ => rfl⟩
theorem bounces_0LA : Bounces b4_0LA := ⟨[.V, .P1], 5, by decide, fun _ _ => rfl⟩

/--
**A `<B1` event with a nonzero counter is survived completely.**  For the five
members whose `A> 241` rule bounces the head back to the left, the whole event —
the `<B1` sweep, the creation of the `141` block, its conversion to `241` and
its consumption — is a block run ending in a configuration that again has a
well-formed counter stack on the left and *no* `141`/`241` block anywhere: the
old right-hand tape `rt` is untouched and only harmless blocks have been put in
front of it.

Since a pending digit in front of a `141`/`241` block is the only way these
members can halt, and the `<B1` sweep is the only source of such a block, this
reduces non-halting for them to a single question: **if the counter is never
`0` when a `<B1` sweep starts, the member never halts.**  (The converse fails:
a `<B1` sweep with the counter at `0` may also run off the left end, which is
the spinout and never halts.)
-/
theorem brun_Bt_clear (hb : Bounces b4) {lt : List LB} (hst : CStack lt)
    (h : 1 ≤ cval lt) (rt : List RB) :
    ∃ (s : List LB) (pre : List RB) (k : ℕ),
      BRun b4 ⟨lt, .Bt, rt⟩ ⟨s, .Lt, pre ++ rt⟩ k ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G := by
  obtain ⟨gpre, gcost, hgpre, hg⟩ := hb
  obtain ⟨s, n, k, hst', hrun | hrun⟩ := brun_Bt_safe (b4 := b4) hst h rt
  · refine ⟨s, .X :: .P2 :: List.replicate n .Y, k, by simpa using hrun, hst', ?_⟩
    intro b hbm
    simp only [List.mem_cons] at hbm
    rcases hbm with rfl | rfl | hbm
    · exact ⟨by simp, by simp⟩
    · exact ⟨by simp, by simp⟩
    · rw [List.eq_of_mem_replicate hbm]; exact ⟨by simp, by simp⟩
  · refine ⟨s, gpre ++ List.replicate n .Y, k + gcost, ?_, hst', ?_⟩
    · have hstep : bstep b4 ⟨s, .Rt, .G :: (List.replicate n .Y ++ rt)⟩
          = some (⟨s, .Lt, gpre ++ (List.replicate n .Y ++ rt)⟩, gcost) := hg _ _
      simpa [List.append_assoc] using hrun.trans (BRun.of_step hstep)
    · intro b hbm
      rcases List.mem_append.mp hbm with hbm | hbm
      · exact hgpre b hbm
      · rw [List.eq_of_mem_replicate hbm]; exact ⟨by simp, by simp⟩

/-! ## Predicting the next overflow: the drain at the right end -/

/-- The number of round trips the head makes at the right end before the
counter overflows.  One *drain cycle* is

```
   lt A> 21 $   ⟶   03 lt A> $   ⟶   03 lt <A 21 $   ⟶   lt' A> 21 $
```

(consume the `21`, hit the blank end which writes a fresh `21`, and one
excursion into the counter), and it replaces the counter value `v` by
`v / 2 - 1`: the `03` block that the head pushes is a *shift*. -/
def drainCycles (v : ℕ) : ℕ :=
  if v / 2 = 0 then 0 else 1 + drainCycles (v / 2 - 1)
decreasing_by omega

theorem drainCycles_of_le_one {v : ℕ} (h : v ≤ 1) : drainCycles v = 0 := by
  rw [drainCycles]; simp [Nat.div_eq_of_lt (show v < 2 by omega)]

theorem drainCycles_of_two_le {v : ℕ} (h : 2 ≤ v) :
    drainCycles v = 1 + drainCycles (v / 2 - 1) := by
  rw [drainCycles]
  have : v / 2 ≠ 0 := by omega
  simp [this]

/-- **The overflow happens after at most `log₂ (v + 2)` drain cycles.** -/
theorem two_pow_drainCycles_le (v : ℕ) : 2 ^ drainCycles v ≤ v + 2 := by
  induction v using Nat.strong_induction_on with
  | _ v ih =>
      rcases Nat.lt_or_ge v 2 with h | h
      · rw [drainCycles_of_le_one (by omega)]; simp
      · rw [drainCycles_of_two_le (by omega)]
        have := ih (v / 2 - 1) (by omega)
        calc 2 ^ (1 + drainCycles (v / 2 - 1)) = 2 * 2 ^ drainCycles (v / 2 - 1) := by ring
          _ ≤ 2 * (v / 2 - 1 + 2) := by omega
          _ ≤ v + 2 := by omega

/-- One drain cycle, while the counter still has something left. -/
theorem brun_drain_step {lt : List LB} (hst : CStack lt) (h : 2 ≤ cval lt) :
    ∃ lt' k, BRun b4 ⟨lt, .Rt, [.V, .R]⟩ ⟨lt', .Rt, [.V, .R]⟩ k ∧ CStack lt' ∧
      cval lt' = cval lt / 2 - 1 := by
  have h0 : bstep b4 ⟨lt, .Rt, [.V, .R]⟩ = some (⟨.W :: lt, .Rt, [.R]⟩, 2) := rfl
  have h1 : bstep b4 ⟨.W :: lt, .Rt, [.R]⟩ = some (⟨.W :: lt, .Lt, [.V, .R]⟩, 3) := rfl
  have hv : cval (.W :: lt) = cval lt / 2 := rfl
  obtain ⟨lt', k, hrun, hst', _, hv'⟩ :=
    cval_decrement (b4 := b4) hst.consW (by omega) [.V, .R]
  exact ⟨lt', 2 + (3 + k), BRun.head h0 (BRun.head h1 hrun), hst', by omega⟩

/-- The last drain cycle: the counter overflows and the head reaches the left
end. -/
theorem brun_drain_last {lt : List LB} (hst : CStack lt) (h : cval lt ≤ 1) :
    ∃ rt' k, BRun (b4 := b4) ⟨lt, .Rt, [.V, .R]⟩ ⟨[.L], .Lt, rt'⟩ k := by
  have h0 : bstep b4 ⟨lt, .Rt, [.V, .R]⟩ = some (⟨.W :: lt, .Rt, [.R]⟩, 2) := rfl
  have h1 : bstep b4 ⟨.W :: lt, .Rt, [.R]⟩ = some (⟨.W :: lt, .Lt, [.V, .R]⟩, 3) := rfl
  have hv : cval (.W :: lt) = 0 := by
    show cval lt / 2 = 0
    omega
  obtain ⟨rt', k, hrun⟩ := cval_overflow (b4 := b4) hst.consW hv [.V, .R]
  exact ⟨rt', 2 + (3 + k), BRun.head h0 (BRun.head h1 hrun)⟩

/--
**The counter always overflows.**  Once the head is bouncing off the right end
of the tape, every round trip halves the counter (and decrements it), so after
`drainCycles (cval lt) ≤ log₂ (cval lt + 2)` round trips the counter reaches
`0` and the head walks all the way down to the left end `^11` — where the next
pending digit `2>` is created.  This is the *overflow* of the shift-overflow
counter, and the theorem predicts exactly when it happens.
-/
theorem brun_drain {lt : List LB} (hst : CStack lt) :
    ∃ rt' k, BRun (b4 := b4) ⟨lt, .Rt, [.V, .R]⟩ ⟨[.L], .Lt, rt'⟩ k := by
  generalize hv : cval lt = v
  induction v using Nat.strong_induction_on generalizing lt with
  | _ v ih =>
      rcases Nat.lt_or_ge (cval lt) 2 with h | h
      · exact brun_drain_last hst (by omega)
      · obtain ⟨lt', k, hrun, hst', hv'⟩ := brun_drain_step (b4 := b4) hst (by omega)
        obtain ⟨rt', k', hrun'⟩ := ih (cval lt') (by omega) hst' rfl
        exact ⟨rt', k + k', hrun.trans hrun'⟩


/-! ## The reset phase: the pending digit re-parses the tape

A shift-overflow counter alternates a *counter phase*, in which the block
decomposition is fixed and the machine runs as a double counter, with a *reset
phase*, in which the offsets of the blocks change and the tape is re-parsed
into new digits.  Here the reset phase is the rightward march of the pending
digit `1>`/`2>` created at the left end: it re-parses the right-hand tape one
block at a time, and each re-parsed block is immediately swallowed and pushed
onto the counter as a new digit.

The parsing offset — the pending digit itself — is the *phase*.  It matters
because it exchanges the roles of `21` and `12`: with the offset shifted, a
`21` block is read as a `2`+`1`, that is as the bit `22 1>`, while without it
`21` is a shift.  This is where the counter gains the digits that keep it
alive.
-/

/-- The pending digit of a phase: `true` is `2>`, `false` is `1>`. -/
def pd : Bool → RB
  | true => .P2
  | false => .P1

/--
One block of the reset phase, as an operation on the counter value: the new
phase and the new counter value, or `none` if the machine cannot do it (an
unexpected block, or the counter underflowing).  In phase `1>` the head has to
turn around at the block, which costs one excursion, i.e. one decrement.
-/
def resetStep (p : Bool) (b : RB) (v : ℕ) : Option (Bool × ℕ) :=
  if p = false ∧ v = 0 then none
  else
    let u := if p then v else v - 1
    match b with
    | .X => some (false, u / 2)
    | .V => some (false, 2 * u + 1)
    | .Y => some (true, 2 * u + 1)
    | .U => some (true, u / 2)
    | _ => none

/-- **One block of the reset phase.**  The head crosses one block of the
right-hand tape, pushing one digit onto the counter, and the pending digit —
the parsing offset — moves on. -/
theorem brun_reset_step {lt : List LB} (hst : CStack lt) {p p' : Bool} {b : RB} {v : ℕ}
    (rest : List RB) (h : resetStep p b (cval lt) = some (p', v)) :
    ∃ lt' k, BRun b4 ⟨lt, .Rt, pd p :: b :: rest⟩ ⟨lt', .Rt, pd p' :: rest⟩ k ∧
      CStack lt' ∧ cval lt' = v := by
  cases p with
  | true =>
      cases b with
      | U =>
          obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj
            (show some (true, cval lt / 2) = some (p', v) from h))
          exact ⟨.W :: lt, 0 + 2,
            BRun.head (show bstep b4 ⟨lt, .Rt, .P2 :: .U :: rest⟩
              = some (⟨lt, .Rt, .V :: .P2 :: rest⟩, 0) from rfl)
              (BRun.of_step (show bstep b4 ⟨lt, .Rt, .V :: .P2 :: rest⟩
                = some (⟨.W :: lt, .Rt, .P2 :: rest⟩, 2) from rfl)), hst.consW, rfl⟩
      | V =>
          obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj
            (show some (false, 2 * cval lt + 1) = some (p', v) from h))
          exact ⟨.Z :: lt, 0 + 2,
            BRun.head (show bstep b4 ⟨lt, .Rt, .P2 :: .V :: rest⟩
              = some (⟨lt, .Rt, .Y :: .P1 :: rest⟩, 0) from rfl)
              (BRun.of_step (show bstep b4 ⟨lt, .Rt, .Y :: .P1 :: rest⟩
                = some (⟨.Z :: lt, .Rt, .P1 :: rest⟩, 2) from rfl)), hst.consZ, rfl⟩
      | X =>
          obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj
            (show some (false, cval lt / 2) = some (p', v) from h))
          exact ⟨.W :: lt, 0 + 2,
            BRun.head (show bstep b4 ⟨lt, .Rt, .P2 :: .X :: rest⟩
              = some (⟨lt, .Rt, .V :: .P1 :: rest⟩, 0) from rfl)
              (BRun.of_step (show bstep b4 ⟨lt, .Rt, .V :: .P1 :: rest⟩
                = some (⟨.W :: lt, .Rt, .P1 :: rest⟩, 2) from rfl)), hst.consW, rfl⟩
      | Y =>
          obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj
            (show some (true, 2 * cval lt + 1) = some (p', v) from h))
          exact ⟨.Z :: lt, 0 + 2,
            BRun.head (show bstep b4 ⟨lt, .Rt, .P2 :: .Y :: rest⟩
              = some (⟨lt, .Rt, .Y :: .P2 :: rest⟩, 0) from rfl)
              (BRun.of_step (show bstep b4 ⟨lt, .Rt, .Y :: .P2 :: rest⟩
                = some (⟨.Z :: lt, .Rt, .P2 :: rest⟩, 2) from rfl)), hst.consZ, rfl⟩
      | _ => exact absurd h (by simp [resetStep])
  | false =>
      by_cases hv : cval lt = 0
      · exact absurd h (by simp [resetStep, hv])
      · have hv1 : 1 ≤ cval lt := by omega
        cases b with
        | U =>
            -- `1> 12` re-parses to `11 2>`; the head turns, then pushes a shift
            have e : resetStep false RB.U (cval lt) = some (true, (cval lt - 1) / 2) := by
              unfold resetStep; rw [if_neg (fun hh => hv hh.2)]; rfl
            rw [e] at h
            obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj h)
            obtain ⟨lt₁, k, hrun, hst₁, _, hv₁⟩ :=
              cval_decrement (b4 := b4) hst hv1 (.V :: .P2 :: rest)
            refine ⟨.W :: lt₁, 0 + (1 + (k + 2)), ?_, hst₁.consW, by simp [cval, hv₁]⟩
            exact BRun.head (show bstep b4 ⟨lt, .Rt, .P1 :: .U :: rest⟩
                = some (⟨lt, .Rt, .X :: .P2 :: rest⟩, 0) from rfl)
              (BRun.head (show bstep b4 ⟨lt, .Rt, .X :: .P2 :: rest⟩
                  = some (⟨lt, .Lt, .V :: .P2 :: rest⟩, 1) from rfl)
                (hrun.trans (BRun.of_step (show bstep b4 ⟨lt₁, .Rt, .V :: .P2 :: rest⟩
                  = some (⟨.W :: lt₁, .Rt, .P2 :: rest⟩, 2) from rfl))))
        | V =>
            -- `1> 21` re-parses to `12 1>`; the head turns, then pushes a bit
            have e : resetStep false RB.V (cval lt) = some (false, 2 * (cval lt - 1) + 1) := by
              unfold resetStep; rw [if_neg (fun hh => hv hh.2)]; rfl
            rw [e] at h
            obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj h)
            obtain ⟨lt₁, k, hrun, hst₁, _, hv₁⟩ :=
              cval_decrement (b4 := b4) hst hv1 (.Y :: .P1 :: rest)
            refine ⟨.Z :: lt₁, 0 + (1 + (k + 2)), ?_, hst₁.consZ, by simp [cval, hv₁]⟩
            exact BRun.head (show bstep b4 ⟨lt, .Rt, .P1 :: .V :: rest⟩
                = some (⟨lt, .Rt, .U :: .P1 :: rest⟩, 0) from rfl)
              (BRun.head (show bstep b4 ⟨lt, .Rt, .U :: .P1 :: rest⟩
                  = some (⟨lt, .Lt, .Y :: .P1 :: rest⟩, 1) from rfl)
                (hrun.trans (BRun.of_step (show bstep b4 ⟨lt₁, .Rt, .Y :: .P1 :: rest⟩
                  = some (⟨.Z :: lt₁, .Rt, .P1 :: rest⟩, 2) from rfl))))
        | X =>
            have e : resetStep false RB.X (cval lt) = some (false, (cval lt - 1) / 2) := by
              unfold resetStep; rw [if_neg (fun hh => hv hh.2)]; rfl
            rw [e] at h
            obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj h)
            obtain ⟨lt₁, k, hrun, hst₁, _, hv₁⟩ :=
              cval_decrement (b4 := b4) hst hv1 (.V :: .P1 :: rest)
            refine ⟨.W :: lt₁, 0 + (1 + (k + 2)), ?_, hst₁.consW, by simp [cval, hv₁]⟩
            exact BRun.head (show bstep b4 ⟨lt, .Rt, .P1 :: .X :: rest⟩
                = some (⟨lt, .Rt, .X :: .P1 :: rest⟩, 0) from rfl)
              (BRun.head (show bstep b4 ⟨lt, .Rt, .X :: .P1 :: rest⟩
                  = some (⟨lt, .Lt, .V :: .P1 :: rest⟩, 1) from rfl)
                (hrun.trans (BRun.of_step (show bstep b4 ⟨lt₁, .Rt, .V :: .P1 :: rest⟩
                  = some (⟨.W :: lt₁, .Rt, .P1 :: rest⟩, 2) from rfl))))
        | Y =>
            have e : resetStep false RB.Y (cval lt) = some (true, 2 * (cval lt - 1) + 1) := by
              unfold resetStep; rw [if_neg (fun hh => hv hh.2)]; rfl
            rw [e] at h
            obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Option.some.inj h)
            obtain ⟨lt₁, k, hrun, hst₁, _, hv₁⟩ :=
              cval_decrement (b4 := b4) hst hv1 (.Y :: .P2 :: rest)
            refine ⟨.Z :: lt₁, 0 + (1 + (k + 2)), ?_, hst₁.consZ, by simp [cval, hv₁]⟩
            exact BRun.head (show bstep b4 ⟨lt, .Rt, .P1 :: .Y :: rest⟩
                = some (⟨lt, .Rt, .U :: .P2 :: rest⟩, 0) from rfl)
              (BRun.head (show bstep b4 ⟨lt, .Rt, .U :: .P2 :: rest⟩
                  = some (⟨lt, .Lt, .Y :: .P2 :: rest⟩, 1) from rfl)
                (hrun.trans (BRun.of_step (show bstep b4 ⟨lt₁, .Rt, .Y :: .P2 :: rest⟩
                  = some (⟨.Z :: lt₁, .Rt, .P2 :: rest⟩, 2) from rfl))))
        | _ => exact absurd h (by simp [resetStep, hv])

/-- The reset phase over a whole word of blocks, as an operation on the
counter: `resetRun p w v` is the phase and the counter value after the pending
digit has re-parsed and swallowed the word `w`. -/
def resetRun (p : Bool) : List RB → ℕ → Option (Bool × ℕ)
  | [], v => some (p, v)
  | b :: w, v => (resetStep p b v).bind fun q => resetRun q.1 w q.2

/-- **The reset phase.**  If the arithmetic of `resetRun` goes through, the
machine really does re-parse the word `w`, and the counter ends with the
predicted value. -/
theorem brun_reset {p : Bool} : ∀ (w : List RB) {lt : List LB}, CStack lt →
    ∀ {p' : Bool} {v : ℕ}, resetRun p w (cval lt) = some (p', v) → ∀ rest : List RB,
      ∃ lt' k, BRun b4 ⟨lt, .Rt, pd p :: (w ++ rest)⟩ ⟨lt', .Rt, pd p' :: rest⟩ k ∧
        CStack lt' ∧ cval lt' = v := by
  intro w
  induction w generalizing p with
  | nil =>
      intro lt hst p' v h rest
      simp only [resetRun, Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, rfl⟩ := h
      exact ⟨lt, 0, by simpa using BRun.refl (b4 := b4) _, hst, rfl⟩
  | cons b w ih =>
      intro lt hst p' v h rest
      rw [resetRun, Option.bind_eq_some_iff] at h
      obtain ⟨⟨p₁, v₁⟩, h1, h2⟩ := h
      obtain ⟨lt₁, k₁, hrun₁, hst₁, hv₁⟩ :=
        brun_reset_step (b4 := b4) hst (w ++ rest) h1
      obtain ⟨lt₂, k₂, hrun₂, hst₂, hv₂⟩ := ih hst₁ (by rw [hv₁]; exact h2) rest
      exact ⟨lt₂, k₁ + k₂, by simpa using hrun₁.trans hrun₂, hst₂, hv₂⟩

/-- **The end of the reset phase.**  When the pending digit reaches the right
end of the tape the machine enters the `<B1` sweep — the point at which a
shift-overflow counter can halt.  The counter value there is the one the reset
phase has built (one less if the offset is `1>`, which costs a last
excursion). -/
theorem brun_reset_end {lt : List LB} (hst : CStack lt) {p : Bool}
    (h : p = true ∨ 1 ≤ cval lt) :
    ∃ lt' k, BRun b4 ⟨lt, .Rt, [pd p, .R]⟩ ⟨lt', .Bt, [.Y, .R1]⟩ k ∧ CStack lt' ∧
      cval lt' = (if p then cval lt else cval lt - 1) := by
  cases p with
  | true =>
      refine ⟨lt, 0 + 11, ?_, hst, by simp⟩
      exact BRun.head (show bstep b4 ⟨lt, .Rt, [.P2, .R]⟩ = some (⟨lt, .Rt, [.R2]⟩, 0) from rfl)
        (BRun.of_step (show bstep b4 ⟨lt, .Rt, [.R2]⟩ = some (⟨lt, .Bt, [.Y, .R1]⟩, 11) from rfl))
  | false =>
      have hv : 1 ≤ cval lt := by simpa using h
      obtain ⟨lt₁, k, hrun, hst₁, _, hv₁⟩ := cval_decrement (b4 := b4) hst hv [.R2]
      refine ⟨lt₁, 0 + (1 + (k + 11)), ?_, hst₁, by simpa using hv₁⟩
      exact BRun.head (show bstep b4 ⟨lt, .Rt, [.P1, .R]⟩ = some (⟨lt, .Rt, [.R1]⟩, 0) from rfl)
        (BRun.head (show bstep b4 ⟨lt, .Rt, [.R1]⟩ = some (⟨lt, .Lt, [.R2]⟩, 1) from rfl)
          (hrun.trans (BRun.of_step
            (show bstep b4 ⟨lt₁, .Rt, [.R2]⟩ = some (⟨lt₁, .Bt, [.Y, .R1]⟩, 11) from rfl))))

/--
**One whole reset phase of a shift-overflow counter, and the `<B1` event that
follows it.**  Starting at the left end (counter `0`, pending digit `2>`), the
machine re-parses the tape `w`, arrives at the right end with the counter value
that `resetRun` predicts, and survives the `<B1` sweep — provided that
predicted value is nonzero.  It ends with a well-formed counter stack and no
`141`/`241` block left anywhere.

This is the exact halting criterion for the five members that bounce: they halt
if and only if some reset phase delivers the counter value `0`.
-/
theorem brun_reset_cycle (hb : Bounces b4) (w : List RB) {p' : Bool} {v : ℕ}
    (h : resetRun true w 0 = some (p', v))
    (hv : if p' then 1 ≤ v else 2 ≤ v) :
    ∃ (s : List LB) (pre : List RB) (k : ℕ),
      BRun b4 ⟨[.L], .Lt, w ++ [.R]⟩ ⟨s, .Lt, pre ++ [.Y, .R1]⟩ k ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G := by
  have h0 : bstep b4 ⟨[.L], .Lt, w ++ [.R]⟩ = some (⟨[.L], .Rt, .P2 :: (w ++ [.R])⟩, 4) := rfl
  have hL : CStack [.L] := CStack.base
  have hc : cval ([.L] : List LB) = 0 := rfl
  obtain ⟨lt₁, k₁, hrun₁, hst₁, hv₁⟩ := brun_reset (b4 := b4) w hL (by rw [hc]; exact h) [.R]
  have hp : p' = true ∨ 1 ≤ cval lt₁ := by
    cases p' with
    | true => exact Or.inl rfl
    | false =>
        have h2 : 2 ≤ v := by simpa using hv
        exact Or.inr (by omega)
  obtain ⟨lt₂, k₂, hrun₂, hst₂, hv₂⟩ := brun_reset_end (b4 := b4) hst₁ hp
  have hv2 : 1 ≤ cval lt₂ := by
    cases p' with
    | true =>
        have h1 : 1 ≤ v := by simpa using hv
        rw [hv₂, hv₁]
        show (1 : ℕ) ≤ v
        omega
    | false =>
        have h2 : 2 ≤ v := by simpa using hv
        rw [hv₂, hv₁]
        show (1 : ℕ) ≤ v - 1
        omega
  obtain ⟨s, pre, k₃, hrun₃, hst₃, hpre⟩ := brun_Bt_clear (b4 := b4) hb hst₂ hv2 [.Y, .R1]
  exact ⟨s, pre, 4 + (k₁ + (k₂ + k₃)),
    BRun.head h0 (hrun₁.trans (hrun₂.trans hrun₃)), hst₃, hpre⟩

/-! ## The counter phase: no pending digit, a fixed parse

Between two reset phases the parse of the tape is fixed and the machine runs as
a plain double counter: the head marches right over the blocks of the tape,
each block pushing one digit onto the left stack, and the blocks `11`/`12` in
addition turn the head around, which costs one excursion, i.e. one decrement of
the counter.  The arithmetic is the same as in the reset phase, but — this is
the point of the phase — the letters play different roles.

If the counter is exhausted at one of those turns the head runs off the bottom
of the stack: that is the *overflow*, and the reset phase begins.  So the whole
of the counter phase is captured by the arithmetic of `countStep` below,
exactly as `resetStep` captures the reset phase.
-/

/--
One block of the counter phase, as an operation on the counter value; `none`
means the machine cannot do it (an unexpected block, or the counter
overflowing at a turn — in which case the head reaches the left end and the
reset phase starts).
-/
def countStep (b : RB) (v : ℕ) : Option ℕ :=
  match b with
  | .Y => some (2 * v + 1)
  | .V => some (v / 2)
  | .X => if v = 0 then none else some ((v - 1) / 2)
  | .U => if v = 0 then none else some (2 * (v - 1) + 1)
  | _ => none

/-- **One block of the counter phase.**  The head swallows one block of the
tape and pushes one digit onto the counter. -/
theorem brun_count_step {lt : List LB} (hst : CStack lt) {b : RB} {v : ℕ}
    (rest : List RB) (h : countStep b (cval lt) = some v) :
    ∃ lt' k, BRun b4 ⟨lt, .Rt, b :: rest⟩ ⟨lt', .Rt, rest⟩ k ∧ CStack lt' ∧ cval lt' = v := by
  cases b with
  | Y =>
      obtain rfl := Option.some.inj (show some (2 * cval lt + 1) = some v from h)
      exact ⟨.Z :: lt, 2, BRun.of_step (show bstep b4 ⟨lt, .Rt, .Y :: rest⟩
        = some (⟨.Z :: lt, .Rt, rest⟩, 2) from rfl), hst.consZ, rfl⟩
  | V =>
      obtain rfl := Option.some.inj (show some (cval lt / 2) = some v from h)
      exact ⟨.W :: lt, 2, BRun.of_step (show bstep b4 ⟨lt, .Rt, .V :: rest⟩
        = some (⟨.W :: lt, .Rt, rest⟩, 2) from rfl), hst.consW, rfl⟩
  | X =>
      by_cases hv : cval lt = 0
      · exact absurd h (by simp [countStep, hv])
      · have hv1 : 1 ≤ cval lt := by omega
        have e : countStep RB.X (cval lt) = some ((cval lt - 1) / 2) := by
          simp [countStep, hv]
        rw [e] at h
        obtain rfl := Option.some.inj h
        obtain ⟨lt₁, k, hrun, hst₁, _, hv₁⟩ := cval_decrement (b4 := b4) hst hv1 (.V :: rest)
        refine ⟨.W :: lt₁, 1 + (k + 2), ?_, hst₁.consW, by simp [hv₁]⟩
        exact BRun.head (show bstep b4 ⟨lt, .Rt, .X :: rest⟩
            = some (⟨lt, .Lt, .V :: rest⟩, 1) from rfl)
          (hrun.trans (BRun.of_step (show bstep b4 ⟨lt₁, .Rt, .V :: rest⟩
            = some (⟨.W :: lt₁, .Rt, rest⟩, 2) from rfl)))
  | U =>
      by_cases hv : cval lt = 0
      · exact absurd h (by simp [countStep, hv])
      · have hv1 : 1 ≤ cval lt := by omega
        have e : countStep RB.U (cval lt) = some (2 * (cval lt - 1) + 1) := by
          simp [countStep, hv]
        rw [e] at h
        obtain rfl := Option.some.inj h
        obtain ⟨lt₁, k, hrun, hst₁, _, hv₁⟩ := cval_decrement (b4 := b4) hst hv1 (.Y :: rest)
        refine ⟨.Z :: lt₁, 1 + (k + 2), ?_, hst₁.consZ, by simp [hv₁]⟩
        exact BRun.head (show bstep b4 ⟨lt, .Rt, .U :: rest⟩
            = some (⟨lt, .Lt, .Y :: rest⟩, 1) from rfl)
          (hrun.trans (BRun.of_step (show bstep b4 ⟨lt₁, .Rt, .Y :: rest⟩
            = some (⟨.Z :: lt₁, .Rt, rest⟩, 2) from rfl)))
  | _ => exact absurd h (by simp [countStep])

/-- The counter phase over a whole word of blocks. -/
def countRun : List RB → ℕ → Option ℕ
  | [], v => some v
  | b :: w, v => (countStep b v).bind fun u => countRun w u

/-- **The counter phase.**  If the arithmetic of `countRun` goes through, the
machine really does swallow the word `w`, and the counter ends with the
predicted value. -/
theorem brun_count : ∀ (w : List RB) {lt : List LB}, CStack lt → ∀ {v : ℕ},
    countRun w (cval lt) = some v → ∀ rest : List RB,
      ∃ lt' k, BRun b4 ⟨lt, .Rt, w ++ rest⟩ ⟨lt', .Rt, rest⟩ k ∧ CStack lt' ∧ cval lt' = v := by
  intro w
  induction w with
  | nil =>
      intro lt hst v h rest
      obtain rfl := Option.some.inj h
      exact ⟨lt, 0, by simpa using BRun.refl (b4 := b4) _, hst, rfl⟩
  | cons b w ih =>
      intro lt hst v h rest
      rw [countRun, Option.bind_eq_some_iff] at h
      obtain ⟨v₁, h1, h2⟩ := h
      obtain ⟨lt₁, k₁, hrun₁, hst₁, hv₁⟩ := brun_count_step (b4 := b4) hst (w ++ rest) h1
      obtain ⟨lt₂, k₂, hrun₂, hst₂, hv₂⟩ := ih hst₁ (by rw [hv₁]; exact h2) rest
      exact ⟨lt₂, k₁ + k₂, by simpa using hrun₁.trans hrun₂, hst₂, hv₂⟩

/-- **The other way a counter phase can end: the overflow.**  When `countStep`
fails because the counter is exhausted at a turn (`11` or `12`), the head does
not get stuck: it runs off the bottom of the stack and reaches the left end,
where the pending digit of the next reset phase is created. -/
theorem brun_count_overflow {lt : List LB} (hst : CStack lt) (h : cval lt = 0) {b : RB}
    (hb : b = RB.X ∨ b = RB.U) (rest : List RB) :
    ∃ rt' k, BRun (b4 := b4) ⟨lt, .Rt, b :: rest⟩ ⟨[.L], .Lt, rt'⟩ k := by
  rcases hb with rfl | rfl
  · obtain ⟨rt', k, hrun⟩ := cval_overflow (b4 := b4) hst h (.V :: rest)
    exact ⟨rt', 1 + k, BRun.head (show bstep b4 ⟨lt, .Rt, .X :: rest⟩
      = some (⟨lt, .Lt, .V :: rest⟩, 1) from rfl) hrun⟩
  · obtain ⟨rt', k, hrun⟩ := cval_overflow (b4 := b4) hst h (.Y :: rest)
    exact ⟨rt', 1 + k, BRun.head (show bstep b4 ⟨lt, .Rt, .U :: rest⟩
      = some (⟨lt, .Lt, .Y :: rest⟩, 1) from rfl) hrun⟩

/-- **The other way a reset phase can end: a nested overflow.**  When
`resetStep` fails — the offset is `1>` and the counter is exhausted — the head
again reaches the left end, where a fresh pending digit is created. -/
theorem brun_reset_overflow {lt : List LB} (hst : CStack lt) (h : cval lt = 0) {b : RB}
    (hb : b = RB.X ∨ b = RB.V ∨ b = RB.Y ∨ b = RB.U) (rest : List RB) :
    ∃ rt' k, BRun (b4 := b4) ⟨lt, .Rt, pd false :: b :: rest⟩ ⟨[.L], .Lt, rt'⟩ k := by
  rcases hb with rfl | rfl | rfl | rfl
  · obtain ⟨rt', k, hrun⟩ := cval_overflow (b4 := b4) hst h (.V :: .P1 :: rest)
    exact ⟨rt', 0 + (1 + k), BRun.head (show bstep b4 ⟨lt, .Rt, .P1 :: .X :: rest⟩
        = some (⟨lt, .Rt, .X :: .P1 :: rest⟩, 0) from rfl)
      (BRun.head (show bstep b4 ⟨lt, .Rt, .X :: .P1 :: rest⟩
        = some (⟨lt, .Lt, .V :: .P1 :: rest⟩, 1) from rfl) hrun)⟩
  · obtain ⟨rt', k, hrun⟩ := cval_overflow (b4 := b4) hst h (.Y :: .P1 :: rest)
    exact ⟨rt', 0 + (1 + k), BRun.head (show bstep b4 ⟨lt, .Rt, .P1 :: .V :: rest⟩
        = some (⟨lt, .Rt, .U :: .P1 :: rest⟩, 0) from rfl)
      (BRun.head (show bstep b4 ⟨lt, .Rt, .U :: .P1 :: rest⟩
        = some (⟨lt, .Lt, .Y :: .P1 :: rest⟩, 1) from rfl) hrun)⟩
  · obtain ⟨rt', k, hrun⟩ := cval_overflow (b4 := b4) hst h (.Y :: .P2 :: rest)
    exact ⟨rt', 0 + (1 + k), BRun.head (show bstep b4 ⟨lt, .Rt, .P1 :: .Y :: rest⟩
        = some (⟨lt, .Rt, .U :: .P2 :: rest⟩, 0) from rfl)
      (BRun.head (show bstep b4 ⟨lt, .Rt, .U :: .P2 :: rest⟩
        = some (⟨lt, .Lt, .Y :: .P2 :: rest⟩, 1) from rfl) hrun)⟩
  · obtain ⟨rt', k, hrun⟩ := cval_overflow (b4 := b4) hst h (.V :: .P2 :: rest)
    exact ⟨rt', 0 + (1 + k), BRun.head (show bstep b4 ⟨lt, .Rt, .P1 :: .U :: rest⟩
        = some (⟨lt, .Rt, .X :: .P2 :: rest⟩, 0) from rfl)
      (BRun.head (show bstep b4 ⟨lt, .Rt, .X :: .P2 :: rest⟩
        = some (⟨lt, .Lt, .V :: .P2 :: rest⟩, 1) from rfl) hrun)⟩

/-- **The end of the counter phase.**  Reaching the right end of the tape in
state `A>` with the marker `R1` costs one more excursion and then starts the
`<B1` sweep — the only point at which the machine can halt. -/
theorem brun_count_end {lt : List LB} (hst : CStack lt) (h : 1 ≤ cval lt) :
    ∃ lt' k, BRun b4 ⟨lt, .Rt, [.R1]⟩ ⟨lt', .Bt, [.Y, .R1]⟩ k ∧ CStack lt' ∧
      cval lt' = cval lt - 1 := by
  obtain ⟨lt₁, k, hrun, hst₁, _, hv₁⟩ := cval_decrement (b4 := b4) hst h [.R2]
  refine ⟨lt₁, 1 + (k + 11), ?_, hst₁, hv₁⟩
  exact BRun.head (show bstep b4 ⟨lt, .Rt, [.R1]⟩ = some (⟨lt, .Lt, [.R2]⟩, 1) from rfl)
    (hrun.trans (BRun.of_step
      (show bstep b4 ⟨lt₁, .Rt, [.R2]⟩ = some (⟨lt₁, .Bt, [.Y, .R1]⟩, 11) from rfl)))

/--
**One whole counter phase, and the `<B1` event that follows it.**  The head
starts at the left of the tape word `w`, swallows it digit by digit as
`countRun` predicts, reaches the right end, and survives the `<B1` sweep —
provided the predicted counter value is at least `2`, one unit being spent by
the last excursion.  Together with `brun_reset_cycle` this covers the whole
cycle of a shift-overflow counter: the counter phase runs until the counter
overflows, the overflow sends the head to the left end, and the reset phase
re-parses the tape into a new counter.
-/
theorem brun_count_cycle (hb : Bounces b4) (w : List RB) {lt : List LB} (hst : CStack lt)
    {v : ℕ} (h : countRun w (cval lt) = some v) (hv : 2 ≤ v) :
    ∃ (s : List LB) (pre : List RB) (k : ℕ),
      BRun b4 ⟨lt, .Rt, w ++ [.R1]⟩ ⟨s, .Lt, pre ++ [.Y, .R1]⟩ k ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G := by
  obtain ⟨lt₁, k₁, hrun₁, hst₁, hv₁⟩ := brun_count (b4 := b4) w hst h [.R1]
  obtain ⟨lt₂, k₂, hrun₂, hst₂, hv₂⟩ := brun_count_end (b4 := b4) hst₁ (by omega)
  obtain ⟨s, pre, k₃, hrun₃, hst₃, hpre⟩ :=
    brun_Bt_clear (b4 := b4) hb hst₂ (by omega) [.Y, .R1]
  exact ⟨s, pre, k₁ + (k₂ + k₃), hrun₁.trans (hrun₂.trans hrun₃), hst₃, hpre⟩

/-!
## The converse

If the counter overflows under a fresh `141` the machine is in trouble: the
head runs off the bottom of the stack, a pending digit `2>` is created at the
left end and walks into the `141`.  The case in which the stack below the `03`
contains no further `03` is `BB25.halts_Lt_Xrun_F` of `Sweep.lean` (the head
then deposits only `22` blocks, which the pending digit crosses unharmed);
`BB25.halts_WZL_F` of `Invariant.lean` is the smallest case with a `03` below.
-/

end BB25
