import RequestProject.BB25.Reduction

/-!
# Two of the thirteen members have the same block dynamics

The members `2RB` and `0RA` of the family differ in what their `A> 241` rule
puts on the left stack: `2RB` writes the block `J = 023` and `0RA` writes the
block `K1 = 011` (and they take a different number of base steps to do it).
But `023` and `011` behave *identically* in the block analysis: under `<A`
both turn into `11` and send the head right with a pending `2>`, and neither
has a rule under `<B1`.  Renaming `023` to `011` is therefore an isomorphism
between the block simulations of the two members.

Consequently the longitudinal analysis of `2RB` and of `0RA` is literally the
same computation, and any proof of non-halting obtained from the block
analysis of one of them transfers to the other.
-/

namespace BB25

/-- Renaming the block `023` of `2RB` to the block `011` of `0RA`. -/
def swapJK : LB → LB
  | .J => .K1
  | b => b

@[simp] theorem swapJK_idem (b : LB) : swapJK (swapJK b) = swapJK b := by
  cases b <;> rfl

/-- The renaming, on block configurations. -/
def mapC (c : BCfg) : BCfg := ⟨c.lt.map swapJK, c.st, c.rt⟩

@[simp] theorem mapC_idem (c : BCfg) : mapC (mapC c) = mapC c := by
  simp [mapC, List.map_map, Function.comp_def]

@[simp] theorem mapC_binit : mapC binit = binit := rfl

/-- **The block simulations of `2RB` and `0RA` are isomorphic**: one block step
of `2RB` is one block step of `0RA` on the renamed configuration (the number of
base steps it stands for may differ). -/
theorem bstep_twin (c : BCfg) :
    (bstep b4_2RB c).map (fun p => mapC p.1)
      = (bstep b4_0RA (mapC c)).map (fun p => p.1) := by
  obtain ⟨lt, st, rt⟩ := c
  cases st
  case Rt =>
      rcases rt with _ | ⟨b, rt⟩
      · rfl
      cases b <;> try rfl
      -- the two pending-digit blocks need one more block of look-ahead
      all_goals rcases rt with _ | ⟨b₂, rt₂⟩
      all_goals first
        | rfl
        | (cases b₂ <;> rfl)
  case Lt =>
      rcases lt with _ | ⟨a, lt⟩
      · rfl
      cases a <;> try rfl
      -- the left end `^11` is the one-element stack `[L]`
      rcases lt with _ | ⟨a₂, lt₂⟩
      · rfl
      · cases a₂ <;> rfl
  case Bt =>
      rcases lt with _ | ⟨a, lt⟩
      · rfl
      cases a <;> rfl

theorem bstep_twin_some {c c₁ : BCfg} {k : ℕ} (h : bstep b4_2RB c = some (c₁, k)) :
    ∃ k', bstep b4_0RA (mapC c) = some (mapC c₁, k') := by
  have := bstep_twin c
  rw [h] at this
  cases hb : bstep b4_0RA (mapC c) with
  | none => rw [hb] at this; simp at this
  | some p =>
      obtain ⟨d, k'⟩ := p
      rw [hb] at this
      simp only [Option.map_some] at this
      exact ⟨k', by rw [Option.some.inj this]⟩

theorem bstep_twin_none {c : BCfg} (h : bstep b4_2RB c = none) :
    bstep b4_0RA (mapC c) = none := by
  have := bstep_twin c
  rw [h] at this
  cases hb : bstep b4_0RA (mapC c) with
  | none => rfl
  | some p => rw [hb] at this; simp at this

theorem bstep_twin_some' {c d : BCfg} {k' : ℕ} (h : bstep b4_0RA (mapC c) = some (d, k')) :
    ∃ c₁ k, bstep b4_2RB c = some (c₁, k) ∧ mapC c₁ = d := by
  cases hb : bstep b4_2RB c with
  | none => rw [bstep_twin_none hb] at h; simp at h
  | some p =>
      obtain ⟨c₁, k⟩ := p
      obtain ⟨k'', h'⟩ := bstep_twin_some hb
      rw [h'] at h
      exact ⟨c₁, k, rfl, (Prod.mk.inj (Option.some.inj h)).1⟩

/-- The renaming carries the whole simulation of `2RB` to that of `0RA`. -/
theorem bsteps_isSome_twin : ∀ (n : ℕ) (c : BCfg),
    (bsteps b4_2RB n c).isSome = (bsteps b4_0RA n (mapC c)).isSome := by
  intro n
  induction n with
  | zero => intro c; rfl
  | succ n ih =>
      intro c
      rw [bsteps, bsteps]
      cases hb : bstep b4_2RB c with
      | none => rw [bstep_twin_none hb]; rfl
      | some p =>
          obtain ⟨c₁, k⟩ := p
          obtain ⟨k', hb'⟩ := bstep_twin_some hb
          rw [hb']
          simpa using ih c₁

theorem neverStuck_twin (c : BCfg) :
    NeverStuck b4_2RB c ↔ NeverStuck b4_0RA (mapC c) := by
  constructor <;> intro h n
  · rw [← bsteps_isSome_twin]; exact h n
  · rw [bsteps_isSome_twin]; exact h n

/-- **The two members stand or fall together (as far as the block analysis is
concerned).**  If the block simulation of `0RA` never gets stuck then neither
machine halts, and likewise with the two members exchanged. -/
theorem not_halts_twins (h : NeverStuck b4_0RA binit ∨ NeverStuck b4_2RB binit) :
    ¬ Halts (M b4_2RB) init ∧ ¬ Halts (M b4_0RA) init := by
  have h0 : NeverStuck b4_2RB binit := by
    rcases h with h | h
    · exact (neverStuck_twin binit).mpr (by simpa using h)
    · exact h
  have h1 : NeverStuck b4_0RA binit := by
    simpa using (neverStuck_twin binit).mp h0
  exact ⟨not_halts_of_neverStuck h0, not_halts_of_neverStuck h1⟩

end BB25
