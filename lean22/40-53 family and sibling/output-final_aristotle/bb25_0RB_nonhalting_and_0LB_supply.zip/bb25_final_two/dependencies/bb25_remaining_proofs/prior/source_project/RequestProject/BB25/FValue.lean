/-
# The rebuilt counter `f`: how it is transformed, and which of its invariants decide halting

`Phase.lean` computes, for a word `w` of digit blocks, the shift map
`rmap true w = (ph, ⟨c, d, e, f⟩)` of the reset phase that re-parses it: `f` is
the value of the counter the reset hands back to the left-hand side and `e` its
number of digits.  `Counter.lean` (`brun_reset_cycle`) shows that this single
number decides the fate of the whole cycle: if the reset ends in phase `2>`
with `f ≥ 1`, or in phase `1>` with `f ≥ 2`, then the `<B1` event at the far end
of the tape is survived and the machine comes back to the left end with a
well-formed counter stack.  So for the members whose `A> 241` merely bounces
(`Bounces b4`) the *only* danger is a reset that rebuilds `f ≤ 1`.

This file studies the transformations of `f` themselves.

## The three primitive transformations

Reading a word in the reset phase composes three operations on `⟨e, f⟩`:
`push` (`f ↦ 2f+1`, `e ↦ e+1`) at a bit block, `pop` (`f ↦ f/2`, `e ↦ e-1`) at a
shift block, and, in phase `1>` only, a `dec` (`f ↦ f-1`) before the block.

## Runs: two exactly linear laws

* a run of `22` blocks (`Y`) multiplies `f + 1` by two per block
  (`rmapFrom_Yrun`): from a fresh start `Y^n` builds `f = 2^n - 1`;
* a run of `21` blocks (`V`) multiplies `f - 1` by two per block
  (`rmapFrom_Vrun`), because after a `V` the phase is `1>`, so each further `V`
  performs `dec` and then `push`: `f ↦ 2f - 1`.

The second law explains the empirical observation that `f ≡ 1 (mod 8)` from the
sixth overflow onwards for every member: the words the machine deposits end in
a run of `21` blocks, and a trailing run of `n` of them forces
`f ≡ 1 (mod 2^(n-1))` (`rmap_Vrun_mod`).  **It also shows why no such modular
law can decide the halting problem**: the dangerous value `f = 1` is itself
`≡ 1 (mod 2^k)` for every `k`, and indeed `f = 1` after the run exactly when
`f = 1` before it (`rmapFrom_Vrun_eq_one_iff`).  A modular invariant of `f` is
never enough; what is needed is a *lower bound* on `f`.

## The invariant that does decide it: the deficit

The right quantity is the **deficit** `δ = 2^e - (f+1)`, the distance of `f`
from the all-ones numeral, equivalently the normalised value
`t = (f+1)/2^e ∈ (0,1]`.  Its transformation law is exact and simple:

```
    push :  δ ↦ 2δ           (t unchanged)
    pop  :  2δ' ≤ δ          (t does not decrease)
    dec  :  δ ↦ δ + 1        (t decreases by exactly 2^-e)
```

So `t` is a monotone quantity: it *only* decreases, and only at decrements, by
`2^-e` each — the deeper the counter, the less a decrement costs.  Summing the
losses along the word (`rcostFrom`) gives `tval_rmapFrom_ge`, and hence the
criterion `rmap_f_lower`: if the total cost of a word is at most `1/2` then

```
    2 ^ (e - 1) ≤ f + 1 ,
```

i.e. the top bit of `f` is set — a *non-modular* invariant, which is what the
empirical data actually shows (the value of `f` has exactly `e` binary digits at
every overflow of every member, and at every intermediate step of every reset).
Together with `e ≥ 3` it gives `f ≥ 3`, which is exactly the hypothesis of
`brun_reset_cycle`: `reset_cycle_of_cost` packages the two into a survival
theorem for one full cycle, and `danger_iff_f_le_one` states the reduction the
other way round: for a bouncing member, a reset word is dangerous only if it
rebuilds `f ≤ 1`.

Two decidable forms of the criterion avoid rational arithmetic: the integer cost
`rncost K` at a fixed scale `2 ^ K` (`rcost_le_half_of_nat`,
`reset_cycle_of_ncost`), which is what `FTrace.lean` checks in the kernel
against the runs themselves, and the coarser counting form
`rcost_le_half_of_deep` — at most `2 ^ (m-1)` decrements, all at digit count at
least `m`.
-/
import RequestProject.BB25.Counter
import RequestProject.BB25.Phase

namespace BB25

variable {b4 : Option (Sym × Dir × St)}

namespace SMap

/-! ## The deficit `2^e - (f+1)` and the normalised value `(f+1)/2^e` -/

/-- The **deficit** of a shift map: how far the rebuilt counter `f` is below the
all-ones numeral `2^e - 1` of its digit count. -/
def deficit (p : SMap) : ℕ := 2 ^ p.e - (p.f + 1)

/-- The **normalised value** of the rebuilt counter, `(f+1)/2^e ∈ (0,1]`. -/
def tval (p : SMap) : ℚ := (p.f + 1) / 2 ^ p.e

theorem tval_pos (p : SMap) : 0 < tval p := by
  have h : (0:ℚ) < 2 ^ p.e := by positivity
  have : (0:ℚ) < (p.f : ℚ) + 1 := by positivity
  exact div_pos this h

theorem tval_le_one {p : SMap} (hp : WF p) : tval p ≤ 1 := by
  have h : (0:ℚ) < 2 ^ p.e := by positivity
  rw [tval, div_le_one h]
  have : (p.f : ℚ) + 1 ≤ 2 ^ p.e := by
    have := hp
    have h2 : p.f + 1 ≤ 2 ^ p.e := this
    exact_mod_cast h2
  simpa using this

theorem deficit_eq {p : SMap} (hp : WF p) : p.f + 1 + p.deficit = 2 ^ p.e := by
  have h : p.f + 1 ≤ 2 ^ p.e := hp
  simp only [deficit]
  omega

/-- **A bit block doubles the deficit** (the normalised value is unchanged). -/
theorem deficit_push (p : SMap) : (push p).deficit = 2 * p.deficit := by
  simp only [deficit, push, pow_succ]
  omega

/-- **A shift block at least halves the deficit.** -/
theorem deficit_pop (p : SMap) (hp : WF p) : 2 * (pop p).deficit ≤ p.deficit := by
  unfold pop
  split
  · rename_i he
    have : p.f = 0 := by have : p.f < 2 ^ p.e := hp; rw [he] at this; omega
    simp [deficit, he, this]
  · rename_i he
    have h1 : p.f < 2 ^ p.e := hp
    obtain ⟨k, hk⟩ : ∃ k, p.e = k + 1 := ⟨p.e - 1, by omega⟩
    have h2 : (2:ℕ) ^ p.e = 2 * 2 ^ k := by rw [hk, pow_succ]; ring
    simp only [deficit, hk, Nat.add_sub_cancel]
    have h3 : p.f / 2 * 2 ≤ p.f := Nat.div_mul_le_self _ _
    have h4 : p.f < 2 * 2 ^ k := by omega
    have h5 : p.f / 2 < 2 ^ k := by omega
    omega

/-- **A decrement adds one to the deficit** (it can only help when the numeral
is exhausted, where the threshold `c` rises instead). -/
theorem deficit_dec (p : SMap) (hp : WF p) : (dec p).deficit ≤ p.deficit + 1 := by
  unfold dec
  split
  · rename_i hf
    have : (2:ℕ) ^ p.e - 1 + 1 = 2 ^ p.e := by
      have : 1 ≤ 2 ^ p.e := Nat.one_le_two_pow
      omega
    simp [deficit, this]
  · rename_i hf
    have h1 : p.f < 2 ^ p.e := hp
    simp only [deficit]
    omega

theorem tval_push (p : SMap) : tval (push p) = tval p := by
  simp only [tval, push, pow_succ]
  push_cast
  rw [div_eq_div_iff (by positivity) (by positivity)]
  ring

theorem tval_pop (p : SMap) (hp : WF p) : tval p ≤ tval (pop p) := by
  unfold pop
  split
  · rename_i he
    have hf : p.f = 0 := by have : p.f < 2 ^ p.e := hp; rw [he] at this; omega
    simp [tval, he, hf]
  · rename_i he
    obtain ⟨k, hk⟩ : ∃ k, p.e = k + 1 := ⟨p.e - 1, by omega⟩
    simp only [tval, hk, Nat.add_sub_cancel]
    rw [div_le_div_iff₀ (by positivity) (by positivity)]
    have h3 : p.f ≤ 2 * (p.f / 2) + 1 := by omega
    have h3' : (p.f : ℚ) ≤ 2 * ((p.f / 2 : ℕ) : ℚ) + 1 := by exact_mod_cast h3
    have hpow : (0:ℚ) < 2 ^ k := by positivity
    rw [pow_succ]
    nlinarith

/-- **A decrement costs exactly `2^-e` of normalised value** (and less when the
numeral is exhausted, where the threshold rises instead). -/
theorem tval_dec (p : SMap) : tval p - 1 / 2 ^ p.e ≤ tval (dec p) := by
  unfold dec
  split
  · rename_i hf
    have h1 : (1:ℕ) ≤ 2 ^ p.e := Nat.one_le_two_pow
    have hc : ((2 ^ p.e - 1 : ℕ) : ℚ) + 1 = 2 ^ p.e := by
      have h2 : ((2 ^ p.e - 1 : ℕ) : ℚ) = (2:ℚ) ^ p.e - 1 := by
        push_cast [Nat.cast_sub h1]; ring
      rw [h2]; ring
    simp only [tval]
    rw [hc]
    have hp2 : (0:ℚ) < 2 ^ p.e := by positivity
    rw [div_self (ne_of_gt hp2)]
    have hle : ((p.f : ℚ) + 1) / 2 ^ p.e ≤ 1 := by
      rw [div_le_one hp2]
      have h1' : (1:ℚ) ≤ 2 ^ p.e := by exact_mod_cast h1
      simp [hf]; linarith
    have hnn : (0:ℚ) < 1 / 2 ^ p.e := by positivity
    linarith
  · rename_i hf
    have hf' : 1 ≤ p.f := Nat.one_le_iff_ne_zero.mpr hf
    have hc : ((p.f - 1 : ℕ) : ℚ) = (p.f : ℚ) - 1 := by
      rw [Nat.cast_sub hf']; norm_num
    simp only [tval]
    rw [hc]
    have hp2 : (0:ℚ) < 2 ^ p.e := by positivity
    rw [div_sub_div_same]
    ring_nf
    rfl

end SMap

/-! ## Runs of one block: the two linear laws -/

/-- **A run of `22` blocks doubles `f + 1` per block.**  (After a `22` the phase
is `2>`, so no decrement intervenes: each block is a plain `push`.) -/
theorem rmapFrom_Yrun (p : SMap) (n : ℕ) :
    (rmapFrom true p (List.replicate n RB.Y)).2.f + 1 = 2 ^ n * (p.f + 1) ∧
      (rmapFrom true p (List.replicate n RB.Y)).2.e = p.e + n ∧
      (rmapFrom true p (List.replicate n RB.Y)).1 = true := by
  induction n generalizing p with
  | zero => simp [rmapFrom]
  | succ n ih =>
      have hstep : rmapStep true p RB.Y = p.push := rfl
      simp only [List.replicate_succ, rmapFrom, rphaseStep, hstep]
      obtain ⟨h1, h2, h3⟩ := ih p.push
      refine ⟨?_, ?_, h3⟩
      · rw [h1]; simp [SMap.push, pow_succ]; ring
      · rw [h2]; simp [SMap.push]; omega

/-- **A run of `21` blocks doubles `f - 1` per block.**  (After a `21` the phase
is `1>`, so every further block costs a decrement first: `f ↦ 2(f-1)+1`.) -/
theorem rmapFrom_Vrun (p : SMap) (hp : SMap.WF p) (hf : 1 ≤ p.f) (n : ℕ) :
    (rmapFrom false p (List.replicate n RB.V)).2.f = 2 ^ n * (p.f - 1) + 1 ∧
      (rmapFrom false p (List.replicate n RB.V)).2.e = p.e + n := by
  induction n generalizing p with
  | zero => simp [rmapFrom]; omega
  | succ n ih =>
      have hstep : rmapStep false p RB.V = p.dec.push := rfl
      have hdecf : p.dec.f = p.f - 1 := by
        unfold SMap.dec; rw [if_neg (by omega)]
      have hdece : p.dec.e = p.e := by unfold SMap.dec; split <;> rfl
      have hwf : SMap.WF p.dec.push := SMap.WF_push _ (SMap.WF_dec _ hp)
      have hf' : 1 ≤ p.dec.push.f := by simp [SMap.push]
      simp only [List.replicate_succ, rmapFrom, rphaseStep, hstep]
      obtain ⟨h1, h2⟩ := ih p.dec.push hwf hf'
      refine ⟨?_, ?_⟩
      · rw [h1]
        simp only [SMap.push, hdecf]
        have : 2 * (p.f - 1) + 1 - 1 = 2 * (p.f - 1) := by omega
        rw [this, pow_succ]
        ring
      · rw [h2]; simp [SMap.push]; omega

/-- **A trailing run of `21` blocks forces `f ≡ 1` modulo a power of two.**
This is the reason the rebuilt counter is `≡ 1 (mod 8)` from some point on: the
deposited words end in runs of `21` blocks. -/
theorem rmapFrom_Vrun_mod (p : SMap) (hp : SMap.WF p) (hf : 1 ≤ p.f) (n : ℕ) :
    (rmapFrom false p (List.replicate n RB.V)).2.f % 2 ^ n = 1 % 2 ^ n := by
  rw [(rmapFrom_Vrun p hp hf n).1, Nat.mul_add_mod]

/-- **…and it cannot rule the dangerous value out.**  The rebuilt counter is `1`
after a run of `21` blocks exactly when it was `1` before it, so a congruence
`f ≡ 1 (mod 2^k)` — which the value `f = 1` satisfies — can never certify
non-halting on its own. -/
theorem rmapFrom_Vrun_eq_one_iff (p : SMap) (hp : SMap.WF p) (hf : 1 ≤ p.f) (n : ℕ) :
    (rmapFrom false p (List.replicate n RB.V)).2.f = 1 ↔ p.f = 1 := by
  rw [(rmapFrom_Vrun p hp hf n).1]
  have h2 : 0 < 2 ^ n := Nat.two_pow_pos n
  constructor
  · intro h
    have : 2 ^ n * (p.f - 1) = 0 := by omega
    rcases Nat.mul_eq_zero.mp this with h' | h'
    · omega
    · omega
  · intro h; simp [h]

/-! ## The cost of a word, and the lower bound on `f` -/

/-- The total normalised value a word costs: `2^-e` for every block read in
phase `1>`, at the digit count `e` the counter has when the block is read. -/
def rcostFrom (ph : Bool) (p : SMap) : List RB → ℚ
  | [] => 0
  | b :: w => (if ph then 0 else 1 / 2 ^ p.e) + rcostFrom (rphaseStep b) (rmapStep ph p b) w

/-- The cost of a word read from a fresh start (the left end, pending `2>`). -/
def rcost (w : List RB) : ℚ := rcostFrom true SMap.one w

theorem rcostFrom_nonneg (ph : Bool) (p : SMap) (w : List RB) : 0 ≤ rcostFrom ph p w := by
  induction w generalizing ph p with
  | nil => simp [rcostFrom]
  | cons b w ih =>
      have : (0:ℚ) ≤ if ph then 0 else 1 / 2 ^ p.e := by
        cases ph <;> simp
      have := ih (rphaseStep b) (rmapStep ph p b)
      simp only [rcostFrom]
      linarith

theorem tval_rmapStep {p : SMap} (hp : SMap.WF p) (ph : Bool) (b : RB) :
    SMap.tval p - (if ph then 0 else 1 / 2 ^ p.e) ≤ SMap.tval (rmapStep ph p b) := by
  have key : ∀ q : SMap, SMap.WF q → SMap.tval q ≤ SMap.tval (rmapStep true q b) := by
    intro q hq
    cases b <;>
      simp only [rmapStep, if_true] <;>
      first
        | exact le_of_eq (SMap.tval_push q).symm
        | exact SMap.tval_pop q hq
        | exact le_refl _
  cases ph with
  | true => simpa using key p hp
  | false =>
      have hdec : SMap.tval p - 1 / 2 ^ p.e ≤ SMap.tval p.dec := SMap.tval_dec p
      have hwf : SMap.WF p.dec := SMap.WF_dec _ hp
      have hstep : rmapStep false p b = rmapStep true p.dec b := by cases b <;> rfl
      have := key p.dec hwf
      rw [hstep]
      simp only [Bool.false_eq_true, if_false]
      linarith

/-- **The normalised value only decreases at decrements.**  Reading a word can
cost at most `rcostFrom` of normalised value; the deeper the counter is when a
decrement happens, the less it costs. -/
theorem tval_rmapFrom_ge {p : SMap} (hp : SMap.WF p) (ph : Bool) (w : List RB) :
    SMap.tval p - rcostFrom ph p w ≤ SMap.tval (rmapFrom ph p w).2 := by
  induction w generalizing ph p with
  | nil => simp [rmapFrom, rcostFrom]
  | cons b w ih =>
      have h1 := tval_rmapStep hp ph b
      have h2 := ih (rmapStep_WF hp ph b) (rphaseStep b)
      simp only [rmapFrom, rcostFrom]
      linarith

/-- **The lower bound on the rebuilt counter.**  If a word costs at most half of
the normalised value then the top bit of the counter it rebuilds is set:
`2^(e-1) ≤ f + 1`.  This is a non-modular invariant of `f`, and it is the one
the family actually satisfies. -/
theorem rmap_f_lower {w : List RB} (h : rcost w ≤ 1 / 2) :
    2 ^ ((rmap true w).2.e - 1) ≤ (rmap true w).2.f + 1 := by
  have hone : SMap.tval SMap.one = 1 := by simp [SMap.tval, SMap.one]
  have hge := tval_rmapFrom_ge (p := SMap.one) SMap.WF_one true w
  rw [hone] at hge
  have h2 : (1:ℚ) / 2 ≤ SMap.tval (rmap true w).2 := by
    rw [rmap]
    have : (1:ℚ) - rcostFrom true SMap.one w ≥ 1 - 1/2 := by
      have : rcostFrom true SMap.one w ≤ 1/2 := h
      linarith
    linarith
  set p := (rmap true w).2 with hp
  have hpow : (0:ℚ) < 2 ^ p.e := by positivity
  rw [SMap.tval, le_div_iff₀ hpow] at h2
  -- `2 ^ e ≤ 2 * (f + 1)` in ℚ, hence in ℕ
  have h3 : (2:ℚ) ^ p.e ≤ 2 * ((p.f : ℚ) + 1) := by linarith
  have h4 : (2:ℕ) ^ p.e ≤ 2 * (p.f + 1) := by exact_mod_cast h3
  rcases Nat.eq_zero_or_pos p.e with he | he
  · simp [he]
  · obtain ⟨k, hk⟩ : ∃ k, p.e = k + 1 := ⟨p.e - 1, by omega⟩
    rw [hk] at h4 ⊢
    simp only [Nat.add_sub_cancel]
    rw [pow_succ] at h4
    omega

/-- The rebuilt counter is at least `3` as soon as the word is cheap and builds
at least three digits. -/
theorem rmap_f_ge_two {w : List RB} (h : rcost w ≤ 1 / 2) (he : 3 ≤ (rmap true w).2.e) :
    3 ≤ (rmap true w).2.f := by
  have h1 := rmap_f_lower h
  have h2 : (2:ℕ) ^ 2 ≤ 2 ^ ((rmap true w).2.e - 1) :=
    Nat.pow_le_pow_right (by norm_num) (by omega)
  simp only [] at h2
  omega

/-! ## A kernel-checkable form of the cost: integer arithmetic at a fixed scale -/

/-- The cost of a word measured in units of `2 ^ -K`, rounded **up**: a
decrement at digit count `e` counts `2 ^ (K - e)`, which is `2 ^ K` times its
real cost `2 ^ -e` when `e ≤ K`, and an over-estimate when `e > K` (natural
subtraction truncates to `2 ^ 0 = 1 ≥ 2 ^ (K - e)`).  Unlike `rcostFrom`, this
is a natural number, so the criterion below can be checked by `decide`. -/
def rncostFrom (K : ℕ) (ph : Bool) (p : SMap) : List RB → ℕ
  | [] => 0
  | b :: w => (if ph then 0 else 2 ^ (K - p.e)) + rncostFrom K (rphaseStep b) (rmapStep ph p b) w

/-- The integer cost of a word read from a fresh start, at scale `2 ^ K`. -/
def rncost (K : ℕ) (w : List RB) : ℕ := rncostFrom K true SMap.one w

theorem rcostFrom_le_rncostFrom (K : ℕ) (ph : Bool) (p : SMap) (w : List RB) :
    rcostFrom ph p w ≤ (rncostFrom K ph p w : ℚ) / 2 ^ K := by
  induction w generalizing ph p with
  | nil => simp [rcostFrom, rncostFrom]
  | cons b w ih =>
      have hterm : (if ph then (0:ℚ) else 1 / 2 ^ p.e)
          ≤ ((if ph then 0 else 2 ^ (K - p.e) : ℕ) : ℚ) / 2 ^ K := by
        cases ph with
        | true => simp
        | false =>
            simp only [Bool.false_eq_true, if_false]
            rcases Nat.lt_or_ge K p.e with hlt | hle
            · have hK : K - p.e = 0 := by omega
              rw [hK]
              have h1 : (1:ℚ) / 2 ^ p.e ≤ 1 / 2 ^ K := by
                apply div_le_div_of_nonneg_left (by norm_num) (by positivity)
                exact pow_le_pow_right₀ (by norm_num) (le_of_lt hlt)
              simpa using h1
            · have hEq : ((2 ^ (K - p.e) : ℕ) : ℚ) / 2 ^ K = 1 / 2 ^ p.e := by
                push_cast
                rw [div_eq_div_iff (by positivity) (by positivity), one_mul, ← pow_add,
                  Nat.sub_add_cancel hle]
              rw [hEq]
      have hrec := ih (rphaseStep b) (rmapStep ph p b)
      simp only [rcostFrom, rncostFrom, Nat.cast_add, add_div]
      linarith

theorem rcost_le_rncost (K : ℕ) (w : List RB) : rcost w ≤ (rncost K w : ℚ) / 2 ^ K :=
  rcostFrom_le_rncostFrom K true SMap.one w

/-- **The cost criterion in integer form.**  `2 * rncost K w ≤ 2 ^ K` implies
`rcost w ≤ 1/2`, and is decidable. -/
theorem rcost_le_half_of_nat {K : ℕ} {w : List RB} (h : 2 * rncost K w ≤ 2 ^ K) :
    rcost w ≤ 1 / 2 := by
  have h1 : ((2 * rncost K w : ℕ) : ℚ) ≤ ((2 ^ K : ℕ) : ℚ) := by exact_mod_cast h
  push_cast at h1
  have h2 : (rncost K w : ℚ) / 2 ^ K ≤ 1 / 2 := by
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]
    linarith
  exact le_trans (rcost_le_rncost K w) h2

/-! ## A human-readable form of the same criterion: how many decrements, how deep -/

/-- The number of blocks of a word that are read in phase `1>`, i.e. the number
of decrements the reset performs. -/
def rdecCountFrom (ph : Bool) (p : SMap) : List RB → ℕ
  | [] => 0
  | b :: w => (if ph then 0 else 1) + rdecCountFrom (rphaseStep b) (rmapStep ph p b) w

/-- Do all the decrements of a word happen at digit count at least `m`? -/
def rdecDeepFrom (m : ℕ) (ph : Bool) (p : SMap) : List RB → Bool
  | [] => true
  | b :: w => (ph || decide (m ≤ p.e)) && rdecDeepFrom m (rphaseStep b) (rmapStep ph p b) w

def rdecCount (w : List RB) : ℕ := rdecCountFrom true SMap.one w

def rdecDeep (m : ℕ) (w : List RB) : Bool := rdecDeepFrom m true SMap.one w

theorem rcostFrom_le_of_deep {m : ℕ} (ph : Bool) (p : SMap) (w : List RB)
    (h : rdecDeepFrom m ph p w = true) :
    rcostFrom ph p w ≤ (rdecCountFrom ph p w : ℚ) / 2 ^ m := by
  induction w generalizing ph p with
  | nil => simp [rcostFrom, rdecCountFrom]
  | cons b w ih =>
      rw [rdecDeepFrom, Bool.and_eq_true] at h
      have hterm : (if ph then (0:ℚ) else 1 / 2 ^ p.e)
          ≤ ((if ph then 0 else 1 : ℕ) : ℚ) / 2 ^ m := by
        cases ph with
        | true => simp
        | false =>
            have hm : m ≤ p.e := by simpa using h.1
            simp only [Bool.false_eq_true, if_false, Nat.cast_one]
            apply div_le_div_of_nonneg_left (by norm_num) (by positivity)
            exact pow_le_pow_right₀ (by norm_num) hm
      have hrec := ih (rphaseStep b) (rmapStep ph p b) h.2
      simp only [rcostFrom, rdecCountFrom, Nat.cast_add, add_div]
      linarith

/-- **The criterion in counting form.**  If every decrement of a word happens at
digit count at least `m`, and the word has at most `2 ^ (m-1)` decrements, then
the word is cheap: `rcost w ≤ 1/2`, so the counter it rebuilds has its top bit
set.  (Read: a counter of depth `m` can afford half as many decrements as its
depth allows.) -/
theorem rcost_le_half_of_deep {m : ℕ} {w : List RB} (h : rdecDeep m w = true)
    (hc : 2 * rdecCount w ≤ 2 ^ m) : rcost w ≤ 1 / 2 := by
  have h1 : ((2 * rdecCount w : ℕ) : ℚ) ≤ ((2 ^ m : ℕ) : ℚ) := by exact_mod_cast hc
  push_cast at h1
  have h2 : (rdecCount w : ℚ) / 2 ^ m ≤ 1 / 2 := by
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]
    linarith
  exact le_trans (rcostFrom_le_of_deep true SMap.one w h) h2

/-! ## The reduction of halting to `f` -/

/--
**One full cycle is survived when the reset rebuilds a counter of at least two.**
For a member whose `A> 241` bounces, if the word the reset phase re-parses needs
no borrow (`c = 0`) and rebuilds `f ≥ 2`, then the machine crosses the word,
survives the `<B1` event at the far end and comes back to the left end with a
well-formed counter stack and no `141`/`241` on the tape.  This is
`brun_reset_cycle` phrased in terms of the shift map `rmap` of the word.
-/
theorem reset_cycle_of_f_ge_two (hb : Bounces b4) {w : List RB} (hw : CWord w)
    (hc : (rmap true w).2.c = 0) (hf : 2 ≤ (rmap true w).2.f) :
    ∃ (s : List LB) (pre : List RB) (k : ℕ),
      BRun b4 ⟨[.L], .Lt, w ++ [.R]⟩ ⟨s, .Lt, pre ++ [.Y, .R1]⟩ k ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G := by
  have hrun : resetRun true w 0 = some ((rmap true w).1, (rmap true w).2.apply 0) :=
    (resetRun_rmap hw true 0).1 (by rw [hc])
  have hval : (rmap true w).2.apply 0 = (rmap true w).2.f := by
    simp [SMap.apply, hc]
  rw [hval] at hrun
  exact brun_reset_cycle hb w hrun (by cases (rmap true w).1 <;> simp <;> omega)

/--
**One full cycle is survived when the word is cheap.**  For a member whose
`A> 241` bounces, if the word the reset phase re-parses costs at most `1/2` of
normalised value and rebuilds at least three digits, then the machine crosses
the word, survives the `<B1` event at the far end and comes back to the left end
with a well-formed counter stack and no `141`/`241` on the tape.

This is the promised reduction: *the halting question for these members is a
question about the value `f` the reset hands back*, and a lower bound on `f` —
not a congruence — is what settles it.
-/
theorem reset_cycle_of_cost (hb : Bounces b4) {w : List RB} (hw : CWord w)
    (hc : (rmap true w).2.c = 0) (hcost : rcost w ≤ 1 / 2) (he : 3 ≤ (rmap true w).2.e) :
    ∃ (s : List LB) (pre : List RB) (k : ℕ),
      BRun b4 ⟨[.L], .Lt, w ++ [.R]⟩ ⟨s, .Lt, pre ++ [.Y, .R1]⟩ k ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G :=
  reset_cycle_of_f_ge_two hb hw hc (by have := rmap_f_ge_two hcost he; omega)

/--
**And the converse reading**: a reset word can only be dangerous if the counter
it rebuilds is `0` or `1`.  (`brun_reset_cycle` needs `f ≥ 1` in phase `2>` and
`f ≥ 2` in phase `1>`; `f ≥ 2` covers both.)
-/
theorem danger_iff_f_le_one (hb : Bounces b4) {w : List RB} (hw : CWord w)
    (hc : (rmap true w).2.c = 0)
    (hsafe : ¬ ∃ (s : List LB) (pre : List RB) (k : ℕ),
      BRun b4 ⟨[.L], .Lt, w ++ [.R]⟩ ⟨s, .Lt, pre ++ [.Y, .R1]⟩ k ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G) :
    (rmap true w).2.f ≤ 1 := by
  by_contra hf
  push_neg at hf
  have hrun : resetRun true w 0 = some ((rmap true w).1, (rmap true w).2.apply 0) :=
    (resetRun_rmap hw true 0).1 (by rw [hc])
  have hval : (rmap true w).2.apply 0 = (rmap true w).2.f := by
    simp [SMap.apply, hc]
  rw [hval] at hrun
  exact hsafe (brun_reset_cycle hb w hrun (by cases (rmap true w).1 <;> simp <;> omega))

/--
**The cycle criterion in decidable form.**  If the integer cost of the word at
scale `2 ^ K` is at most half of `2 ^ K` and the word builds at least three
digits, the cycle is survived.  Both hypotheses are decidable, so this is the
form in which the criterion is checked against the actual runs
(`FTrace.lean`).
-/
theorem reset_cycle_of_ncost (hb : Bounces b4) {K : ℕ} {w : List RB} (hw : CWord w)
    (hc : (rmap true w).2.c = 0) (hcost : 2 * rncost K w ≤ 2 ^ K)
    (he : 3 ≤ (rmap true w).2.e) :
    ∃ (s : List LB) (pre : List RB) (k : ℕ),
      BRun b4 ⟨[.L], .Lt, w ++ [.R]⟩ ⟨s, .Lt, pre ++ [.Y, .R1]⟩ k ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G :=
  reset_cycle_of_cost hb hw hc (rcost_le_half_of_nat hcost) he

end BB25
