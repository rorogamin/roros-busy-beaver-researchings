# Five additional nonhalting arguments: 0RA, 2RB, 2RA, 1RB, 1LB

Date: 2026-09-16.

## Status, scope, and dependencies

This is a proposed complete mathematical nonhalting argument for the five
blank-tape machines

```
0RA: 1RB2LA0RB1LB---_1LA3RA1RA4LB0RA
2RB: 1RB2LA0RB1LB---_1LA3RA1RA4LB2RB
2RA: 1RB2LA0RB1LB---_1LA3RA1RA4LB2RA
1RB: 1RB2LA0RB1LB---_1LA3RA1RA4LB1RB
1LB: 1RB2LA0RB1LB---_1LA3RA1RA4LB1LB
```

It is NOT a Lean kernel certificate. It uses the sound block/counter rules
in the supplied Aristotle project and the mathematical interface lemmas in
`previous/previous/PROOF_PREVIOUS.md` and `previous/PROOF_MORE.md`. Those prior
mathematical proofs are included unchanged, not independently re-certified
here. The new argument contains no conjectured growth, eventual-congruence,
or finite-simulation assumption.

The new restriction is that a normal B checkpoint ends in a zero block X.
This is true at the common blank-tape seed and at every completed return.
It guarantees at least two Y blocks in the tail that protects a new marker.
It also excludes the previous 1LB counterexample, whose stack ended in W.

The 0RA/2RB proofs share a stack map, but not identical base-step costs.
The archive's twin block isomorphism explains the shared construction;
the proof here supplies a return theorem for each member.

## 1. Counter and reset interface

All left stacks below are written **bottom first**, excluding the permanent
bottom L. Right words are written in encounter order. The block names are

```
left:  X=11, Z=01, W=03, J=023, K0=001, K1=011, J1=013
right: X=11, Y=22, V=21, U=12, F=141, G=241
ends:  R=$, R1=1$, P1=1>, P2=2>
```

For a pure left stack s over X,Z,W, let

\[
v(\epsilon)=0,\quad v(sX)=2v(s),\quad
v(sZ)=2v(s)+1,\quad v(sW)=\lfloor v(s)/2\rfloor.
\]

Admissibility means every prefix has at least as many bits X,Z as pops W.
Match a W to the last unmatched bit. The unmatched bits carry v(s).
A successful excursion D(s), when v(s)>0, subtracts one from the unmatched
bits, leaving matched bits and the matching structure unchanged.

The paired decoder P emits Y for every bit, X for a W matched to X, and V
for a W matched to Z. It is a colored Dyck prefix. The height is the number
of unmatched bits. A decrement leaves P unchanged at every prefix. No
prefix counter increases under a decrement. When v(s)=0, an excursion
through s deposits P(s) and reaches the stack below it.

Define adjusted reset maps over integers:

\[
Y:a\mapsto2a+1,\quad V:a\mapsto2a,\quad
X:a\mapsto\lfloor a/2\rfloor-1,\quad
U:a\mapsto\lfloor a/2\rfloor.
\tag{1}
\]

Let rho_z(w) denote composition starting at z, and rho(w)=rho_0(w).
The adjusted counter is the physical counter in pending phase 2, and the
physical counter minus one in pending phase 1. A clean word has nonnegative
adjusted value at every prefix. For words over Y,V,X, negativity is preserved
by each map, so a nonnegative final value is sufficient for cleanliness.

Put b(s)=rho(P(s)) and

\[
\operatorname{Good}(s)\iff s\text{ admissible and }
 b(p)\ge v(p)\text{ for every prefix }p\preceq s.
\tag{2}
\]

The prior proofs supply the following interface.

* D and appending either bit preserve Good.
* If Good(s) and v(s)>=d>=2, then Good(D^d(s)W).
* Clean resets over Y,V,X create Good paid stacks T(w), of value rho(w):

\[
T(wY)=T(w)Z,\quad T(wV)=T(w)X,\quad
T(wX)=D(T(w)W).
\tag{3}
\]

The last operation is pop first, then pay the pending-1 decrement. An
uncharged U reset appends W instead. The paid convention describes the
stack effect, not an identical physical head location at each word prefix.

### 1.1 Reset above an existing Good stack

The same induction proves a useful extension. Start at

\[
L\,s\ A>P2\,wR,
\]

where Good(s), w is over Y,V,X, and its adjusted evaluation starting at
v(s) is clean. Define T_s(w) by (3) starting at s rather than epsilon.
Then Good(T_s(w)) and v(T_s(w))=rho_{v(s)}(w).

For an X, let a=v(t), b=b(t), with b>=a>=2 before the operation. The new
actual value is floor(a/2)-1. The new decoder value is floor(b/2)-1 if the
popped bit was zero, or 2b if it was one. Both dominate the actual value;
older prefix inequalities survive D. This proves the induction.

If w ends in V and its final adjusted value is positive, the reset completes
at the normal right-end B marker, with stack T_s(w), and the last block is
X. The final pending debt is paid by the right-end turn. In particular,
any word clean from zero stays clean when started at a nonnegative value,
since all the maps are monotone.

### 1.2 Protected drain and odd-terminal reset

A stack is decoder-clean if it is admissible and every prefix of P(s) has
nonnegative adjusted value. The weaker drain lemma proved previously is

\[
\text{decoder-clean}(s),\qquad b(s)+2\ge3(v(s)+1)
\tag{4}
\]

at A>R implies a finite return to a Good positive B checkpoint. The return
is a clean reset ending in V, so its stack ends in X.

For completeness, a positive right-end round is s -> D(s)W, and sends
v to floor((v-1)/2). With U=v+1 and C=b+2 its two possibilities are

\[
(U,C)\mapsto
\begin{cases}
(U/2,\lfloor C/2\rfloor),&U\text{ even},\\
((U-1)/2,2C-2),&U\text{ odd}.
\end{cases}
\]

They preserve C>=3U and decoder-cleanliness; v strictly decreases.
At zero, b>=1, and the overflow word P(s)VR resets to value 2b>=2.

At a pending-2 tail P2 Y^r R1, r>=1, the new values at A>R are

\[
v'=2^{r-1}(v+1)-1,\qquad b'=2^{r+1}(b+1)-2.
\tag{5}
\]

Thus the sufficient entry condition is decoder-cleanliness and

\[
4(b+1)\ge3(v+1).
\tag{6}
\]

In particular it holds for any Good stack. A clean reset P(s)Y^rR1
from the left end, with Good(s), is also safe: its last reset bit is one,
and the final R1 pop establishes the stronger factor-four version of (4).
This is called the odd-tail return below.

### 1.3 The common Z branch

The previous proof handles, for any Good core c and r>=1,

\[
L\,c\ <A\,X P2 Y^rR1.
\tag{7}
\]

It either returns to a Good positive B checkpoint or enters the explicit
left XY spinout. All successful outputs end in X: direct cases use a
protected drain ending in a V reset; early clean cases already end in V;
the exceptional early case uses an odd-terminal reset and then a drain.
No B4 rule is used in this branch.

## 2. The strengthened normal checkpoint

Call a checkpoint normal when

\[
\boxed{L\,s\ <B1\ YR1,\qquad
\operatorname{Good}(s),\quad v(s)>0,\quad s\text{ ends in }X.}
\tag{N}
\]

Strip k trailing X blocks, k>=1. Set r=k+1>=2. The next block is Z or W.
The Z case is (7), so returns normally or spins out.

In the W case write the original stack as C W X^k. Then v(C)>=2, so the
two excursions through F and G are available. Let

\[
c=D^2(C),\qquad a=v(c)=v(C)-2,\qquad b=b(c)=b(C).
\]

Good(c), and the original Good condition gives the margins

\[
\boxed{b\ge a+2;\qquad a\text{ even}\Longrightarrow b\ge a+4.}
\tag{8}
\]

The second inequality uses Good at C W. If v(C) is even, its final bit is
zero, so floor(b(C)/2)-1 >= v(C)/2.

The member-specific G rules now give:

| Member | Configuration after consuming G |
|---|---|
| 0RA | c K1 A> Y^r R1 |
| 2RB | c J A> Y^r R1 |
| 2RA | c K0 A> Y^r R1 |
| 1RB | c J1 A> Y^r R1 |
| 1LB | c <A X P1 Y^r R1 |

There is no F or G remaining at this point. The marker rules used below
are exactly those in the source Family.lean and the reference simulator.

## 3. A closed finite drain identity

For n>=2 consider the ordinary pure-stack configuration at A>R with stack

\[
D^2(Z^n)\,WZZW.
\]

Its value is 2^n-3. It undergoes exactly n-1 positive drain rounds before
its local counter is zero. The resulting stack is

\[
\boxed{\Omega_n=X Z^{n-1} W X Z W^n.}
\tag{9}
\]

This is an identity of complete stacks, not just their values. Here is an
explicit induction. D^2(Z^n)=Z^{n-2}XZ. After the first round the stack is
Z^{n-2}XZWXZWW. After j rounds, for 1<=j<=n-1, it is

\[
Z^{n-j-1} X Z^j W X Z W^{j+1},
\tag{10}
\]

with unmatched bits Z^{n-j-1}X and value 2^{n-j}-2. Decrement changes the
last two unmatched bits ZX to XZ, and the following W matches the new
last Z. This gives the j+1 case. At j=n-1 the one remaining unmatched bit
is the first X, and (9) follows. No pop ever matches this first bit.

The paired decoder is

\[
\boxed{P(\Omega_n)=Y^n VYYVX V^{n-2}.}
\tag{11}
\]

The first W closes a Z; among the final W's, the first closes Z, the
second closes X, and the rest close Z's.

Two reset evaluations used below are

\[
\rho_z(Y^n VYYVX V^{n-1})
 =2^{2n+2}(z+1)-3\cdot2^n,
\tag{12}
\]

\[
\rho_z(Y^{n-1}VYYVX V^{n-1})
 =2^{2n+1}(z+1)-3\cdot2^n.
\tag{13}
\]

For n>=2 these words are clean from every z>=0 and have strictly positive
final values. There is only one contracting X, preceded by enough Y/V
maps that its incoming counter is at least 22 even in the smaller word.

## 4. The one-use marker return word

For a marker M in {K1,J,J1}, start at c M A>Y^rR1, r>=2.
The right sweep creates Z^r above M. The R1 turn decrements its last one
bit, giving the intermediate B checkpoint

\[
c M Z^{r-1}X\ <B1\ YR1.
\]

B strips its final X and encounters Z, not M. This is where r>=2 is
essential. The resulting configuration is

\[
c M Z^{r-2}\ <A\ X P2 YYR1.
\tag{14}
\]

Until the first leftward visit to M, this calculation is independent of c
and of the marker rule. At that visit the right word, after literal
re-parsing, is w_r R, where

\[
\boxed{
w_r=\begin{cases}
XYYV,&r=2,\\
YVYYV,&r=3,\\
Y^n VYYVX V^{n-1},&r\ge4,\quad n=r-2.
\end{cases}}
\tag{15}
\]

For r=2 the local core in (14) is empty and the residual word is
X P2 YYR1 = XYYVR. For r=3 its one-bit core permits the first decrement,
then deposits Y before the residual V P2 YYR1. For r>=4 its core Z^n
permits both decrements, the X consumes a pop, and the pending-2 YY tail
adds ZZW. This is exactly (9)-(11), followed by the overflow's extra V.
All these runs are finite. There is no additional B encounter before the
marker visit. In particular B never reads one of the dangerous marker
blocks in this calculation.

## 5. Nonhalting return for 0RA and 2RB

The source rules are

\[
K1\ <A\longrightarrow X\ A>P2\quad(0RA),\qquad
J\ <A\longrightarrow X\ A>P2\quad(2RB).
\]

Thus the marker visit becomes

\[
cX\ A>P2\,w_rR.
\tag{16}
\]

The initial stack cX is Good. For r>=3, (15) is clean from zero and ends
in V with a positive result, so the reset-above-a-Good-stack lemma returns
normally. For r=3 the final value from z is 32z+22; for r>=4 use (12).

For r=2, its initial counter is 2a. If a>=1, w_2=XYYV is clean and the
final value is 8a-2>=6, again giving a normal return.

The only remaining case is r=2,a=0. The reset's X creates cXW with counter
zero and pending 1. By (8), b(c)>=4, hence

\[
b(cXW)=b(c)-1\ge3.
\]

So cXW is Good. Its pending debt cannot be paid; the attempted turn on the
first Y overflows. The right word at that overflow is precisely

\[
P(cXW)\,YYY R1.
\]

The odd-tail return applies and returns normally. This proves the full
normal return theorem for both 0RA and 2RB.

## 6. Nonhalting return for 2RA

Here K0's first leftward visit gives K1 A>, without a pending digit, and
its next leftward visit gives X A>P2. The first rule behaves exactly like
a one bit becoming zero; the second is a local reset boundary.

For r=2, expand (14) directly: the first excursion changes K0 to K1,
the intervening X turns the head left once more, and K1 becomes X P2.
The resulting configuration is

\[
cX\ A>P2\,VYYVR.
\tag{17}
\]

For r>=3, include K0 as the leading one bit of the local core Z^{r-1}.
Put n=r-1>=2. The calculation (9)-(10) applies to it as a bit: its first
visit changes it to K1 exactly when that leading bit changes to zero.
The leading bit is never matched by a W. At the final local overflow,
K1 supplies X P2 instead of emitting the leading Y of (11). Therefore

\[
cX\ A>P2\,Y^{n-1}VYYVX V^{n-1}R.
\tag{18}
\]

The word VYYV in (17) has value 16z+6 from z>=0. Equation (13) handles
(18). Both are clean, positive, and end in V. Since cX is Good, every
case returns normally. There are no small-reset exceptions for 2RA.

## 7. A stronger structural small-value barrier

This section sharpens the counted-expansion lemma from the previous proof.
Let u be a clean colored Dyck prefix of height h>=2, and set

\[
t=T(u),\qquad f=v(t)=\rho(u),\qquad B=b(t)=\rho(Q(u)).
\]

Here Q=P o T is the transducer

\[
Y\mapsto Y,\quad V\mapsto Y,\quad
X\mapsto\begin{cases}V,&\text{incoming first counter odd},\\
X,&\text{incoming first counter even}.
\end{cases}
\]

A closing letter is expanding if it is an original V, or an original X
read with odd incoming first counter. Write q for their number. The prior
matched-group proof gives

\[
\boxed{3(B+1)\ge2^h(2\cdot4^q+1).}
\tag{19}
\]

Also B>=f, since T(u) is Good. In particular:

\[
f\text{ even}\Longrightarrow q\ge1\text{ and }B\ge11,
\tag{20}
\]

\[
\boxed{f\ge4,\quad f\equiv0,2,4\pmod8
\Longrightarrow q\ge2\text{ and }B\ge43,}
\tag{21}
\]

\[
B=f\text{ even}\Longrightarrow f\ge12.
\tag{22}
\]

Proof of the new implication (21): q=0 means u=Y^h and gives odd f.
For q=1 there is one balanced tree, and it is a nested chain, since each
leaf requires an expanding close. For some 0<=i<=h and n>=1,

\[
u=Y^i[Y^n C X^{n-1}]Y^{h-i},\qquad C\in\{X,V\}.
\]

Direct application of (1), as in the preceding proof, gives

\[
f=2^h-2^{h-i}-1\quad(C=X),\qquad
f=2^{h+2}-2^{h-i}-1\quad(C=V).
\]

If f is even, i=h. Hence f is either 2^h-2 or 2^{h+2}-2.
For h>=2 and f>=4, both are 6 modulo 8. (The excluded exception is
h=2, f=2.) This proves q>=2 in (21), and (19) gives B>=43.
Equation (20) follows by excluding q=0; (22) follows because an even
integer at least eleven is at least twelve.

These bounds apply at the early overflows used below. Their u is P(c)
for a zero counter reached by decrementing a Good source with value two
or three. Thus h>=2. Equation (8) supplies f>=4 in the value-two case
and f>=3 in the value-three case.

## 8. A common repair for a one-unit deficit

Let K be decoder-clean with

\[
v(K)=A\ge3,\qquad b(K)=A-1,
\]

and suppose A even implies A>=8. For every j>=0, the checkpoint

\[
K Z^{j+1}X\ <B1\ YR1
\tag{23}
\]

returns normally by the common Z branch, even though K need not be Good.

B removes X and Z. Its core K Z^j has values

\[
A_j=2^j(A+1)-1,\qquad C_j=2^j A-1.
\]

Two decrements and a pop are available. Decoding is unchanged by those
decrements. If A_j is odd, the new values are

\[
v_1=(A_j-3)/2,\qquad b_1=2C_j.
\]

Condition (6) becomes 16C_j+11>=3A_j. The difference is
2^j(13A-3)-2>0. If A_j is even, j=0 and A is even, giving

\[
v_1=A/2-1,\qquad b_1=A/2-2.
\]

Now (6) is exactly A>=8. Decoder-cleanliness persists in either case,
and the pending-2 YY tail followed by the protected drain returns to Good
with a positive counter and final X. No member-specific G rule is involved.

## 9. Nonhalting return for 1LB

Write the W source as C W X^k, set A=v(C)>=2 and r=k+1>=2.
The two F/G decrements are followed by the 1LB replacement <A X P1.

### 9.1 A>=4

Four decrements total and the following pop give

\[
z=D^4(C)W,
\]

which is Good. If A>=6, its counter floor((A-4)/2) is positive, so the
pending-1 debt is paid; D(z) with a pending-2 Y^rR1 tail returns normally.
If A=4 or 5, z has value zero, and the pending debt overflows to the clean
reset P(z)Y^rVR. Its value is positive and it ends in V, so it returns
normally as well.

### 9.2 A=3

After the available decrements, let u=P(D^3(C)), t=T(u), f=v(t), B=b(t).
Here f>=3 and h(u)>=2. Literal re-parsing of the early overflow gives

\[
u V U Y^{r-1}VR,
\]

whose first completed B checkpoint is

\[
K Z^{r-1}X\ <B1\ YR1,\qquad K=tXW.
\tag{24}
\]

Indeed V pushes X and U pops it without the extra charge. All these
operations are legal, and v(K)=f, b(K)=B-1. Only the new final prefix K
can violate Good. If B>=f+1, the checkpoint is already normal. Otherwise
B=f, and K has the one-unit deficit of Section 8, with A=f>=3. If A is
even, (22) gives A>=12. Since r>=2, apply (23) with j=r-2.

### 9.3 A=2

Now u=P(D^2(C)), t=T(u), f>=4 and B>=f. The overflow re-parses as

\[
u X U Y^{r-1}VR,
\]

whose first B checkpoint is

\[
K Z^{r-1}X\ <B1\ YR1,\qquad K=D(tW)W.
\tag{25}
\]

The first X reset is legal because f>=4; its paid stack D(tW) is Good.
The following U is another legal pop: t has at least two unmatched bits.
The checkpoint is positive because r>=2, even if v(K)=0.

Put f=4q+e, 0<=e<=3. The full values after these two pops are:

| e | v(K) | b(K) |
|---|---:|---:|
| 0 | q-1 | 2 floor(B/2)-2 |
| 1 | q-1 | 4B |
| 2 | q | floor((B-2)/4)-1 |
| 3 | q | B-1 |

The only possible failed Good prefix is the last prefix K. All rows
except e=2 dominate v(K). In the e=2 row, failure means exactly

\[
b(K)=q-1,\qquad f\le B\le f+3.
\tag{26}
\]

This gives a decoder-clean one-unit deficit. If q is odd, q=1 would give
f=6 and B<=9, contradicting (20). Thus q>=3. If q is even, then f is 2
modulo 8, so (21) gives B>=43. Together with B<=4q+5 this gives q>=10.
The repair lemma of Section 8 therefore applies in every deficient case.

All 1LB branches return normally or, in the shared Z branch, spin out.
At most one non-Good normal-right-end B checkpoint is passed before repair.
The suffix X requirement is indispensable to this argument: it enforces
r>=2 in (24)-(25).

## 10. Nonhalting return for 1RB

The marker rule is J1 <A -> <A X P2. At the marker visit of Section 4 it
therefore gives

\[
c\ <A\ X P2\,w_rR.
\tag{27}
\]

Use a=v(c), b=b(c) and the margins (8).

### 10.1 a>=2

The two extra decrements and a pop give the Good stack

\[
t=D^2(c)W
\]

followed by the pending-2 reset w_rR. For r>=3 the word is clean from zero
and positive, so returns normally. For r=2 it is XYYV; if a>=6 then
v(t)=floor((a-2)/2)>=2, and the reset is clean and positive.

If r=2 and 2<=a<=5, the first X pop leaves z=tW with physical counter
zero and a pending-1 debt. This z is Good:

* For a=4,5 the popped bit is one, so its decoded close is V.
* For a=2, b>=6 by (8). The decoded value at t is floor(b/2)-1>=2,
  and its next closing X still leaves a nonnegative decoded value.
* For a=3, b>=5. The decoded value at t is 2b>=10, so the next closing
  X also leaves a nonnegative value.

Older prefixes of z are Good, and v(z)=0. The failed pending debt thus
overflows to P(z)YYYR1 and the odd-tail return applies.

### 10.2 a=0 or 1: the exact early reset word

Let c0=D^a(c), u=P(c0), t=T(u), f=v(t), B=b(t).
Then h(u)>=2, f>=4 for a=0, and f>=3 for a=1. The residual digit is

\[
d=X\quad(a=0),\qquad d=V\quad(a=1).
\]

At the left end the tape is u d P2 w_r R. The literal re-parsing

\[
P2\,w_rR=h_rR1
\]

has the following closed forms:

\[
\boxed{
h_r=\begin{cases}
VUYY,&r=2,\\
YYUYY,&r=3,\\
Y^{n+1}UYYXU^{n-1},&r\ge4,\quad n=r-2.
\end{cases}}
\tag{28}
\]

Thus the complete early reset word is u d h_r R1.
First reset u d. Its paid stack s is Good and has values x=v(s)>=1 and
b_s=b(s). For a=1, s=tX and

\[
x=2f,\qquad b_s=2B+1\ge x+1.
\tag{29}
\]

For a=0, s=D(tW) and

\[
x=\lfloor f/2\rfloor-1,\qquad
b_s=\begin{cases}2B,&f\text{ odd},\\
\lfloor B/2\rfloor-1,&f\text{ even}.
\end{cases}
\tag{30}
\]

Now evaluate (28), including its last R1 pop. Each U pop is legal: the
indicated preceding bit pushes provide the necessary unmatched bits. The
only X in the r>=4 word has a large positive incoming counter; its paid
decrement changes the last freshly pushed one bit to zero and does not
borrow into s. The exact stacks at A>R are:

| Case | Stack | Actual value | Decoder value |
|---|---|---:|---:|
| r=2 | s X W Z Z W | 2x+1 | 8b_s-2 |
| r=3 | s Z Z W Z Z W | 4x+3 | 64b_s+54 |
| r>=4, n=r-2 | s Z^(n+1) W X Z W^(n+1) | 2x+1 | 2^(2n+3)(b_s+1)-3*2^n |

All these stacks are decoder-clean. For the first row its new prefixes
need b_s>=1, supplied by (29)-(30) and the bounds below. In the other
rows the decoded closing letters are expanding except for one X after
substantial growth. Their earlier prefixes remain those of the Good s.

For r=2, condition (4) reduces exactly to

\[
4b_s\ge3(x+1).
\tag{31}
\]

Equation (29) suffices in the a=1 case. In the a=0 case, odd f gives
b_s=2B>=2f and is more than sufficient. For even f>=8, x>=3 and b_s>=x,
which also suffices. The only remaining even values are f=4 and f=6:
(21) gives B>=43 at f=4, hence b_s>=20 and x=1; (20) gives B>=11 at
f=6, hence b_s>=4 and x=2. Both satisfy (31).

For r=3, condition (4) is
64b_s+56 >= 12x+12, immediate from b_s>=x. For n>=2 the final row has

\[
b'+2=2^{2n+3}(b_s+1)-3\cdot2^n+2\ge6(x+1)=3(v'+1),
\]

also immediate from b_s>=x and n>=2. Therefore every row admits the
protected drain and returns normally. This closes all 1RB early cases.

## 11. Blank-tape conclusion and positive running time

For every one of the five members, 156 base transitions from blank reach

\[
L\,ZZZXXX\ <B1\ YR1.
\]

The six prefix pairs (v,b) are

\[
(1,1),\ (3,3),\ (7,7),\ (14,15),\ (28,31),\ (56,63).
\]

This is a normal checkpoint. The base transition prefix is replayed
separately for all five members by the verification program; it does not
rely on any infinite simulation claim.

Sections 2-10 prove: every normal checkpoint of each of the five machines
reaches another normal checkpoint in finite positive time, or enters the
shared nonhalting spinout. In the marker cases the intermediate checkpoint
has at least one Z protecting its marker; it is not asserted to be normal.
In the 1LB repair cases one decoder-clean, non-Good checkpoint can occur.

Every return begins by stripping at least one X in state B, costing six
base transitions. All subsequent excursions and finite word scans have
finite cost; the protected drain strictly decreases a nonnegative counter,
and the explicit local drain takes exactly n-1 rounds. Thus these are
positive-time returns, not a possible zero-cost parsing loop.

Iterating the return theorem yields arbitrarily many base transitions,
unless a nonhalting spinout occurs first. Consequently

\[
\boxed{\neg\operatorname{Halts}(M_m,\mathrm{blank})
\quad\text{for }m\in\{0RA,2RB,2RA,1RB,1LB\}.}
\]

This is the conclusion of the mathematical argument, pending formal
certification of the new lemmas and their composition with the prior work.

## 12. Finite validation and scope boundary

`verify_next.py` implements the constructive returns, separately from the
archive's block simulator. `check_next.py` compares their exact endpoint
stacks, not only survival. Its completed default run covers every Good
positive X-ending stack of length at most eleven (31,259 stacks), 100
larger randomized stacks, and 108 deliberately constructed long-tail
stacks. It checks all five members on every input: 157,335 exact return
comparisons. It also replays all five seeds and checks 5,000 unaccelerated
base/block transitions. The maximum reference return in that run used
1,236 accelerated block steps.

`check_components_next.py` separately checks 1,377,307 clean Dyck prefixes,
including 240,542 instances of the new mod-8 barrier; 7,435 1LB exceptional
stack instances, including 260 exact repairs of non-Good checkpoints;
7,435 exact 1RB early-reset comparisons; and the explicit local drain for
n=2,...,128, including 8,128 drain-round instances and 2,540 closed reset
value checks. All assertions in the recorded completed runs passed.

These finite checks are not proofs of the universal statements. Their
role is to check calculations, parsing, branch coverage, and agreement
with the source rules. The quantified arguments above carry the infinite
conclusions. Full records are in the JSON and log files.

The remaining three members are 0LB, 0RB, and 1LA. Nothing here decides
their blank-tape behavior. In fact the present universal normal-checkpoint
theorem is false for 0RB and 1LA. The stack

\[
L\,ZXZWWX\ <B1\ YR1
\]

is Good, ends in X, and has value 2, but reaches an undefined A4 transition
after 108 defined base transitions for 0RB and after 76 for 1LA. These are
specified nonblank configurations, not claims that either blank run halts.
The obstruction is recorded and replayed in the component checker.

The original block interface also encounters an uncovered pending-P2/N2
case for 0LB on some Good checkpoints. An uncovered rule is not itself a
halting proof, and is not treated as one here. A further proof for the
remaining members needs additional reachability information or a different
checkpoint construction.
