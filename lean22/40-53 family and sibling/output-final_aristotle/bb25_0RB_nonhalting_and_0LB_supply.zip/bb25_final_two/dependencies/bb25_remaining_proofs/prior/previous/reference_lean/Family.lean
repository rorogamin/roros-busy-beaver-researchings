/-
# The family-specific rules

The 13 members of `1RB2LA0RB1LB---_1LA3RA1RA4LB---` share the whole
longitudinal table of `RequestProject.BB25.Rules`; they differ only in the way
the head interacts with the block `G = 241`, which is where the free
transition `B4` is used for the first time.

This file verifies, for each of the 13 members, the rule for `A> 241` quoted in
the family notes, with its exact step count, together with the auxiliary rules
for the extra blocks (`023`, `013`, `003`, `001`, `011`, `101`, `201`) that
some of those members create.

It also records the halting patterns: the machine halts as soon as it reads
the symbol `4` in state `A`, which happens exactly when the head meets a
`141`/`241` block *out of phase* (i.e. preceded by a pending digit `1>`/`2>`).
-/
import RequestProject.BB25.Rules

namespace BB25

variable (l r : List Sym)

/-! ## `A> 241` for each of the 13 members -/

/-- `B4 = 2LB`:  `A> 241 → <A 12 1>`  (3 steps). -/
theorem G_2LB :
    steps (M b4_2LB) 3 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨l, .A, .L, 1 :: 2 :: 1 :: r⟩ := rfl

/-- `B4 = 2RB`:  `A> 241 → 023 A>`  (3 steps). -/
theorem G_2RB :
    steps (M b4_2RB) 3 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨3 :: 2 :: 0 :: l, .A, .R, r⟩ := rfl

/-- `B4 = 1LB`:  `A> 241 → <A 11 1>`  (3 steps). -/
theorem G_1LB :
    steps (M b4_1LB) 3 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨l, .A, .L, 1 :: 1 :: 1 :: r⟩ := rfl

/-- `B4 = 1RB`:  `A> 241 → 013 A>`  (3 steps). -/
theorem G_1RB :
    steps (M b4_1RB) 3 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨3 :: 1 :: 0 :: l, .A, .R, r⟩ := rfl

/-- `B4 = 0LB`:  `A> 241 → <A 101`  (3 steps). -/
theorem G_0LB :
    steps (M b4_0LB) 3 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨l, .A, .L, 1 :: 0 :: 1 :: r⟩ := rfl

/-- `B4 = 0RB`:  `A> 241 → 003 A>`  (3 steps). -/
theorem G_0RB :
    steps (M b4_0RB) 3 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨3 :: 0 :: 0 :: l, .A, .R, r⟩ := rfl

/-- `B4 = 3RA`:  `A> 241 → <A 11 2>`  (5 steps). -/
theorem G_3RA :
    steps (M b4_3RA) 5 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨l, .A, .L, 1 :: 1 :: 2 :: r⟩ := rfl

/-- `B4 = 2LA`:  `A> 241 → <A 22 2>`  (7 steps). -/
theorem G_2LA :
    steps (M b4_2LA) 7 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨l, .A, .L, 2 :: 2 :: 2 :: r⟩ := rfl

/-- `B4 = 2RA`:  `A> 241 → 001 A>`  (5 steps). -/
theorem G_2RA :
    steps (M b4_2RA) 5 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨1 :: 0 :: 0 :: l, .A, .R, r⟩ := rfl

/-- `B4 = 1LA`:  `A> 241 → <B1 22`  (9 steps). -/
theorem G_1LA :
    steps (M b4_1LA) 9 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨l, .B, .L, 1 :: 2 :: 2 :: r⟩ := rfl

/-- `B4 = 1RA`:  `A> 241 → 11 A> 2>`  (6 steps). -/
theorem G_1RA :
    steps (M b4_1RA) 6 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨1 :: 1 :: l, .A, .R, 2 :: r⟩ := rfl

/-- `B4 = 0LA`:  `A> 241 → <A 21 1>`  (5 steps). -/
theorem G_0LA :
    steps (M b4_0LA) 5 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨l, .A, .L, 2 :: 1 :: 1 :: r⟩ := rfl

/-- `B4 = 0RA`:  `A> 241 → 011 A>`  (5 steps). -/
theorem G_0RA :
    steps (M b4_0RA) 5 ⟨l, .A, .R, 2 :: 4 :: 1 :: r⟩ = some ⟨1 :: 1 :: 0 :: l, .A, .R, r⟩ := rfl

/-! ## Auxiliary blocks

The rules below never read the symbol `4` in state `B`, so they hold for every
member of the family. -/

variable (b4 : Option (Sym × Dir × St))

/-- `023 <A → 11 A> 2>`  (6 steps).  In block form: `J <A → X A> P2`; used by
the member `B4 = 2RB`. -/
theorem rule_J_A :
    steps (M b4) 6 ⟨3 :: 2 :: 0 :: l, .A, .L, r⟩ = some ⟨1 :: 1 :: l, .A, .R, 2 :: r⟩ := rfl

/-- `013 <A → <A 11 2>`  (5 steps); used by the member `B4 = 1RB`. -/
theorem rule_013_A :
    steps (M b4) 5 ⟨3 :: 1 :: 0 :: l, .A, .L, r⟩ = some ⟨l, .A, .L, 1 :: 1 :: 2 :: r⟩ := rfl

/-- `003 <A → <B1 22`  (9 steps); used by the member `B4 = 0RB`. -/
theorem rule_003_A :
    steps (M b4) 9 ⟨3 :: 0 :: 0 :: l, .A, .L, r⟩ = some ⟨l, .B, .L, 1 :: 2 :: 2 :: r⟩ := rfl

/-- `001 <A → 011 A>`  (3 steps); used by the member `B4 = 2RA`. -/
theorem rule_001_A :
    steps (M b4) 3 ⟨1 :: 0 :: 0 :: l, .A, .L, r⟩ = some ⟨1 :: 1 :: 0 :: l, .A, .R, r⟩ := rfl

/-- `011 <A → 11 A> 2>`  (4 steps); used by the members `B4 = 2RA` and
`B4 = 0RA`. -/
theorem rule_011_A :
    steps (M b4) 4 ⟨1 :: 1 :: 0 :: l, .A, .L, r⟩ = some ⟨1 :: 1 :: l, .A, .R, 2 :: r⟩ := rfl

/-- `A> 101 → <A 201`  (1 step); used by the member `B4 = 0LB`. -/
theorem rule_A_101 :
    steps (M b4) 1 ⟨l, .A, .R, 1 :: 0 :: 1 :: r⟩ = some ⟨l, .A, .L, 2 :: 0 :: 1 :: r⟩ := rfl

/-- `A> 201 → <B1 22`  (9 steps); used by the member `B4 = 0LB`. -/
theorem rule_A_201 :
    steps (M b4) 9 ⟨l, .A, .R, 2 :: 0 :: 1 :: r⟩ = some ⟨l, .B, .L, 1 :: 2 :: 2 :: r⟩ := rfl

/-! ## Halting patterns

The only halting transition of the family is `A4`, so the machine halts
exactly when the head reads a `4` in state `A`.  A `4` only ever occurs inside
a block `F = 141` or `G = 241`, and the head always enters such a block on its
first symbol -- unless a pending digit `1>`/`2>` has shifted the phase, which
is precisely the situation that kills the machine. -/

/-- The unique halting transition: `A> 4 → HALT`. -/
theorem halt_A4 : steps (M b4) 1 ⟨l, .A, .R, 4 :: r⟩ = none := rfl

/-- `2> 141`: a pending `2` in front of an `F` block halts in 3 steps. -/
theorem halt_P2_F : steps (M b4) 3 ⟨l, .A, .R, 2 :: 1 :: 4 :: 1 :: r⟩ = none := rfl

/-- `2> 241`: a pending `2` in front of a `G` block halts in 3 steps. -/
theorem halt_P2_G : steps (M b4) 3 ⟨l, .A, .R, 2 :: 2 :: 4 :: 1 :: r⟩ = none := rfl

/-- `1> 141`: a pending `1` in front of an `F` block turns the head around and
leaves the fatal pattern `2> 141` behind. -/
theorem halt_P1_F :
    steps (M b4) 1 ⟨l, .A, .R, 1 :: 1 :: 4 :: 1 :: r⟩ = some ⟨l, .A, .L, 2 :: 1 :: 4 :: 1 :: r⟩ :=
  rfl

/-- `1> 241`: a pending `1` in front of a `G` block turns the head around and
leaves the fatal pattern `2> 241` behind. -/
theorem halt_P1_G :
    steps (M b4) 1 ⟨l, .A, .R, 1 :: 2 :: 4 :: 1 :: r⟩ = some ⟨l, .A, .L, 2 :: 2 :: 4 :: 1 :: r⟩ :=
  rfl

end BB25
