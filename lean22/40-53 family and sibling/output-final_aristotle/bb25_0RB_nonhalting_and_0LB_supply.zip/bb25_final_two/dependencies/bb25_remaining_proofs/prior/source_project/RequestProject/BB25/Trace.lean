/-
# The first overflows of all 13 members, computed inside Lean

`Phase.lean` says what a word of digit blocks does to the counter; this file
*computes* the words that actually occur, for every member of the family, by
running the accelerated block simulator of `Blocks.lean` from the blank tape
and recording the shift map (`SMap`) of the word that each reset phase
re-parses.

The point is that the members share a prefix of their behaviour: the first five
overflows produce exactly the same reset words for all 13 members, and the
maps have `c = 0` (the reset never asks the empty counter for a decrement it
cannot pay, which is the hypothesis of `brun_overflow_reset_cycle`) and `d = 0`
(no digit of the counter is deleted: the word is read as a plain binary
numeral).  These are the facts that `tools/phases.py` finds empirically; here
they are checked by the kernel.
-/
import RequestProject.BB25.Phase

namespace BB25

/-- The digit blocks at the head end of the tape: the word the next phase will
read. -/
def digitPrefix : List RB → List RB
  | .Y :: w => .Y :: digitPrefix w
  | .V :: w => .V :: digitPrefix w
  | .U :: w => .U :: digitPrefix w
  | .X :: w => .X :: digitPrefix w
  | _ => []

theorem digitPrefix_CWord (w : List RB) : CWord (digitPrefix w) := by
  induction w with
  | nil => exact CWord.nil
  | cons b w ih => cases b <;> simp_all [digitPrefix, CWord]

/-- Is the configuration at an overflow, i.e. is the head at the left end of
the tape with the counter gone? -/
def atOverflow (c : BCfg) : Bool :=
  match c with
  | ⟨[.L], .Lt, _⟩ => true
  | _ => false

/-- Run the accelerated block simulator for `n` steps and list the shift map of
the word each reset phase re-parses, in the order the overflows happen. -/
def ovTrace (b4 : Option (Sym × Dir × St)) : ℕ → BCfg → List SMap
  | 0, _ => []
  | n + 1, c =>
      let rest :=
        match bstepFast b4 c with
        | some (c', _) => ovTrace b4 n c'
        | none => []
      if atOverflow c then (rmap true (digitPrefix c.rt)).2 :: rest else rest

/-- The reset words of the first five overflows, for a member. -/
def ovPrefix (b4 : Option (Sym × Dir × St)) : List SMap :=
  (ovTrace b4 1200 binit).take 5

/-- The common prefix: the shift maps of the first five reset phases. -/
def sharedPrefix : List SMap :=
  [⟨0, 0, 0, 0⟩, ⟨1, 0, 1, 1⟩, ⟨0, 0, 3, 5⟩, ⟨0, 0, 6, 57⟩, ⟨0, 0, 6, 53⟩]

set_option maxRecDepth 40000
set_option maxHeartbeats 4000000

/--
**The 13 members share their first five overflows.**  Running the block
simulator from the blank tape, the word that each of the first five reset
phases re-parses is the same for every member of the family, with the shift
maps `sharedPrefix`.

Read off the list: the second reset is the only one of the five with `c = 1`
(it needs one decrement), all five have `d = 0`, and the counters they rebuild
are `0, 1, 5, 57, 53`.
-/
theorem shared_overflow_prefix :
    ovPrefix b4_2LB = sharedPrefix ∧ ovPrefix b4_2RB = sharedPrefix ∧
    ovPrefix b4_1LB = sharedPrefix ∧ ovPrefix b4_1RB = sharedPrefix ∧
    ovPrefix b4_0LB = sharedPrefix ∧ ovPrefix b4_0RB = sharedPrefix ∧
    ovPrefix b4_3RA = sharedPrefix ∧ ovPrefix b4_2LA = sharedPrefix ∧
    ovPrefix b4_2RA = sharedPrefix ∧ ovPrefix b4_1LA = sharedPrefix ∧
    ovPrefix b4_1RA = sharedPrefix ∧ ovPrefix b4_0LA = sharedPrefix ∧
    ovPrefix b4_0RA = sharedPrefix := by
  refine ⟨by decide, by decide, by decide, by decide, by decide, by decide, by decide,
    by decide, by decide, by decide, by decide, by decide, by decide⟩

/-- Does the member reach at least seven overflows within `n` block steps, and
does every reset phase after the second read its word with no borrow (`c = 0`)
and no deletion of counter digits (`d = 0`)? -/
def resetsClean (b4 : Option (Sym × Dir × St)) (n : ℕ) : Bool :=
  let t := ovTrace b4 n binit
  (7 ≤ t.length) && (t.drop 2).all (fun p => p.c == 0 && p.d == 0)

/--
**The resets neither borrow nor delete digits.**  For every member, in every
one of the first overflows the simulator reaches (at least seven of them), the
word the reset phase re-parses has `c = 0` and `d = 0` — apart from the second
overflow of every member, which is the `⟨1,0,1,1⟩` of `sharedPrefix`.

`c = 0` is exactly the hypothesis `hc` of `brun_overflow_reset_cycle`, so on
this stretch of every member's run the overflow–reset cycle is the closed-form
one.  `d = 0` says the reset deletes no digit of the counter: it simply reads
the deposited word as a binary numeral, which is why the counter grows.
-/
theorem reset_maps_clean :
    resetsClean b4_2LB 4000 = true ∧ resetsClean b4_2RB 4000 = true ∧
    resetsClean b4_1LB 4000 = true ∧ resetsClean b4_1RB 4000 = true ∧
    resetsClean b4_0LB 4000 = true ∧ resetsClean b4_0RB 4000 = true ∧
    resetsClean b4_3RA 4000 = true ∧ resetsClean b4_2LA 4000 = true ∧
    resetsClean b4_2RA 4000 = true ∧ resetsClean b4_1LA 4000 = true ∧
    resetsClean b4_1RA 4000 = true ∧ resetsClean b4_0LA 4000 = true ∧
    resetsClean b4_0RA 4000 = true := by
  refine ⟨by decide, by decide, by decide, by decide, by decide, by decide, by decide,
    by decide, by decide, by decide, by decide, by decide, by decide⟩

end BB25
