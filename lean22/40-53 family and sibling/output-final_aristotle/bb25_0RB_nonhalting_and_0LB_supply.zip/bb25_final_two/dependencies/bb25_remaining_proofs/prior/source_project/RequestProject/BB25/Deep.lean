/-
# The deep end of the counter: what the overflow really deposits

`Overflow.lean` describes the word `ofw lt` an overflow deposits, and
`FValue.lean` reduces the halting question for the bouncing members to one
number: the counter `f` the following reset rebuilds, for which a *lower* bound
is needed.  The bound available there is the cost criterion `rcost w ≤ 1/2`,
which was verified against the runs but not related to the word the overflow
actually produces.  This file makes that link, by looking at the **deep end** of
the counter stack — the blocks next to the left end `^11`, which carry the high
digits.

## The leading run of `22` blocks

The main structural theorem is `ofw_bit_tail`: if the `k` deepest blocks of the
counter are *bit* blocks (`11` or `01`, no shift digit `03` among them), then

```
    ofw lt  =  22^k ++ r ,        r.length = (number of blocks above them).
```

The reason is that the overflow walks the stack from the head downwards, and the
decrements it performs on the way (`cdec`, one for every shift digit whose
sub-counter is still alive) never change a bit block into a shift block: they
only flip bits.  By the time the walk reaches the deep bit blocks their value is
`0`, and a bit block of value `0` is deposited as a `22`.  So whatever the
machine has been doing above, the deep bit blocks are always handed to the reset
as a run of `22`s.

## Why the leading run is the whole point

A reset reading `22^k` builds the full `k`-digit numeral `2^k - 1`: its
**deficit is zero** (`deficit_Ynum`) and it has cost nothing
(`rcost_replicate_Y`).  So the entire cost of the word — the entire risk of the
cycle — sits in the `r` part, and it is measured against a counter that already
has `k` digits: `rcost_bit_tail` reduces the criterion of `FValue.lean` to

```
    (number of decrements in r) ≤ 2^(m-1) ,   all of them at digit count ≥ m .
```

and `r` is no longer than the number of blocks above the deep run
(`ofw_bit_tail`).  `cycle_of_bit_tail` packages this into a survival theorem for
one full cycle of a bouncing member.

## Propagation

`Deep.lean` also proves that this structure *reproduces itself*.  The reset
phase at the level of blocks is `rstackRun` (the reset analogue of
`cstackRun`); `brun_rstackRun` proves the machine performs it.  Reading a `22`
or a `21` pushes a **bit** block, so a word that begins with `k` blocks from
`{22, 21}` rebuilds a stack whose `k` deepest blocks are bits
(`rstackRun_bit_tail`), and nothing that happens afterwards can spoil that: the
counter phase and the decrements only ever add blocks on top of the stack or
flip bits (`BitTail` is preserved by `cdec`, `pushDigit`, `cstackStep`,
`cstackRun`).  Hence

```
    deep bit run of the next counter  ≥  leading run of 22/21 blocks of ofw lt
                                      ≥  deep bit run of the present counter
```

(`bit_tail_propagates`): the depth of the exact part of the counter never
decreases while the stack is not eaten into from the top, which is what the
measurements of `ANALYSIS.md` show it doing.
-/
import RequestProject.BB25.FValue
import RequestProject.BB25.Overflow

namespace BB25

variable {b4 : Option (Sym × Dir × St)}

/-! ## Bit stacks: counters with no shift digit -/

/-- A counter stack made of *bit* blocks only: `11` and `01` over the left end.
No shift digit `03` occurs, so such a stack is a plain binary numeral. -/
inductive BitStack : List LB → Prop
  | base : BitStack [.L]
  | consX {s : List LB} : BitStack s → BitStack (.X :: s)
  | consZ {s : List LB} : BitStack s → BitStack (.Z :: s)

theorem BitStack.CStack {s : List LB} (h : BitStack s) : CStack s := by
  induction h with
  | base => exact .base
  | consX _ ih => exact ih.consX
  | consZ _ ih => exact ih.consZ

/-- **A decrement cannot turn a bit block into a shift block.**  It only flips
bits, so the deep end of the counter keeps its shape. -/
theorem BitStack.cdec {s : List LB} (h : BitStack s) : BitStack (cdec s) := by
  induction h with
  | base => exact BitStack.base
  | consX _ ih => rw [cdec_X]; exact ih.consZ
  | consZ h _ => rw [cdec_Z]; exact h.consX

theorem BitStack.cdec_iterate {s : List LB} (h : BitStack s) (m : ℕ) :
    BitStack (cdec^[m] s) := by
  induction m generalizing s with
  | zero => simpa using h
  | succ m ih => rw [Function.iterate_succ_apply]; exact ih h.cdec

theorem cdec_iterate_length (m : ℕ) (s : List LB) : (cdec^[m] s).length = s.length := by
  induction m generalizing s with
  | zero => simp
  | succ m ih => rw [Function.iterate_succ_apply, ih, cdec_length]

/-- A bit stack of value `0` is a run of zero bits. -/
theorem BitStack.eq_replicate_X {s : List LB} (h : BitStack s) (hv : cval s = 0) :
    s = List.replicate (s.length - 1) .X ++ [.L] := by
  induction h with
  | base => rfl
  | @consX s h ih =>
      have h0 : cval s = 0 := by simpa using hv
      have hne : s ≠ [] := h.CStack.ne_nil
      have hlen : s.length ≠ 0 := fun hc => hne (List.length_eq_zero_iff.mp hc)
      conv_lhs => rw [ih h0]
      simp only [List.length_cons, Nat.add_sub_cancel]
      rw [show s.length = (s.length - 1) + 1 by omega, List.replicate_succ]
      simp
  | consZ => simp at hv

/-- **The overflow deposits a `22` for every deep zero bit.** -/
theorem ofw_BitStack {s : List LB} (h : BitStack s) (hv : cval s = 0) :
    ofw s = List.replicate (s.length - 1) RB.Y := by
  conv_lhs => rw [h.eq_replicate_X hv]
  rw [ofw_replicate_X]

/-! ## A decrement leaves the deep end in place -/

private theorem cdec_append_aux : ∀ (n : ℕ) (t u : List LB), t.length ≤ n →
    ∃ (t' : List LB) (m : ℕ), cdec (t ++ u) = t' ++ cdec^[m] u ∧ t'.length = t.length := by
  intro n
  induction n with
  | zero =>
      intro t u ht
      obtain rfl : t = [] := List.length_eq_zero_iff.mp (Nat.le_zero.mp ht)
      exact ⟨[], 1, by simp, rfl⟩
  | succ n ih =>
      intro t u ht
      match t with
      | [] => exact ⟨[], 1, by simp, rfl⟩
      | .Z :: t' => exact ⟨.X :: t', 0, by rw [List.cons_append, cdec_Z]; simp, rfl⟩
      | .X :: t' =>
          obtain ⟨a, m, h1, hl1⟩ := ih t' u (by simpa using ht)
          exact ⟨.Z :: a, m, by rw [List.cons_append, cdec_X, h1]; simp, by simp [hl1]⟩
      | .W :: t' =>
          obtain ⟨a, m, h1, hl1⟩ := ih t' u (by simpa using ht)
          obtain ⟨b, m', h2, hl2⟩ := ih a (cdec^[m] u) (by omega)
          refine ⟨.W :: b, m' + m, ?_, by simp [hl2, hl1]⟩
          rw [List.cons_append, cdec_W, h1, h2, Function.iterate_add_apply]
          simp
      | .L :: t' => exact ⟨.L :: t', 0, by rw [List.cons_append, cdec_L]; simp, rfl⟩
      | .J :: t' => exact ⟨.J :: t', 0, by simp [cdec, cdecF], rfl⟩
      | .J1 :: t' => exact ⟨.J1 :: t', 0, by simp [cdec, cdecF], rfl⟩
      | .J0 :: t' => exact ⟨.J0 :: t', 0, by simp [cdec, cdecF], rfl⟩
      | .K0 :: t' => exact ⟨.K0 :: t', 0, by simp [cdec, cdecF], rfl⟩
      | .K1 :: t' => exact ⟨.K1 :: t', 0, by simp [cdec, cdecF], rfl⟩

/-- **A decrement only rewrites blocks in place.**  Whatever the borrow does to
the top of the stack, the deep part `u` is left as `u` decremented some number of
times — in particular it keeps its length and its block shape. -/
theorem cdec_append (t u : List LB) :
    ∃ (t' : List LB) (m : ℕ), cdec (t ++ u) = t' ++ cdec^[m] u ∧ t'.length = t.length :=
  cdec_append_aux t.length t u (le_refl _)

/-! ## The leading run of `22` blocks -/

private theorem ofw_bit_tail_aux : ∀ (n : ℕ) (t u : List LB), t.length ≤ n → BitStack u →
    CStack (t ++ u) → cval (t ++ u) = 0 →
    ∃ r : List RB, r.length = t.length ∧
      ofw (t ++ u) = List.replicate (u.length - 1) RB.Y ++ r := by
  intro n
  induction n with
  | zero =>
      intro t u ht hu _ hv
      obtain rfl : t = [] := List.length_eq_zero_iff.mp (Nat.le_zero.mp ht)
      exact ⟨[], rfl, by simpa using ofw_BitStack hu (by simpa using hv)⟩
  | succ n ih =>
      intro t u ht hu hst hv
      match t with
      | [] => exact ⟨[], rfl, by simpa using ofw_BitStack hu (by simpa using hv)⟩
      | .Z :: t' => simp at hv
      | .X :: t' =>
          have hv' : cval (t' ++ u) = 0 := by simpa using hv
          have hst' : CStack (t' ++ u) := by
            rw [List.cons_append] at hst; cases hst with | consX h => exact h
          obtain ⟨r, hr, hofw⟩ := ih t' u (by simpa using ht) hu hst' hv'
          refine ⟨r ++ [RB.Y], by simp [hr], ?_⟩
          rw [List.cons_append, ofw_X, hofw, List.append_assoc]
      | .W :: t' =>
          have hst' : CStack (t' ++ u) := by
            rw [List.cons_append] at hst; cases hst with | consW h => exact h
          have hle : cval (t' ++ u) ≤ 1 := by
            have : cval (t' ++ u) / 2 = 0 := by simpa using hv
            omega
          rcases Nat.eq_zero_or_pos (cval (t' ++ u)) with h0 | h0
          · obtain ⟨r, hr, hofw⟩ := ih t' u (by simpa using ht) hu hst' h0
            refine ⟨r ++ [RB.X], by simp [hr], ?_⟩
            rw [List.cons_append, ofw_W, if_pos h0, hofw, List.append_assoc]
          · obtain ⟨a, m, hsplit, hla⟩ := cdec_append t' u
            have hstd : CStack (cdec (t' ++ u)) := cdec_CStack hst' h0
            have hvd : cval (cdec (t' ++ u)) = 0 := by
              rw [cdec_cval hst' h0]; omega
            rw [hsplit] at hstd hvd
            obtain ⟨r, hr, hofw⟩ :=
              ih a (cdec^[m] u) (by omega) (hu.cdec_iterate m) hstd hvd
            refine ⟨r ++ [RB.V], by simp [hr, hla], ?_⟩
            rw [List.cons_append, ofw_W, if_neg (by omega), hsplit, hofw,
              cdec_iterate_length, List.append_assoc]
      | .L :: t' => rw [List.cons_append] at hst; cases hst
      | .J :: t' => rw [List.cons_append] at hst; cases hst
      | .J1 :: t' => rw [List.cons_append] at hst; cases hst
      | .J0 :: t' => rw [List.cons_append] at hst; cases hst
      | .K0 :: t' => rw [List.cons_append] at hst; cases hst
      | .K1 :: t' => rw [List.cons_append] at hst; cases hst

/--
**The deep bit blocks of the counter are deposited as a leading run of `22`s.**

If the `k` blocks of the counter next to the left end are bit blocks (`11` or
`01`) — no shift digit `03` among them — then the word the overflow hands to the
reset phase begins with `k` copies of the `22` block, and the rest of the word
has exactly one block per block of the counter above the deep run.

The decrements the overflow performs on its way down only flip bits, so
whichever of the deep blocks were `01` have become `11` by the time the walk
reaches them, and a `11` is deposited as a `22`.
-/
theorem ofw_bit_tail {t u : List LB} (hu : BitStack u) (hst : CStack (t ++ u))
    (hv : cval (t ++ u) = 0) :
    ∃ r : List RB, r.length = t.length ∧
      ofw (t ++ u) = List.replicate (u.length - 1) RB.Y ++ r :=
  ofw_bit_tail_aux t.length t u (le_refl _) hu hst hv

/-! ## What a leading run of `22` blocks is worth to the reset -/

theorem rmapFrom_append (ph : Bool) (p : SMap) (w₁ w₂ : List RB) :
    rmapFrom ph p (w₁ ++ w₂) =
      rmapFrom (rmapFrom ph p w₁).1 (rmapFrom ph p w₁).2 w₂ := by
  induction w₁ generalizing ph p with
  | nil => rfl
  | cons b w ih => simpa [rmapFrom] using ih (rphaseStep b) (rmapStep ph p b)

theorem rcostFrom_append (ph : Bool) (p : SMap) (w₁ w₂ : List RB) :
    rcostFrom ph p (w₁ ++ w₂) =
      rcostFrom ph p w₁ + rcostFrom (rmapFrom ph p w₁).1 (rmapFrom ph p w₁).2 w₂ := by
  induction w₁ generalizing ph p with
  | nil => simp [rcostFrom, rmapFrom]
  | cons b w ih =>
      simp only [List.cons_append, rcostFrom, rmapFrom]
      rw [ih (rphaseStep b) (rmapStep ph p b)]
      ring

/-- **A run of `22` blocks costs nothing.**  The pending digit after a `22` is
`2>`, so no decrement ever intervenes. -/
theorem rcostFrom_replicate_Y (p : SMap) (n : ℕ) :
    rcostFrom true p (List.replicate n RB.Y) = 0 := by
  induction n generalizing p with
  | zero => simp [rcostFrom]
  | succ n ih =>
      rw [List.replicate_succ, rcostFrom]
      simp [ih, show rphaseStep RB.Y = true from rfl]

/-- The `k`-digit all-ones numeral: what a run of `k` blocks `22` rebuilds. -/
def Ynum (k : ℕ) : SMap := ⟨0, 0, k, 2 ^ k - 1⟩

theorem rmap_replicate_Y_num (k : ℕ) : rmap true (List.replicate k RB.Y) = (true, Ynum k) :=
  rmap_replicate_Y k

/-- **Its deficit is zero**: the counter a leading run of `22` blocks rebuilds is
*exactly* the all-ones numeral, the largest value of its digit count. -/
theorem deficit_Ynum (k : ℕ) : (Ynum k).deficit = 0 := by
  have h : 1 ≤ 2 ^ k := Nat.one_le_two_pow
  simp only [SMap.deficit, Ynum]
  omega

theorem WF_Ynum (k : ℕ) : SMap.WF (Ynum k) := by
  have h : 1 ≤ 2 ^ k := Nat.one_le_two_pow
  show 2 ^ k - 1 < 2 ^ k
  omega

/-- **The reset of a word with a leading run of `22` blocks.**  The run is read
free of charge and leaves the full `k`-digit numeral, so the shift map — and the
cost — of the whole word are those of the rest of the word read from `Ynum k`. -/
theorem rmap_Y_prefix (k : ℕ) (r : List RB) :
    rmap true (List.replicate k RB.Y ++ r) = rmapFrom true (Ynum k) r := by
  rw [rmap, rmapFrom_append]
  have h : rmapFrom true SMap.one (List.replicate k RB.Y) = (true, Ynum k) :=
    rmap_replicate_Y_num k
  rw [h]

theorem rcost_Y_prefix (k : ℕ) (r : List RB) :
    rcost (List.replicate k RB.Y ++ r) = rcostFrom true (Ynum k) r := by
  rw [rcost, rcostFrom_append]
  have h : rmapFrom true SMap.one (List.replicate k RB.Y) = (true, Ynum k) :=
    rmap_replicate_Y_num k
  rw [h, rcostFrom_replicate_Y]
  simp

/--
**The cost criterion, relative to the deep run.**  For a word that begins with a
run of `k` blocks `22`, the whole risk sits in the rest `r`: if every decrement
`r` performs happens at digit count at least `m`, and `r` performs at most
`2^(m-1)` of them, the word is cheap and the counter it rebuilds has its top bit
set.

Since the leading run already puts the counter at `k` digits, and the number of
decrements is at most the length of `r`, this is a criterion about the blocks of
the counter *above* its deep bit run.
-/
theorem rcost_bit_tail {k m : ℕ} {r : List RB}
    (hdeep : rdecDeepFrom m true (Ynum k) r = true)
    (hcount : 2 * rdecCountFrom true (Ynum k) r ≤ 2 ^ m) :
    rcost (List.replicate k RB.Y ++ r) ≤ 1 / 2 := by
  have h1 : ((2 * rdecCountFrom true (Ynum k) r : ℕ) : ℚ) ≤ ((2 ^ m : ℕ) : ℚ) := by
    exact_mod_cast hcount
  push_cast at h1
  have h2 : (rdecCountFrom true (Ynum k) r : ℚ) / 2 ^ m ≤ 1 / 2 := by
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]
    linarith
  rw [rcost_Y_prefix]
  exact le_trans (rcostFrom_le_of_deep true (Ynum k) r hdeep) h2

/--
**A whole cycle survived, from the shape of the counter at the overflow.**
Let the counter have `k` deep bit blocks and let `r` be the rest of the word the
overflow deposits (one block per block of the counter above the deep run).  If
the reset needs no borrow, builds at least three digits, and the decrements of
`r` are few and deep, then a bouncing member crosses the word, survives the
`<B1` event at the far end and comes back to the left end with a well-formed
counter stack carrying no `141`/`241` block.
-/
theorem cycle_of_bit_tail (hb : Bounces b4) {k m : ℕ} {r : List RB}
    (hw : CWord (List.replicate k RB.Y ++ r))
    (hc : (rmap true (List.replicate k RB.Y ++ r)).2.c = 0)
    (hdeep : rdecDeepFrom m true (Ynum k) r = true)
    (hcount : 2 * rdecCountFrom true (Ynum k) r ≤ 2 ^ m)
    (he : 3 ≤ (rmap true (List.replicate k RB.Y ++ r)).2.e) :
    ∃ (s : List LB) (pre : List RB) (j : ℕ),
      BRun b4 ⟨[.L], .Lt, (List.replicate k RB.Y ++ r) ++ [.R]⟩
        ⟨s, .Lt, pre ++ [.Y, .R1]⟩ j ∧ CStack s ∧
        ∀ b ∈ pre, b ≠ RB.F ∧ b ≠ RB.G :=
  reset_cycle_of_cost hb hw hc (rcost_bit_tail hdeep hcount) he

end BB25
