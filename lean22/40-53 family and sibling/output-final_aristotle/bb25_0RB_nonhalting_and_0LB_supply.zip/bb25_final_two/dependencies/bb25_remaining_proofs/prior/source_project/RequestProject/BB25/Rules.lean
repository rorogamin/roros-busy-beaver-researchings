/-
# The shared longitudinal rules

Every rule of the longitudinal table of the family
`1RB2LA0RB1LB---_1LA3RA1RA4LB---` that does *not* depend on the free
transition `B4`, together with its exact number of base steps.

Notation.  A configuration is written `… <A …` / `… A> …` as in
`BB25.Cfg`; the tape is read left to right, and `$` denotes the (all `0`)
end of the tape.  `<B1` abbreviates a left-facing head in state `B`
immediately followed on the tape by the symbol `1`; that trailing `1` is part
of the marker and is written out explicitly in the Lean statements.

Every statement below is proved by `rfl`, i.e. by running the machine.
-/
import RequestProject.BB25.Machine

namespace BB25

variable (b4 : Option (Sym × Dir × St)) (l r : List Sym)

/-! ## The head moving left in state `A` -/

/-- `03 <A → <A 11`  (2 steps).  In block form: `W <A → <A X`. -/
theorem rule_W_A : steps (M b4) 2 ⟨3 :: 0 :: l, .A, .L, r⟩ = some ⟨l, .A, .L, 1 :: 1 :: r⟩ := rfl

/-- `01 <A → 11 A>`  (3 steps).  In block form: `Z <A → X A>`. -/
theorem rule_Z_A : steps (M b4) 3 ⟨1 :: 0 :: l, .A, .L, r⟩ = some ⟨1 :: 1 :: l, .A, .R, r⟩ := rfl

/-- `11 <A → <A 22`  (2 steps).  In block form: `X <A → <A Y`. -/
theorem rule_X_A : steps (M b4) 2 ⟨1 :: 1 :: l, .A, .L, r⟩ = some ⟨l, .A, .L, 2 :: 2 :: r⟩ := rfl

/-! ## The head moving left in state `B` (`<B1`) -/

/-- `03 <B1 → <A 141`  (2 steps).  In block form: `W <B1 → <A F`. -/
theorem rule_W_B1 :
    steps (M b4) 2 ⟨3 :: 0 :: l, .B, .L, 1 :: r⟩ = some ⟨l, .A, .L, 1 :: 4 :: 1 :: r⟩ := rfl

/-- `01 <B1 → <A 11 2>`  (4 steps).  In block form: `Z <B1 → <A X P2`. -/
theorem rule_Z_B1 :
    steps (M b4) 4 ⟨1 :: 0 :: l, .B, .L, 1 :: r⟩ = some ⟨l, .A, .L, 1 :: 1 :: 2 :: r⟩ := rfl

/-- `11 <B1 → <B1 22`  (6 steps).  In block form: `X <B1 → <B1 Y`. -/
theorem rule_X_B1 :
    steps (M b4) 6 ⟨1 :: 1 :: l, .B, .L, 1 :: r⟩ = some ⟨l, .B, .L, 1 :: 2 :: 2 :: r⟩ := rfl

/-! ## The head moving right in state `A` -/

/-- `A> 11 → <A 21`  (1 step).  In block form: `A> X → <A V`. -/
theorem rule_A_X : steps (M b4) 1 ⟨l, .A, .R, 1 :: 1 :: r⟩ = some ⟨l, .A, .L, 2 :: 1 :: r⟩ := rfl

/-- `A> 21 → 03 A>`  (2 steps).  In block form: `A> V → W A>`. -/
theorem rule_A_V : steps (M b4) 2 ⟨l, .A, .R, 2 :: 1 :: r⟩ = some ⟨3 :: 0 :: l, .A, .R, r⟩ := rfl

/-- `A> 22 → 01 A>`  (2 steps).  In block form: `A> Y → Z A>`. -/
theorem rule_A_Y : steps (M b4) 2 ⟨l, .A, .R, 2 :: 2 :: r⟩ = some ⟨1 :: 0 :: l, .A, .R, r⟩ := rfl

/-- `A> 12 → <A 22`  (1 step).  In block form: `A> U → <A Y`. -/
theorem rule_A_U : steps (M b4) 1 ⟨l, .A, .R, 1 :: 2 :: r⟩ = some ⟨l, .A, .L, 2 :: 2 :: r⟩ := rfl

/-- `A> 141 → <A 241`  (1 step).  In block form: `A> F → <A G`. -/
theorem rule_A_F :
    steps (M b4) 1 ⟨l, .A, .R, 1 :: 4 :: 1 :: r⟩ = some ⟨l, .A, .L, 2 :: 4 :: 1 :: r⟩ := rfl

/-! ## The right end of the tape -/

/-- `A> $ → <A 21 $`  (3 steps).  In block form: `A> R → <A V R`. -/
theorem rule_A_R : steps (M b4) 3 ⟨l, .A, .R, []⟩ = some ⟨l, .A, .L, [2, 1]⟩ := rfl

/-- `A> 1$ → <A 2$`  (1 step).  In block form: `A> R1 → <A R2`. -/
theorem rule_A_R1 : steps (M b4) 1 ⟨l, .A, .R, [1]⟩ = some ⟨l, .A, .L, [2]⟩ := rfl

/-- `A> 2$ → <B1 22 1$`  (11 steps).  In block form: `A> R2 → <B1 Y R1`.
This is the only way the family ever produces a left-moving `B` head, and
hence (via `rule_W_B1`) the only source of the blocks `141`/`241` that carry
the halting symbol `4`. -/
theorem rule_A_R2 : steps (M b4) 11 ⟨l, .A, .R, [2]⟩ = some ⟨l, .B, .L, [1, 2, 2, 1]⟩ := rfl

/-! ## The left end of the tape -/

/-- `$ 11 <A → $ 11 A> 2>`  (4 steps).  In block form: `L <A → L A> P2`.
Here the left tape consists of exactly `11`, i.e. the block `L = ^11`. -/
theorem rule_L_A : steps (M b4) 4 ⟨[1, 1], .A, .L, r⟩ = some ⟨[1, 1], .A, .R, 2 :: r⟩ := rfl

/-! ## Variants of the end-of-tape rules with explicit `0`s

The list encoding leaves the `0`s outside the two lists implicit, so the
`$`-rules above are stated for the empty right tape.  For convenience we also
record the versions in which the `0`s are written out. -/

/-- `A> 00 → <A 21`  (3 steps). -/
theorem rule_A_00 : steps (M b4) 3 ⟨l, .A, .R, 0 :: 0 :: r⟩ = some ⟨l, .A, .L, 2 :: 1 :: r⟩ := rfl

/-- `A> 10 → <A 20`  (1 step). -/
theorem rule_A_10 : steps (M b4) 1 ⟨l, .A, .R, 1 :: 0 :: r⟩ = some ⟨l, .A, .L, 2 :: 0 :: r⟩ := rfl

/-- `A> 2000 → <B1 2210`  (11 steps). -/
theorem rule_A_2000 :
    steps (M b4) 11 ⟨l, .A, .R, 2 :: 0 :: 0 :: 0 :: r⟩ = some ⟨l, .B, .L, 1 :: 2 :: 2 :: 1 :: r⟩ :=
  rfl

end BB25
