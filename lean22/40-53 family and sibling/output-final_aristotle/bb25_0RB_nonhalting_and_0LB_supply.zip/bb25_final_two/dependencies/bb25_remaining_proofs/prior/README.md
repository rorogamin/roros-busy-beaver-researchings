# Five more BB(2,5) nonhalting arguments

## Results and certification status

The new mathematical arguments cover `0RA`, `2RB`, `2RA`, `1RB`, and `1LB`
in the family `1RB2LA0RB1LB---_1LA3RA1RA4LB---`.

They are proposed complete mathematical proofs, not Lean-certified
nonhalting theorems. The original Aristotle Lean source is copied unchanged
in `source_project/`. The new results are not inserted as axioms or as
unproved Lean declarations.

Together with the earlier proposed arguments for `3RA`, `2LA`, `1RA`,
`0LA`, and `2LB`, this gives proposed mathematical coverage of ten of the
thirteen supplied members. The three not decided here are `0LB`, `0RB`,
and `1LA`. Formal certification of the combined arguments remains separate.

## Files

`PROOF_NEXT.md` is the mathematical argument, including the arbitrary-length
local marker calculation, all early-reset cases, and the final induction.

`FORMALIZATION_NEXT.md` gives the required Lean interfaces, existing source
declarations, suggested new lemmas, and phase/context pitfalls.

`verify_next.py` implements the constructive return operations independently
of the source block simulator.

`check_next.py` and `check_components_next.py` contain the reproducible finite
checks. Their completed run records are `verification_results_next.json`,
`component_results_next.json`, and the corresponding text logs.

`RESEARCH_NOTES.md` records the strengthened checkpoint restriction and
explicit obstructions for further work.

`previous/` contains the previous three-member package unchanged in content,
including its own previous two-member proof. `source_project/` contains the
original Lean project source and toolchain metadata, not a new formalization.
`PROVENANCE.json` and `SHA256SUMS_NEXT.json` record source and deliverable hashes.

## Reproduce the checks

Python 3.10 or later is sufficient; only the standard library is used.
From this directory run:

```sh
python check_next.py --max-length 11 --random 100
python check_components_next.py
```

The first command checks 31,259 exhaustive normal stacks, 100 deterministic
random stacks, and 108 long-tail stacks for each of the five members:
157,335 exact endpoint comparisons. It also replays each blank seed and
5,000 base/block transitions.

The component command checks 1,377,307 clean Dyck prefixes, 7,435 exceptional
1LB stacks, 7,435 exact 1RB early resets, and the local drain through n=128.
It also confirms the stated nonblank counterexamples for 0RB and 1LA.

Do not use Python's `-O` option: assertions are the checks. A finite successful
run is evidence of consistency, not a replacement for the universal proofs.

## What changed mathematically

The normal checkpoint is now **Good, positive, and X-ending**. This ensures
that a new unusual marker is shielded from B by a Z, and that the delicate
1LB early reset has a nonempty run of one bits before its last X.

The main new tools are an explicit local drain identity, reset above an
existing Good base, the strengthened mod-8 expansion barrier, and a generic
one-unit-deficit repair. Unlike the earlier universal-Good proposal for
1LB, this theorem excludes the known halting counterexample ending in W.
