/-
# The overflow itself: what the left counter hands to the right-hand counter

`Phase.lean` computes what happens *inside* a phase.  This file is about the
event between two phases — the **overflow** — and about the exact way the value
of the counter enters the word that the next **reset** phase re-parses.

Two explicit functions do the work.

* `cdec` is the decrement of the counter *as an operation on the stack of
  blocks*, i.e. the carry (borrow) propagation:

  ```
      01 s  ↦  11 s                (borrow stops:   the value was odd)
      11 s  ↦  01 (cdec s)         (borrow travels: the value was even)
      03 s  ↦  03 (cdec (cdec s))  (a shift digit costs *two* decrements)
  ```

  `brun_cdec` proves that this is what the machine does, and `cdec_cval` that
  it decrements the value.  So how deep a decrement reaches into the stack is
  decided by the low digits of the counter — `cdec_run_of_zeros`:
  `11^m 01 s ↦ 01^m 11 s`, one block per trailing zero.

* `ofw` is the word the overflow *deposits* on the right-hand tape.  When the
  counter is `0` the head walks off the bottom of the stack, and on the way it
  converts every block of the stack into one block of the right-hand tape
  (`brun_overflow_word`):

  ```
      11 (bit 0)  ↦  22          03 (shift) ↦ 11   if the counter below is 0
                                            ↦ 21   if it is 1  (one decrement)
  ```

  So the overflow **re-encodes the whole left counter in the right-hand digit
  representation**, block for block (`ofw_length`), and hands that word to the
  reset phase, which parses it back with the *other* digit table.  That closed
  loop — counter phase (right → left), overflow (left → right), reset phase
  (right → left) — is the whole dynamics of the family.

## Does the reset depend on the value of the counter?

Yes, and `ofw` says exactly how.  The word depends on the stack, and the stack
depends on the counter value through the borrow propagation of `cdec`: the two
stacks of `overflow_word_value_dependent` have the same length and the same
digits in the same places except for the value they carry, and they hand
different words to the reset phase.  The dependence is on the *digits* of the
counter (its residues mod `2 ^ k`, through the trailing zeros a borrow has to
cross), not merely on its size — which is the shape a "reset depends on the
counter mod `k`" phenomenon would take here.

What is *not* value-dependent: inside one phase the itinerary is fixed.  The
sequence of pending digits and the digit read at each block depend only on the
word (`rmapFrom`, `cmapFrom` do not mention the counter), and the counter value
enters only through the single threshold `c` — `Phase.lean`.  So all the
value-dependence of a run is concentrated in the two events this file
describes: how far a borrow travels, and what the overflow deposits.
-/
import RequestProject.BB25.Phase

namespace BB25

variable {b4 : Option (Sym × Dir × St)}

/-! ## The decrement of the counter, as an operation on the stack -/

/-- The decrement of the block stack, with a step budget (the budget is always
taken to be the length of the stack; see `cdec`). -/
def cdecF : ℕ → List LB → List LB
  | 0, s => s
  | _ + 1, [] => []
  | _ + 1, .Z :: s => .X :: s
  | n + 1, .X :: s => .Z :: cdecF n s
  | n + 1, .W :: s => .W :: cdecF n (cdecF n s)
  | _ + 1, s => s

theorem cdecF_length : ∀ (n : ℕ) (s : List LB), (cdecF n s).length = s.length := by
  intro n
  induction n with
  | zero => intro s; rfl
  | succ n ih =>
      intro s
      match s with
      | [] => rfl
      | .Z :: s => rfl
      | .X :: s => simpa [cdecF] using ih s
      | .W :: s => simp [cdecF, ih]
      | .L :: s => rfl
      | .J :: s => rfl
      | .J1 :: s => rfl
      | .J0 :: s => rfl
      | .K0 :: s => rfl
      | .K1 :: s => rfl

theorem cdecF_stable : ∀ (n m : ℕ) (s : List LB), s.length ≤ n → s.length ≤ m →
    cdecF n s = cdecF m s := by
  intro n
  induction n with
  | zero =>
      intro m s hn _
      have : s = [] := List.length_eq_zero_iff.mp (Nat.le_zero.mp hn)
      subst this
      cases m <;> rfl
  | succ n ih =>
      intro m s hn hm
      match s with
      | [] => cases m <;> rfl
      | .Z :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .L :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .J :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .J1 :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .J0 :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .K0 :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .K1 :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .X :: s => cases m with
          | zero => simp at hm
          | succ m =>
              have h1 : s.length ≤ n := by simpa using hn
              have h2 : s.length ≤ m := by simpa using hm
              simp only [cdecF]
              rw [ih m s h1 h2]
      | .W :: s => cases m with
          | zero => simp at hm
          | succ m =>
              have h1 : s.length ≤ n := by simpa using hn
              have h2 : s.length ≤ m := by simpa using hm
              have hin : cdecF n s = cdecF m s := ih m s h1 h2
              have hlen : (cdecF m s).length ≤ n := by rw [cdecF_length]; exact h1
              have hlen' : (cdecF m s).length ≤ m := by rw [cdecF_length]; exact h2
              simp only [cdecF]
              rw [hin, ih m (cdecF m s) hlen hlen']

/-- **The decrement of the counter, on the stack.**  One head excursion
rewrites the stack exactly like this. -/
def cdec (s : List LB) : List LB := cdecF s.length s

@[simp] theorem cdec_nil : cdec [] = [] := rfl

@[simp] theorem cdec_length (s : List LB) : (cdec s).length = s.length := cdecF_length _ _

/-- A `01` block is a `1` bit: the borrow stops there. -/
@[simp] theorem cdec_Z (s : List LB) : cdec (.Z :: s) = .X :: s := rfl

/-- A `11` block is a `0` bit: the borrow travels on. -/
@[simp] theorem cdec_X (s : List LB) : cdec (.X :: s) = .Z :: cdec s := rfl

/-- **A shift digit costs two decrements.**  This is what makes the counter a
*mixed-digit* one: a borrow crossing a `03` block has to be paid for twice. -/
@[simp] theorem cdec_W (s : List LB) : cdec (.W :: s) = .W :: cdec (cdec s) := by
  show cdecF (s.length + 1) (.W :: s) = _
  simp only [cdecF, cdec]
  rw [cdecF_stable s.length s.length s (le_refl _) (le_refl _),
    cdecF_stable s.length (cdecF s.length s).length (cdecF s.length s)
      (by rw [cdecF_length]) (le_refl _)]

@[simp] theorem cdec_L (s : List LB) : cdec (.L :: s) = .L :: s := rfl

theorem cdec_aux : ∀ (n : ℕ) (s : List LB), s.length ≤ n → CStack s → 1 ≤ cval s →
    CStack (cdec s) ∧ cval (cdec s) = cval s - 1 := by
  intro n
  induction n with
  | zero =>
      intro s hlen hst _
      exact absurd (List.length_eq_zero_iff.mp (Nat.le_zero.mp hlen)) hst.ne_nil
  | succ n ih =>
      intro s hlen hst hv
      cases hst with
      | base => exact absurd hv (by simp)
      | @consZ s hs => exact ⟨by rw [cdec_Z]; exact hs.consX, by rw [cdec_Z, cval_X, cval_Z]; omega⟩
      | @consX s hs =>
          have hs1 : 1 ≤ cval s := by simp at hv; omega
          obtain ⟨h1, h2⟩ := ih s (by simpa using hlen) hs hs1
          exact ⟨by rw [cdec_X]; exact h1.consZ, by rw [cdec_X, cval_Z, cval_X, h2]; omega⟩
      | @consW s hs =>
          have hs2 : 2 ≤ cval s := by simp at hv; omega
          obtain ⟨h1, h2⟩ := ih s (by simpa using hlen) hs (by omega)
          obtain ⟨h3, h4⟩ := ih (cdec s) (by rw [cdec_length]; simpa using hlen) h1 (by omega)
          refine ⟨by rw [cdec_W]; exact h3.consW, ?_⟩
          rw [cdec_W, cval_W, cval_W, h4, h2]
          omega

/-- The decrement keeps the stack well formed. -/
theorem cdec_CStack {s : List LB} (hst : CStack s) (hv : 1 ≤ cval s) : CStack (cdec s) :=
  (cdec_aux s.length s (le_refl _) hst hv).1

/-- The decrement decrements the value. -/
theorem cdec_cval {s : List LB} (hst : CStack s) (hv : 1 ≤ cval s) :
    cval (cdec s) = cval s - 1 :=
  (cdec_aux s.length s (le_refl _) hst hv).2

/-- **The machine performs `cdec`.**  A head that enters a nonzero counter in
state `<A` comes back out in state `A>` with the stack rewritten by `cdec`, the
right-hand tape untouched. -/
theorem brun_cdec : ∀ (n : ℕ) (s : List LB), s.length ≤ n → CStack s → 1 ≤ cval s →
    ∀ rt : List RB, ∃ k, BRun (b4 := b4) ⟨s, .Lt, rt⟩ ⟨cdec s, .Rt, rt⟩ k := by
  intro n
  induction n with
  | zero =>
      intro s hlen hst _ _
      exact absurd (List.length_eq_zero_iff.mp (Nat.le_zero.mp hlen)) hst.ne_nil
  | succ n ih =>
      intro s hlen hst hv rt
      cases hst with
      | base => exact absurd hv (by simp)
      | @consX s hs =>
          have hlen' : s.length ≤ n := by simpa using hlen
          have hs1 : 1 ≤ cval s := by simp at hv; omega
          obtain ⟨k, hrun⟩ := ih s hlen' hs hs1 (.Y :: rt)
          refine ⟨2 + (k + 2), ?_⟩
          rw [cdec_X]
          exact BRun.head (show bstep b4 ⟨.X :: s, .Lt, rt⟩ = some (⟨s, .Lt, .Y :: rt⟩, 2) from rfl)
            (hrun.trans (BRun.of_step (show bstep b4 ⟨cdec s, .Rt, .Y :: rt⟩
              = some (⟨.Z :: cdec s, .Rt, rt⟩, 2) from rfl)))
      | @consZ s hs =>
          refine ⟨3, ?_⟩
          rw [cdec_Z]
          exact BRun.of_step
            (show bstep b4 ⟨.Z :: s, .Lt, rt⟩ = some (⟨.X :: s, .Rt, rt⟩, 3) from rfl)
      | @consW s hs =>
          have hlen' : s.length ≤ n := by simpa using hlen
          have hs2 : 2 ≤ cval s := by simp at hv; omega
          obtain ⟨k₁, hrun₁⟩ := ih s hlen' hs (by omega) (.X :: rt)
          have hv' : cval (cdec s) = cval s - 1 := cdec_cval hs (by omega)
          have hlen'' : (cdec s).length ≤ n := by rw [cdec_length]; exact hlen'
          obtain ⟨k₂, hrun₂⟩ := ih (cdec s) hlen'' (cdec_CStack hs (by omega)) (by omega) (.V :: rt)
          refine ⟨2 + (k₁ + (1 + (k₂ + 2))), ?_⟩
          rw [cdec_W]
          exact BRun.head (show bstep b4 ⟨.W :: s, .Lt, rt⟩ = some (⟨s, .Lt, .X :: rt⟩, 2) from rfl)
            (hrun₁.trans (BRun.head (show bstep b4 ⟨cdec s, .Rt, .X :: rt⟩
                = some (⟨cdec s, .Lt, .V :: rt⟩, 1) from rfl)
              (hrun₂.trans (BRun.of_step (show bstep b4 ⟨cdec (cdec s), .Rt, .V :: rt⟩
                = some (⟨.W :: cdec (cdec s), .Rt, rt⟩, 2) from rfl)))))

/-- **The decrement of the counter, explicitly.** -/
theorem brun_cdec_of {s : List LB} (hst : CStack s) (hv : 1 ≤ cval s) (rt : List RB) :
    ∃ k, BRun (b4 := b4) ⟨s, .Lt, rt⟩ ⟨cdec s, .Rt, rt⟩ k :=
  brun_cdec s.length s (le_refl _) hst hv rt

/-- **A borrow crosses exactly the trailing zeros of the counter.**
`11^m 01 s ↦ 01^m 11 s`: the number of blocks the decrement rewrites is fixed by
the low digits of the counter — this is the value-dependence of the tape shape,
and hence of everything the next overflow will hand to the reset phase. -/
theorem cdec_run_of_zeros (m : ℕ) (s : List LB) :
    cdec (List.replicate m .X ++ .Z :: s) = List.replicate m .Z ++ .X :: s := by
  induction m with
  | zero => simp
  | succ m ih => simp [List.replicate_succ, ih]

/-! ## The overflow: the counter is written back onto the tape -/

/-- The word the overflow deposits on the right-hand tape, with a step budget
(always the length of the stack; see `ofw`). -/
def ofwF : ℕ → List LB → List RB
  | 0, _ => []
  | _ + 1, [] => []
  | n + 1, .X :: s => ofwF n s ++ [.Y]
  | n + 1, .W :: s => if cval s = 0 then ofwF n s ++ [.X] else ofwF n (cdec s) ++ [.V]
  | _ + 1, _ => []

theorem ofwF_stable : ∀ (n m : ℕ) (s : List LB), s.length ≤ n → s.length ≤ m →
    ofwF n s = ofwF m s := by
  intro n
  induction n with
  | zero =>
      intro m s hn _
      have : s = [] := List.length_eq_zero_iff.mp (Nat.le_zero.mp hn)
      subst this
      cases m <;> rfl
  | succ n ih =>
      intro m s hn hm
      match s with
      | [] => cases m <;> rfl
      | .Z :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .L :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .J :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .J1 :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .J0 :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .K0 :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .K1 :: s => cases m with
          | zero => simp at hm
          | succ m => rfl
      | .X :: s => cases m with
          | zero => simp at hm
          | succ m =>
              have h1 : s.length ≤ n := by simpa using hn
              have h2 : s.length ≤ m := by simpa using hm
              simp only [ofwF]
              rw [ih m s h1 h2]
      | .W :: s => cases m with
          | zero => simp at hm
          | succ m =>
              have h1 : s.length ≤ n := by simpa using hn
              have h2 : s.length ≤ m := by simpa using hm
              have hlen : (cdec s).length ≤ n := by rw [cdec_length]; exact h1
              have hlen' : (cdec s).length ≤ m := by rw [cdec_length]; exact h2
              simp only [ofwF]
              rw [ih m s h1 h2, ih m (cdec s) hlen hlen']

/-- **The word the overflow deposits.**  Read from the head outwards, it is the
whole left stack translated block for block into the right-hand digits. -/
def ofw (s : List LB) : List RB := ofwF s.length s

@[simp] theorem ofw_nil : ofw [] = [] := rfl
@[simp] theorem ofw_L (s : List LB) : ofw (.L :: s) = [] := rfl
@[simp] theorem ofw_Z (s : List LB) : ofw (.Z :: s) = [] := rfl

/-- A `11` block of the counter leaves a `22` block on the tape. -/
@[simp] theorem ofw_X (s : List LB) : ofw (.X :: s) = ofw s ++ [.Y] := rfl

/-- A `03` block leaves an `11` block, or a `21` block if the head still had a
decrement to spend below it. -/
@[simp] theorem ofw_W (s : List LB) :
    ofw (.W :: s) = if cval s = 0 then ofw s ++ [.X] else ofw (cdec s) ++ [.V] := by
  show ofwF (s.length + 1) (.W :: s) = _
  simp only [ofwF, ofw]
  rw [ofwF_stable s.length s.length s (le_refl _) (le_refl _),
    ofwF_stable s.length (cdec s).length (cdec s) (by rw [cdec_length]) (le_refl _)]

/-- The overflow deposits exactly one block of the tape per block of the
counter, and they are all digit blocks: the word is a legitimate input for the
next phase. -/
theorem ofw_aux : ∀ (n : ℕ) (s : List LB), s.length ≤ n → CStack s → cval s = 0 →
    (ofw s).length = s.length - 1 ∧ CWord (ofw s) := by
  intro n
  induction n with
  | zero =>
      intro s hlen hst _
      exact absurd (List.length_eq_zero_iff.mp (Nat.le_zero.mp hlen)) hst.ne_nil
  | succ n ih =>
      intro s hlen hst hv
      cases hst with
      | base => exact ⟨rfl, CWord.nil⟩
      | @consZ s hs => exact absurd hv (by simp)
      | @consX s hs =>
          have hlen' : s.length ≤ n := by simpa using hlen
          have h0 : cval s = 0 := by simp at hv; omega
          obtain ⟨h1, h2⟩ := ih s hlen' hs h0
          have hne : 1 ≤ s.length := by
            cases s with
            | nil => exact absurd rfl hs.ne_nil
            | cons _ _ => simp
          refine ⟨by simp only [ofw_X, List.length_append, List.length_cons,
            List.length_nil]; omega, ?_⟩
          intro b hb
          rcases List.mem_append.mp hb with hb | hb
          · exact h2 b hb
          · simp only [List.mem_cons, List.not_mem_nil, or_false] at hb
            exact Or.inr (Or.inr (Or.inr hb))
      | @consW s hs =>
          have hlen' : s.length ≤ n := by simpa using hlen
          have h1 : cval s ≤ 1 := by simp at hv; omega
          have hne : 1 ≤ s.length := by
            cases s with
            | nil => exact absurd rfl hs.ne_nil
            | cons _ _ => simp
          rcases Nat.eq_zero_or_pos (cval s) with h0 | h0
          · obtain ⟨hl, hw⟩ := ih s hlen' hs h0
            rw [ofw_W, if_pos h0]
            refine ⟨by simp only [List.length_append, List.length_cons, List.length_nil]; omega, ?_⟩
            intro b hb
            rcases List.mem_append.mp hb with hb | hb
            · exact hw b hb
            · simp only [List.mem_cons, List.not_mem_nil, or_false] at hb
              exact Or.inl hb
          · have hlen'' : (cdec s).length ≤ n := by rw [cdec_length]; exact hlen'
            have hv' : cval (cdec s) = 0 := by rw [cdec_cval hs (by omega)]; omega
            obtain ⟨hl, hw⟩ := ih (cdec s) hlen'' (cdec_CStack hs (by omega)) hv'
            rw [cdec_length] at hl
            rw [ofw_W, if_neg (by omega)]
            refine ⟨by simp only [List.length_append, List.length_cons, List.length_nil]; omega, ?_⟩
            intro b hb
            rcases List.mem_append.mp hb with hb | hb
            · exact hw b hb
            · simp only [List.mem_cons, List.not_mem_nil, or_false] at hb
              exact Or.inr (Or.inr (Or.inl hb))

/-- The overflow deposits exactly one block per block of the counter. -/
theorem ofw_length {s : List LB} (hst : CStack s) (hv : cval s = 0) :
    (ofw s).length = s.length - 1 :=
  (ofw_aux s.length s (le_refl _) hst hv).1

/-- Only digit blocks are deposited. -/
theorem ofw_CWord {s : List LB} (hst : CStack s) (hv : cval s = 0) : CWord (ofw s) :=
  (ofw_aux s.length s (le_refl _) hst hv).2

/--
**The overflow re-encodes the counter onto the tape.**  If the counter is `0`
the head walks off the bottom of the stack and reaches the left end `^11`, and
the tape it leaves behind is the old tape with the word `ofw lt` — the whole
stack, translated block for block into right-hand digits — in front of it.
This word is the input of the next reset phase.
-/
theorem brun_overflow_word : ∀ (n : ℕ) (s : List LB), s.length ≤ n → CStack s → cval s = 0 →
    ∀ rt : List RB, ∃ k, BRun (b4 := b4) ⟨s, .Lt, rt⟩ ⟨[.L], .Lt, ofw s ++ rt⟩ k := by
  intro n
  induction n with
  | zero =>
      intro s hlen hst _ _
      exact absurd (List.length_eq_zero_iff.mp (Nat.le_zero.mp hlen)) hst.ne_nil
  | succ n ih =>
      intro s hlen hst hv rt
      cases hst with
      | base => exact ⟨0, by simpa using BRun.refl (b4 := b4) _⟩
      | @consZ s hs => exact absurd hv (by simp)
      | @consX s hs =>
          have hlen' : s.length ≤ n := by simpa using hlen
          have h0 : cval s = 0 := by simp at hv; omega
          obtain ⟨k, hrun⟩ := ih s hlen' hs h0 (.Y :: rt)
          refine ⟨2 + k, ?_⟩
          rw [ofw_X]
          simpa using
            BRun.head (show bstep b4 ⟨.X :: s, .Lt, rt⟩ = some (⟨s, .Lt, .Y :: rt⟩, 2) from rfl) hrun
      | @consW s hs =>
          have hlen' : s.length ≤ n := by simpa using hlen
          have h1 : cval s ≤ 1 := by simp at hv; omega
          rcases Nat.eq_zero_or_pos (cval s) with h0 | h0
          · obtain ⟨k, hrun⟩ := ih s hlen' hs h0 (.X :: rt)
            refine ⟨2 + k, ?_⟩
            rw [ofw_W, if_pos h0]
            simpa using
              BRun.head (show bstep b4 ⟨.W :: s, .Lt, rt⟩ = some (⟨s, .Lt, .X :: rt⟩, 2) from rfl)
                hrun
          · obtain ⟨k₁, hrun₁⟩ := brun_cdec_of (b4 := b4) hs h0 (.X :: rt)
            have hlen'' : (cdec s).length ≤ n := by rw [cdec_length]; exact hlen'
            have hv' : cval (cdec s) = 0 := by rw [cdec_cval hs (by omega)]; omega
            obtain ⟨k₂, hrun₂⟩ := ih (cdec s) hlen'' (cdec_CStack hs (by omega)) hv' (.V :: rt)
            refine ⟨2 + (k₁ + (1 + k₂)), ?_⟩
            rw [ofw_W, if_neg (by omega)]
            have hrun : BRun (b4 := b4) ⟨.W :: s, .Lt, rt⟩ ⟨[.L], .Lt, ofw (cdec s) ++ (.V :: rt)⟩
                (2 + (k₁ + (1 + k₂))) :=
              BRun.head (show bstep b4 ⟨.W :: s, .Lt, rt⟩ = some (⟨s, .Lt, .X :: rt⟩, 2) from rfl)
                (hrun₁.trans (BRun.head (show bstep b4 ⟨cdec s, .Rt, .X :: rt⟩
                    = some (⟨cdec s, .Lt, .V :: rt⟩, 1) from rfl) hrun₂))
            simpa using hrun

/-- **The overflow, packaged.** -/
theorem brun_overflow_of {s : List LB} (hst : CStack s) (hv : cval s = 0) (rt : List RB) :
    ∃ k, BRun (b4 := b4) ⟨s, .Lt, rt⟩ ⟨[.L], .Lt, ofw s ++ rt⟩ k :=
  brun_overflow_word s.length s (le_refl _) hst hv rt

/-! ## The whole overflow–reset cycle, in closed form -/

/--
**One turn of the shift-overflow cycle.**  Starting from a counter that has just
run out (`cval lt = 0`), the machine

1. *overflows*: the head reaches the left end and the counter is re-encoded on
   the tape as the word `ofw lt`;
2. starts a *reset phase*: a pending digit `2>` is created and marches back
   across that word, re-parsing it with the other digit table;
3. arrives at the far end with the counter value `(rmap true (ofw lt)).2.f` —
   the numeral the word carries in the reset representation — and with the
   pending digit `(rmap true (ofw lt)).1`,

provided the word does not ask for a decrement the empty counter cannot pay
(`c = 0`, which is what `hc` says).  Everything here is computed from `lt`
alone: this is the sense in which the overflow and the reset are predicted, not
simulated.
-/
theorem brun_overflow_reset_cycle {lt : List LB} (hst : CStack lt) (hv : cval lt = 0)
    (hc : (rmap true (ofw lt)).2.c = 0) (rest : List RB) :
    ∃ (lt' : List LB) (k : ℕ),
      BRun (b4 := b4) ⟨lt, .Lt, rest⟩ ⟨lt', .Rt, pd (rmap true (ofw lt)).1 :: rest⟩ k ∧
        CStack lt' ∧ cval lt' = (rmap true (ofw lt)).2.f := by
  obtain ⟨k₀, hrun₀⟩ := brun_overflow_of (b4 := b4) hst hv rest
  have hstep : bstep b4 ⟨[.L], .Lt, ofw lt ++ rest⟩
      = some (⟨[.L], .Rt, .P2 :: (ofw lt ++ rest)⟩, 4) := rfl
  have hL : CStack [LB.L] := CStack.base
  have hcv : cval ([LB.L] : List LB) = 0 := rfl
  obtain ⟨lt', k₁, hrun₁, hst₁, hv₁⟩ :=
    (brun_reset_dichotomy (b4 := b4) (ofw_CWord hst hv) (ph := true) hL rest).1
      (by rw [hcv, hc])
  refine ⟨lt', k₀ + (4 + k₁), hrun₀.trans (BRun.head hstep hrun₁), hst₁, ?_⟩
  rw [hv₁, hcv]
  show ((0 - (rmap true (ofw lt)).2.c) / 2 ^ _) * 2 ^ _ + (rmap true (ofw lt)).2.f = _
  simp

/-- **How big a counter a reset can rebuild.**  The word deposited by the
overflow has one block per block of the old counter, and a reset phase appends
at most one digit per block, so the counter after the reset is smaller than
`2 ^ (number of blocks of the old counter)`. -/
theorem reset_value_bound {lt : List LB} (hst : CStack lt) (hv : cval lt = 0) :
    (rmap true (ofw lt)).2.f < 2 ^ (lt.length - 1) := by
  have hwf : SMap.WF (rmap true (ofw lt)).2 := rmapFrom_WF SMap.WF_one _ _
  have he : (rmap true (ofw lt)).2.e ≤ lt.length - 1 := by
    have h1 := rmap_e_le true (ofw lt)
    rw [ofw_length hst hv] at h1
    exact h1
  calc (rmap true (ofw lt)).2.f < 2 ^ (rmap true (ofw lt)).2.e := hwf
    _ ≤ 2 ^ (lt.length - 1) := Nat.pow_le_pow_right (by norm_num) he

/-! ## An overflow–reset cycle computed end to end -/

/-- A stack of `m` zero bits standing on the left end is a legal counter. -/
theorem CStack_replicate_X (n : ℕ) : CStack (List.replicate n .X ++ [.L]) := by
  induction n with
  | zero => exact CStack.base
  | succ n ih => exact (by simpa [List.replicate_succ] using ih.consX)

/-- Its value is `0`. -/
theorem cval_replicate_X (n : ℕ) : cval (List.replicate n .X ++ [.L]) = 0 := by
  induction n with
  | zero => rfl
  | succ n ih => simp [List.replicate_succ, ih]

/-- Every zero bit of the counter is deposited as a `22` block. -/
theorem ofw_replicate_X (n : ℕ) :
    ofw (List.replicate n .X ++ [.L]) = List.replicate n .Y := by
  induction n with
  | zero => rfl
  | succ n ih =>
      rw [List.replicate_succ, List.cons_append, ofw_X, ih, ← List.replicate_succ']

/-- A word of `22` blocks read in the reset representation is the all-ones
numeral: the reset appends a `1` bit for each of them. -/
theorem rmapFrom_replicate_Y : ∀ (n : ℕ) (p : SMap),
    rmapFrom true p (List.replicate n .Y) = (true, ⟨p.c, p.d, p.e + n, (p.f + 1) * 2 ^ n - 1⟩) := by
  intro n
  induction n with
  | zero => intro p; cases p; simp [rmapFrom]
  | succ n ih =>
      intro p
      rw [List.replicate_succ, rmapFrom,
        show rphaseStep RB.Y = true from rfl,
        show rmapStep true p RB.Y = p.push by simp [rmapStep], ih]
      have h : (2 * p.f + 1 + 1) * 2 ^ n = (p.f + 1) * 2 ^ (n + 1) := by ring
      simp [SMap.push, h, Nat.add_assoc, Nat.add_comm 1 n]

theorem rmap_replicate_Y (n : ℕ) :
    rmap true (List.replicate n .Y) = (true, ⟨0, 0, n, 2 ^ n - 1⟩) := by
  rw [rmap, rmapFrom_replicate_Y]
  simp [SMap.one]

/--
**The simplest overflow–reset cycle, in closed form.**  A counter of `n` zero
bits that has just run out overflows, and the reset phase that follows rebuilds
it as the *full* counter `2 ^ n - 1`, ending in the pending digit `2>`.

This is the extreme case of `brun_overflow_reset_cycle`: the whole left counter
is re-encoded as `n` copies of the `22` block, and the reset reads every one of
them as a `1` bit.  It also shows `reset_value_bound` is sharp.
-/
theorem overflow_reset_of_zero_bits (n : ℕ) (rest : List RB) :
    ∃ (lt' : List LB) (k : ℕ),
      BRun (b4 := b4) ⟨List.replicate n .X ++ [.L], .Lt, rest⟩
          ⟨lt', .Rt, RB.P2 :: rest⟩ k ∧
        CStack lt' ∧ cval lt' = 2 ^ n - 1 := by
  have hofw : ofw (List.replicate n .X ++ [LB.L]) = List.replicate n .Y := ofw_replicate_X n
  have hr : rmap true (ofw (List.replicate n .X ++ [LB.L])) = (true, ⟨0, 0, n, 2 ^ n - 1⟩) := by
    rw [hofw, rmap_replicate_Y]
  obtain ⟨lt', k, hrun, hst, hv⟩ :=
    brun_overflow_reset_cycle (b4 := b4) (CStack_replicate_X n) (cval_replicate_X n)
      (by rw [hr]) rest
  rw [hr] at hrun hv
  exact ⟨lt', k, hrun, hst, hv⟩

/-! ## The counter phase at the level of blocks: the two sides share one pool

`Phase.lean` follows the *value* of the counter across a phase.  Here is the
same phase at the level of blocks, which is what the next overflow will need:
each block of the tape that the head swallows becomes exactly one block of the
left stack, so the total number of blocks does not change.  The two counters
are two halves of one pool of blocks, and a phase just moves blocks from one
half to the other.
-/

/-- Pushing one digit onto the counter stack: a bit is `01`, a shift is `03`. -/
def pushDigit (bit : Bool) (lt : List LB) : List LB := if bit then .Z :: lt else .W :: lt

@[simp] theorem pushDigit_length (bit : Bool) (lt : List LB) :
    (pushDigit bit lt).length = lt.length + 1 := by
  unfold pushDigit; split <;> simp

theorem pushDigit_CStack {lt : List LB} (h : CStack lt) (bit : Bool) :
    CStack (pushDigit bit lt) := by
  unfold pushDigit; split
  · exact h.consZ
  · exact h.consW

/-- One block of the counter phase, as an operation on the *stack*: the block
is turned into one counter digit, and the blocks `11`/`12` cost one decrement
first (`none` if the counter cannot pay, which is the overflow). -/
def cstackStep (lt : List LB) : RB → Option (List LB)
  | .Y => some (pushDigit true lt)
  | .V => some (pushDigit false lt)
  | .X => if cval lt = 0 then none else some (pushDigit false (cdec lt))
  | .U => if cval lt = 0 then none else some (pushDigit true (cdec lt))
  | _ => none

/-- The counter phase over a whole word, at the level of blocks. -/
def cstackRun (lt : List LB) : List RB → Option (List LB)
  | [] => some lt
  | b :: w => (cstackStep lt b).bind fun lt' => cstackRun lt' w

/-- **One block of the counter phase, on the stack.**  The machine really does
push the digit, and the stack grows by exactly one block. -/
theorem brun_cstackStep {lt lt' : List LB} (hst : CStack lt) {b : RB}
    (h : cstackStep lt b = some lt') (rest : List RB) :
    (∃ k, BRun (b4 := b4) ⟨lt, .Rt, b :: rest⟩ ⟨lt', .Rt, rest⟩ k) ∧ CStack lt' ∧
      lt'.length = lt.length + 1 := by
  cases b with
  | Y =>
      obtain rfl := Option.some.inj (show some (pushDigit true lt) = some lt' from h)
      refine ⟨⟨2, BRun.of_step (show bstep b4 ⟨lt, .Rt, .Y :: rest⟩
        = some (⟨.Z :: lt, .Rt, rest⟩, 2) from rfl)⟩, pushDigit_CStack hst true, by simp⟩
  | V =>
      obtain rfl := Option.some.inj (show some (pushDigit false lt) = some lt' from h)
      refine ⟨⟨2, BRun.of_step (show bstep b4 ⟨lt, .Rt, .V :: rest⟩
        = some (⟨.W :: lt, .Rt, rest⟩, 2) from rfl)⟩, pushDigit_CStack hst false, by simp⟩
  | X =>
      by_cases hv : cval lt = 0
      · exact absurd h (by simp [cstackStep, hv])
      · rw [show cstackStep lt RB.X = some (pushDigit false (cdec lt)) by
          simp [cstackStep, hv]] at h
        obtain rfl := Option.some.inj h
        obtain ⟨k, hrun⟩ := brun_cdec_of (b4 := b4) hst (by omega) (.V :: rest)
        refine ⟨⟨1 + (k + 2), ?_⟩, pushDigit_CStack (cdec_CStack hst (by omega)) false,
          by simp [cdec_length]⟩
        exact BRun.head (show bstep b4 ⟨lt, .Rt, .X :: rest⟩
            = some (⟨lt, .Lt, .V :: rest⟩, 1) from rfl)
          (hrun.trans (BRun.of_step (show bstep b4 ⟨cdec lt, .Rt, .V :: rest⟩
            = some (⟨.W :: cdec lt, .Rt, rest⟩, 2) from rfl)))
  | U =>
      by_cases hv : cval lt = 0
      · exact absurd h (by simp [cstackStep, hv])
      · rw [show cstackStep lt RB.U = some (pushDigit true (cdec lt)) by
          simp [cstackStep, hv]] at h
        obtain rfl := Option.some.inj h
        obtain ⟨k, hrun⟩ := brun_cdec_of (b4 := b4) hst (by omega) (.Y :: rest)
        refine ⟨⟨1 + (k + 2), ?_⟩, pushDigit_CStack (cdec_CStack hst (by omega)) true,
          by simp [cdec_length]⟩
        exact BRun.head (show bstep b4 ⟨lt, .Rt, .U :: rest⟩
            = some (⟨lt, .Lt, .Y :: rest⟩, 1) from rfl)
          (hrun.trans (BRun.of_step (show bstep b4 ⟨cdec lt, .Rt, .Y :: rest⟩
            = some (⟨.Z :: cdec lt, .Rt, rest⟩, 2) from rfl)))
  | _ => exact absurd h (by simp [cstackStep])

/--
**Block conservation across a counter phase.**  The head swallows the word `w`
and the left stack grows by exactly `w.length` blocks: no block is created or
destroyed, they only change sides.  The counter is one two-sided object, and a
phase is a transfer from its right half to its left half.
-/
theorem brun_cstackRun : ∀ (w : List RB) {lt lt' : List LB}, CStack lt →
    cstackRun lt w = some lt' → ∀ rest : List RB,
      (∃ k, BRun (b4 := b4) ⟨lt, .Rt, w ++ rest⟩ ⟨lt', .Rt, rest⟩ k) ∧ CStack lt' ∧
        lt'.length = lt.length + w.length := by
  intro w
  induction w with
  | nil =>
      intro lt lt' hst h rest
      obtain rfl := Option.some.inj h
      exact ⟨⟨0, by simpa using BRun.refl (b4 := b4) _⟩, hst, by simp⟩
  | cons b w ih =>
      intro lt lt' hst h rest
      rw [cstackRun, Option.bind_eq_some_iff] at h
      obtain ⟨lt₁, h1, h2⟩ := h
      obtain ⟨⟨k₁, hrun₁⟩, hst₁, hlen₁⟩ := brun_cstackStep (b4 := b4) hst h1 (w ++ rest)
      obtain ⟨⟨k₂, hrun₂⟩, hst₂, hlen₂⟩ := ih hst₁ h2 rest
      exact ⟨⟨k₁ + k₂, by simpa using hrun₁.trans hrun₂⟩, hst₂, by simp [hlen₂, hlen₁]; omega⟩

/-- The stack-level phase computes the same value as the arithmetic one. -/
theorem cstackStep_cval {lt lt' : List LB} (hst : CStack lt) {b : RB}
    (h : cstackStep lt b = some lt') :
    countStep b (cval lt) = some (cval lt') := by
  cases b with
  | Y => obtain rfl := Option.some.inj h; rfl
  | V => obtain rfl := Option.some.inj h; rfl
  | X =>
      by_cases hv : cval lt = 0
      · exact absurd h (by simp [cstackStep, hv])
      · rw [show cstackStep lt RB.X = some (pushDigit false (cdec lt)) by
          simp [cstackStep, hv]] at h
        obtain rfl := Option.some.inj h
        rw [show pushDigit false (cdec lt) = LB.W :: cdec lt from rfl,
          show countStep RB.X (cval lt) = some ((cval lt - 1) / 2) by simp [countStep, hv],
          cval_W, cdec_cval hst (by omega)]
  | U =>
      by_cases hv : cval lt = 0
      · exact absurd h (by simp [cstackStep, hv])
      · rw [show cstackStep lt RB.U = some (pushDigit true (cdec lt)) by
          simp [cstackStep, hv]] at h
        obtain rfl := Option.some.inj h
        rw [show pushDigit true (cdec lt) = LB.Z :: cdec lt from rfl,
          show countStep RB.U (cval lt) = some (2 * (cval lt - 1) + 1) by simp [countStep, hv],
          cval_Z, cdec_cval hst (by omega)]
  | _ => exact absurd h (by simp [cstackStep])

/-! ## The value-dependence of the reset -/

/--
**Where a "mod 2" would come from.**  At a shift block the overflow deposits
`11` or `21` according to whether the counter standing below it is exhausted.
When that counter is `0` or `1` — which is what a shift digit leaves after the
two decrements it costs — that test is exactly the low bit of its value: the
digit written on the tape is the parity of the counter below.  This is the only
place a residue of the counter enters the word the reset phase will read. -/
theorem ofw_W_low_bit {s : List LB} (h : cval s ≤ 1) :
    ofw (.W :: s) = if cval s % 2 = 0 then ofw s ++ [.X] else ofw (cdec s) ++ [.V] := by
  rw [ofw_W]
  interval_cases hv : cval s <;> simp

/--
**The word handed to the reset phase depends on the value of the counter, not
only on the shape of the stack.**  The two stacks below have the same length and
carry the same blocks; they differ in the value stored below the shift digit,
and they deposit different words on the tape, so the reset phase that follows
re-parses different digits and rebuilds a different counter.

This is where a dependence of the reset on the counter's residues would live:
the deposits differ because the borrow of `cdec` travels a different distance
through the low digits of the counter.
-/
theorem overflow_word_value_dependent :
    CStack [LB.W, LB.W, LB.X, LB.Z, LB.L] ∧ CStack [LB.W, LB.W, LB.Z, LB.X, LB.L] ∧
      cval [LB.W, LB.W, LB.X, LB.Z, LB.L] = 0 ∧ cval [LB.W, LB.W, LB.Z, LB.X, LB.L] = 0 ∧
      ofw [LB.W, LB.W, LB.X, LB.Z, LB.L] = [RB.Y, RB.Y, RB.X, RB.V] ∧
      ofw [LB.W, LB.W, LB.Z, LB.X, LB.L] = [RB.Y, RB.Y, RB.V, RB.X] ∧
      (rmap true (ofw [LB.W, LB.W, LB.X, LB.Z, LB.L])).2.f = 1 ∧
      (rmap true (ofw [LB.W, LB.W, LB.Z, LB.X, LB.L])).2.f = 3 :=
  ⟨CStack.base.consZ.consX.consW.consW, CStack.base.consX.consZ.consW.consW,
    rfl, rfl, rfl, rfl, rfl, rfl⟩

end BB25
