/-
# A well-formedness invariant, and what "getting stuck" can mean

`Reduction.lean` reduces non-halting of a member to the statement that its
block simulation never gets stuck, i.e. never reaches one of the finitely many
patterns on which `bstep` is undefined.  This file cuts that list down to the
two patterns that really matter, for the members whose `A> 241` rule bounces
the head back to the left without creating new left blocks:

```
  B4 = 2LB   A> 241 → <A 12 1>
  B4 = 1LB   A> 241 → <A 11 1>
  B4 = 3RA   A> 241 → <A 11 2>
  B4 = 2LA   A> 241 → <A 22 2>
  B4 = 0LA   A> 241 → <A 21 1>
```

For these five members the block alphabet stays inside

```
  left  :  03, 11, 01   over the left end  ^11
  right :  12, 21, 11, 22, 141, 241 and the pending digits 1>, 2>
```

(`BB25.WF`), and this is an inductive invariant (`BB25.Tame.wf_bstep`); the
number of `141`/`241` blocks is at most one at any time, and is zero whenever
the head is in state `<B1` (so the `<B1` sweep of `Sweep.lean` really is the
only source of an `F`).

Consequently a well-formed block configuration on which `bstep` is undefined is
either

* `A> 1>/2>` in front of a `141`/`241` block -- and then the machine **halts**
  (`BB25.Danger`), or
* the head at the left end in state `<B1` -- and then the machine **never
  halts** (left spinout).

This gives the sharp criterion `BB25.not_halts_of_no_danger`: such a member
fails to halt as soon as its block simulation never produces a pending digit in
front of a `141`/`241` block.
-/
import RequestProject.BB25.Sweep

namespace BB25

variable {b4 : Option (Sym × Dir × St)}

/-! ## The well-formed block alphabet -/

/-- Left blocks other than the left end marker. -/
def okL : LB → Bool
  | .W | .X | .Z => true
  | _ => false

/-- Right blocks the head can cross or bounce off. -/
def okR : RB → Bool
  | .U | .V | .X | .Y | .P1 | .P2 => true
  | _ => false

/-- The two dangerous right blocks `141`, `241`. -/
def isFG : RB → Bool
  | .F | .G => true
  | _ => false

/-- The right end of the tape: `$`, `1$`, `2$`. -/
def isEnd : RB → Bool
  | .R | .R1 | .R2 => true
  | _ => false

/-- A well-formed left stack: `03`/`11`/`01` blocks resting on the left end. -/
def wfL : List LB → Bool
  | [] => false
  | [b] => b == .L
  | b :: bs => okL b && wfL bs

/-- A well-formed right stack. -/
def wfR : List RB → Bool
  | [] => true
  | [b] => okR b || isFG b || isEnd b
  | b :: bs => (okR b || isFG b) && wfR bs

/-- The number of `141`/`241` blocks. -/
def nFG : List RB → ℕ
  | [] => 0
  | b :: bs => (if isFG b then 1 else 0) + nFG bs

theorem wfL_cons_eq (b : LB) (bs : List LB) :
    wfL (b :: bs) = ((bs.isEmpty && (b == .L)) || (okL b && wfL bs)) := by
  cases bs <;> simp [wfL]

theorem wfR_cons_eq (b : RB) (bs : List RB) :
    wfR (b :: bs) = (((okR b || isFG b) && wfR bs) || (bs.isEmpty && isEnd b)) := by
  cases bs <;> simp [wfR]

@[simp] theorem nFG_cons (b : RB) (bs : List RB) :
    nFG (b :: bs) = (if isFG b then 1 else 0) + nFG bs := rfl

/-- **Well-formed block configurations.**  The left stack is a stack of
`03`/`11`/`01` blocks on the left end marker, the right stack uses only the
blocks of the shared longitudinal table, at most one `141`/`241` block is
present, and there is none while the head is in state `<B1`. -/
structure WF (c : BCfg) : Prop where
  left : wfL c.lt
  right : wfR c.rt
  fg : nFG c.rt ≤ 1
  bt : c.st = .Bt → nFG c.rt = 0

theorem wf_binit : WF binit :=
  ⟨rfl, rfl, by decide, by decide⟩

/-! ## The members for which the invariant works -/

/-- A member is *tame* when its `A> 241` rule is defined and preserves the
well-formed alphabet.  The five members `2LB`, `1LB`, `3RA`, `2LA`, `0LA`
are tame. -/
structure Tame (b4 : Option (Sym × Dir × St)) : Prop where
  gsome : ∀ (lt : List LB) (rest : List RB), (gStep b4 lt rest).isSome
  gwf : ∀ (lt : List LB) (rest : List RB) (c' : BCfg) (k : ℕ),
    gStep b4 lt rest = some (c', k) → WF ⟨lt, .Rt, .G :: rest⟩ → WF c'

theorem wfR_tail : ∀ {b : RB} {bs : List RB}, wfR (b :: bs) → wfR bs
  | _, [], _ => rfl
  | b, c :: cs, h => by
      rw [wfR_cons_eq] at h
      simpa using (by simpa using h : (okR b || isFG b) = true ∧ wfR (c :: cs) = true).2

theorem wfR_cons {b : RB} {bs : List RB} (hb : okR b || isFG b) (h : wfR bs) :
    wfR (b :: bs) := by
  rw [wfR_cons_eq, hb, h]
  simp

theorem Tame.bstep_G (ht : Tame b4) (lt : List LB) (rest : List RB) :
    bstep b4 ⟨lt, .Rt, .G :: rest⟩ ≠ none := by
  have hs := ht.gsome lt rest
  intro hh
  rw [show bstep b4 ⟨lt, .Rt, .G :: rest⟩ = gStep b4 lt rest from rfl] at hh
  rw [hh] at hs
  simp at hs

theorem nFG_append : ∀ (l r : List RB), nFG (l ++ r) = nFG l + nFG r
  | [], r => by simp [nFG]
  | b :: l, r => by simp [nFG_append l r]; omega

theorem wfR_append_okR : ∀ (l : List RB), (∀ b ∈ l, okR b) → ∀ {rest : List RB},
    wfR rest → wfR (l ++ rest)
  | [], _, _, h => h
  | b :: l, hb, rest, h =>
      wfR_cons (by simp [hb b (by simp)]) (wfR_append_okR l (fun x hx => hb x (by simp [hx])) h)

/-- The generic step for a tame `A> 241` rule: the head bounces back to the
left, the `241` block is replaced by blocks of the shared alphabet, and no new
left block is created. -/
theorem wf_of_G {lt : List LB} {rest : List RB} (hw : WF ⟨lt, .Rt, .G :: rest⟩)
    (pre : List RB) (hpre : ∀ b ∈ pre, okR b) {st : HSt} (hst : st ≠ .Bt) :
    WF ⟨lt, st, pre ++ rest⟩ := by
  have hrest : wfR rest := wfR_tail hw.right
  have hn : nFG rest = 0 := by
    have := hw.fg
    simp [nFG, isFG] at this
    omega
  have hpre0 : nFG pre = 0 := by
    induction pre with
    | nil => rfl
    | cons b l ih =>
        have hb : okR b := hpre b (by simp)
        have : isFG b = false := by cases b <;> simp [okR] at hb <;> rfl
        simp [nFG, this, ih (fun x hx => hpre x (by simp [hx]))]
  refine ⟨hw.left, wfR_append_okR pre hpre hrest, ?_, fun h => absurd h hst⟩
  simp [nFG_append, hpre0, hn]

/-! ## The invariant is inductive -/

/-- **The well-formed alphabet is an inductive invariant** for a tame member. -/
theorem Tame.wf_bstep (ht : Tame b4) {c c' : BCfg} {k : ℕ} (hw : WF c)
    (h : bstep b4 c = some (c', k)) : WF c' := by
  obtain ⟨hl, hr, hf, hb⟩ := hw
  unfold bstep at h
  split at h <;>
    first
      | exact ht.gwf _ _ _ _ h ⟨hl, hr, hf, hb⟩
      | (rw [Option.some.injEq, Prod.mk.injEq] at h
         obtain ⟨rfl, rfl⟩ := h
         simp only [] at hl hr hf hb ⊢
         refine ⟨?_, ?_, ?_, ?_⟩ <;>
           simp_all [nFG, wfL_cons_eq, wfR_cons_eq, okL, okR, isFG, isEnd])
      | simp at h

/-! ## The five tame members -/

theorem tame_2LB : Tame b4_2LB := by
  refine ⟨fun lt rest => rfl, fun lt rest c' k h hw => ?_⟩
  rw [show gStep b4_2LB lt rest = some (⟨lt, .Lt, .U :: .P1 :: rest⟩, 3) from rfl] at h
  obtain ⟨rfl, -⟩ := Prod.mk.injEq .. ▸ Option.some.injEq .. ▸ h
  exact wf_of_G hw [.U, .P1] (by intro b hb; fin_cases hb <;> rfl) (by simp)

theorem tame_1LB : Tame b4_1LB := by
  refine ⟨fun lt rest => rfl, fun lt rest c' k h hw => ?_⟩
  rw [show gStep b4_1LB lt rest = some (⟨lt, .Lt, .X :: .P1 :: rest⟩, 3) from rfl] at h
  obtain ⟨rfl, -⟩ := Prod.mk.injEq .. ▸ Option.some.injEq .. ▸ h
  exact wf_of_G hw [.X, .P1] (by intro b hb; fin_cases hb <;> rfl) (by simp)

theorem tame_3RA : Tame b4_3RA := by
  refine ⟨fun lt rest => rfl, fun lt rest c' k h hw => ?_⟩
  rw [show gStep b4_3RA lt rest = some (⟨lt, .Lt, .X :: .P2 :: rest⟩, 5) from rfl] at h
  obtain ⟨rfl, -⟩ := Prod.mk.injEq .. ▸ Option.some.injEq .. ▸ h
  exact wf_of_G hw [.X, .P2] (by intro b hb; fin_cases hb <;> rfl) (by simp)

theorem tame_2LA : Tame b4_2LA := by
  refine ⟨fun lt rest => rfl, fun lt rest c' k h hw => ?_⟩
  rw [show gStep b4_2LA lt rest = some (⟨lt, .Lt, .Y :: .P2 :: rest⟩, 7) from rfl] at h
  obtain ⟨rfl, -⟩ := Prod.mk.injEq .. ▸ Option.some.injEq .. ▸ h
  exact wf_of_G hw [.Y, .P2] (by intro b hb; fin_cases hb <;> rfl) (by simp)

theorem tame_0LA : Tame b4_0LA := by
  refine ⟨fun lt rest => rfl, fun lt rest c' k h hw => ?_⟩
  rw [show gStep b4_0LA lt rest = some (⟨lt, .Lt, .V :: .P1 :: rest⟩, 5) from rfl] at h
  obtain ⟨rfl, -⟩ := Prod.mk.injEq .. ▸ Option.some.injEq .. ▸ h
  exact wf_of_G hw [.V, .P1] (by intro b hb; fin_cases hb <;> rfl) (by simp)

/-! ## What a well-formed stuck configuration looks like -/

/-- The dangerous pattern: a pending `2>` in front of a `141`/`241` block. -/
def Danger (c : BCfg) : Prop :=
  c.st = .Rt ∧ ∃ f rest, (f = RB.F ∨ f = RB.G) ∧ c.rt = .P2 :: f :: rest

/-- A dangerous configuration halts (in three base steps). -/
theorem halts_of_danger {c : BCfg} (hd : Danger c) : Halts (M b4) c.den := by
  obtain ⟨lt, st, rt⟩ := c
  obtain ⟨rfl, f, rest, hf, rfl⟩ := hd
  rcases hf with rfl | rfl
  · exact ⟨3, bhalt_P2_F b4 lt rest⟩
  · exact ⟨3, bhalt_P2_G b4 lt rest⟩

/-- **Classification of the well-formed stuck configurations.**  A well-formed
block configuration on which the block simulation of a tame member gets stuck
is either a dangerous one, or the head at the left end in state `<B1`. -/
theorem wf_stuck (ht : Tame b4) {c : BCfg} (hw : WF c) (h : bstep b4 c = none) :
    Danger c ∨ (c.st = .Bt ∧ c.lt = [.L]) := by
  obtain ⟨lt, st, rt⟩ := c
  obtain ⟨hl, hr, -, -⟩ := hw
  simp only [] at hl hr ⊢
  cases st
  case Rt =>
      rcases rt with _ | ⟨b, rt2⟩
      · exfalso; revert h; simp [bstep]
      rcases rt2 with _ | ⟨b2, rt3⟩
      · cases b <;>
          first
            | (exfalso; revert h; simp [bstep]; done)
            | exact absurd h (ht.bstep_G lt _)
      · cases b <;> cases b2 <;>
          first
            | (exfalso; revert h; simp [bstep]; done)
            | exact absurd h (ht.bstep_G lt _)
            | (exfalso; revert hr; simp [wfR_cons_eq, okR, isFG, isEnd]; done)
            | exact Or.inl ⟨rfl, _, _, Or.inl rfl, rfl⟩
            | exact Or.inl ⟨rfl, _, _, Or.inr rfl, rfl⟩
  case Lt =>
      rcases lt with _ | ⟨b, lt2⟩
      · exfalso; revert hl; simp [wfL]
      rcases lt2 with _ | ⟨b2, lt3⟩
      · cases b <;> (exfalso; revert h; simp [bstep])
      · cases b <;>
          first
            | (exfalso; revert h; simp [bstep]; done)
            | (exfalso; revert hl; simp [wfL_cons_eq, okL])
  case Bt =>
      rcases lt with _ | ⟨b, lt2⟩
      · exfalso; revert hl; simp [wfL]
      rcases lt2 with _ | ⟨b2, lt3⟩
      · cases b <;>
          first
            | (exfalso; revert h; simp [bstep]; done)
            | exact Or.inr ⟨rfl, rfl⟩
            | (exfalso; revert hl; simp [wfL_cons_eq, okL])
      · cases b <;>
          first
            | (exfalso; revert h; simp [bstep]; done)
            | (exfalso; revert hl; simp [wfL_cons_eq, okL])

/-! ## The resulting halting criterion -/

/-- The invariant holds all along a block run. -/
theorem Tame.wf_bsteps (ht : Tame b4) : ∀ (n : ℕ) {c c' : BCfg} {k : ℕ},
    WF c → bsteps b4 n c = some (c', k) → WF c' := by
  intro n
  induction n with
  | zero =>
      intro c c' k hw h
      simp only [bsteps, Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, -⟩ := h
      exact hw
  | succ n ih =>
      intro c c' k hw h
      rw [bsteps, Option.bind_eq_some_iff] at h
      obtain ⟨⟨c₁, k₁⟩, hb, h⟩ := h
      rw [Option.map_eq_some_iff] at h
      obtain ⟨⟨c₂, k₂⟩, hr, he⟩ := h
      simp only [Prod.mk.injEq] at he
      obtain ⟨rfl, -⟩ := he
      exact ih (ht.wf_bstep hw hb) hr

/-- If a block run gets stuck, it passes through a configuration on which one
block step is undefined. -/
theorem stuck_witness : ∀ (n : ℕ) (c : BCfg), bsteps b4 n c = none →
    ∃ (m : ℕ) (c' : BCfg) (k : ℕ), bsteps b4 m c = some (c', k) ∧ bstep b4 c' = none := by
  intro n
  induction n with
  | zero => intro c h; simp [bsteps] at h
  | succ n ih =>
      intro c h
      cases hb : bstep b4 c with
      | none => exact ⟨0, c, 0, rfl, hb⟩
      | some p =>
          obtain ⟨c₁, k₁⟩ := p
          rw [bsteps, hb] at h
          simp only [Option.bind_some, Option.map_eq_none_iff] at h
          obtain ⟨m, c', k, hrun, hstuck⟩ := ih c₁ h
          refine ⟨1 + m, c', k₁ + k, ?_, hstuck⟩
          have h1 : bsteps b4 1 c = some (c₁, k₁) := by rw [bsteps, hb]; simp [bsteps]
          exact bsteps_comp h1 hrun

/--
**Halting criterion for the tame members.**  A tame member (`2LB`, `1LB`,
`3RA`, `2LA`, `0LA`) never halts as soon as its block simulation never reaches
a configuration with a pending `2>` in front of a `141`/`241` block.

This is sharper than `BB25.not_halts_of_neverStuck`: the block simulation is
allowed to get stuck, provided it gets stuck at the left end in state `<B1`
(where the machine spins out).
-/
theorem not_halts_of_no_danger (ht : Tame b4)
    (hnd : ∀ (n : ℕ) (c : BCfg) (k : ℕ), bsteps b4 n binit = some (c, k) → ¬ Danger c) :
    ¬ Halts (M b4) init := by
  by_cases hns : NeverStuck b4 binit
  · exact not_halts_of_neverStuck hns
  · rw [NeverStuck] at hns
    push_neg at hns
    obtain ⟨n, hn⟩ := hns
    have hnone : bsteps b4 n binit = none := by
      cases hb : bsteps b4 n binit with
      | none => rfl
      | some p => rw [hb] at hn; simp at hn
    obtain ⟨m, c', k, hrun, hstuck⟩ := stuck_witness n binit hnone
    have hwf : WF c' := ht.wf_bsteps m wf_binit hrun
    rcases wf_stuck ht hwf hstuck with hd | ⟨hst, hlt⟩
    · exact absurd hd (hnd m c' k hrun)
    · intro hh
      have h5 : steps (M b4) 5 init = some binit.den := init_five b4
      have hreach := steps_trans h5 (bsteps_sound b4 m binit c' k hrun)
      have : Halts (M b4) c'.den := hh.of_run hreach
      refine not_halts_Bt_L (b4 := b4) c'.rt ?_
      obtain ⟨lt, st, rt⟩ := c'
      simp only [] at hst hlt
      subst hst; subst hlt
      exact this

/-! ## The danger is real

The criterion `halts_Bt_of_no_Z_below_W` of `Sweep.lean` -- an `F` created
above nothing but `11` blocks is fatal -- is not the only fatal pattern: the
left stack `03 01 ^11` below the `03` that creates the `F` kills the machine
too, after a short excursion.  So no criterion phrased only in terms of the
block alphabet can decide the family: which counter states are reachable is
what matters.  (All the steps below are shared by the 13 members.) -/

/-- From `03 01 ^11 <A 141` the head comes back as `A> 2> 141` in 20 base
steps -- a dangerous configuration. -/
theorem brun_WZL_F (rt : List RB) :
    BRun b4 ⟨[.W, .Z, .L], .Lt, .F :: rt⟩ ⟨[.X, .Z, .L], .Rt, .P2 :: .F :: rt⟩ 20 :=
  ⟨11, rfl⟩

/-- `03 01 ^11 <A 141` halts. -/
theorem halts_WZL_F (rt : List RB) :
    Halts (M b4) (BCfg.den ⟨[.W, .Z, .L], .Lt, .F :: rt⟩) :=
  (brun_WZL_F rt).halts (halts_of_danger ⟨rfl, _, _, Or.inl rfl, rfl⟩)

/-- A `<B1` sweep started above the left stack `11^n 03 03 01 ^11` kills the
machine, although that stack does contain a `01` block. -/
theorem halts_Bt_WWZL (n : ℕ) (rt : List RB) :
    Halts (M b4) (BCfg.den ⟨List.replicate n .X ++ .W :: [.W, .Z, .L], .Bt, rt⟩) :=
  (brun_Bt_W n [.W, .Z, .L] rt).halts (halts_WZL_F _)

end BB25
