/-
# Phases in closed form: the right-hand counter, and the exact overflow threshold

`Counter.lean` gives the *left* counter: the stack of blocks `11`/`01`/`03`
below the head carries a number `cval`, one head excursion decrements it, and
when it is `0` the head runs off the bottom (the *overflow*).  What the left
counter does **not** contain is the other half of the machine: the blocks to
the right of the head.  Those are the second counter of the "double counter"
picture, and this file gives them a value of their own and proves the law that
joins the two sides.

## The right-hand counter

A block to the right of the head is one of `11`, `12`, `21`, `22`, and each of
them is a *digit* — but which digit depends on the *phase*, i.e. on the parsing
offset carried by the pending digit `1>`/`2>`:

| block | counter phase (`countStep`) | reset phase (`resetStep`) |
|---|---|---|
| `22` (`Y`) | bit `1` | bit `1`, stay in `2>` |
| `21` (`V`) | *shift* | bit `1`, switch to `1>` |
| `11` (`X`) | *shift*, and a turn | *shift*, switch to `1>` |
| `12` (`U`) | bit `1`, and a turn | *shift*, stay in `2>` |

(`digit_roles_swap`).  So the two sides really do use different digit
representations, and the right-hand side uses two different ones itself, one
per phase; the roles of `21` and `12` are exchanged when the phase changes.
"A turn" means the head first walks into the left stack and back, which costs
one decrement of the left counter — in phase `1>` *every* block costs such a
decrement.

## The value of a right-hand word: a shift map

Reading a whole word `w` of right-hand blocks therefore acts on the left
counter `v` by a composition of the three primitive operations

```
   push :  v ↦ 2v+1        pop :  v ↦ v/2        dec :  v ↦ v-1  (or overflow)
```

The main theorem of this file is that **every such composition is a single
"shift map"**

```
   v  ↦  ((v - c) / 2 ^ d) * 2 ^ e + f ,        defined exactly for v ≥ c,
```

with four natural-number parameters computed from `w` by a fold
(`SMap`, `cmap`, `rmap`).  The parameters have a direct counter meaning:

* `d` — how many digits of the left counter the word consumes (net shifts);
* `e` — how many digits the word appends (net bits);
* `f` — the `e`-digit numeral the word appends: **this is the value of the
  right-hand counter**, and `f < 2 ^ e` always (`WF`);
* `c` — the exact *overflow threshold*: the phase runs to the end of `w` if and
  only if the left counter starts at `v ≥ c`, and overflows otherwise.

In particular, if the word has no net shift (`d = 0`) the law is the plain
concatenation of the two counters, `v ↦ (v - c) * 2 ^ e + f`
(`SMap.apply_of_d_zero`): the right-hand numeral `f` is appended to the left
counter.  In general the word first deletes `d` digits.  And `e - d` is exactly
`#bits - #shifts` of the word (`cmap_digit_count`), so a phase multiplies the
counter by `2 ^ (e-d)` up to the bounded correction of `apply_bounds` — this is
the growth measured empirically in `ANALYSIS.md` §14.

## Overflows and resets

Because `c` is an exact threshold, each phase is a clean dichotomy
(`brun_count_dichotomy`, `brun_reset_dichotomy`):

* `cval ≥ c`: the head crosses the whole word and the counter ends at
  `((cval - c) / 2 ^ d) * 2 ^ e + f`;
* `cval < c`: the head overflows — it reaches the left end `^11`, where the
  pending digit of the next reset phase is created.

Neither case can get stuck, so a run really is an alternation of counter phases
and reset phases separated by overflows.
-/
import RequestProject.BB25.Counter

namespace BB25

variable {b4 : Option (Sym × Dir × St)}

/-! ## Shift maps -/

/-- A *shift map* `v ↦ ((v - c) / 2 ^ d) * 2 ^ e + f`, defined for `v ≥ c`.
It is the closed form of the action of a word of right-hand blocks on the left
counter: `d` digits of the counter are deleted, the `e`-digit numeral `f` is
appended, and `c` is the value below which the counter overflows first. -/
structure SMap where
  /-- the overflow threshold -/
  c : ℕ
  /-- the number of counter digits the word deletes -/
  d : ℕ
  /-- the number of digits the word appends -/
  e : ℕ
  /-- the numeral the word appends (the value of the right-hand counter) -/
  f : ℕ
deriving DecidableEq, Repr

namespace SMap

/-- The map itself.  Meaningful for `p.c ≤ v`. -/
def apply (p : SMap) (v : ℕ) : ℕ := ((v - p.c) / 2 ^ p.d) * 2 ^ p.e + p.f

/-- The identity shift map (the empty word). -/
def one : SMap := ⟨0, 0, 0, 0⟩

/-- Appending the bit `1`: `v ↦ 2v + 1`. -/
def push (p : SMap) : SMap := ⟨p.c, p.d, p.e + 1, 2 * p.f + 1⟩

/-- A shift: `v ↦ v / 2`. -/
def pop (p : SMap) : SMap :=
  if p.e = 0 then ⟨p.c, p.d + 1, 0, 0⟩ else ⟨p.c, p.d, p.e - 1, p.f / 2⟩

/-- A decrement (one head excursion): `v ↦ v - 1`, raising the threshold when
the appended numeral is exhausted. -/
def dec (p : SMap) : SMap :=
  if p.f = 0 then ⟨p.c + 2 ^ p.d, p.d, p.e, 2 ^ p.e - 1⟩ else ⟨p.c, p.d, p.e, p.f - 1⟩

/-- Well-formedness: the appended numeral really has `e` digits. -/
def WF (p : SMap) : Prop := p.f < 2 ^ p.e

theorem WF_one : WF one := by simp [WF, one]

@[simp] theorem one_apply (v : ℕ) : one.apply v = v := by simp [apply, one]

@[simp] theorem one_c : one.c = 0 := rfl

@[simp] theorem push_c (p : SMap) : p.push.c = p.c := rfl

@[simp] theorem pop_c (p : SMap) : p.pop.c = p.c := by unfold pop; split <;> rfl

theorem apply_push (p : SMap) (v : ℕ) : p.push.apply v = 2 * p.apply v + 1 := by
  show ((v - p.c) / 2 ^ p.d) * 2 ^ (p.e + 1) + (2 * p.f + 1)
    = 2 * (((v - p.c) / 2 ^ p.d) * 2 ^ p.e + p.f) + 1
  rw [pow_succ]; ring

theorem apply_pop (p : SMap) (hp : WF p) (v : ℕ) : p.pop.apply v = p.apply v / 2 := by
  unfold pop
  by_cases he : p.e = 0
  · have hf : p.f = 0 := by have := hp; rw [WF, he] at this; simpa using this
    simp [apply, he, hf, pow_succ, Nat.div_div_eq_div_mul]
  · have hpow : (2 : ℕ) ^ p.e = 2 ^ (p.e - 1) * 2 := by rw [← pow_succ]; congr 1; omega
    rw [if_neg he]
    show ((v - p.c) / 2 ^ p.d) * 2 ^ (p.e - 1) + p.f / 2
      = (((v - p.c) / 2 ^ p.d) * 2 ^ p.e + p.f) / 2
    rw [hpow, show (v - p.c) / 2 ^ p.d * (2 ^ (p.e - 1) * 2) + p.f
          = p.f + ((v - p.c) / 2 ^ p.d * 2 ^ (p.e - 1)) * 2 by ring,
        Nat.add_mul_div_right _ _ (by norm_num : 0 < 2)]
    omega

theorem WF_push (p : SMap) (hp : WF p) : WF p.push := by
  have h := hp; rw [WF] at h
  show 2 * p.f + 1 < 2 ^ (p.e + 1)
  rw [pow_succ]; omega

theorem WF_pop (p : SMap) (hp : WF p) : WF p.pop := by
  unfold pop
  by_cases he : p.e = 0
  · rw [if_pos he]; show (0 : ℕ) < 2 ^ 0; norm_num
  · have hpow : (2 : ℕ) ^ p.e = 2 ^ (p.e - 1) * 2 := by rw [← pow_succ]; congr 1; omega
    rw [if_neg he]
    have h2 := hp; rw [WF, hpow] at h2
    show p.f / 2 < 2 ^ (p.e - 1)
    omega

theorem WF_dec (p : SMap) (hp : WF p) : WF p.dec := by
  unfold dec
  by_cases hf : p.f = 0
  · rw [if_pos hf]
    have : 0 < 2 ^ p.e := Nat.two_pow_pos _
    show 2 ^ p.e - 1 < 2 ^ p.e
    omega
  · rw [if_neg hf]; have := hp; rw [WF] at this; show p.f - 1 < 2 ^ p.e; omega

theorem dec_c_le (p : SMap) : p.c ≤ p.dec.c := by
  unfold dec; by_cases hf : p.f = 0 <;> simp [hf]

@[simp] theorem dec_d (p : SMap) : p.dec.d = p.d := by unfold dec; split <;> rfl

@[simp] theorem dec_e (p : SMap) : p.dec.e = p.e := by unfold dec; split <;> rfl

/-- A shift digit: the balance `e - d` drops by one. -/
theorem pop_digit (p : SMap) : p.pop.e + p.d + 1 = p.pop.d + p.e := by
  unfold pop
  by_cases he : p.e = 0
  · rw [if_pos he]; simp [he]
  · rw [if_neg he]; show p.e - 1 + p.d + 1 = p.d + p.e; omega

@[simp] theorem push_e (p : SMap) : p.push.e = p.e + 1 := rfl

theorem pop_e_le (p : SMap) : p.pop.e ≤ p.e := by
  unfold pop; split
  · show (0 : ℕ) ≤ p.e; omega
  · show p.e - 1 ≤ p.e; omega

/-- A bit digit: the balance `e - d` rises by one. -/
theorem push_digit (p : SMap) : p.push.e + p.d = p.push.d + p.e + 1 := by
  show p.e + 1 + p.d = p.d + p.e + 1; omega

/-- **A decrement above the threshold really decrements.** -/
theorem apply_dec (p : SMap) {v : ℕ} (h : p.dec.c ≤ v) :
    1 ≤ p.apply v ∧ p.dec.apply v = p.apply v - 1 := by
  unfold dec at h ⊢
  by_cases hf : p.f = 0
  · simp only [if_pos hf] at h ⊢
    have hpos : 0 < 2 ^ p.d := Nat.two_pow_pos _
    have hA : 1 ≤ (v - p.c) / 2 ^ p.d := by rw [Nat.le_div_iff_mul_le hpos]; omega
    have hsub : (v - (p.c + 2 ^ p.d)) / 2 ^ p.d = (v - p.c) / 2 ^ p.d - 1 := by
      have h2 : (v - p.c) / 2 ^ p.d = (v - p.c - 2 ^ p.d) / 2 ^ p.d + 1 :=
        Nat.div_eq_sub_div hpos (show 2 ^ p.d ≤ v - p.c by omega)
      rw [show v - (p.c + 2 ^ p.d) = v - p.c - 2 ^ p.d from by omega, h2]; simp
    have hpe : 0 < 2 ^ p.e := Nat.two_pow_pos _
    have hmul : 2 ^ p.e ≤ (v - p.c) / 2 ^ p.d * 2 ^ p.e := Nat.le_mul_of_pos_left _ (by omega)
    refine ⟨by show 1 ≤ (v - p.c) / 2 ^ p.d * 2 ^ p.e + p.f; omega, ?_⟩
    show ((v - (p.c + 2 ^ p.d)) / 2 ^ p.d) * 2 ^ p.e + (2 ^ p.e - 1)
      = (v - p.c) / 2 ^ p.d * 2 ^ p.e + p.f - 1
    rw [hsub, Nat.sub_mul, one_mul]
    omega
  · simp only [if_neg hf] at h ⊢
    have hf1 : 1 ≤ p.f := by omega
    exact ⟨by show 1 ≤ (v - p.c) / 2 ^ p.d * 2 ^ p.e + p.f; omega, by
      show (v - p.c) / 2 ^ p.d * 2 ^ p.e + (p.f - 1) = (v - p.c) / 2 ^ p.d * 2 ^ p.e + p.f - 1
      omega⟩

/-- **Below the threshold the counter is already exhausted**, so the decrement
overflows instead. -/
theorem apply_eq_zero_of_lt_dec_c (p : SMap) {v : ℕ} (hc : p.c ≤ v) (h : v < p.dec.c) :
    p.apply v = 0 := by
  unfold dec at h
  by_cases hf : p.f = 0
  · simp only [if_pos hf] at h
    have h0 : (v - p.c) / 2 ^ p.d = 0 := Nat.div_eq_of_lt (by omega)
    show (v - p.c) / 2 ^ p.d * 2 ^ p.e + p.f = 0
    simp [h0, hf]
  · simp only [if_neg hf] at h; omega

/-- **The two-sided law without shifts.**  A word that deletes no digit of the
left counter simply *appends* its own numeral: the two counters concatenate. -/
theorem apply_of_d_zero (p : SMap) (h : p.d = 0) (v : ℕ) :
    p.apply v = (v - p.c) * 2 ^ p.e + p.f := by
  show ((v - p.c) / 2 ^ p.d) * 2 ^ p.e + p.f = _
  rw [h]; simp

/-- **The growth of the counter across a phase**, sharply: up to the appended
numeral `f` and one unit of rounding, the counter is multiplied by `2 ^ e / 2 ^ d`. -/
theorem apply_bounds (p : SMap) (v : ℕ) :
    2 ^ p.d * (p.apply v - p.f) ≤ 2 ^ p.e * (v - p.c) ∧
      2 ^ p.e * (v - p.c) < 2 ^ p.d * (p.apply v - p.f + 2 ^ p.e) := by
  have hpos : 0 < 2 ^ p.d := Nat.two_pow_pos _
  set A := (v - p.c) / 2 ^ p.d with hA
  have hdm : 2 ^ p.d * A + (v - p.c) % 2 ^ p.d = v - p.c := Nat.div_add_mod _ _
  have hmod : (v - p.c) % 2 ^ p.d < 2 ^ p.d := Nat.mod_lt _ hpos
  have h1 : 2 ^ p.d * A ≤ v - p.c := by omega
  have h2 : v - p.c < 2 ^ p.d * (A + 1) := by
    have : 2 ^ p.d * (A + 1) = 2 ^ p.d * A + 2 ^ p.d := by ring
    omega
  have hv : p.apply v - p.f = A * 2 ^ p.e := by
    show (A * 2 ^ p.e + p.f) - p.f = A * 2 ^ p.e
    omega
  rw [hv]
  constructor
  · calc 2 ^ p.d * (A * 2 ^ p.e) = 2 ^ p.e * (2 ^ p.d * A) := by ring
      _ ≤ 2 ^ p.e * (v - p.c) := Nat.mul_le_mul_left _ h1
  · have key : 2 ^ p.e * (v - p.c) < 2 ^ p.e * (2 ^ p.d * (A + 1)) :=
      Nat.mul_lt_mul_of_pos_left h2 (Nat.two_pow_pos _)
    have heq : 2 ^ p.e * (2 ^ p.d * (A + 1)) = 2 ^ p.d * (A * 2 ^ p.e + 2 ^ p.e) := by ring
    omega

end SMap

/-! ## The digits of the right-hand counter -/

/-- A word of right-hand *digit* blocks: `11`, `12`, `21`, `22`. -/
def CWord (w : List RB) : Prop :=
  ∀ b ∈ w, b = RB.X ∨ b = RB.U ∨ b = RB.V ∨ b = RB.Y

theorem CWord.nil : CWord [] := by simp [CWord]

theorem CWord.of_cons {b : RB} {w : List RB} (h : CWord (b :: w)) : CWord w :=
  fun x hx => h x (List.mem_cons_of_mem _ hx)

theorem CWord.head {b : RB} {w : List RB} (h : CWord (b :: w)) :
    b = RB.X ∨ b = RB.U ∨ b = RB.V ∨ b = RB.Y :=
  h b (List.mem_cons_self ..)

/--
**The same block is a different digit in the two phases.**  In the counter
phase `21` is a shift and `12` a bit; in the reset phase it is the other way
round.  This is the parsing offset — the pending digit — at work, and it is the
reason the left and the right counter of this family are written in different
digit representations.
-/
theorem digit_roles_swap (v : ℕ) :
    (countStep .Y v = some (2 * v + 1) ∧ resetStep true .Y v = some (true, 2 * v + 1)) ∧
    (countStep .V v = some (v / 2) ∧ resetStep true .V v = some (false, 2 * v + 1)) ∧
    (countStep .U v = (if v = 0 then none else some (2 * (v - 1) + 1)) ∧
      resetStep true .U v = some (true, v / 2)) ∧
    (countStep .X v = (if v = 0 then none else some ((v - 1) / 2)) ∧
      resetStep true .X v = some (false, v / 2)) :=
  ⟨⟨rfl, rfl⟩, ⟨rfl, rfl⟩, ⟨rfl, rfl⟩, ⟨rfl, rfl⟩⟩

/-! ## The counter phase in closed form -/

/-- The shift map of one block of the counter phase. -/
def cmapStep (p : SMap) : RB → SMap
  | .Y => p.push
  | .V => p.pop
  | .X => p.dec.pop
  | .U => p.dec.push
  | _ => p

/-- The shift map of a word of the counter phase, starting from `p`. -/
def cmapFrom (p : SMap) : List RB → SMap
  | [] => p
  | b :: w => cmapFrom (cmapStep p b) w

/-- **The value of a right-hand word in the counter phase**: the shift map it
applies to the left counter. -/
def cmap (w : List RB) : SMap := cmapFrom SMap.one w

theorem cmapStep_WF {p : SMap} (hp : SMap.WF p) (b : RB) : SMap.WF (cmapStep p b) := by
  cases b <;>
    simp only [cmapStep] <;>
    first
      | exact hp
      | exact SMap.WF_push _ hp
      | exact SMap.WF_pop _ hp
      | exact SMap.WF_push _ (SMap.WF_dec _ hp)
      | exact SMap.WF_pop _ (SMap.WF_dec _ hp)

theorem cmapStep_c_le (p : SMap) (b : RB) : p.c ≤ (cmapStep p b).c := by
  cases b <;> simp only [cmapStep, SMap.push_c, SMap.pop_c] <;>
    first
      | exact le_refl _
      | exact SMap.dec_c_le p

theorem cmapFrom_WF {p : SMap} (hp : SMap.WF p) (w : List RB) : SMap.WF (cmapFrom p w) := by
  induction w generalizing p with
  | nil => exact hp
  | cons b w ih => exact ih (cmapStep_WF hp b)

theorem cmapFrom_c_le (p : SMap) (w : List RB) : p.c ≤ (cmapFrom p w).c := by
  induction w generalizing p with
  | nil => exact le_refl _
  | cons b w ih => exact le_trans (cmapStep_c_le p b) (ih _)

/-- One block of the counter phase, above the threshold. -/
theorem countStep_cmapStep {p : SMap} (hp : SMap.WF p) {b : RB}
    (hb : b = RB.X ∨ b = RB.U ∨ b = RB.V ∨ b = RB.Y) {v : ℕ}
    (h : (cmapStep p b).c ≤ v) :
    countStep b (p.apply v) = some ((cmapStep p b).apply v) := by
  rcases hb with rfl | rfl | rfl | rfl
  · -- `11`: a decrement and a shift
    simp only [cmapStep, SMap.pop_c] at h ⊢
    obtain ⟨h1, h2⟩ := SMap.apply_dec p h
    have hz : p.apply v ≠ 0 := by omega
    rw [show countStep RB.X (p.apply v) = some ((p.apply v - 1) / 2) by simp [countStep, hz],
      SMap.apply_pop _ (SMap.WF_dec _ hp), h2]
  · -- `12`: a decrement and a bit
    simp only [cmapStep, SMap.push_c] at h ⊢
    obtain ⟨h1, h2⟩ := SMap.apply_dec p h
    have hz : p.apply v ≠ 0 := by omega
    rw [show countStep RB.U (p.apply v) = some (2 * (p.apply v - 1) + 1) by simp [countStep, hz],
      SMap.apply_push, h2]
  · -- `21`: a shift
    simp only [cmapStep] at h ⊢
    rw [show countStep RB.V (p.apply v) = some (p.apply v / 2) from rfl, SMap.apply_pop _ hp]
  · -- `22`: a bit
    simp only [cmapStep] at h ⊢
    rw [show countStep RB.Y (p.apply v) = some (2 * p.apply v + 1) from rfl, SMap.apply_push]

/-- One block of the counter phase, below the threshold: the counter overflows. -/
theorem countStep_cmapStep_none {p : SMap} {b : RB}
    (hb : b = RB.X ∨ b = RB.U ∨ b = RB.V ∨ b = RB.Y) {v : ℕ}
    (hc : p.c ≤ v) (h : v < (cmapStep p b).c) :
    countStep b (p.apply v) = none := by
  rcases hb with rfl | rfl | rfl | rfl
  · simp only [cmapStep, SMap.pop_c] at h
    rw [SMap.apply_eq_zero_of_lt_dec_c p hc h]; rfl
  · simp only [cmapStep, SMap.push_c] at h
    rw [SMap.apply_eq_zero_of_lt_dec_c p hc h]; rfl
  · simp only [cmapStep, SMap.pop_c] at h; omega
  · simp only [cmapStep, SMap.push_c] at h; omega

/-- **The counter phase in closed form.**  Above the threshold the arithmetic of
the whole word is a single shift map. -/
theorem countRun_cmapFrom {p : SMap} (hp : SMap.WF p) :
    ∀ {w : List RB}, CWord w → ∀ {v : ℕ}, (cmapFrom p w).c ≤ v →
      countRun w (p.apply v) = some ((cmapFrom p w).apply v) := by
  intro w
  induction w generalizing p with
  | nil => intro _ v _; rfl
  | cons b w ih =>
      intro hw v h
      have hstep : (cmapStep p b).c ≤ v := le_trans (cmapFrom_c_le _ w) (by simpa [cmapFrom] using h)
      rw [countRun, countStep_cmapStep hp hw.head hstep]
      simpa [cmapFrom] using ih (cmapStep_WF hp b) hw.of_cons (by simpa [cmapFrom] using h)

/-- **Below the threshold the counter phase does not finish.** -/
theorem countRun_cmapFrom_none {p : SMap} (hp : SMap.WF p) :
    ∀ {w : List RB}, CWord w → ∀ {v : ℕ}, p.c ≤ v → v < (cmapFrom p w).c →
      countRun w (p.apply v) = none := by
  intro w
  induction w generalizing p with
  | nil => intro _ v h1 h2; exact absurd h2 (by simpa [cmapFrom] using Nat.not_lt.mpr h1)
  | cons b w ih =>
      intro hw v hc h
      rcases Nat.lt_or_ge v (cmapStep p b).c with hlt | hge
      · rw [countRun, countStep_cmapStep_none hw.head hc hlt]; rfl
      · rw [countRun, countStep_cmapStep hp hw.head hge]
        simpa [cmapFrom] using ih (cmapStep_WF hp b) hw.of_cons hge (by simpa [cmapFrom] using h)

/-- **The closed form of a counter phase**, from a fresh start: `c` is the exact
threshold, and above it the phase multiplies the counter as `apply` says. -/
theorem countRun_cmap {w : List RB} (hw : CWord w) (v : ℕ) :
    (((cmap w).c ≤ v → countRun w v = some ((cmap w).apply v)) ∧
      (v < (cmap w).c → countRun w v = none)) := by
  constructor
  · intro h
    simpa using countRun_cmapFrom SMap.WF_one hw (p := SMap.one) (v := v) h
  · intro h
    simpa using countRun_cmapFrom_none SMap.WF_one hw (p := SMap.one) (v := v) (by simp) h

/-! ## Overflows: the dichotomy of a counter phase -/

/-- If the arithmetic of a counter phase fails, the machine does not get stuck:
it overflows, i.e. the head reaches the left end `^11`. -/
theorem brun_count_overflow_of_none :
    ∀ {w : List RB}, CWord w → ∀ {lt : List LB}, CStack lt → countRun w (cval lt) = none →
      ∀ rest : List RB, ∃ rt' k, BRun (b4 := b4) ⟨lt, .Rt, w ++ rest⟩ ⟨[.L], .Lt, rt'⟩ k := by
  intro w
  induction w with
  | nil => intro _ lt _ h _; exact absurd h (by simp [countRun])
  | cons b w ih =>
      intro hw lt hst h rest
      rcases Option.eq_none_or_eq_some (countStep b (cval lt)) with h0 | ⟨v₁, h0⟩
      · -- the counter is exhausted at a turn: the overflow
        have hb : b = RB.X ∨ b = RB.U := by
          rcases hw.head with rfl | rfl | rfl | rfl
          · exact Or.inl rfl
          · exact Or.inr rfl
          · simp [countStep] at h0
          · simp [countStep] at h0
        have hv : cval lt = 0 := by
          by_contra hne
          rcases hb with rfl | rfl <;> simp [countStep, hne] at h0
        obtain ⟨rt', k, hrun⟩ := brun_count_overflow (b4 := b4) hst hv hb (w ++ rest)
        exact ⟨rt', k, by simpa using hrun⟩
      · obtain ⟨lt₁, k₁, hrun₁, hst₁, hv₁⟩ :=
          brun_count_step (b4 := b4) hst (w ++ rest) h0
        have hnone : countRun w (cval lt₁) = none := by
          rw [hv₁]
          rw [countRun, h0] at h
          simpa using h
        obtain ⟨rt', k₂, hrun₂⟩ := ih hw.of_cons hst₁ hnone rest
        exact ⟨rt', k₁ + k₂, by simpa using hrun₁.trans hrun₂⟩

/--
**The dichotomy of a counter phase.**  Let `w` be a word of right-hand digit
blocks and `c, d, e, f` the parameters of its shift map `cmap w`.  Then exactly
one of two things happens, and the counter alone decides which:

* if `cval ≥ c`, the head crosses the whole word and the counter ends at
  `((cval - c) / 2 ^ d) * 2 ^ e + f`;
* if `cval < c`, the counter overflows: the head reaches the left end `^11`,
  where the pending digit of the next reset phase is created.
-/
theorem brun_count_dichotomy {w : List RB} (hw : CWord w) {lt : List LB} (hst : CStack lt)
    (rest : List RB) :
    ((cmap w).c ≤ cval lt →
      ∃ lt' k, BRun (b4 := b4) ⟨lt, .Rt, w ++ rest⟩ ⟨lt', .Rt, rest⟩ k ∧ CStack lt' ∧
        cval lt' = (cmap w).apply (cval lt)) ∧
    (cval lt < (cmap w).c →
      ∃ rt' k, BRun (b4 := b4) ⟨lt, .Rt, w ++ rest⟩ ⟨[.L], .Lt, rt'⟩ k) := by
  constructor
  · intro h
    exact brun_count (b4 := b4) w hst ((countRun_cmap hw (cval lt)).1 h) rest
  · intro h
    exact brun_count_overflow_of_none (b4 := b4) hw hst ((countRun_cmap hw (cval lt)).2 h) rest

/-! ## Digit counts: why the counter grows -/

/-- The number of *bit* digits of a word in the counter phase (`22` and `12`). -/
def cbits : List RB → ℕ
  | [] => 0
  | .Y :: w => cbits w + 1
  | .U :: w => cbits w + 1
  | _ :: w => cbits w

/-- The number of *shift* digits of a word in the counter phase (`21` and `11`). -/
def cshifts : List RB → ℕ
  | [] => 0
  | .V :: w => cshifts w + 1
  | .X :: w => cshifts w + 1
  | _ :: w => cshifts w

/-- **The exponents of the shift map are the digit counts.**  For a word of
digit blocks, `e - d = #bits - #shifts`: the counter phase multiplies the
counter by `2 ^ (#bits - #shifts)`, up to the bounded correction of
`SMap.apply_bounds`.  This is the quantity called `D` in `ANALYSIS.md` §14. -/
theorem cmapFrom_digit_count {p : SMap} :
    ∀ {w : List RB}, CWord w →
      (cmapFrom p w).e + p.d + cshifts w = (cmapFrom p w).d + p.e + cbits w := by
  intro w
  induction w generalizing p with
  | nil => intro _; simp only [cmapFrom, cbits, cshifts]; omega
  | cons b w ih =>
      intro hw
      have h := ih (p := cmapStep p b) hw.of_cons
      rcases hw.head with rfl | rfl | rfl | rfl <;>
        simp only [cbits, cshifts, cmapFrom] at h ⊢
      · have hs := SMap.pop_digit p.dec
        rw [SMap.dec_d, SMap.dec_e] at hs
        simp only [cmapStep] at h ⊢
        omega
      · have hs := SMap.push_digit p.dec
        rw [SMap.dec_d, SMap.dec_e] at hs
        simp only [cmapStep] at h ⊢
        omega
      · have hs := SMap.pop_digit p
        simp only [cmapStep] at h ⊢
        omega
      · have hs := SMap.push_digit p
        simp only [cmapStep] at h ⊢
        omega

/-- The digit-count identity, from a fresh start. -/
theorem cmap_digit_count {w : List RB} (hw : CWord w) :
    (cmap w).e + cshifts w = (cmap w).d + cbits w := by
  have := cmapFrom_digit_count (p := SMap.one) hw
  simpa [cmap, SMap.one] using this

/-! ## The reset phase in closed form

The reset phase is the same arithmetic in the other digit representation: the
pending digit `1>`/`2>` is carried along, `21`/`22` are bits and `11`/`12` are
shifts, and in phase `1>` every block costs one extra decrement of the left
counter (the head has to turn around at it).
-/

/-- The phase after crossing one block: `22` and `12` leave a pending `2`, the
other two a pending `1`. -/
def rphaseStep : RB → Bool
  | .Y => true
  | .U => true
  | _ => false

/-- The shift map of one block of the reset phase, in phase `ph`
(`true` = `2>`, `false` = `1>`). -/
def rmapStep (ph : Bool) (p : SMap) (b : RB) : SMap :=
  let q := if ph then p else p.dec
  match b with
  | .V => q.push
  | .Y => q.push
  | .X => q.pop
  | .U => q.pop
  | _ => q

/-- The phase and the shift map of a word of the reset phase. -/
def rmapFrom (ph : Bool) (p : SMap) : List RB → Bool × SMap
  | [] => (ph, p)
  | b :: w => rmapFrom (rphaseStep b) (rmapStep ph p b) w

/-- **The value of a right-hand word in the reset phase**: the phase it ends in
and the shift map it applies to the left counter. -/
def rmap (ph : Bool) (w : List RB) : Bool × SMap := rmapFrom ph SMap.one w

theorem rmapStep_WF {p : SMap} (hp : SMap.WF p) (ph : Bool) (b : RB) :
    SMap.WF (rmapStep ph p b) := by
  have hq : SMap.WF (if ph then p else p.dec) := by
    cases ph
    · exact SMap.WF_dec _ hp
    · exact hp
  cases b <;>
    simp only [rmapStep] <;>
    first
      | exact hq
      | exact SMap.WF_push _ hq
      | exact SMap.WF_pop _ hq

theorem rmapStep_c_le (p : SMap) (ph : Bool) (b : RB) : p.c ≤ (rmapStep ph p b).c := by
  have hq : p.c ≤ (if ph then p else p.dec).c := by
    cases ph
    · exact SMap.dec_c_le p
    · exact le_refl _
  cases b <;> simp only [rmapStep, SMap.push_c, SMap.pop_c] <;> exact hq

theorem rmapFrom_WF {p : SMap} (hp : SMap.WF p) (ph : Bool) (w : List RB) :
    SMap.WF (rmapFrom ph p w).2 := by
  induction w generalizing p ph with
  | nil => exact hp
  | cons b w ih => exact ih (rmapStep_WF hp ph b) _

theorem rmapFrom_c_le (p : SMap) (ph : Bool) (w : List RB) : p.c ≤ (rmapFrom ph p w).2.c := by
  induction w generalizing p ph with
  | nil => exact le_refl _
  | cons b w ih => exact le_trans (rmapStep_c_le p ph b) (ih _ _)

/-- One block of the reset phase, above the threshold. -/
theorem resetStep_rmapStep {p : SMap} (hp : SMap.WF p) {ph : Bool} {b : RB}
    (hb : b = RB.X ∨ b = RB.U ∨ b = RB.V ∨ b = RB.Y) {v : ℕ}
    (h : (rmapStep ph p b).c ≤ v) :
    resetStep ph b (p.apply v) = some (rphaseStep b, (rmapStep ph p b).apply v) := by
  cases ph with
  | true =>
      have hq : (if true then p else p.dec) = p := rfl
      rcases hb with rfl | rfl | rfl | rfl <;>
        simp only [rmapStep, rphaseStep, resetStep, if_neg (by simp : ¬((true = false) ∧ _))]
      · exact congrArg _ (congrArg _ (SMap.apply_pop _ hp v).symm)
      · exact congrArg _ (congrArg _ (SMap.apply_pop _ hp v).symm)
      · exact congrArg _ (congrArg _ (SMap.apply_push p v).symm)
      · exact congrArg _ (congrArg _ (SMap.apply_push p v).symm)
  | false =>
      have hq : (if false then p else p.dec) = p.dec := rfl
      have hc : p.dec.c ≤ v := by
        rcases hb with rfl | rfl | rfl | rfl <;>
          simpa only [rmapStep, hq, SMap.push_c, SMap.pop_c] using h
      obtain ⟨h1, h2⟩ := SMap.apply_dec p hc
      have hdec : SMap.WF p.dec := SMap.WF_dec _ hp
      have hz : ¬ (True ∧ p.apply v = 0) := by simp; omega
      rcases hb with rfl | rfl | rfl | rfl <;>
        · simp only [rmapStep, rphaseStep, resetStep, if_neg hz, Bool.false_eq_true, if_false]
          first
            | rw [SMap.apply_pop _ hdec, h2]
            | rw [SMap.apply_push, h2]

/-- One block of the reset phase, below the threshold: the counter overflows. -/
theorem resetStep_rmapStep_none {p : SMap} {ph : Bool} {b : RB}
    (hb : b = RB.X ∨ b = RB.U ∨ b = RB.V ∨ b = RB.Y) {v : ℕ}
    (hc : p.c ≤ v) (h : v < (rmapStep ph p b).c) :
    resetStep ph b (p.apply v) = none := by
  cases ph with
  | true =>
      exfalso
      rcases hb with rfl | rfl | rfl | rfl <;>
        · simp only [rmapStep, SMap.push_c, SMap.pop_c] at h
          simp at h
          omega
  | false =>
      have hdec : v < p.dec.c := by
        rcases hb with rfl | rfl | rfl | rfl <;>
          simpa only [rmapStep, SMap.push_c, SMap.pop_c] using h
      have h0 : p.apply v = 0 := SMap.apply_eq_zero_of_lt_dec_c p hc hdec
      simp [resetStep, h0]

/-- **The reset phase in closed form.** -/
theorem resetRun_rmapFrom {p : SMap} (hp : SMap.WF p) :
    ∀ {w : List RB}, CWord w → ∀ {ph : Bool} {v : ℕ}, (rmapFrom ph p w).2.c ≤ v →
      resetRun ph w (p.apply v) = some ((rmapFrom ph p w).1, (rmapFrom ph p w).2.apply v) := by
  intro w
  induction w generalizing p with
  | nil => intro _ ph v _; rfl
  | cons b w ih =>
      intro hw ph v h
      have hstep : (rmapStep ph p b).c ≤ v :=
        le_trans (rmapFrom_c_le _ _ w) (by simpa [rmapFrom] using h)
      rw [resetRun, resetStep_rmapStep hp hw.head hstep]
      simpa [rmapFrom] using
        ih (rmapStep_WF hp ph b) hw.of_cons (ph := rphaseStep b) (by simpa [rmapFrom] using h)

/-- **Below the threshold the reset phase does not finish.** -/
theorem resetRun_rmapFrom_none {p : SMap} (hp : SMap.WF p) :
    ∀ {w : List RB}, CWord w → ∀ {ph : Bool} {v : ℕ}, p.c ≤ v → v < (rmapFrom ph p w).2.c →
      resetRun ph w (p.apply v) = none := by
  intro w
  induction w generalizing p with
  | nil => intro _ ph v h1 h2; exact absurd h2 (by simpa [rmapFrom] using Nat.not_lt.mpr h1)
  | cons b w ih =>
      intro hw ph v hc h
      rcases Nat.lt_or_ge v (rmapStep ph p b).c with hlt | hge
      · rw [resetRun, resetStep_rmapStep_none hw.head hc hlt]; rfl
      · rw [resetRun, resetStep_rmapStep hp hw.head hge]
        simpa [rmapFrom] using
          ih (rmapStep_WF hp ph b) hw.of_cons (ph := rphaseStep b) hge (by simpa [rmapFrom] using h)

/-- The closed form of a reset phase started at the left end (counter `0`,
pending digit `2>`), which is how every reset phase begins. -/
theorem resetRun_rmap {w : List RB} (hw : CWord w) (ph : Bool) (v : ℕ) :
    (((rmap ph w).2.c ≤ v →
        resetRun ph w v = some ((rmap ph w).1, (rmap ph w).2.apply v)) ∧
      (v < (rmap ph w).2.c → resetRun ph w v = none)) := by
  constructor
  · intro h
    simpa using resetRun_rmapFrom SMap.WF_one hw (p := SMap.one) (ph := ph) (v := v) h
  · intro h
    simpa using
      resetRun_rmapFrom_none SMap.WF_one hw (p := SMap.one) (ph := ph) (v := v) (by simp) h

/-- If the arithmetic of a reset phase fails, the machine overflows again: the
head reaches the left end, where a fresh pending digit is created.  (A *nested*
overflow: the reset phase has not managed to rebuild a counter yet.) -/
theorem brun_reset_overflow_of_none :
    ∀ {w : List RB}, CWord w → ∀ {ph : Bool} {lt : List LB}, CStack lt →
      resetRun ph w (cval lt) = none → ∀ rest : List RB,
        ∃ rt' k, BRun (b4 := b4) ⟨lt, .Rt, pd ph :: (w ++ rest)⟩ ⟨[.L], .Lt, rt'⟩ k := by
  intro w
  induction w with
  | nil => intro _ ph lt _ h _; exact absurd h (by simp [resetRun])
  | cons b w ih =>
      intro hw ph lt hst h rest
      rcases Option.eq_none_or_eq_some (resetStep ph b (cval lt)) with h0 | ⟨q, h0⟩
      · have hph : ph = false ∧ cval lt = 0 := by
          by_contra hne
          rcases hw.head with rfl | rfl | rfl | rfl <;>
            simp [resetStep] at h0 <;> tauto
        obtain ⟨hph, hv⟩ := hph
        subst hph
        have hb : b = RB.X ∨ b = RB.V ∨ b = RB.Y ∨ b = RB.U := by
          rcases hw.head with rfl | rfl | rfl | rfl <;> tauto
        obtain ⟨rt', k, hrun⟩ := brun_reset_overflow (b4 := b4) hst hv hb (w ++ rest)
        exact ⟨rt', k, by simpa using hrun⟩
      · obtain ⟨lt₁, k₁, hrun₁, hst₁, hv₁⟩ :=
          brun_reset_step (b4 := b4) hst (w ++ rest) h0
        have hnone : resetRun q.1 w (cval lt₁) = none := by
          rw [hv₁]
          rw [resetRun, h0] at h
          simpa using h
        obtain ⟨rt', k₂, hrun₂⟩ := ih hw.of_cons hst₁ hnone rest
        exact ⟨rt', k₁ + k₂, by simpa using hrun₁.trans hrun₂⟩

/--
**The dichotomy of a reset phase.**  With `c, d, e, f` the parameters of the
shift map `(rmap ph w).2` of the word `w` read in the reset phase:

* if `cval ≥ c`, the pending digit crosses the whole word, re-parsing it into
  counter digits, and the counter ends at `((cval - c) / 2 ^ d) * 2 ^ e + f`
  with the pending digit `(rmap ph w).1`;
* if `cval < c`, the counter overflows again and the head is back at the left
  end.

Started at the left end the counter is `0`, so the reset phase gets going
exactly when `c = 0` — i.e. as long as the word does not ask for a decrement
the counter cannot pay.
-/
theorem brun_reset_dichotomy {w : List RB} (hw : CWord w) {ph : Bool} {lt : List LB}
    (hst : CStack lt) (rest : List RB) :
    ((rmap ph w).2.c ≤ cval lt →
      ∃ lt' k, BRun (b4 := b4) ⟨lt, .Rt, pd ph :: (w ++ rest)⟩
          ⟨lt', .Rt, pd (rmap ph w).1 :: rest⟩ k ∧ CStack lt' ∧
        cval lt' = (rmap ph w).2.apply (cval lt)) ∧
    (cval lt < (rmap ph w).2.c →
      ∃ rt' k, BRun (b4 := b4) ⟨lt, .Rt, pd ph :: (w ++ rest)⟩ ⟨[.L], .Lt, rt'⟩ k) := by
  constructor
  · intro h
    exact brun_reset (b4 := b4) w hst ((resetRun_rmap hw ph (cval lt)).1 h) rest
  · intro h
    exact brun_reset_overflow_of_none (b4 := b4) hw hst ((resetRun_rmap hw ph (cval lt)).2 h) rest

/-! ## The two digit representations really are different -/

/-- The number of *bit* digits of a word in the reset phase (`21` and `22`). -/
def rbits : List RB → ℕ
  | [] => 0
  | .V :: w => rbits w + 1
  | .Y :: w => rbits w + 1
  | _ :: w => rbits w

/-- The number of *shift* digits of a word in the reset phase (`11` and `12`). -/
def rshifts : List RB → ℕ
  | [] => 0
  | .X :: w => rshifts w + 1
  | .U :: w => rshifts w + 1
  | _ :: w => rshifts w

theorem rmapFrom_digit_count {p : SMap} :
    ∀ {w : List RB}, CWord w → ∀ {ph : Bool},
      (rmapFrom ph p w).2.e + p.d + rshifts w = (rmapFrom ph p w).2.d + p.e + rbits w := by
  intro w
  induction w generalizing p with
  | nil => intro _ ph; simp only [rmapFrom, rbits, rshifts]; omega
  | cons b w ih =>
      intro hw ph
      have h := ih (p := rmapStep ph p b) hw.of_cons (ph := rphaseStep b)
      have hq : ∀ q : SMap, q.dec.d = q.d ∧ q.dec.e = q.e := fun q => ⟨SMap.dec_d q, SMap.dec_e q⟩
      obtain ⟨hd, he⟩ := hq (if ph then p else p.dec)
      have hpd : (if ph then p else p.dec).d = p.d := by cases ph <;> simp
      have hpe : (if ph then p else p.dec).e = p.e := by cases ph <;> simp
      rcases hw.head with rfl | rfl | rfl | rfl <;>
        simp only [rbits, rshifts, rmapFrom] at h ⊢ <;>
        simp only [rmapStep] at h ⊢
      · have hs := SMap.pop_digit (if ph then p else p.dec); omega
      · have hs := SMap.pop_digit (if ph then p else p.dec); omega
      · have hs := SMap.push_digit (if ph then p else p.dec); omega
      · have hs := SMap.push_digit (if ph then p else p.dec); omega

/-- The reset phase appends at most one digit per block of the word. -/
theorem rmapStep_e_le (p : SMap) (ph : Bool) (b : RB) : (rmapStep ph p b).e ≤ p.e + 1 := by
  have he : (if ph then p else p.dec).e = p.e := by cases ph <;> simp
  have hpop := SMap.pop_e_le (if ph then p else p.dec)
  cases b <;> simp only [rmapStep, SMap.push_e] <;> omega

theorem rmapFrom_e_le (p : SMap) (ph : Bool) (w : List RB) :
    (rmapFrom ph p w).2.e ≤ p.e + w.length := by
  induction w generalizing p ph with
  | nil => simp [rmapFrom]
  | cons b w ih =>
      have h1 := ih (rmapStep ph p b) (rphaseStep b)
      have h2 := rmapStep_e_le p ph b
      simp only [rmapFrom, List.length_cons]
      omega

/-- The numeral a reset phase builds has at most one digit per block of the
word it re-parses. -/
theorem rmap_e_le (ph : Bool) (w : List RB) : (rmap ph w).2.e ≤ w.length := by
  have := rmapFrom_e_le SMap.one ph w
  simpa [rmap, SMap.one] using this

/-- The digit-count identity for the reset phase. -/
theorem rmap_digit_count {w : List RB} (hw : CWord w) (ph : Bool) :
    (rmap ph w).2.e + rshifts w = (rmap ph w).2.d + rbits w := by
  have := rmapFrom_digit_count (p := SMap.one) hw (ph := ph)
  simpa [rmap, SMap.one] using this

/--
**The two sides do not read the tape the same way.**  The word `21 21 22`
carries one bit and two shifts for the counter phase, but three bits and no
shift for the reset phase: the same tape content is a different number in the
two digit representations.  This is why a single value cannot describe both
counters at once, and why the shift map — which records the representation as
well as the value — is the right notion.
-/
theorem digit_counts_differ :
    cbits [RB.V, RB.V, RB.Y] = 1 ∧ cshifts [RB.V, RB.V, RB.Y] = 2 ∧
    rbits [RB.V, RB.V, RB.Y] = 3 ∧ rshifts [RB.V, RB.V, RB.Y] = 0 ∧
    cmap [RB.V, RB.V, RB.Y] = ⟨0, 2, 1, 1⟩ ∧
    rmap true [RB.V, RB.V, RB.Y] = (true, ⟨0, 0, 3, 1⟩) := by
  refine ⟨rfl, rfl, rfl, rfl, rfl, rfl⟩

/-! ## A phase never branches on a residue of the counter

The question these two theorems answer is whether the family is one of the
shift-overflow counters whose phases go differently according to `v mod k`.
Inside a phase they are not: the counter enters only through the quotient
`⌊(v − c) / 2^d⌋` and the all-or-nothing threshold test `v ≥ c`.  Two counter
values with the same quotient are indistinguishable to the phase — the residue
mod `2^d` is *discarded*, never tested.  (Value dependence does exist in the
family, but it enters at the overflow, not inside a phase; see
`Overflow.lean`.)
-/

/-- **A counter phase depends on the counter only through the quotient
`⌊(v − c) / 2^d⌋`.** -/
theorem countRun_no_residue_dependence {w : List RB} (hw : CWord w) {v v' : ℕ}
    (hv : (cmap w).c ≤ v) (hv' : (cmap w).c ≤ v')
    (h : (v - (cmap w).c) / 2 ^ (cmap w).d = (v' - (cmap w).c) / 2 ^ (cmap w).d) :
    countRun w v = countRun w v' := by
  rw [(countRun_cmap hw v).1 hv, (countRun_cmap hw v').1 hv', SMap.apply, SMap.apply, h]

/-- **A reset phase depends on the counter only through the quotient
`⌊(v − c) / 2^d⌋`**, and so does the pending digit it ends in. -/
theorem resetRun_no_residue_dependence {w : List RB} (hw : CWord w) (ph : Bool) {v v' : ℕ}
    (hv : (rmap ph w).2.c ≤ v) (hv' : (rmap ph w).2.c ≤ v')
    (h : (v - (rmap ph w).2.c) / 2 ^ (rmap ph w).2.d
        = (v' - (rmap ph w).2.c) / 2 ^ (rmap ph w).2.d) :
    resetRun ph w v = resetRun ph w v' := by
  rw [(resetRun_rmap hw ph v).1 hv, (resetRun_rmap hw ph v').1 hv',
    SMap.apply, SMap.apply, h]

end BB25
