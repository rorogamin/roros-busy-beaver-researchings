# Formalization map for 1RA, 0LA and 2LB

## Status

This is a specification and dependency map, NOT a completed Lean development.
None of the new proof below has been compiled in Lean in this session.
The original archive specifies `leanprover/lean4:v4.28.0`.

The previous prefix-safety proof is itself not formalized in the supplied
Aristotle project. Its interface must be proved first; do not silently treat
those new lemmas as axioms or as already present in the archive.

## 1. Preserve the machine-level source of truth

Use the original files under `RequestProject/BB25`:

- `Family.lean`: `G_1RA`, `G_0LA`, `G_2LB` with exact base-step counts.
- `Blocks.lean`: denotation, re-parsing, and BRun soundness.
- `Pairing.lean`: transparent matched groups and their compositions.
- `Counter.lean`: counter decrements, overflows, and `resetStep` /
  `brun_reset_step`, including the `.U` case.
- `Overflow.lean`: the exact deposited overflow word.
- `Machine.lean`, `Nonhalt.lean`, `Simulation.lean`: reachability and the
  final conversion to the existing nonhalting predicate.

The proof and Python code write stacks bottom-first. Original Lean and
`blocksim.py` use nearest-to-head first. An explicit reversal adapter is
required. The permanent L block is not an ordinary counter bit.

Do not confuse `<B1` with a bare B head: its denotation includes the extra
right-hand symbol 1.

## 2. First formalize the previous interface

The dependency map in `previous/FORMALIZATION_PREVIOUS.md` remains relevant.
Required objects and facts are:

1. Admissibility, noncrossing bit/pop matching, and the paired decoder P.
2. A successful decrement changes only final unmatched bits; it preserves
   every decoded prefix and cannot increase any prefix counter.
3. A zero-counter excursion deposits P(s).
4. Integer adjusted reset evaluation rho, paid reset stack T, and the phase
   debt endpoint theorem. Negative subtraction must NOT be truncated.
5. Prefix Good, its preservation by D and bit append, and the `d>=2` pop
   lemma: Good(s) and v(s)>=d>=2 imply Good(D^d(s)W).
6. Clean u implies Good(T(u)), v(T(u))=rho(u), P(T(u))=Q(u).
7. The common Z-boundary return theorem, including the nonempty exceptional
   early reset and the arbitrary-suffix nine-step XY spinout.
8. The common 156-step blank seed.

Only (7) requires the previous proof's delicate low-counter argument. The
new members introduce no changes to that common branch.

## 3. New arithmetic/structural module

Suggested definitions (schematic names, not claims of existing Lean code):

```
DecoderClean(s) := Admissible(s) and every prefix of P(s) has rho >= 0
Protected3(s) := DecoderClean(s) and b(s) + 2 >= 3 * (v(s) + 1)
```

Represent rho as integer arithmetic (`Int` division by positive two), or
keep a natural counter plus a separate legality proof. A pure Nat fold with
truncated subtraction is not equivalent on dirty words.

### Protected drain

Prove a positive-cost finite return from A>R under Protected3.
Use `U=v+1`, `C=b+2`. The two drain updates are

```
U even: (U,C) -> (U/2, C/2)
U odd:  (U,C) -> ((U-1)/2, 2*C-2)
```

Induct on v. At v=0, C>=3 gives b>=1; the reset P(s)VR ends at a Good
B checkpoint with counter at least two. No Good assumption on the initial
stack is available or necessary in this lemma.

The tail bridge assumes DecoderClean(s) and

```
4*(b(s)+1) >= 3*(v(s)+1)
```

and derives Protected3 after P2 Y^r R1 for r>=1, with the exact endpoint
values in PROOF_MORE.md, Lemma 2.

### Counted transducer

Q and the expansion count q must be defined as a STATEFUL transducer.
The first adjusted value determines the X branch. For concatenation, the
second word starts at the first word's final first-counter value, not zero.
Count a close when it is an original V or an X with odd incoming first
counter. The value of the first counter may be any integer in the balanced
forest induction.

Prove, simultaneously with cleanliness, for every balanced forest:

```
3 * second_final >= 3 * 4^q * second_start + 2 * (4^q - 1)
```

for second_start>=0. This denominator-free form avoids rational arithmetic.
Use `4^q == 1 (mod 3)` for the exact fractional presentation in the paper.
For a contracting root, its interior is nonempty and contains at least one
expanding close; the arithmetic difference is `(4^q-4)/6 >= 0`.

For a Dyck prefix of height h derive

```
3 * (rho(Q(u)) + 1) >= 2^h * (2*4^q + 1).
```

Then prove the two structural consequences for h>=2:

```
rho(u) % 4 = 0          -> rho(Q(u)) >= 43
rho(Q(u)) = rho(u), even rho(u) -> rho(u) >= 12
```

The first is NOT established by numerical testing. Prove that q=0 gives
u=Y^h, and q=1 forces the chain normal form

```
Y^i (Y^n C X^(n-1)) Y^(h-i), C in {X,V}, n>=1, i<=h.
```

Its first adjusted value is respectively

```
2^h - 2^(h-i) - 1
2^(h+2) - 2^(h-i) - 1.
```

For h>=2 neither has residue zero modulo four. Therefore q>=2 and the
height-sensitive bound gives 43. The second consequence needs only that a
nonempty matched group implies q>=1.

## 4. Exact early-reset endpoints

At a safe B checkpoint, remove trailing X's and then the encountered W;
write the underlying stack c and a=v(c). Before G the stack is D^2(c).

In the a=2 cases, define u=P(c), t=T(u), f=rho(u), B=rho(Q(u)). Prove
explicitly:

```
Good(t), B>=f>=4, height(u)>=2.
```

The lower bound FOUR uses Good at the original prefix cW, not merely
Good(c): its last matched bit is zero, so

```
f/2 - 1 >= 1.
```

This detail prevents the invalid low-counter generalizations.

With r>=1, the exact first B checkpoints are

```
0LA: t X W Z^(r-1) X
2LB: t W W Z^(r-1) X.
```

Formalize the phase-sensitive U reset directly from `resetStep`:
U maps a to floor(a/2) and appends W without a final debt. Check stack
admissibility and phase-debt legality explicitly. The identities

```
P1 Y^r R1 = U Y^(r-1) V R
P2 Y^r R1 =   Y^r     V R
```

are denotational equalities of raw tape lists.

## 5. The two repair lemmas

### 0LA

If B>=f+1, the first checkpoint is Good. Otherwise B=f.
For r=1, B removes X W and leaves the Good core tX of value 2f>=8.
For r>=2, after B removes X Z the core has

```
A = 2^(r-2)*(f+1)-1
C = 2^(r-2)*f-1.
```

Two decrements and one pop satisfy the tail bridge. If A is even then
r=2 and f is even; the structural barrier f>=12 supplies the required
f>=8. Use the weaker protected drain, not Good preservation of all
intermediate stacks.

### 2LB

For K=tWW, set A0=f/4 and C0=b(K). Odd f gives Good immediately.
The remaining cases have clean decoders and satisfy either

```
f == 2 (mod 4): C0>=4*A0, A0>=1
f == 0 (mod 4), not Good(K): f>=40, A0>=10, C0>=A0-2.
```

The second line uses B>=43. Values f<=36 make both new prefixes Good,
so cannot occur in that line.

For r=1, the underlying core is tW. Only its final prefix can be
non-Good, by at most one; the two F/G decrements repair it. If its value
is >=4, finish the ordinary G branch. The value-three case has f=6 and
an early clean Y U reset.

For r>=2 the underlying core is K Z^(r-2). Handle A=1 by the explicit
clean overflow with residual V. For A>=2 prove the tail-bridge inequality
after the two decrements and pop by parity. The last small threshold is
A0>=8 in the even case, supplied by A0>=10.

Each repair reaches Good at the next canonical B checkpoint. Do not claim
that every intermediate B checkpoint is Good.

## 6. Machine return and final theorem

Combine the common Z lemma, the exact G rules, the ordinary branches and
the two repair lemmas. State a POSITIVE-COST return theorem, with a
nonhalting spinout alternative.

For 1RA, at most one canonical B checkpoint is crossed per return. For
0LA/2LB, at most two are crossed. Zero-cost re-parsings must not be used to
justify an infinite run without positive base-step growth.

Use the exact blank seed and iterate the return theorem, ruling out a
finite halting time. The target conclusions are the original project's
nonhalting predicates for `b4_1RA`, `b4_0LA`, and `b4_2LB`.

## 7. Tests and a negative control

The reference Python simulator files in this package are copied unchanged
from the archive. `verify_more.py` uses a separate constructive successor
and checks exact equality of its returned stack with the reference run.

`check_more_components.py` tests the structural bounds and repairs, and
checks a nonblank 1LB counterexample directly on the base transition table:

```
L XZXWXW <B1 YR1
```

This stack is Good with value one, but reaches the undefined A4
transition after 203 defined base transitions. It is a useful negative
control: a purported universal Good-checkpoint return lemma for all five
bouncing members is false. It says nothing about the blank run of 1LB.
