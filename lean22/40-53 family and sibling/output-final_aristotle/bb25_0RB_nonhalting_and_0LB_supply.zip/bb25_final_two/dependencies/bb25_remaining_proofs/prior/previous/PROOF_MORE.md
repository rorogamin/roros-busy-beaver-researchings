# Three further nonhalting arguments: 1RA, 0LA and 2LB

Date: 2026-09-16.

## Status and scope

This document extends the previous prefix-safety argument to

```
1RA: 1RB2LA0RB1LB---_1LA3RA1RA4LB1RA
0LA: 1RB2LA0RB1LB---_1LA3RA1RA4LB0LA
2LB: 1RB2LA0RB1LB---_1LA3RA1RA4LB2LB
```

These are mathematical nonhalting proofs using the transition rules and
counter/transparent-pair results in the supplied Aristotle project, and the
common Z-branch argument from the previous proof. The new theorems have NOT
been compiled or kernel-checked in Lean. The accompanying programs are finite
checks, not substitutes for the universal arguments.

The previous proof is included unchanged as `previous/PROOF_PREVIOUS.md`.
Its proposed conclusions for 3RA and 2LA are not re-certified here.

The important changes are:

1. 1RA preserves the old Good checkpoint invariant directly.
2. 0LA and 2LB sometimes lose Good at an intermediate B checkpoint. Demanding
   its preservation at every such checkpoint is false.
3. Those exceptional checkpoints have precise stack forms. They return to
   Good at the very next B checkpoint, using a weaker drain condition and a
   quantitative strengthening of the matched-group lemma.

## 1. Notation and the established counter interface

Stacks are written **bottom first**, with the permanent bottom block L=^11
omitted. The left blocks are X=11, Z=01, W=03. Define

\[
v(\epsilon)=0,\qquad v(sX)=2v(s),\qquad
v(sZ)=2v(s)+1,\qquad v(sW)=\lfloor v(s)/2\rfloor.
\]

A stack is admissible when every prefix has at least as many bits X,Z as
pops W. Match a W with the most recent unmatched bit. The remaining bits
carry v(s), with leading zero bits allowed.

A successful left excursion D(s), for v(s)>0, subtracts one from those
remaining bits. It changes no matched bit and does not change the stack
shape. Define the paired decoder P by

- either left bit X or Z emits right Y=22;
- a W matched with X emits right X=11;
- a W matched with Z emits right V=21.

Thus P(s) is a colored Dyck prefix: Y opens a pair and X,V close it. Its
height is the number of unmatched bits of s. For positive counters,
P(D(s))=P(s), including all decoded prefixes. When v(s)=0, a left excursion
reaches the bottom and deposits P(s) before the existing right suffix.

These are the counter and transparent-pair facts used from the archive;
see `Pairing.lean`, `Counter.lean` and `Overflow.lean`. The unchanged
`reference_tools/blocksim.py` records the local block rules used below.

For right reset words use the integer-valued adjusted maps

\[
Y:a\mapsto2a+1,\quad V:a\mapsto2a,\quad
X:a\mapsto\lfloor a/2\rfloor-1. \tag{1}
\]

Write rho(w) for their composition from zero. A word is clean when every
prefix has nonnegative adjusted value. Negative integers remain negative
under all three maps, so a nonnegative final value implies cleanliness.
The adjusted value equals the physical counter in pending phase 2 and the
physical counter minus one in pending phase 1.

Put b(s)=rho(P(s)). The previous invariant is

\[
\operatorname{Good}(s)\iff s\text{ admissible and }
 b(p)\ge v(p)\text{ for every prefix }p\preceq s. \tag{2}
\]

The interface lemmas from the previous proof are:

* D preserves Good and cannot increase any prefix counter.
* Appending either bit preserves Good.
* If s is Good and v(s)>=d>=2, then D^d(s)W is Good.
* A clean reset w creates its paid stack T(w), which is Good and has value
  rho(w), where

\[
T(\epsilon)=\epsilon,\quad T(wY)=T(w)Z,\quad
T(wV)=T(w)X,\quad T(wX)=D(T(w)W). \tag{3}
\]

The last formula charges the pending-1 debt in advance. It describes the
stack effect; it is not an assertion that every charged prefix has the same
physical head location. A clean reset of wR, with positive final adjusted
value, ends at the B checkpoint

\[
L\,T(w)\ <B1\ YR1. \tag{4}
\]

Here R is the bare right end and R1 is the right end preceded by 1.

We will also use the right block U=12. Its adjusted reset map is

\[
U:a\mapsto\lfloor a/2\rfloor,\qquad T(wU)=T(w)W, \tag{5}
\]

provided the corresponding reset is legal. Unlike an X reset, this pop
carries no final charged decrement and need not preserve Good. All U uses
below have explicit nonnegative counters and enough unmatched bits. Equation
(5) follows from the same `resetStep` definition as (1).

The literal suffix re-parsing identities needed below are

\[
P2\,Y^rR1=Y^rVR,\qquad
P1\,Y^rR1=U\,Y^{r-1}VR\quad(r\ge1). \tag{6}
\]

They are identities of the raw tape symbols, not additional machine steps.

## 2. A weaker protected-drain lemma

Call a stack decoder-clean when it is admissible and P(s) is clean. Good
implies decoder-clean, but the converse is false.

### Lemma 1 (threefold drain)

At A>R, assume s is decoder-clean and

\[
\boxed{b(s)+2\ge3(v(s)+1).} \tag{7}
\]

Then a finite, nonhalting run reaches a Good B checkpoint with positive
counter.

**Proof.** At A>R, a positive counter undergoes

\[
s\longmapsto D(s)W,\qquad v'=\lfloor(v-1)/2\rfloor.
\]

Put U=v+1 and C=b+2. If U is even, the newly matched bit is zero and

\[
(U',C')=(U/2,\lfloor C/2\rfloor).
\]

If U is odd, the newly matched bit is one and

\[
(U',C')=((U-1)/2,2C-2).
\]

Both preserve C>=3U. Old decoded prefixes are unchanged by the decrement;
the newly appended prefix has b'=C'-2>=1. Hence decoder-cleanliness also
persists. Appending W is admissible because a positive counter had at least
one unmatched bit, and D preserves that number.

The natural number v strictly decreases, so eventually v=0. At that point
(7) gives b>=1. The next left excursion deposits P(s)VR. This is clean,
with adjusted value 2b>=2. Its paid reset produces a Good, positive B
checkpoint by (3)-(4). All excursions are finite. QED.

### Lemma 2 (pending-2 tail)

Suppose s is decoder-clean and

\[
4(b(s)+1)\ge3(v(s)+1). \tag{8}
\]

Then A>P2 Y^r R1, for any r>=1, reaches the situation of Lemma 1.

**Proof.** The r Y blocks push r one bits; the final P2 R1=VR pops the
last one. The new values at A>R are

\[
v'=2^{r-1}(v+1)-1,\qquad b'=2^{r+1}(b+1)-2.
\]

Thus (8) is precisely b'+2>=3(v'+1). Decoder-cleanliness persists under
the appended Y's and the V-colored last pop. QED.

In particular, every Good stack satisfies (8). Unlike the previous
fourfold drain lemma, Lemma 1 does not require Good at its starting point.

## 3. Counting expanding closes in the transduced reset

For a clean right word u define Q(u) by reading the first adjusted counter a
and emitting

\[
Y\mapsto Y,\qquad V\mapsto Y,\qquad
X\mapsto\begin{cases}V,&a\text{ odd before X},\\
X,&a\text{ even before X}.
\end{cases} \tag{9}
\]

The paired-stack calculation gives P(T(u))=Q(u).

For a colored Dyck word or prefix, call a closing letter **expanding** if
it is an original V, or an original X read with odd first counter. These
are exactly the closing letters whose emitted second-counter map doubles
rather than halves. Let q be their number.

### Lemma 3 (quantitative matched-group expansion)

For any balanced colored Dyck word d, let q count its expanding closes in
the transduction (9), with any integer starting value of the first counter.
Starting the second counter at c>=0, its transduced word is clean and ends
at least at

\[
F_q(c)=4^q c+\frac{2(4^q-1)}3. \tag{10}
\]

Every nonempty balanced tree contains at least one expanding close.

**Proof.** Induct on forests and trees. A leaf YX has an odd first counter
at X, and a leaf YV always expands; thus a nonempty tree has an expanding
close.

Concatenation uses F_p(F_q(c))=F_{p+q}(c). For a tree Y e C, the opening
maps the second counter to 2c+1. Let e contain j expanding closes and put
A=4^j. Its output is at least

\[
A(2c+1)+2(A-1)/3=2Ac+(5A-2)/3.
\]

If the final close expands, its output is at least twice that quantity.
This is at least F_{j+1}(c); the difference between the respective constant
terms is 2(A-1)/3>=0.

If the final close contracts, it is an X read with even first counter. The
interior is nonempty, since an empty interior would leave an odd first
counter after the opening Y. Therefore j>=1 and A>=4. The last output is
at least

\[
Ac+(5A-8)/6
=F_j(c)+(A-4)/6\ge F_j(c).
\]

The displayed floor calculation is exact for the lower bound because
(5A-2)/3 is even. Its input is at least 6, so the final contracting X is
clean. Expanding closes cannot cause underflow. QED.

### Corollary 3.1 (height-sensitive bound)

For a colored Dyck prefix u of height h, let B=rho(Q(u)). Then

\[
\boxed{3(B+1)\ge2^h(2\cdot4^q+1).} \tag{11}
\]

**Proof.** Decompose u into balanced forests separated by its h unmatched
Y's. The inequality

\[
F_q(2c+1)\ge2F_q(c)+1
\]

shows that moving a forest before an unmatched Y weakly decreases the
lower bound. Putting all forests first gives

\[
B\ge2^h(F_q(0)+1)-1
=2^h(2\cdot4^q+1)/3-1.
\]

QED.

### Corollary 3.2 (two small-value barriers)

Suppose u is clean, is a Dyck prefix of height h>=2, and set

\[
a=\rho(u),\qquad B=\rho(Q(u)).
\]

Then:

\[
\boxed{a\equiv0\pmod4\ \Longrightarrow\ B\ge43,} \tag{12}
\]

and

\[
\boxed{B=a\text{ even}\ \Longrightarrow\ a\ge12.} \tag{13}
\]

**Proof of (12).** With q=0, u has no completed pair, so u=Y^h and
 a=2^h-1, not divisible by four.

With q=1, there is only one balanced tree and it is a chain: every leaf
requires an expanding close. For some 0<=i<=h and n>=1, the word therefore
has form

\[
u=Y^i\,[Y^n C X^{n-1}]\,Y^{h-i},\qquad C\in\{X,V\}.
\]

The innermost close C is the unique expanding one. The remaining closes
are contracting X's. Direct application of (1) gives respectively

\[
a=2^h-2^{h-i}-1\quad(C=X),\qquad
 a=2^{h+2}-2^{h-i}-1\quad(C=V).
\]

For h>=2, these have residue 2, 1 or 3 modulo four according as h-i is
0, 1, or at least 2. A clean word excludes any negative case. Therefore
four-divisibility forces q>=2. Equation (11) then yields
B>=11*2^h-1>=43.

For (13), q=0 would give B=a=2^h-1, which is odd. Thus q>=1, so (11)
gives B>=3*2^h-1>=11. Equality to an even a implies a>=12. QED.

These are universal structural bounds. No finite search over stack lengths
is used in their proof.

## 4. The common B checkpoint and the 1RA extension

A safe checkpoint means

\[
L\,s\ <B1\ YR1,\qquad \operatorname{Good}(s),\quad v(s)>0. \tag{14}
\]

B strips k terminal X blocks. Let r=k+1>=1 and write the remaining
stack as cZ or cW. The tail is now Y^rR1.

If the encountered block is Z, the rule is

\[
cZ\ <B1\ Y^rR1\longrightarrow c\ <A\ X P2Y^rR1.
\]

This is the common branch already proved in the previous argument, for
all B4 choices under consideration. It returns to a safe checkpoint or to
the explicit left XY spinout. For completeness, the ingredients are:

* If v(c)>=2, two decrements followed by W give a Good stack, and Lemma 2
  applies to its pending-2 tail.
* If v(c)=0 or 1, overflow leaves P(c_0) d Y^r VR with d=X or V.
  It resets cleanly unless d=X and rho(P(c_0)) is 0 or 1.
* Empty P(c_0) in that exception gives the exact nine-base-step spinout
  L <A 1122t -> L <A 11222t.
* In the nonempty exception, the previous matched-group lemma shows that
  the additional pop has a clean decoder; the next overflow yields the
  clean odd-terminal word P(T(P(c_0))W)Y^(r+1)R1. Its final one-bit pop
  establishes the protected drain. See previous proof, sections 4 and 6.

No new use of a G rule occurs in this common branch.

Now consider W. Put a=v(c). Because the checkpoint was positive,
a>=2, and c is Good. The W and F rules make exactly two decrements before
reaching G:

\[
cW\ <B1\ Y^rR1\longrightarrow D^2(c)\ A>G Y^rR1. \tag{15}
\]

For 1RA the member-specific rule is

\[
A>G\longrightarrow X\ A>P2.
\]

Consequently the left stack becomes D^2(c)X, which is Good, followed by
P2Y^rR1. Lemma 2 and then Lemma 1 return to a safe checkpoint.

This proves the return theorem for 1RA with no new exceptional W cases.

## 5. Reduction of the 0LA and 2LB W cases

At G after (15), the exact rules are

\[
0LA:\ A>G\longrightarrow <A\ VP1,
\qquad
2LB:\ A>G\longrightarrow <A\ UP1. \tag{16}
\]

### 5.1 Ordinary 0LA cases

For a>=3, the next decrement and V consumption give

\[
z=D^3(c)W\quad\text{at}\quad A>P1Y^rR1.
\]

This z is Good. If a>=5, its counter is positive, so the pending-1 turn
pays one further decrement. The resulting Good stack is followed by a
pending-2 Y^rR1 tail, and Lemma 2 applies.

For a=3 or 4, v(z)=0. The pending-1 turn instead overflows. Re-parsing
leaves the clean reset word P(z)Y^rVR, whose value is at least two. Its
paid reset is a safe checkpoint.

The remaining 0LA case is a=2.

### 5.2 Ordinary 2LB cases

For a>=4, two more decrements and U consumption give D^4(c)Z followed
by P1Y^rR1. The appended one bit guarantees that the pending-1 debt is
payable. After payment, the stack is Good and Lemma 2 applies.

For a=3, one more decrement reaches zero, then U turns left and the
next excursion overflows with residual Y P1Y^rR1. Let u=P(D^3(c)).
Using (6), the reset word is

\[
uY UY^{r-1}VR.
\]

Its paid stack is

\[
T(u)ZWZ^{r-1}X. \tag{17}
\]

The ZW pair is good: its last popped bit is one, so its decoded close is
V. The counter rho(u)>=3, and (17) is a safe checkpoint.

The remaining 2LB case is again a=2.

### 5.3 Exact forms in the remaining a=2 cases

Let c_0=D^2(c), u=P(c_0)=P(c), and define

\[
t=T(u),\qquad f=v(t)=\rho(u),\qquad B=b(t)=\rho(Q(u)). \tag{18}
\]

The following conditions are crucial:

\[
\operatorname{Good}(t),\qquad B\ge f\ge4,
\qquad u\text{ has height at least two}. \tag{19}
\]

Indeed, c has value two, so it has at least two unmatched bits, and its
last unmatched bit is zero. At the prefix cW of the ORIGINAL Good
checkpoint, this last W therefore decodes as X. Good gives

\[
\lfloor\rho(P(c))/2\rfloor-1\ge v(cW)=1,
\]

hence f>=4. This is stronger than merely using Good(c), and must not be
omitted.

For 0LA, the early overflow leaves u V P1Y^rR1, hence the clean reset
word u V UY^(r-1)VR. Its paid stack is exactly

\[
\boxed{S_0=tXWZ^{r-1}X.} \tag{20}
\]

For 2LB, the early overflow leaves u U P1Y^rR1, hence u U UY^(r-1)VR.
Its paid stack is exactly

\[
\boxed{S_2=tWWZ^{r-1}X.} \tag{21}
\]

All U operations here are legal: f>=4, and t has at least three unmatched
bits because it represents f. Both final checkpoints have positive
counter. They need not be Good; the next two sections prove their repair.

## 6. Repair of the 0LA exception

For K=tXW, the old prefixes and the appended X satisfy Good, while the
last pop has

\[
v(K)=f,\qquad b(K)=B-1. \tag{22}
\]

Thus K, and consequently S_0, is Good if B>=f+1. Return at this first
checkpoint in that case.

Otherwise B=f. The decoder is still clean, since f>=4. We will return
to Good at the NEXT B checkpoint.

### Case r=1

Here S_0=tXWX. B strips X and encounters W with the Good underlying
stack tX, whose value is 2f>=8. This is the ordinary a>=5 case of
0LA already proved in section 5.1. It returns safely to Good.

### Case r>=2

B strips the last X and then encounters Z. Put j=r-2. Its underlying
stack is

\[
H=tXWZ^j,
\]

which is decoder-clean, with values

\[
A=v(H)=2^j(f+1)-1,\qquad C=b(H)=2^j f-1. \tag{23}
\]

Here A>=4. The Z rule makes two decrements and appends W. Let A_1,C_1
be the two values after that pop. If A is odd,

\[
A_1=(A-3)/2,\qquad C_1=2C.
\]

Then

\[
4(C_1+1)\ge3(A_1+1),
\]

because the equivalent inequality 16C+11>=3A follows on substitution
from 2^j(13f-3)-2>=0.

If A is even, j=0 and f is even. Since B=f, Corollary 3.2 gives f>=12.
In this case

\[
A_1=f/2-1,\qquad C_1=f/2-2,
\]

and 4(C_1+1)>=3(A_1+1) reduces to f>=8, which holds.

In both cases the newly appended prefix is clean, while all older decoded
prefixes were unchanged by the decrements. The new pending-2 tail has
length two: B stripped exactly one X. Lemmas 2 and 1 apply, yielding a
Good positive checkpoint. QED.

## 7. Repair of the 2LB exception

Put K=tWW, A_0=v(K)=floor(f/4), and C_0=b(K). By f>=4,
A_0>=1. Compute the two new decoded prefixes according to f modulo four.

If f is odd, both new Good comparisons hold: for residue three both
closes are V; for residue one they are V then X, with final decoded
value B-1>=floor(f/4). Hence S_2 is already Good.

Suppose f is even. The first close is X, with decoded value
floor(B/2)-1.

For f=4A_0+2, the second close is V, and

\[
\boxed{C_0\ge4A_0.} \tag{24}
\]

All decoded prefixes are clean. A Good failure is possible only at the
first of the two appended pops.

For f=4A_0, the second close is X. In this case Corollary 3.2 gives
B>=43. In particular both appended prefixes are clean, and

\[
C_0\ge A_0-2.
\]

If f<=36 then B>=f+7, which makes both new prefixes Good as well. Thus
in the genuinely non-Good case we have

\[
\boxed{f\ge40,\qquad A_0\ge10,\qquad C_0\ge A_0-2.} \tag{25}
\]

This proves that (21) is always decoder-clean and positive. If it is
Good, return immediately. Otherwise only (24) or (25) can occur.

### Case r=1

The checkpoint is tWWX. B strips X and encounters W, with underlying
stack tW. Write a'=v(tW)=floor(f/2). Its old prefixes are Good, and
the ONLY possible deficient prefix is its last one, with

\[
b(tW)\ge a'-1.
\]

In the non-Good cases above a'>=3. The two decrements before G make
D^2(tW) Good: old prefix counters cannot increase, and the last value
has decreased by two while its decoder has not changed.

If a'>=4, the 2LB G rule can make its two further decrements and append
Z. The pending-1 debt is paid, leaving a Good stack followed by the
pending-2 tail of length two. Lemmas 2 and 1 return to Good.

If a'=3, then f=6. At G the counter is one; the next decrement succeeds,
and the turn at U then overflows with residual Y P1Y^2R1. The zero
stack is Good. Its reset has the form (17), now with r=2, and is Good
and positive. This also returns safely.

### Case r>=2

B strips X and encounters Z. With j=r-2, its underlying stack is
KZ^j, with values

\[
A=2^j(A_0+1)-1,\qquad C=2^j(C_0+1)-1. \tag{26}
\]

It is decoder-clean. If A=1, one decrement succeeds and the second
overflows after the residual X has become V. The reset word is
P(H_0)VY^2VR, where H_0 is the resulting zero stack. Its decoded prefix
is clean, and the tail makes the final reset value positive. It returns
to Good.

For A>=2, the two decrements and appended W give values A_1,C_1. We
verify the entry condition (8).

If A is odd, then A_1=(A-3)/2 and C_1=2C. The required inequality is
16C+11>=3A. Under (24) this is immediate. Under (25), substitution
in (26) gives the sufficient inequality

\[
2^j(13A_0-19)-2\ge0,
\]

which holds for A_0>=10.

If A is even, then j=0 and A_0 is even. We have

\[
A_1=A_0/2-1,\qquad C_1=\lfloor C_0/2\rfloor-1.
\]

The required inequality is

\[
4\lfloor C_0/2\rfloor\ge3A_0/2.
\]

It follows immediately from (24). Under (25), its left side is at least
2A_0-4, which is sufficient for A_0>=8; we have A_0>=10.

The new prefix is therefore clean, and so are all older decoded prefixes.
The pending-2 tail of length two satisfies Lemma 2 and then Lemma 1.
The next B checkpoint is Good and positive. QED.

## 8. Return theorem and blank-tape nonhalting

### Theorem

For each member in {1RA,0LA,2LB}, every safe checkpoint (14) reaches
another safe checkpoint in positive finite time, or enters the common
nonhalting XY spinout. For 1RA the next B checkpoint suffices. For 0LA
and 2LB, at most one non-Good B checkpoint intervenes.

**Proof.** B stripping terminates because the checkpoint counter is
positive. The encountered Z is handled by the common argument. For W,
the two excursions before G are available because the underlying counter
is at least two. Section 4 handles 1RA; section 5 covers the ordinary
0LA/2LB cases and isolates precisely (20)-(21); sections 6-7 handle them.
No F/G remains during the early resets. Every invoked excursion, reset and
drain is finite. At least the initial B transition has positive base-step
cost, including when intermediate re-parsings cost zero. QED.

For all three machines, the shared finite prefix from blank reaches

\[
\boxed{L\,ZZZXXX\ <B1\ YR1}\tag{27}
\]

after exactly 156 base steps. This prefix does not use B4. Its successive
actual counter values are 1,3,7,14,28,56; its decoded values are
1,3,7,15,31,63. Thus (27) is a safe checkpoint.

Repeatedly apply the return theorem. Either the explicit spinout is
reached, or there are arbitrarily many returns, each taking a positive
number of base steps. Neither possibility is compatible with finite
halting. Therefore

\[
\neg\mathrm{Halts}(M_{1RA},\mathrm{blank}),\qquad
\neg\mathrm{Halts}(M_{0LA},\mathrm{blank}),\qquad
\neg\mathrm{Halts}(M_{2LB},\mathrm{blank}).
\]

This argument does not assume eventual growth, a numerical simulation
cutoff, or an unproved congruence property of the blank run.

## 9. Why this does not automatically prove 1LB

The invariant cannot simply be assigned to every bouncing member. For
1LB, the perfectly Good positive checkpoint

\[
L\,XZXWXW\ <B1\ YR1
\]

halts. Its counter value is one. Direct base simulation makes 203 defined
transitions and the 204th call detects the undefined A4 transition. This
is an exact finite counterexample to the universal Good-checkpoint return
claim for 1LB, NOT a claim that the blank-tape 1LB machine halts.

The underlying cause is different from (20)-(21): its low-counter reset
can introduce a paid pop followed by an unpaid pop, producing a zero B
checkpoint whose next F/G passage has insufficient counter. A proof for
1LB must exclude such histories from the blank run or use a different
invariant. Nothing here decides 1LB or the other remaining members.

## 10. Recorded finite checks

`verify_more.py` implements the constructive returns independently of the
archive's block simulator and compares the exact returned stacks with it.
The completed recorded run uses all 31,259 Good positive stacks of length
at most ten and 200 larger randomized Good stacks. For each of the three
members this gives 31,459 exact return comparisons, or 94,377 total. The
three 156-base-step seeds are also checked directly.

`check_more_components.py` additionally records:

- 1,377,307 clean Dyck-prefix checks of (11), through length sixteen;
- 144,132 four-divisibility barrier checks and 342 even-equality checks;
- 5,880 repair instances, including 236 actual non-Good repairs compared
  exactly against the reference simulator;
- 3,285 weaker-drain stack instances, including 153 that are NOT Good;
- 3,000 unaccelerated block-to-base transition comparisons;
- the explicit nonblank 1LB halting checkpoint above.

All recorded assertions passed. These finite checks support consistency
of the implementation and the derivation, but do not certify the infinite
conclusion in a proof assistant. Formal certification still requires the
new lemmas and return theorem described in `FORMALIZATION_MORE.md`.
