# Research notes and remaining obstructions

Date: 2026-09-16.

## 1. The missing bit of checkpoint information

The earlier proof interface allowed every Good positive B stack. Actual
completed reset/drain returns have a further structural property: their
last block is X. Preserving this property is much stronger than merely
requiring an even numerical counter, because it identifies the actual top
block. The new proof uses the block suffix, not just parity.

The old 1LB counterexample `XZXWXW` has positive value one but ends in W,
so it is outside the new theorem. The new theorem is not an attempt to
ignore or reclassify that counterexample: it changes the quantified class
and proves that the smaller class contains the seed and is return-closed.

In the marker cases, k>=1 stripped X's give r=k+1>=2. At the first new B
checkpoint the marker is under `Z^(r-1) X`; B therefore reads Z, not the
marker. This leads to the closed reset words in the proof.

## 2. What the finite comparisons tested

The constructive return functions predict an exact pure-stack endpoint
using counter operations and reset formulas. The reference checker uses
`bstep` and its original left stride, copied from the Aristotle archive.
It does not call those new return functions to predict an endpoint.

Comparison stops at the first subsequent Good positive X-ending checkpoint
with the normal right suffix YR1, or at the common XY spinout. Marker-bearing
intermediate B configurations and the single possible 1LB non-Good
checkpoint are not incorrectly treated as successful endpoints.

The recorded tests include every qualifying stack through length eleven,
not merely prefixes seen from blank tape. Additional tests exercise long
marker intervals, source counters two through seventeen plus 33 and 65,
and exceptional resets independently of complete normal returns.

These tests still depend on the accuracy of the underlying simulator and
are finite. The local block rules are separately replayed against the base
machine; their original Lean soundness development remains the intended
formal source of truth.

## 3. A real boundary for the new invariant

For BOTH 1LA and 0RB, the normal checkpoint

```
L Z X Z W W X <B1 Y R1
```

has a Good stack, final X, and value two, but halts from that nonblank
configuration. The component checker confirms 76 defined base transitions
before the undefined A4 step for 1LA, and 108 for 0RB.

The critical W source is C=`ZXZW`, value two. The two F/G decrements leave
`XXZW`, a zero counter with a matched group still present. The 1LA G rule
immediately starts B on that zero counter. A later B encounter with W
creates a fatal F/G sequence. The analogous 0RB path returns B from its
J0 marker and has the same fundamental obstruction.

Thus merely extending Normal to these two members is false. An invariant
for their blank runs must exclude some normal stacks, track the origin or
matched-group history of reset stacks, or use a different return relation.
Nothing here says their blank runs halt.

## 4. 0LB: an incomplete local interface, not a halting certificate

For 0LB, starting from the Good X-ending stack `ZZWX` at the normal B
marker, the current block simulator reaches a pending P2 before N2=201,
which its table does not handle. N2 itself has no symbol 4. An undefined
block rule here must not be mistaken for an undefined base-machine
transition. This case may require additional longitudinal rules before
an invariant search in the existing block alphabet is meaningful.

## 5. Formalization scope

The two marker-only return arguments (0RA/2RB and 2RA) do not require the
new mod-8 barrier; they use the previous Good/reset/drain interface plus the
explicit local clock. The 1LB and 1RB arguments additionally require the
counted-expansion lemma and its strengthened corollary.

For 2RA all resulting reset words are clean and positive from zero, with
no special low-counter repair. For 0RA/2RB there is one odd-terminal repair.
This separation permits the marker branches to be formalized before the
more delicate one-unit repair and 1RB early-reset branches.
