# BB(2,5): 1LA nonhalting argument and reductions for the last two members

Date: 2026-09-16.

## What this package claims

A new proposed complete mathematical nonhalting proof for

```
1LA: 1RB2LA0RB1LB---_1LA3RA1RA4LB1LA
```

It is NOT a Lean-certified result. The new invariant, reverse-debt lemma,
comparison lemma, and exact return theorem have not been compiled in Lean.
The proof depends on the counter/reset interface and common-Z arguments in
the supplied Aristotle project and the earlier proposed proof packages.

There is NO completed nonhalting proof for 0RB or 0LB in this package. Their
exact local reductions and remaining gaps are documented separately. All
counterexamples concern specified NONBLANK inputs, not their blank runs.

## Main documents

- `PROOF_1LA.md`: the full new mathematical nonhalting proof.
- `FORMALIZATION_1LA.md`: detailed formalization order, actual source entry
  points, arithmetic identities, and the precise new lemmas to certify.
- `REMAINING_0RB_0LB.md`: proved finite marker/scan reductions for 0RB, the
  newly covered pending-N/H rules, failed invariants, and unresolved goals.

## Executable checks (Python standard library only)

Run from this directory with Python 3.10 or later:

```
python verify_last.py --max-length 12 --random 250
python check_components.py
python check_0RB_scan.py
python probe_remaining.py --max-length 12
```

`last_core.py` implements the constructive 1LA return and new lemma checks.
`remaining_tools.py` implements the new local rules and exact 0RB scan.
The reference simulator in `prior/previous/reference_tools/` is unchanged.

The default commands overwrite their corresponding local JSON result files.
They do not contact any network service. Search/reference step limits in
experiments are explicit; they are not treated as mathematical bounds on
arbitrary inputs.

## Completed recorded checks

The recorded `verification_last.json` contains 90,392 exact 1LA return
comparisons: 90,135 exhaustive admissible checkpoint instances through
length twelve, 250 randomized longer inputs, and seven constructed long
families. It separately replays the 156-step blank seed and 3,000
unaccelerated base/block transitions.

`component_results_last.json` includes 33,175 debt-interpreter comparisons,
179,181 dual-credit instances, 16,044 complete common-Z checks, 1,036,827
binary reverse-step checks, 2,046 exact marker returns, 2,275 new/combined
base-rule checks, and direct nonblank halting-counterexample replays.

`scan_0RB_results.json` records 9,830 exact finite scan comparisons.
`remaining_probe_results.json` records candidate-invariant experiments for
0RB, explicitly NOT a universal return theorem. In particular it preserves
counts showing why a narrower Dyck-reset-image predicate should not simply
be assumed invariant.

All recorded verifier assertions passed. Finite tests are checks for errors,
not the proof of the infinite conclusion.

## Prior work and provenance

`prior/` is the previously supplied five-member extension package, including
its earlier packages and the original Lean source snapshot. It is included
to make the present mathematical dependencies and Python imports available
without downloading another artifact. Its proof status is not upgraded by
being copied here.

`PACKAGE_QA.json` records byte-for-byte checks of the reference simulator
against the original archive, syntax checks, result status checks, and
clean-copy smoke tests. `SHA256SUMS.json` hashes the deliverable files other
than itself. The ZIP excludes Python bytecode caches.
