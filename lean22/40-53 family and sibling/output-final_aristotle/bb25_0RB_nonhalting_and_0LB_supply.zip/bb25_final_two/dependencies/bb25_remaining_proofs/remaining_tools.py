#!/usr/bin/env python3
"""Exact local reductions for 0RB and the missing 0LB interface.

These are NOT complete nonhalting proofs for either remaining member.
The original reference simulator remains unchanged.
"""
from __future__ import annotations
from last_core import *
import sim as base

LDEN=dict(ref.LDEN,H=[3,1]) # H=13, represented nearest-to-head first.

def denote(lt:list[str],st:str,rt:list[str]):
    l=[x for b in lt for x in LDEN[b]]
    r=[x for b in rt for x in ref.RDEN[b]]
    return (l,base.A,'R',r) if st=='R' else ((l,base.A,'L',r) if st=='L' else (l,base.B,'L',[1]+r))

def extended_bstep(member:str,lt:list[str],st:str,rt:list[str]):
    """Adds five uniform finite rules; does not turn unknown cases into halts."""
    if st=='R' and len(rt)>=2 and rt[0] in ('P1','P2') and rt[1] in ('N1','N2'):
        if rt[0]=='P1':return lt,'L',['P2']+rt[1:],1
        block='W' if rt[1]=='N1' else 'Z'
        return ['H',block]+lt,'R',rt[2:],4
    if st=='L' and lt and lt[0]=='H':return lt[1:],'B',['P2']+rt,4
    return ref.bstep(member,lt,st,rt)

def dyck_words(length:int,prefix:str='',height:int=0):
    if length==0:
        yield prefix
        return
    yield from dyck_words(length-1,prefix+'Y',height+1)
    if height:
        yield from dyck_words(length-1,prefix+'X',height-1)
        yield from dyck_words(length-1,prefix+'V',height-1)

def dyck_height(w:str)->int:
    h=0
    for ch in w:
        if ch not in 'YXV':raise ValueError('not a colored parenthesis word')
        h+=1 if ch=='Y' else -1
        if h<0:raise ValueError('not a parenthesis prefix')
    return h

def right_marker_return(w:str)->str:
    """Exact first A-left return above an untouched marker: F(w)=w X^h V."""
    return w+'X'*dyck_height(w)+'V'

def right_marker_reference(w:str,limit:int=200000):
    dyck_height(w)
    lt=['J0','L'];st='R';rt=list(w)+['R'];cost=0
    for i in range(limit):
        if st=='L' and lt==['J0','L']:
            assert rt[-1]=='R'
            return ''.join(rt[:-1]),i,cost
        stride=ref.stride(lt) if st=='L' else None
        if stride:lt,k=stride;st='R'
        else:lt,st,rt,k=ref.bstep('0RB',lt,st,rt)
        cost+=k
    raise RuntimeError('finite reference limit exceeded')

def inverse_reset(s:Stack)->str|None:
    """Unique inverse paid-reset word, or None when the required carry overflows."""
    def inc(t):
        positions=[]
        for i,ch in enumerate(t):
            if ch in ('X','Z'):positions.append(i)
            elif not positions:return None
            else:positions.pop()
        ans=list(t)
        for i in reversed(positions):
            if ans[i]=='X':ans[i]='Z';return tuple(ans)
            ans[i]='X'
        return None
    out=[]
    while s:
        if s[-1]=='W':
            s=inc(s)
            if s is None:return None
            out.append('X');s=s[:-1]
        else:
            out.append('Y' if s[-1]=='Z' else 'V');s=s[:-1]
    return ''.join(reversed(out))

def strict_admissible(s:Stack)->bool:
    h=0
    for ch in s:
        if ch not in 'XZW':return False
        h+=1 if ch!='W' else -1
        if h<=0:return False
    return True

def halt_from_checkpoint(member:str,s:Stack,limit:int=1000000):
    """Direct base replay, reporting defined transitions BEFORE the undefined A4."""
    machine=base.machine(ref.machineB4(member))
    c=ref.denote(list(reversed(s))+['L'],'B',['Y','R1'])
    for n in range(limit):
        nxt=base.step(machine,c)
        if nxt is None:
            side=c[0] if c[2]=='L' else c[3]
            scanned=side[0] if side else 0
            assert c[1]==base.A and scanned==4
            return n,c
        c=nxt
    raise RuntimeError('base replay limit exceeded; not a halting result')

def scan_0RB(s:Stack):
    """Exact finite left B-scan until the next unmarked Z or bottom spinout.

    Hypothesis: normal(s), using the 1LA Ready predicate. This does NOT
    claim that the Z excursion regenerates the hypothesis for 0RB.
    Result: (kind, left_stack_at_Z, canonical_right_blocks, W_event_count).
    """
    if not normal(s):raise ValueError('scan requires a Good, positive, X-ending Ready stack')
    r=1;events=0
    while s and s[-1]=='X':s=s[:-1];r+=1
    if not s:return 'spinout',(),[],0
    if s[-1]=='Z':return 'Z',s,['Y']*r+['R1'],0
    c=s[:-1]
    assert value(c)>=2 and r>=2
    s=decn(c,2);events=1
    # First marker has the old odd terminal. The explicit local-clock theorem
    # in the prior package supplies its first leftward marker-return word.
    w='Y'+prev.return_word(r)
    dyck_height(w)
    while s:
        if s[-1]=='Z':return 'Z',s,list(w)+['R'],events
        if s[-1]=='X':s=s[:-1];w='Y'+w;continue
        c=s[:-1];assert value(c)>=2
        s=decn(c,2);events+=1
        w='Y'+right_marker_return(w)
        assert dyck_height(w)==0
    return 'spinout',(),[],events

def scan_0RB_reference(s:Stack,limit:int=200000):
    lt=list(reversed(s))+['L'];st='B';rt=['Y','R1'];cost=0
    for i in range(limit):
        if st=='B' and lt==['L']:return 'spinout',None,i,cost
        if st=='B' and lt[0]=='Z' and all(x in ('X','Z','W','L') for x in lt):
            return 'Z',ref.denote(lt,st,rt),i,cost
        stride=ref.stride(lt) if st=='L' else None
        if stride:lt,k=stride;st='R'
        else:lt,st,rt,k=ref.bstep('0RB',lt,st,rt)
        cost+=k
    raise RuntimeError('reference scan limit exceeded')
