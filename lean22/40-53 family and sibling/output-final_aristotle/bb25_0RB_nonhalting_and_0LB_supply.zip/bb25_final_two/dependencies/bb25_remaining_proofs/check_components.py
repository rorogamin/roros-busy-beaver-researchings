#!/usr/bin/env python3
"""Independent finite checks of new lemmas and exact remaining-member reductions."""
from last_core import *
from remaining_tools import *
from itertools import product
from collections import Counter
import json,time

def subtract(s:Stack,n:int)->Stack:
    """Independent direct binary subtraction on the unmatched positions."""
    active=[]
    for i,ch in enumerate(s):
        if ch in ('X','Z'):active.append(i)
        else:active.pop()
    v=value(s)
    if not 0<=n<=v:raise ValueError('subtraction underflow')
    out=list(s);v-=n
    for i in reversed(active):out[i]='Z' if v&1 else 'X';v//=2
    assert v==0
    return tuple(out)

def main():
    start=time.time();ct=Counter();details={}
    for length in range(1,10):
        for letters in product('YVX',repeat=length):
            w=''.join(letters);f=adjusted(w)
            if f<0:continue
            s=reset((),w)
            for n in sorted({0,min(f,1),min(f,2),min(f,3),f//2,f}):
                t=subtract(s,n)
                ans=reset_debt_scan(w,n)[0]
                assert ans==b_scan(t).kind,(w,n,ans,b_scan(t))
                ct['debt_vs_concrete_B_scan']+=1
            assert inverse_reset(s)==w
            ct['inverse_reset_roundtrip']+=1
        print('debt length',length,dict(ct),flush=True)
    for length in range(1,10):
        for s in product('XZW',repeat=length):
            a=value(s)
            if a<2 or not good(s):continue
            t=reset((),decode(s))
            for n in range(a//2):
                assert dual_credit(s,n)[0]=='Z'
                assert b_scan(subtract(t,n)).kind=='Z'
                ct['dual_credit_all_debts']+=1
        print('credit length',length,ct['dual_credit_all_debts'],flush=True)
    for length in range(0,9):
        for c in product('XZW',repeat=length):
            if not good(c):continue
            for r in (2,3,4,7):
                ans=certify_z(c,r)
                ct['common_Z_all_cases']+=1
                if value(c)>=2:ct['exact_direct_Z_word']+=1
                elif ans[0]=='spinout':ct['small_Z_spinout']+=1
                else:ct['small_Z_ready']+=1
        print('Z length',length,ct['common_Z_all_cases'],flush=True)
    for mm in range(1,100001):
        n=0;M=1
        for ch in reversed(chi(mm)):
            if ch=='X':n=2*n+4;M*=2
            else:
                if n%2:break
                n//=2;M=2*M+1
            assert n+4<=4*M
            ct['binary_reverse_steps']+=1
        else:
            assert M==mm
            if n%2:assert 2*mm-n>=9;ct['binary_odd_debt_margin']+=1
        ct['binary_values']+=1
    for length in range(0,10):
        for w in dyck_words(length):
            out,steps,cost=right_marker_reference(w)
            assert out==right_marker_return(w),(w,out,right_marker_return(w))
            assert steps>0 and cost>0
            ct['right_marker_exact_returns']+=1
        print('marker length',length,ct['right_marker_exact_returns'],flush=True)
    lefts=[['L'],['X','L'],['Z','W','X','L'],['H','L'],['J0','Z','L']]
    rights=[['R'],['Y','R'],['X','V','R'],['G','R'],['N2','R1']]
    for member in ref.GRULE:
        machine=base.machine(ref.machineB4(member))
        for lt in lefts:
            for rt in rights:
                for p in ('P1','P2'):
                    for nblock in ('N1','N2'):
                        c=denote(lt,'R',[p,nblock]+rt)
                        l2,s2,r2,k=extended_bstep(member,lt,'R',[p,nblock]+rt)
                        for _ in range(k):c=base.step(machine,c);assert c is not None
                        assert c==denote(l2,s2,r2)
                        ct['new_uniform_base_rules']+=1
                c=denote(['H']+lt,'L',rt)
                l2,s2,r2,k=extended_bstep(member,['H']+lt,'L',rt)
                for _ in range(k):c=base.step(machine,c);assert c is not None
                assert c==denote(l2,s2,r2);ct['new_uniform_base_rules']+=1
                for b,cost,outst,outr in [('W',6,'L',['F','P2']),('Z',8,'L',['X','Y'])]:
                    c=denote(['H',b]+lt,'L',rt)
                    for _ in range(cost):c=base.step(machine,c);assert c is not None
                    assert c==denote(lt,outst,outr+rt)
                    ct['combined_H_rules']+=1
    examples=[('1LA','ZXZWWX',76),('0RB','ZXZWWX',108),('0RB','ZWZZXWX',1560),
              ('0LB','ZXZX',225),('0LB','ZZXXWZX',571),('0LB','ZZZXXXWWXXWX',40225)]
    details['nonblank_halting_counterexamples']=[]
    for member,s,expected in examples:
        count,c=halt_from_checkpoint(member,tuple(s));assert count==expected
        record={'member':member,'stack':s,'defined_base_transitions_before_A4':count,
                'good':good(tuple(s)),'ready_1LA':b_scan(tuple(s)).kind!='HALT',
                'strict_admissible':strict_admissible(tuple(s)),
                'inverse_reset_word':inverse_reset(tuple(s))}
        details['nonblank_halting_counterexamples'].append(record)
        ct['base_halting_counterexample_replays']+=1
    out={'status':'all assertions passed','scope':'finite checks, not formal certificates',
         'counts':dict(ct),'details':details,'elapsed_seconds':round(time.time()-start,3)}
    (HERE/'component_results_last.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':main()
