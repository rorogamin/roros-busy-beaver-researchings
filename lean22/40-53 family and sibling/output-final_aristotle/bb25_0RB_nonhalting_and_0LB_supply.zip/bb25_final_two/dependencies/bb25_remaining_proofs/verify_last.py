#!/usr/bin/env python3
"""Independent finite checks for the proposed 1LA nonhalting proof."""
from last_core import *
from itertools import product
from collections import Counter
import argparse,json,random,time
import sim as base

def reference(s:Stack,limit:int=200000):
    lt=list(reversed(s))+['L'];st='B';rt=['Y','R1'];base_count=0
    for i in range(limit):
        if i and st=='B' and rt==['Y','R1']:
            return 'B',tuple(reversed(lt[:-1])),i,base_count
        if st=='B' and lt==['L']:return 'spinout',(),i,base_count
        if st=='L' and lt==['L'] and ref.denote(lt,st,rt)[3][:4]==[1,1,2,2]:
            return 'spinout',(),i,base_count
        stride=ref.stride(lt) if st=='L' else None
        if stride is not None:lt,k=stride;st='R'
        else:lt,st,rt,k=ref.bstep('1LA',lt,st,rt)
        base_count+=k
    raise AssertionError('reference limit exceeded')

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--max-length',type=int,default=11)
    ap.add_argument('--random',type=int,default=100)
    ap.add_argument('--output',type=Path,default=HERE/'verification_last.json')
    args=ap.parse_args()
    if not 2<=args.max_length<=13:ap.error('max-length must be 2..13')
    rng=random.Random(2026091604);ct=Counter();branches=Counter();start=time.time();maxref=0
    def check(s,category):
        nonlocal maxref
        if not normal(s):return
        sk=b_scan(s);kind,out=successor_1LA(s)
        rk,rs,steps,base_steps=reference(s)
        assert (kind,out)==(rk,rs),(s,(kind,out),(rk,rs))
        assert base_steps>0
        ct[category]+=1;ct['exact_returns']+=1
        branches['W_events_'+str(sk.w_events)]+=1
        if sk.kind=='Z':
            a=value(sk.stack[:-1]);branches['Z_counter_'+(str(a) if a<3 else '3+')]+=1
        maxref=max(maxref,steps)
    for n in range(2,args.max_length+1):
        for p in product('XZW',repeat=n-1):check(p+('X',),'exhaustive')
        print('length',n,dict(ct),'seconds',round(time.time()-start,2),flush=True)
    made=0
    while made<args.random:
        s=()
        for _ in range(rng.randrange(20,100)):
            if value(s)>=2 and rng.random()<.42:s=decn(s,2)+('W',)
            else:s+=(rng.choice(('X','Z')),)
        if value(s)==0:s+=('Z',)
        s+=('X',)
        if not normal(s):continue
        check(s,'random');made+=1
    # Long repeated zero-pair families make the first new checkpoint lose its
    # leading one. These exercise the proof beyond a half-full invariant.
    for h in range(2,9):
        w='Y'*h+'VX'*(2**(h-1)-1)+'YV'
        check(reset((),w),'constructed_long')
    seed=tuple('ZZZXXX');machine=base.machine(ref.machineB4('1LA'))
    c=([],base.A,'R',[])
    for _ in range(156):c=base.step(machine,c);assert c is not None
    assert c==ref.denote(list(reversed(seed))+['L'],'B',['Y','R1'])
    assert normal(seed)
    ct['blank_seed_base_steps']=156
    assert ref.crosscheck('1LA',3000)=='ok';ct['base_block_crosschecks']=3000
    out={'status':'all assertions passed','scope':'finite checks, not a Lean certificate',
         'member':'1LA','max_exhaustive_length':args.max_length,
         'counts':dict(ct),'branches':dict(branches),'max_reference_steps':maxref,
         'elapsed_seconds':round(time.time()-start,3)}
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':main()
