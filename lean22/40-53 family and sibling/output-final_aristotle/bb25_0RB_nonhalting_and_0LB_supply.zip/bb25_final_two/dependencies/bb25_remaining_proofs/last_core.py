#!/usr/bin/env python3
"""Constructive 1LA return and new reset/B-scan lemmas.

All stacks are bottom first, without L. This is executable mathematical
content, NOT a Lean certificate. Independent finite checks are in verify_last.py.
"""
from __future__ import annotations
from pathlib import Path
import sys
from dataclasses import dataclass
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'prior'))
import verify_next as prev
m=prev.m; ref=m.ref
value=prev.value; good=prev.good; decode=prev.decode; dec=prev.dec
reset=prev.reset_from; adjusted=prev.adjusted; decn=prev.decn
Stack=tuple[str,...]

@dataclass(frozen=True)
class BScan:
    kind:str
    stack:Stack
    r:int
    w_events:int


def b_scan(s:Stack,r:int=1)->BScan:
    """1LA B phase. HALT means the F/G two-decrement supply failed."""
    q=0
    while s:
        if s[-1]=='Z':return BScan('Z',s,r,q)
        if s[-1]=='X':s=s[:-1];r+=1;continue
        if s[-1]!='W':raise ValueError('not an ordinary stack')
        s=s[:-1]
        if value(s)<2:return BScan('HALT',s,r,q)
        s=decn(s,2);q+=1;r+=1
    return BScan('spinout',(),r,q)


def reset_debt_scan(w:str,n:int=0,d:int=2)->tuple[str,int,int]:
    """B scan on D^n(T(w)); d A-decrements per removed W.

    Reverse reset X adds its own two old decrements before the d new ones.
    The parity stops are independent of the initial reset counter.
    """
    f=[0]
    for ch in w:f.append(m.old.adjusted_step(f[-1],ch))
    if any(v<0 for v in f) or n<0 or n>f[-1]:raise ValueError('invalid paid reset/debt')
    for i in range(len(w)-1,-1,-1):
        if w[i]=='X':
            n=2*n+2+d
            if n>f[i]:return ('HALT',i,n)
        elif w[i]=='Y':
            if n%2==0:return ('Z',i,n//2)
            n//=2
        elif w[i]=='V':
            if n%2:return ('Z',i,(n+1)//2)
            n//=2
        else:raise ValueError(w[i])
    return ('spinout',0,n)


def dual_credit(c:Stack,n:int=0)->tuple[str,int,int]:
    """Good(c), v(c)>=2*n+2 certify a safe B scan on D^n(T(P(c))).

    Executes the proof's induction: peel a maximal zero-colored close run,
    then stop on Y or apply the smaller-prefix induction after V.
    """
    if not good(c) or n<0 or value(c)<2*n+2:raise ValueError('dual-credit hypotheses')
    original=decode(c); initial_n=n
    while c:
        a=value(c); b=adjusted(decode(c))
        assert good(c) and a>=2*n+2 and b>=a
        word=decode(c)
        j=0
        while j<len(word) and word[-1-j]=='X':j+=1
        if j:
            before=c[:-j]
            assert c[-j:]==('W',)*j
            old_n=n
            n=2**j*(n+4)-4
            assert value(before)==2**j*a
            assert adjusted(decode(before))>=2**j*(b+2)-2
            assert adjusted(decode(before))-n>=2
            c=before;word=word[:-j]
            assert word
            if word[-1]=='Y':
                assert n%2==0
                ans=reset_debt_scan(original,initial_n)
                assert ans[0]=='Z'
                return ans
        ch=word[-1]
        if ch=='Y':
            if n%2==0:
                ans=reset_debt_scan(original,initial_n);assert ans[0]=='Z';return ans
            c=c[:-1];n//=2
        elif ch=='V':
            if n%2:
                ans=reset_debt_scan(original,initial_n);assert ans[0]=='Z';return ans
            c=c[:-1];n//=2
        else:raise AssertionError((c,n,ch))
        assert good(c) and value(c)>=2*n+2
    raise AssertionError('positive supply cannot reach the empty source')


def chi(m0:int)->str:
    """Lower binary digits of m>=1, least significant first; 0=X, 1=V."""
    if m0<1:raise ValueError('m must be positive')
    return ''.join('V' if b=='1' else 'X' for b in bin(m0)[3:][::-1])


def z_word(a:int,r:int)->str:
    if a<2 or r<2:raise ValueError('direct Z hypotheses')
    return ('V' if a%2 else 'X')+'Y'*r+'V'+'X'*(r-1)+chi(a//2)+'V'


def certify_z(c:Stack,r:int)->tuple[str,Stack]:
    """Common Z return, plus the new assertion that its next B phase is safe."""
    if not good(c) or r<2:raise ValueError('Z return hypotheses')
    kind,out=m.common_Z(c,r)
    if kind=='spinout':return kind,out
    a=value(c)
    if a>=2:
        word=z_word(a,r)
        assert out==reset(reset((),decode(c)),word)
        mm=1;n=0;stopped=False
        for ch in reversed(chi(a//2)):
            assert n+4<=4*mm
            if ch=='X':mm*=2;n=2*n+4
            else:
                if n%2:stopped=True;break
                mm=2*mm+1;n//=2
            assert n+4<=4*mm
        if not stopped:
            assert mm==a//2
            if n%2:assert 2*mm-n>=9
            if r==2 and n%4==1:
                k=(n-1)//4
                if a%2==0:
                    k=2*k+4
                    assert 2*k+2<=a
                    dual_credit(c,k)
                elif k%2==0:
                    k//=2
                    assert 2*k+2<=a
                    dual_credit(c,k)
        # Independent from the arithmetic branch derivation, this checks its
        # full-word debt conclusion, including stops within the explicit tail.
        assert reset_debt_scan(decode(c)+word)[0]!='HALT'
    else:
        # The proof separates the direct Z^r X suffix from the odd-terminal
        # exceptional reset, whose clock has at least three opening Y's.
        assert b_scan(out).kind!='HALT'
    assert good(out) and value(out)>0 and out[-1]=='X'
    assert b_scan(out).kind!='HALT'
    return kind,out


def normal(s:Stack)->bool:
    return bool(s) and s[-1]=='X' and good(s) and value(s)>0 and b_scan(s).kind!='HALT'


def successor_1LA(s:Stack)->tuple[str,Stack]:
    if not normal(s):raise ValueError('not a safe 1LA checkpoint')
    scan=b_scan(s)
    if scan.kind=='spinout':return 'spinout',()
    assert scan.kind=='Z' and scan.r>=2 and good(scan.stack[:-1])
    kind,out=certify_z(scan.stack[:-1],scan.r)
    assert kind=='spinout' or normal(out)
    return kind,out
