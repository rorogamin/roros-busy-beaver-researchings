# 0LB: a four-decrement supply certificate and a complete one-return theorem

Date: 2026-09-16.
Machine: `1RB2LA0RB1LB---_1LA3RA1RA4LB0LB`.

## Status

This document proves new finite-scan and finite-return theorems. It does NOT
claim nonhalting from blank. The remaining closure statement is isolated in
Section 7, and its computational support is explicitly distinguished from a
proof. No new result here has been checked by Lean.

The notation and Good/counter/reset interfaces are those of PROOF_0RB.md and
the preceding packages. All stacks are bottom first. The permanent L is omitted.

## 1. A numerical certificate for the entire four-decrement B scan

Define the integer-valued energy

    E(empty)=0;
    E(sX)=2E(s);
    E(sZ)=2E(s)+1;
    E(sW)=floor(E(s)/2)-2.                                      (1)

For every admissible stack s there is a nonnegative integer cost K, depending
only on the matching, its matched bits, and the unmatched positions, such that

    E(s)=v(s)-K.                                                (2)

In particular a successful counter decrement satisfies

    E(D(s))=E(s)-1.                                            (3)

To prove (2), decompose the stack into unmatched bits and balanced groups.
Each balanced group acts on the incoming E by subtracting an integer K that
is independent of that incoming value. An opening bit beta, an interior cost
k, and its closing W act by

    z -> floor((2z+beta-k)/2)-2
      = z-[ceil((k-beta)/2)+2].

The cost is at least two. Forests add costs, and unmatched bits multiply all
older costs by two. The actual counter ignores balanced groups. Thus (2)
follows, including the independence of K from the values of unmatched bits.
D changes only those unmatched bits, giving (3).

All three maps in (1) preserve negative integers. Therefore E(s)>=0 implies
E(p)>=0 for every prefix p of s.

### Theorem 1: four-scan supply

If s is admissible and E(s)>=0, the following entire B scan is supplied:

    cX -> c;
    cW -> D^4(c);
    stop at Z, or at the bottom spinout.                        (4)

Indeed an X removal preserves nonnegativity of E. At cW, nonnegative energy
means E(c)>=4. Equation (2) gives v(c)>=4, so all four decrements are available.
The new energy is E(c)-4>=0. Each operation removes one block and hence the
scan terminates after at most |s| operations.

For 0LB, (4) is the actual ordinary B-on-W branch: the first two decrements
consume F/G and create N1, and the next two consume N1/N2 and return to B.
Every X or W removal prepends one Y to the right. Thus the theorem excludes
all exceptional pending-N cases throughout this scan, not just at its first W.

Good is also preserved along (4): X removes a prefix suffix, and D preserves
Good. The theorem does not assert that a later Z return preserves E.

## 2. How energy transforms under a paid reset

The energy of a paid reset obeys a second reset arithmetic:

    Y: e -> 2e+1;
    V: e -> 2e;
    X: e -> floor(e/2)-3.                                      (5)

The extra three at X consists of the pop charge two in (1) and the paid
counter decrement one. These formulas follow from T(wX)=D(T(w)W) and (3).
Write rho3 for (5). In particular E(T(w))=rho3(w) for every legal paid reset.

There is also a useful comparison theorem independent of the next right word.

### Theorem 2: normalized energy does not fall under decoder/reset

Let c be Good, t=T(P(c)), h=height(c), and H=height(t). If q is the number of
V letters in P(c), then H=h+2q and

    (E(t)+1)/2^H >= (E(c)+1)/2^h.                               (6)

This theorem allows negative E as well. In particular E(c)>=0 implies
E(t)>=4^q(E(c)+1)-1>=0.

Proof. Before the first V in P(c), the two heights agree. Put a=v(c), b=b(c),
e=E(c), F=E(T(P(c))) for the current prefixes. Inductively,

    F-e >= b-a >=0.                                            (7)

A bit gives the same doubling rule for both differences, with an extra one
in both differences for an original X. At a zero-matched W, the source a is
even, and

    (b-a)'=floor((b-a)/2)-1;
    (F-e)'=floor(F/2)-floor(e/2)-1
            >=floor((F-e)/2)-1.

Good supplies the second inequality in (7) at every new prefix.

Now compare Q=(E+1)/2^height. A source Z and its decoded Y leave Q unchanged;
an original X lowers the source Q by 1/2^(h+1) while leaving the target Q
unchanged. A source W lowers Q by

    (3+(e mod 2))/2^h.

A one-matched W produces a reset V and lowers the target Q by 1/2^(H+1).
At the first such W we have H=h, so the target loses less; afterwards H>=h+2.
A zero-matched W produces reset X and lowers target Q by

    (5+(F mod 2))/2^H.

Once H>=h+2 this is at most 6/(4*2^h), less than the source loss of at least
3/2^h. Thus after the first V, none of the steps can decrease the difference
between target and source Q. Together with (7), this proves (6). QED.

## 3. A protected-prefix class at Z

Call c rooted when

    c=ZZZ t,
    every prefix of t has nonnegative relative height.         (8)

Thus none of the first three one bits is ever matched by a W. If h=height(c)
and a=v(c), then h>=3 and

    a >= 7*2^(h-3).                                            (9)

Consider the following class of Z configurations:

    L c Z <B1 Y^r R1,
    Good(c), rooted(c), E(c)>=0, r>=4.                          (C)

The new theorem is:

### Theorem 3: one complete protected Z return and subsequent B scan

Every configuration in (C) makes a finite, nonhalting run through the common
Z excursion and then the complete four-decrement B scan. It reaches

    L c' Z <B1 Y^r' R1

with

    Good(c'), E(c')>=0, r'>=4.                                  (10)

No pending-N exception is encountered. Crucially, this theorem does NOT yet
assert rooted(c'). Section 7 gives explicit failures of that stronger claim.

The rest of Sections 4--6 proves Theorem 3.

## 4. A lower bound for the decoded reset energy

Let c satisfy (C), a=v(c), e=E(c), t=T(P(c)), F=E(t), and let q count the
one-matched W's. Then

    F >= 3a/7+2.                                               (11)

### No one-matched W

Suppose q=0 and put M=2^h-1. There are three costs:

    C1=M-b(c); C2=a-E(c); C3=M-E(T(P(c))).

All are sums of balanced-group costs weighted by later unmatched bits. A
zero-matched tree whose interior costs are k1,k2,k3 respectively has costs

    floor(k1/2)+1, ceil(k2/2)+2, floor(k3/2)+3.

Induction on forests and trees gives C2<=4C1 and C3<=5C1. For the tree step,
ceil(4k/2)+2<=4(floor(k/2)+1), and
floor(5k/2)+3<=5(floor(k/2)+1).
Good gives C1<=M-a. Therefore

    e>=5a-4M, F>=5a-4M >= 3a/7+4.                              (12)

The last inequality uses M<=8a/7-1 from (9).

### At least one one-matched W

Before the first such W, (12) applies to that prefix, and (7) gives F>=e.
In particular e>=a/4 there. At the first one-matched W the three quantities
change by

    a -> (a-1)/2;
    e -> floor(e/2)-2;
    F -> 2F.

These imply, for the resulting prefix,

    2F >= a+4e+3.                                              (13)

Indeed before the step 4F>=4e, while the required right-hand side afterwards
is (a-1)/2+4floor(e/2)-5<=a/2+2e-5; e>=a/4 suffices.

Equation (13) is then preserved by every bit and pop. The only nontrivial
case is a zero-matched W: a is even and (13) implies the integer inequality
F>=a/2+2e+2. Thus

    2(floor(F/2)-3) >= F-7
        >= a/2+2e-5 >= a/2+4floor(e/2)-5,

which is exactly (13) for the new prefix. A one-matched W only strengthens
(13), using a,e>=0. Nonnegative e at all prefixes follows from E(c)>=0.

At the final prefix, (13) gives F>=a/2+3/2>=3a/7+2 because a>=7. This proves
(11), including both cases.

## 5. Energy through the exact common-Z clock

Since a>=7, no small-counter exception occurs at this Z. Put m=floor(a/2)
and d=X for even a, d=V for odd a. The earlier exact common-Z formula returns
the B stack

    T(P(c) d Y^r V X^(r-1) chi(m) V),                           (14)

where chi(m) lists the lower binary digits of m, least significant first,
with zero X and one V, omitting the leading one.

Under the energy reset maps (5), for r>=4 the buffer has exact effect

    Y^r V X^(r-1): e -> 4e-2.                                 (15)

For even a, (11) and a>=14 give F>=8. After d=X, the energy is
floor(F/2)-3>=1. After the buffer it is

    A=4floor(F/2)-14 >=2F-16 >=12m/7-12.                       (16)

For odd a, it is A=8F-2, which is larger than needed below.

If a>=14, m begins in binary with 111. Let R(m) be the minimum nonnegative
starting energy whose chi(m) has nonnegative final energy under (5). Reversing
the word computes R from zero by

    reverse X: R -> 2R+6;
    reverse V: R -> ceil(R/2).

Starting after the two leading V's in this reverse reconstruction, the
partial binary integer is M=7 and R=0. Put N=R+6. Then

    N <= 6M/7                                                   (17)

is invariant as the remaining bits are reconstructed. X doubles both sides.
For V, M'=2M+1 and N'=ceil(N/2)+3<=N/2+7/2; for M>=7 this is no greater than
6(2M+1)/7. Therefore

    R(m)<=6m/7-6.

The even-case bound (16) is at least this value because m>=7. The odd case
has more credit. The sole smaller possibility a=7 has m=3 and chi(m)=V,
so there is no subtractive X and it is immediate.

All maps (5) preserve negative integers. The final nonnegative energy just
proved therefore implies nonnegative energy at every paid prefix of (14).
The final V preserves its nonnegativity. Hence the returned B stack has
E>=0, and Theorem 1 supplies the entire following B scan.

## 6. The next right exponent is still at least four

The reverse-debt rules for the four-decrement scan on a paid reset are

    X: n -> 2n+6;
    Y: even n stops at Z; odd n -> (n-1)/2;
    V: odd n stops at Z; even n -> n/2.                         (18)

All their supply requirements are already guaranteed by the energy argument.
The final V of (14) is stripped first, leaving n=0.

If the scan stops inside chi(m), an odd debt at V requires that at least two
prior chi letters were crossed: an X can first create debt six, and a V can
then halve it to three. Together with the final V, at least three B blocks
have been removed. Thus the right exponent is r'>=4.

Otherwise let n be the debt after chi. Reversing X^(r-1) and its preceding V
leaves debt

    2^(r-2)(n+6)-3,

which is odd. The last Y is stripped, leaving

    2^(r-3)(n+6)-2,

which is even since r>=4. The next Y therefore stops the scan at Z. It never
reaches P(c)d. At least r+2 B blocks have been removed, so r'>=r+3>=7.

Good persists during the complete scan. If it stops on c'Z with nonnegative
energy, then 2E(c')+1>=0 implies E(c')>=0. This proves (10) and Theorem 3.

## 7. The exact outstanding closure problem

Rootedness is NOT preserved after just one Z cycle. For example,

    c=ZZZ, r=4        -> c'=ZZXZZX, r'=8;
    c=ZZZX, r=4       -> c'=ZXZZWZX, r'=9.

Both transitions are exact outputs of (14) followed by (4). Thus Theorem 3
cannot simply be iterated using its present hypothesis.

The candidate missing theorem is:

    From every configuration in (C), after one or two complete Z cycles
    and their intervening B scans, one returns to (C), with every scan
    supplied; alternatively a previously proved spinout is reached.   (U)

(U) is still UNPROVED. The first cycle is established by Theorem 3. What
remains is to control the special non-rooted output when it occurs, prove
its next Z/reset remains supplied, and show that the next root is restored.
The raw condition "at most two" is not included as a proved invariant.

Finite checks currently support (U): 47,184 cases with rooted c of length
at most twelve, Good(c), E(c)>=0, and r in {4,5,6,9}; 45,868 returned in one
cycle and 1,316 in two. Another 3,000 deterministic randomized longer inputs
returned in one cycle 2,990 times and in two cycles ten times. These counts
are finite observations, not evidence sufficient to assert (U).

Counting one-matched pops alone does not eliminate the second-cycle issue:

    c=ZZZXXWZWXWWZW, r=4

is rooted and Good, has E(c)=0 and two one-matched W's, but its next core is
ZZXZZWZZZWWXZZZX, which is not rooted. Thus even q>=2 is not a shortcut.

The blank machine reaches the common seed after 156 base transitions. The
first two common-Z/B4 cycles take it to a configuration in (C); the complete
finite prefix is replayed in check_push.py. A proof of (U), or a different
closed restriction containing that configuration, would finish the remaining
blank-tape nonhalting argument.

## 8. Relationship to the old pending-N obstruction

The earlier package supplied H=13 and exact pending-N rules:

    A> P2 N1 -> WH A> (4 transitions);
    A> P2 N2 -> ZH A> (4 transitions);
    H <A -> <B1 P2 (4 transitions).

Those rules are still available, but the present approach avoids all early
N1/N2 returns whenever E>=0. It therefore replaces the need to control that
part of the trajectory by an explicit arithmetic condition. The unresolved
question is preservation of adequate energy and prefix protection, not an
uncovered local transition.

Previously saved nonblank halting examples remain valid and are not claimed
to lie in (C) at the appropriate Z boundary. In particular no finite test here
is used to conclude anything infinite about 0LB.
