from roots import *
def return_root(c,r,limit=6):
    for i in range(1,limit+1):
        kind,s=m.common_Z(c,r)
        if kind=='spinout':return 'spinout',i,c,r
        tag,cc,r=bscan_d(s)
        if tag!='Z':return tag,i,cc,r
        c=cc[:-1]
        if root(c) and energy(c)>=0 and r>=4:return 'ok',i,c,r
    return 'limit',limit,c,r
if __name__=='__main__':
 ct=Counter();bad=[]
 for l in range(3,13):
    for tail in product('XZW',repeat=l-3):
        c=('Z',)*3+tail
        if not root(c) or not good(c) or energy(c)<0:continue
        for r in (4,5,6,9):
            tag,steps,cc,R=return_root(c,r);ct[(tag,steps)]+=1
            if tag not in ('ok','spinout') and len(bad)<20:bad.append((''.join(c),r,tag,steps,''.join(cc),R,energy(c),energy(cc),height(cc)))
    print(l,dict(ct),bad[:3],flush=True)
 print('bad',bad)
