# 0RB nonhalting argument and further 0LB reductions

Date: 2026-09-16.

## Result boundary

- **0RB:** a complete proposed mathematical nonhalting return proof from blank,
  in `PROOF_0RB.md`, using explicitly identified earlier interfaces.
- **0LB:** a new four-decrement energy certificate, normalized reset-energy
  theorem, and complete one-Z-return theorem in `PROGRESS_0LB.md`. The proposed
  two-return prefix-recovery statement remains **unproved**.
- **Formal status:** none of the new results has been compiled or certified in
  Lean. `FORMALIZATION_PUSH.md` gives the dependency map and exact open boundary.

The 0RB result would bring the mathematical coverage of this project's family
to twelve of thirteen, conditional on certification/correctness of the complete
composed arguments. This package does not re-certify the other eleven results.

## Main files

`PROOF_0RB.md`: full quantified 0RB argument and all early-reset cases.
`PROGRESS_0LB.md`: proved finite-return theorems versus the unresolved closure.
`FORMALIZATION_PUSH.md`: proposed formalization order, without fabricated proofs.
`core_0rb.py`: constructive exact 0RB return algorithm.
`profiles.py`: independent minimum-credit and reverse-debt calculations.
`energy.py`: 0LB energy and small exploratory checks.
`research.py`: shared imports, four-decrement scan, independent reference returns.
`roots.py`, `roots2.py`: protected-prefix predicate and bounded closure probe.
`check_push.py`: final return and component validation, using only Python's
standard library and the retained prior reference sources.
`random_roots.py`: deterministic randomized two-return conjecture probe.

## Reproduce recorded checks

Use Python 3.10 or newer from this directory. No third-party Python packages
are required. Run the parts separately:

```
python check_push.py --part returns
python check_push.py --part components
python check_push.py --part rooted
python random_roots.py
```

They rewrite the corresponding JSON result and print progress. Higher exhaustive
limits increase the workload rapidly. A reference limit or assertion failure is
an error, never evidence of nonhalting. The `rooted` and `random_roots` commands
include tests of an explicitly UNPROVED conjecture; a successful finite run does
not promote that conjecture to a theorem.

The final recorded return run contains 72,528 exact 0RB endpoint comparisons:
72,173 exhaustive normal inputs through length twelve, 300 longer randomized
inputs and 55 constructed inputs. All assertions passed. The component records
include 18,423 generated-word profiles, 148,684 clean positive-height Dyck words,
104,196 normalized energy-transfer cases and 47,185 protected one-return cases
in the separate rooted record. See the JSON files for the complete counts.

## Provenance and retained work

`dependencies/bb25_remaining_proofs/` is the preceding package retained without
modifying its proof files or reference simulator. It includes the earlier
packages and the original relevant Lean project. `PACKAGE_QA.json` records
fresh-copy smoke tests and hashes of reference files compared with the original
user archive. `SHA256SUMS.json` records package file hashes.

The `exploratory/` directory preserves additional research scripts and logs,
including falsified stronger invariants. It is not the result/certification
entry point. Run those scripts with `PYTHONPATH=.` from this directory. Some
exploratory runs were stopped after partial progress; only explicitly completed
records should be counted as completed checks. The exploratory length-thirteen
0RB log records a separate completed comparison run and is not included in the
principal 72,528 count.

No finite simulation count in this package is an assumption of an infinite
nonhalting argument. The universal 0RB result rests on the mathematical return
proof, and the remaining 0LB closure statement is kept separate throughout.
