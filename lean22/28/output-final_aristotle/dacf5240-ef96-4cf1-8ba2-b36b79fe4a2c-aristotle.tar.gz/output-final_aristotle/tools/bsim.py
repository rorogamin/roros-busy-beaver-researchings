"""Block-level simulator mirroring RequestProject/BB25/Blocks.lean `bstep`.

Left blocks: L W X Z J J1 J0 K0 K1   (nearest the head first)
Right blocks: R R1 R2 U V X Y F G P1 P2 N1 N2
States: Rt (A>), Lt (<A), Bt (<B1)
"""


def gstep(b4, lt, rest):
    table = {
        (2, 'L', 'B'): (lt, 'Lt', ['U', 'P1'] + rest, 3),
        (2, 'R', 'B'): (['J'] + lt, 'Rt', rest, 3),
        (1, 'L', 'B'): (lt, 'Lt', ['X', 'P1'] + rest, 3),
        (1, 'R', 'B'): (['J1'] + lt, 'Rt', rest, 3),
        (0, 'L', 'B'): (lt, 'Lt', ['N1'] + rest, 3),
        (0, 'R', 'B'): (['J0'] + lt, 'Rt', rest, 3),
        (3, 'R', 'A'): (lt, 'Lt', ['X', 'P2'] + rest, 5),
        (2, 'L', 'A'): (lt, 'Lt', ['Y', 'P2'] + rest, 7),
        (2, 'R', 'A'): (['K0'] + lt, 'Rt', rest, 5),
        (1, 'L', 'A'): (lt, 'Bt', ['Y'] + rest, 9),
        (1, 'R', 'A'): (['X'] + lt, 'Rt', ['P2'] + rest, 6),
        (0, 'L', 'A'): (lt, 'Lt', ['V', 'P1'] + rest, 5),
        (0, 'R', 'A'): (['K1'] + lt, 'Rt', rest, 5),
    }
    if b4 not in table:
        return None
    a, b, c, k = table[b4]
    return ((a, b, c), k)


P1TAB = {'R': ['R1'], 'R1': ['X', 'R'], 'R2': ['U', 'R'], 'X': ['X', 'P1'],
         'V': ['U', 'P1'], 'Y': ['U', 'P2'], 'U': ['X', 'P2'], 'P1': ['X'], 'P2': ['U']}
P2TAB = {'R': ['R2'], 'R1': ['V', 'R'], 'R2': ['Y', 'R'], 'X': ['V', 'P1'],
         'V': ['Y', 'P1'], 'Y': ['Y', 'P2'], 'U': ['V', 'P2'], 'P1': ['V'], 'P2': ['Y']}


def bstep(b4, cfg):
    lt, st, rt = cfg
    if st == 'Rt' and rt and rt[0] == 'P1':
        if len(rt) == 1:
            return ((lt, 'Rt', ['R1']), 0)
        b, rest = rt[1], rt[2:]
        if b in P1TAB:
            return ((lt, 'Rt', P1TAB[b] + rest), 0)
    if st == 'Rt' and rt and rt[0] == 'P2':
        if len(rt) == 1:
            return ((lt, 'Rt', ['R2']), 0)
        b, rest = rt[1], rt[2:]
        if b in P2TAB:
            return ((lt, 'Rt', P2TAB[b] + rest), 0)
    if st == 'Rt':
        if rt == [] or rt == ['R']:
            return ((lt, 'Lt', ['V', 'R']), 3)
        if rt == ['R1']:
            return ((lt, 'Lt', ['R2']), 1)
        if rt == ['R2']:
            return ((lt, 'Bt', ['Y', 'R1']), 11)
        b, rest = rt[0], rt[1:]
        if b == 'X':
            return ((lt, 'Lt', ['V'] + rest), 1)
        if b == 'V':
            return ((['W'] + lt, 'Rt', rest), 2)
        if b == 'Y':
            return ((['Z'] + lt, 'Rt', rest), 2)
        if b == 'U':
            return ((lt, 'Lt', ['Y'] + rest), 1)
        if b == 'F':
            return ((lt, 'Lt', ['G'] + rest), 1)
        if b == 'P1' and rest and rest[0] in ('F', 'G'):
            return ((lt, 'Lt', ['P2'] + rest), 1)
        if b == 'N1':
            return ((lt, 'Lt', ['N2'] + rest), 1)
        if b == 'N2':
            return ((lt, 'Bt', ['Y'] + rest), 9)
        if b == 'G':
            return gstep(b4, lt, rest)
        return None
    if st == 'Lt':
        if lt == ['L']:
            return ((['L'], 'Rt', ['P2'] + rt), 4)
        if not lt:
            return None
        b, rest = lt[0], lt[1:]
        tab = {
            'W': ((rest, 'Lt', ['X'] + rt), 2),
            'Z': ((['X'] + rest, 'Rt', rt), 3),
            'X': ((rest, 'Lt', ['Y'] + rt), 2),
            'J': ((['X'] + rest, 'Rt', ['P2'] + rt), 6),
            'J1': ((rest, 'Lt', ['X', 'P2'] + rt), 5),
            'J0': ((rest, 'Bt', ['Y'] + rt), 9),
            'K0': ((['K1'] + rest, 'Rt', rt), 3),
            'K1': ((['X'] + rest, 'Rt', ['P2'] + rt), 4),
        }
        return tab.get(b)
    if st == 'Bt':
        if not lt:
            return None
        b, rest = lt[0], lt[1:]
        tab = {
            'W': ((rest, 'Lt', ['F'] + rt), 2),
            'Z': ((rest, 'Lt', ['X', 'P2'] + rt), 4),
            'X': ((rest, 'Bt', ['Y'] + rt), 6),
        }
        return tab.get(b)
    return None


def show(cfg):
    lt, st, rt = cfg
    arrow = {'Rt': 'A>', 'Lt': '<A', 'Bt': '<B1'}[st]
    return ' '.join(reversed(lt)) + ' ' + arrow + ' ' + ' '.join(rt)


def run(b4, cfg, n, trace=False, pred=None):
    total = 0
    for i in range(n):
        r = bstep(b4, cfg)
        if r is None:
            return ('stuck', cfg, total, i)
        cfg, k = r
        total += k
        if trace:
            print(i, total, show(cfg))
        if pred is not None and pred(cfg):
            return ('hit', cfg, total, i)
    return ('ok', cfg, total, n)
