"""Invariants of the rebuilt counter f: bit-length vs e, intermediate values."""
import sys
from blocksim import GRULE
import fdyn, fastsim as F
from phases import rmap

def trace_word(word):
    """Step-by-step (f,e,c,d) through a reset word; returns list."""
    p = (0,0,0,0); ph = True; out=[]
    for b in word:
        q = p if ph else fdyn.__dict__  # placeholder
    return out

def dec(p):
    c,d,e,f = p
    return (c+2**d, d, e, 2**e-1) if f==0 else (c,d,e,f-1)
def push(p):
    c,d,e,f = p
    return (c,d,e+1,2*f+1)
def pop(p):
    c,d,e,f = p
    return (c,d+1,0,0) if e==0 else (c,d,e-1,f//2)

def steps(word, ph=True):
    p=(0,0,0,0); out=[]
    for b in word:
        q = p if ph else dec(p)
        p = push(q) if b in ('V','Y') else pop(q)
        ph = b in ('Y','U')
        out.append((b,p,ph))
    return out

def collect(member, nsteps, maxof):
    """Return list of (index, word, (c,d,e,f), ph)."""
    ev,stat = [],''
    lt=['L']; rt=['R1']; st='R'; grule=GRULE[member]
    res=[]
    for i in range(nsteps):
        if st=='L' and lt==['L']:
            word=list(reversed(rt)); digits=[]
            for b in word:
                if b in ('X','V','Y','U'): digits.append(b)
                else: break
            ph,p = rmap(True,digits)
            res.append((i,digits,p,ph, word[len(digits)] if len(digits)<len(word) else '$'))
            if len(res)>=maxof: return res,'events'
        if st=='L':
            if F.stride(lt) is not None: st='R'; continue
        if st=='R':
            top=rt[-1]
            if top in ('P1','P2'):
                tbl=F.SHIFT1 if top=='P1' else F.SHIFT2
                if len(rt)==1: rt[-1]='R1' if top=='P1' else 'R2'; continue
                nxt=rt[-2]
                if top=='P1' and nxt in ('F','G'): rt[-1]='P2'; st='L'; continue
                if nxt not in tbl: return res,f'DANGER {top} {nxt}'
                rt.pop(); rt.pop(); rt.extend(tbl[nxt]); continue
            if top=='R': rt.pop(); rt.extend(['R','V']); st='L'; continue
            if top=='R1': rt[-1]='R2'; st='L'; continue
            if top=='R2': rt.pop(); rt.extend(['R1','Y']); st='B'; continue
            if top=='X': rt[-1]='V'; st='L'; continue
            if top=='V': rt.pop(); lt.append('W'); continue
            if top=='Y': rt.pop(); lt.append('Z'); continue
            if top=='U': rt[-1]='Y'; st='L'; continue
            if top=='F': rt[-1]='G'; st='L'; continue
            if top=='N1': rt[-1]='N2'; st='L'; continue
            if top=='N2': rt[-1]='Y'; st='B'; continue
            if top=='G':
                st2,pl,em,k=grule; rt.pop(); rt.extend(reversed(em)); lt.extend(reversed(pl)); st=st2; continue
            return res,f'STUCK A> {top}'
        if st=='L':
            b=lt[-1]
            if b=='L': rt.append('P2'); st='R'; continue
            lt.pop()
            if b=='W': rt.append('X'); continue
            if b=='Z': lt.append('X'); st='R'; continue
            if b=='X': rt.append('Y'); continue
            if b=='J': lt.append('X'); rt.append('P2'); st='R'; continue
            if b=='J1': rt.append('P2'); rt.append('X'); st='L'; continue
            if b=='J0': rt.append('Y'); st='B'; continue
            if b=='K0': lt.append('K1'); st='R'; continue
            if b=='K1': lt.append('X'); rt.append('P2'); st='R'; continue
            return res,f'STUCK {b} <A'
        if st=='B':
            b=lt[-1]
            if b=='L': return res,'SPINOUT'
            lt.pop()
            if b=='W': rt.append('F'); st='L'; continue
            if b=='Z': rt.append('P2'); rt.append('X'); st='L'; continue
            if b=='X': rt.append('Y'); continue
            return res,f'HALTS {b} <B1'
    return res,'ok'

if __name__=='__main__':
    m=sys.argv[1] if len(sys.argv)>1 else '2LB'
    n=int(sys.argv[2]) if len(sys.argv)>2 else 400000
    k=int(sys.argv[3]) if len(sys.argv)>3 else 12
    res,stat=collect(m,n,k)
    print(f'== {m} {stat}')
    for i,w,(c,d,e,f),ph in [(a,b,cc,dd) for a,b,cc,dd,_ in res]:
        st = steps(w)
        # invariant checks along the pass
        mind = min((p[3]+1)/2**p[2] for _,p,_ in st) if st else 1
        bl = f.bit_length()
        # binary prefix / suffix
        s = bin(f)[2:] if f else '0'
        print(f'i={i:7d} e={e:5d} bl={bl:5d} f%64={f%64:3d} minratio={mind:.3f} '
              f'pre={s[:24]} suf={s[-24:]} word={"".join(w)[:40]}')
