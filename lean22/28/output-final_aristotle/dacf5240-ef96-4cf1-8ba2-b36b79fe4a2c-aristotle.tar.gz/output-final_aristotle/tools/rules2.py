"""End-of-tape rules and the 13 family-specific `A> 241` rules."""
from sim import machine, step, show, A, B
from rules import rule, find

B4 = {
    '2LB': (2, 'L', B), '2RB': (2, 'R', B), '1LB': (1, 'L', B), '1RB': (1, 'R', B),
    '0LB': (0, 'L', B), '0RB': (0, 'R', B), '3RA': (3, 'R', A), '2LA': (2, 'L', A),
    '2RA': (2, 'R', A), '1LA': (1, 'L', A), '1RA': (1, 'R', A), '0LA': (0, 'L', A),
    '0RA': (0, 'R', A),
}


def rule_r(name, m, l, q, d, r, maxn=40):
    """right tail is the real end of tape ($): no padding on the right."""
    print(f'--- {name}:  {show((l, q, d, r))} $')
    for n, c in find(m, l, q, d, r, maxn, nr=0):
        print('   ', n, (show(c) + ' $') if c != 'HALT/short' else c)


if __name__ == '__main__':
    m = machine(None)
    print('== end of tape ==')
    rule_r('A> $', m, [], A, 'R', [])
    rule_r('A> 1$', m, [], A, 'R', [1])
    rule_r('A> 2$', m, [], A, 'R', [2])
    print('== left end (L = ^11, i.e. l = [1,1] exactly) ==')
    print('--- ^11 <A')
    for n, c in find(m, [1, 1], A, 'L', [], 40, nl=0):
        print('   ', n, ('^' + show(c)) if c != 'HALT/short' else c)
    print()
    print('== family specific: A> 241 ==')
    for name, b4 in B4.items():
        mm = machine(b4)
        rule(f'[{name}] A> 241', mm, [], A, 'R', [2, 4, 1], maxn=25)
        print()
