from collections import Counter
import sys, leftwords as LW
m=sys.argv[1]; ne=int(sys.argv[2])
out,stat=LW.run(m,10**9,ne)
Ds=[]
for i,w in out:
    c=Counter(w); Ds.append(c['Y']+c['V']-c['X'])
print(m,stat,'len:',[len(w) for i,w in out])
print(m,'D:',Ds)
print(m,'ratios:',[round(Ds[i+1]/Ds[i],3) for i in range(2,len(Ds)-1)])
print(m,'D(n-1)+D(n)-D(n+1):',[Ds[i-1]+Ds[i]-Ds[i+1] for i in range(3,len(Ds)-1)])
sys.stdout.flush()
