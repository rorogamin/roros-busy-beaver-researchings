"""Arithmetic model of the 0RB reset words: forward reset value, cleanliness,
and the reverse two-decrement debt scan of the paid reset stack."""


def rstep(b, a):
    if b == 'Y':
        return 2 * a + 1
    if b == 'V':
        return 2 * a
    if b == 'X':
        return (a // 2) - 1  # floor division; only used with a >= 0
    raise ValueError(b)


def rho(w, a=0):
    for b in w:
        a = rstep(b, a)
    return a


def clean(w, a=0):
    """all prefix values nonnegative (after each letter)"""
    for b in w:
        a = rstep(b, a)
        if a < 0:
            return False
    return True


def height(w):
    h = 0
    for b in w:
        h += 1 if b == 'Y' else -1
    return h


def dyck(w):
    h = 0
    for b in w:
        h += 1 if b == 'Y' else -1
        if h < 0:
            return False
    return True


def scan(w, a0=0):
    """Reverse debt scan of the paid reset stack of `w` over a base of counter a0.

    Returns ('stop', i)   scan stops inside w at position i (safe, no base needed)
            ('enter', n)  scan crosses the whole of w and enters the base with debt n
            ('fail', i, need, have) an X is undersupplied
    """
    n = 0
    for i in range(len(w) - 1, -1, -1):
        d = w[i]
        if d == 'V':
            if n % 2 == 1:
                return ('stop', i)
            n //= 2
        elif d == 'Y':
            if n % 2 == 0:
                return ('stop', i)
            n = (n - 1) // 2
        elif d == 'X':
            need = 2 * n + 4
            have = rho(w[:i], a0)
            if have < need:
                return ('fail', i, need, have)
            n = need
        else:
            raise ValueError(d)
    return ('enter', n)


def w0(r):
    assert r >= 2
    if r == 2:
        return list('YXYYV')
    if r == 3:
        return list('YYVYYV')
    ell = r - 2
    return list('Y' * (ell + 1) + 'V' + 'YYV' + 'X' + 'V' * (ell - 1))


def gen_words(maxops=4, rmax=6):
    """all generated words with at most maxops closure operations"""
    out = []
    frontier = [(w0(r), r, 0) for r in range(2, rmax + 1)]
    out.extend(frontier)
    cur = frontier
    for _ in range(maxops):
        nxt = []
        for (w, r, m) in cur:
            nxt.append((['Y'] + w, r, m))
            h = height(w)
            nxt.append((['Y'] + w + ['X'] * h + ['V'], r, m + 1))
        out.extend(nxt)
        cur = nxt
    return out


def chi(m):
    """binary digits of m below the leading one, least significant first,
    0 -> X, 1 -> V"""
    assert m >= 1
    bits = bin(m)[2:]          # most significant first, leading 1 included
    rest = bits[1:]            # drop the leading one
    return ['X' if c == '0' else 'V' for c in reversed(rest)]
