"""Search for conserved quantities of the block system.

A candidate quantity assigns a weight to every left block, every right block
and every head state, and evaluates a configuration as the sum of the weights
of its blocks plus the weight of its state.  We solve the linear system that
says the quantity is unchanged by every rule of `bstep`, and print a basis of
the solution space (and, for the rules that do change it, the defect).
"""
from fractions import Fraction
import sys
from blocksim import bstep, GRULE, Stuck

LSYMS = ['L', 'W', 'X', 'Z', 'J', 'J1', 'J0', 'K0', 'K1']
RSYMS = ['R', 'R1', 'R2', 'U', 'V', 'X', 'Y', 'F', 'G', 'P1', 'P2', 'N1', 'N2']
STATES = ['R', 'L', 'B']
VARS = ['L:' + s for s in LSYMS] + ['R:' + s for s in RSYMS] + ['S:' + s for s in STATES]
IDX = {v: i for i, v in enumerate(VARS)}


def vec(lt, st, rt):
    v = [0] * len(VARS)
    for b in lt:
        v[IDX['L:' + b]] += 1
    for b in rt:
        v[IDX['R:' + b]] += 1
    v[IDX['S:' + st]] += 1
    return v


def rules(member):
    """All local rules, as (before, after) configurations with a context marker."""
    out = []
    ctxL = ['@L']          # a symbolic tail; represented by leaving it out of both sides
    for st in STATES:
        for lt0 in [[b] for b in LSYMS] + [[]]:
            for rt0 in [[b] for b in RSYMS] + [[]]:
                for lt1 in [[], ['X']]:      # a little context, to reach rules needing 2 blocks
                    for rt1 in [[], ['X']]:
                        lt = lt0 + lt1
                        rt = rt0 + rt1
                        try:
                            r = bstep(member, list(lt), st, list(rt))
                        except Stuck:
                            continue
                        lt2, st2, rt2, k = r
                        out.append(((lt, st, rt), (lt2, st2, rt2)))
    return out


def solve(rows, ncols):
    """Return a basis of the null space of the given rows (list of lists of Fractions)."""
    rows = [list(map(Fraction, r)) for r in rows]
    pivots = []
    r = 0
    for c in range(ncols):
        piv = None
        for i in range(r, len(rows)):
            if rows[i][c] != 0:
                piv = i
                break
        if piv is None:
            continue
        rows[r], rows[piv] = rows[piv], rows[r]
        pr = rows[r]
        inv = Fraction(1) / pr[c]
        rows[r] = [x * inv for x in pr]
        for i in range(len(rows)):
            if i != r and rows[i][c] != 0:
                f = rows[i][c]
                rows[i] = [a - f * b for a, b in zip(rows[i], rows[r])]
        pivots.append(c)
        r += 1
        if r == len(rows):
            break
    free = [c for c in range(ncols) if c not in pivots]
    basis = []
    for f in free:
        v = [Fraction(0)] * ncols
        v[f] = Fraction(1)
        for i, c in enumerate(pivots):
            v[c] = -rows[i][f]
        basis.append(v)
    return basis


if __name__ == '__main__':
    member = sys.argv[1] if len(sys.argv) > 1 else '2LB'
    rs = rules(member)
    rows = []
    seen = set()
    for (a, b) in rs:
        d = [x - y for x, y in zip(vec(*b), vec(*a))]
        t = tuple(d)
        if t in seen or all(x == 0 for x in d):
            continue
        seen.add(t)
        rows.append(d)
    print(f'{member}: {len(rows)} independent-looking rule defects')
    basis = solve(rows, len(VARS))
    print(f'null space dimension {len(basis)}')
    for v in basis:
        print('   ', {VARS[i]: str(x) for i, x in enumerate(v) if x != 0})
