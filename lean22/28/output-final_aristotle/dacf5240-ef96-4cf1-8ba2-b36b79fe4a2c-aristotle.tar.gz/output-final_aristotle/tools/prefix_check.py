"""Independent check of the prefix-safety invariant on real runs.

The left stack is the project's nearest-first list of blocks over {W,X,Z} with
the bottom block L.  For such a stack

    cval([]) = cval([L]) = 0
    cval(X::s) = 2 cval s        cval(Z::s) = 2 cval s + 1
    cval(W::s) = cval s / 2

and the decoder value (the value of the word the overflow would deposit, run
through the reset arithmetic in the adjusted coordinate) is

    bval([]) = bval([L]) = 0
    bval(X::s) = bval(Z::s) = 2 bval s + 1
    bval(W::s) = 2 bval s            if cval s is odd
               = floor(bval s / 2) - 1   if cval s is even

A stack is *good* when cval t <= bval t for every suffix t (= every bottom
prefix of the stack written bottom first).
"""
import sys
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from blocksim import bstep, Stuck


def cval(s):
    v = 0
    for b in reversed(s):
        if b == 'L':
            v = 0
        elif b == 'X':
            v = 2 * v
        elif b == 'Z':
            v = 2 * v + 1
        elif b == 'W':
            v = v // 2
        else:
            raise ValueError('block ' + b)
    return v


def bval(s):
    # process bottom-first
    v = 0
    b_ = 0
    for b in reversed(s):
        if b == 'L':
            v, b_ = 0, 0
        elif b in ('X', 'Z'):
            b_ = 2 * b_ + 1
            v = 2 * v + (1 if b == 'Z' else 0)
        elif b == 'W':
            b_ = 2 * b_ if v % 2 == 1 else (b_ // 2) - 1   # python // is floor
            v = v // 2
        else:
            raise ValueError('block ' + b)
    return b_


def good(s):
    """check cval t <= bval t for every suffix t of the nearest-first list"""
    for i in range(len(s) + 1):
        t = s[i:]
        if cval(t) > bval(t):
            return False, t
    return True, None


def run(member, max_bsteps=200000):
    lt, st, rt = ['L'], 'R', ['R1']
    checkpoints = 0
    total = 0
    for i in range(max_bsteps):
        if st == 'B' and rt == ['Y', 'R1']:
            ok, bad = good(lt)
            v = cval(lt)
            if not ok or v < 1:
                return ('INVARIANT FAILURE', member, i, lt, v, bad)
            checkpoints += 1
        try:
            lt, st, rt, k = bstep(member, lt, st, rt)
        except Stuck as e:
            return ('STUCK', member, i, st, lt[:8], rt[:8], str(e))
        total += k
    return ('ok', member, checkpoints, total)


if __name__ == '__main__':
    for m in ('3RA', '2LA'):
        print(run(m, int(sys.argv[1]) if len(sys.argv) > 1 else 200000))
