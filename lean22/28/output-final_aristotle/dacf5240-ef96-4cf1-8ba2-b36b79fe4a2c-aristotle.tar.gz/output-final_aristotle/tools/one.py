"""Run the accelerated block simulation of a single member for N block steps."""
import sys
from fastsim import run

m = sys.argv[1]
n = int(sys.argv[2]) if len(sys.argv) > 2 else 100000
i, status, lt, st, rt = run(m, n)
print(f'{m:4s} steps {i:9d} {status:40s} |L|={len(lt)} |R|={len(rt)}', flush=True)
