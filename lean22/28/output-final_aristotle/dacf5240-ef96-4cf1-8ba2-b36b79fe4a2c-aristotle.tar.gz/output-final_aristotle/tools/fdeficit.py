"""The deficit invariant: delta = 2^e - (f+1) >= 0, t = (f+1)/2^e.
push: delta -> 2 delta ; pop: delta -> floor(delta/2) ; dec: delta -> delta+1.
So t decreases only at decs, by 2^-e each.  Log per pass:
  t_end, sum of 2^-e over decs, #decs, min height, initial Y-run.
"""
import sys
from fractions import Fraction
from blocksim import GRULE
import finv

def analyse(word):
    e=0; f=0; ph=True
    S=Fraction(0); ndec=0; minh=None; heights=[]
    for b in word:
        if not ph:
            ndec+=1
            S += Fraction(1,2**e)
            if f==0: return None   # borrow: c increases (not in our regime)
            f -= 1
        if b in ('V','Y'):
            f = 2*f+1; e+=1
        else:
            if e==0: return None
            f//=2; e-=1
        ph = b in ('Y','U')
        heights.append(e)
    return e,f,S,ndec,(min(heights) if heights else 0)

if __name__=='__main__':
    ms = sys.argv[1:] or list(GRULE)
    for m in ms:
        res,stat = finv.collect(m,400000,14)
        print(f'=== {m} {stat}')
        for i,w,(c,d,e,f),ph,after in res:
            a = analyse(w)
            if a is None:
                print(f'  |w|={len(w):6d} (borrow)'); continue
            e2,f2,S,ndec,minh = a
            yrun=0
            for b in w:
                if b=='Y': yrun+=1
                else: break
            t = Fraction(f+1,2**e) if e else Fraction(1)
            print(f'  |w|={len(w):6d} e={e:6d} Yrun={yrun:5d} minh={minh:5d} ndec={ndec:6d} '
                  f'S={float(S):.6f} t={float(t):.9f} delta={2**e-(f+1) if e else 0}'[:120])
        sys.stdout.flush()
