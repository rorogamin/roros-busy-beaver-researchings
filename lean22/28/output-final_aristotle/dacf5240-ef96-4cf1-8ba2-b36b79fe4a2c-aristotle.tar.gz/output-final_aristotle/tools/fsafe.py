"""At every F creation, check the 'arena' safety criterion via the stride counter.

After `W <B1 -> <A F`, the head is <A on top of the remaining left stack S with the
wall F immediately on its right.  The head's excursion into S is exactly the stride
counter: n = 1 at the top, W: n -> 2n, X: n -> ceil(n/2), Z: n -> floor(n/2).
If n reaches 0 inside S the head comes back out and consumes the F (safe);
if it never does, the head reaches the left end while F is present (fatal).
"""
import sys
from blocksim import bstep, stride, Stuck, GRULE


def counter_prefix(S):
    """Return (safe, prefix_length, trajectory) for the stride counter on S."""
    n = 1
    traj = []
    for i, b in enumerate(S):
        traj.append(n)
        if b == 'W':
            n = 2 * n
        elif b == 'X':
            n = (n + 1) // 2
        elif b == 'Z':
            n = n // 2
        elif b == 'L':
            return False, i, traj
        else:
            return None, i, traj   # unknown block (J, K...)
        if n == 0:
            return True, i + 1, traj
    return False, len(S), traj


def scan(member, nsteps, use_stride=True):
    lt, st, rt = ['L'], 'R', ['R1']
    total = 5
    stats = []
    for i in range(nsteps):
        if use_stride and st == 'L':
            s = stride(lt)
            if s is not None:
                lt, k = s
                st = 'R'
                total += k
                continue
        if st == 'B' and lt and lt[0] == 'W':
            S = lt[1:]
            safe, pl, traj = counter_prefix(S)
            stats.append((i, safe, pl, ''.join(S[:pl]), max(traj)))
        try:
            lt, st, rt, k = bstep(member, lt, st, rt)
        except Stuck as e:
            return stats, f'STUCK at {i}: {e}'
        total += k
    return stats, f'ok, {nsteps} steps, ~10^{len(str(total))-1} base steps'


if __name__ == '__main__':
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
    for member in GRULE:
        stats, status = scan(member, n)
        bad = [s for s in stats if s[1] is not True]
        pls = [s[2] for s in stats]
        print(f'{member}: {status}; {len(stats)} F creations; '
              f'unsafe/unknown: {len(bad)}; prefix lengths max {max(pls) if pls else 0}')
        for s in stats[:6]:
            print('    ', s)
        if bad:
            print('   BAD:', bad[:3])
