"""Phase-level log of a member: the shift map of every reset phase, and the
counter value at every `<B1` event.

For each *overflow* (the head reaching the left end) we print the parameters
(c, d, e, f) of the shift map of the word the following reset phase re-parses,
as defined in RequestProject/BB25/Phase.lean, together with the pending digit
the reset ends in.  For each `<B1` event (the only place the machine can halt)
we print the counter value `cval` of the left stack.

Exploratory only: nothing here is machine-checked.

    python3 tools/phases.py 2LB 200000
"""
import sys
from blocksim import GRULE
import fastsim as F

DIGITS = ('X', 'V', 'Y', 'U')


def cval(lt):
    """Value of the counter carried by the left stack (bottom-first list)."""
    v = 0
    for b in lt[1:]:
        if b == 'X':
            v = 2 * v
        elif b == 'Z':
            v = 2 * v + 1
        elif b == 'W':
            v = v // 2
        else:
            return None
    return v


# --- the shift map (SMap of Phase.lean) ------------------------------------

def push(p):
    c, d, e, f = p
    return (c, d, e + 1, 2 * f + 1)


def pop(p):
    c, d, e, f = p
    return (c, d + 1, 0, 0) if e == 0 else (c, d, e - 1, f // 2)


def dec(p):
    c, d, e, f = p
    return (c + 2 ** d, d, e, 2 ** e - 1) if f == 0 else (c, d, e, f - 1)


def rmap(ph, word):
    """Shift map of `word` read in the reset phase starting in phase `ph`
    (True = pending 2>).  Returns (phase, (c, d, e, f))."""
    p = (0, 0, 0, 0)
    for b in word:
        q = p if ph else dec(p)
        p = push(q) if b in ('V', 'Y') else pop(q)
        ph = b in ('Y', 'U')
    return ph, p


def cmap(word):
    """Shift map of `word` read in the counter phase."""
    p = (0, 0, 0, 0)
    for b in word:
        if b == 'Y':
            p = push(p)
        elif b == 'V':
            p = pop(p)
        elif b == 'X':
            p = pop(dec(p))
        elif b == 'U':
            p = push(dec(p))
        else:
            break
    return p


def run(member, nsteps, maxevents=25):
    lt = ['L']
    rt = ['R1']
    st = 'R'
    grule = GRULE[member]
    overflows = []
    bevents = []
    for i in range(nsteps):
        if st == 'L' and lt == ['L']:
            word = list(reversed(rt))          # nearest the head first
            digits = []
            for b in word:
                if b in DIGITS:
                    digits.append(b)
                else:
                    break
            ph, p = rmap(True, digits)
            overflows.append((i, len(rt), len(digits), p, ph))
            if len(overflows) >= maxevents:
                return overflows, bevents, 'events'
        if st == 'L':
            if F.stride(lt) is not None:
                st = 'R'
                continue
        if st == 'R':
            top = rt[-1]
            if top in ('P1', 'P2'):
                tbl = F.SHIFT1 if top == 'P1' else F.SHIFT2
                if len(rt) == 1:
                    rt[-1] = 'R1' if top == 'P1' else 'R2'
                    continue
                nxt = rt[-2]
                if top == 'P1' and nxt in ('F', 'G'):
                    rt[-1] = 'P2'
                    st = 'L'
                    continue
                if nxt not in tbl:
                    return overflows, bevents, f'DANGER {top} {nxt}'
                rt.pop(); rt.pop(); rt.extend(tbl[nxt]); continue
            if top == 'R':
                rt.pop(); rt.extend(['R', 'V']); st = 'L'; continue
            if top == 'R1':
                rt[-1] = 'R2'; st = 'L'; continue
            if top == 'R2':
                rt.pop(); rt.extend(['R1', 'Y']); st = 'B'
                bevents.append((i, cval(lt), len(lt)))
                continue
            if top == 'X':
                rt[-1] = 'V'; st = 'L'; continue
            if top == 'V':
                rt.pop(); lt.append('W'); continue
            if top == 'Y':
                rt.pop(); lt.append('Z'); continue
            if top == 'U':
                rt[-1] = 'Y'; st = 'L'; continue
            if top == 'F':
                rt[-1] = 'G'; st = 'L'; continue
            if top == 'N1':
                rt[-1] = 'N2'; st = 'L'; continue
            if top == 'N2':
                rt[-1] = 'Y'; st = 'B'
                bevents.append((i, cval(lt), len(lt)))
                continue
            if top == 'G':
                st2, pushl, emit, k = grule
                rt.pop(); rt.extend(reversed(emit)); lt.extend(reversed(pushl))
                st = st2
                if st == 'B':
                    bevents.append((i, cval(lt), len(lt)))
                continue
            return overflows, bevents, f'STUCK A> {top}'
        if st == 'L':
            b = lt[-1]
            if b == 'L':
                rt.append('P2'); st = 'R'; continue
            lt.pop()
            if b == 'W':
                rt.append('X'); continue
            if b == 'Z':
                lt.append('X'); st = 'R'; continue
            if b == 'X':
                rt.append('Y'); continue
            if b == 'J':
                lt.append('X'); rt.append('P2'); st = 'R'; continue
            if b == 'J1':
                rt.append('P2'); rt.append('X'); st = 'L'; continue
            if b == 'J0':
                rt.append('Y'); st = 'B'
                bevents.append((i, cval(lt), len(lt)))
                continue
            if b == 'K0':
                lt.append('K1'); st = 'R'; continue
            if b == 'K1':
                lt.append('X'); rt.append('P2'); st = 'R'; continue
            return overflows, bevents, f'STUCK {b} <A'
        if st == 'B':
            b = lt[-1]
            if b == 'L':
                return overflows, bevents, 'SPINOUT'
            lt.pop()
            if b == 'W':
                rt.append('F'); st = 'L'; continue
            if b == 'Z':
                rt.append('P2'); rt.append('X'); st = 'L'; continue
            if b == 'X':
                rt.append('Y'); continue
            return overflows, bevents, f'HALTS {b} <B1'
    return overflows, bevents, 'ok'


if __name__ == '__main__':
    m = sys.argv[1] if len(sys.argv) > 1 else '2LB'
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 200000
    ne = int(sys.argv[3]) if len(sys.argv) > 3 else 25
    ov, bev, stat = run(m, n, ne)
    print(f'== {m}: reset phases (one per overflow)')
    print(f'{"step":>9} {"|tape|":>7} {"#digits":>8} {"c":>4} {"d":>5} {"e":>5} '
          f'{"f (rebuilt counter)":>24} {"end":>5}')
    for i, ln, nd, (c, d, e, f) in [(a, b, cc, dd) for a, b, cc, dd, _ in ov]:
        pass
    for i, ln, nd, p, ph in ov:
        c, d, e, f = p
        fs = str(f) if f < 10 ** 12 else f'~2^{f.bit_length()}'
        print(f'{i:9d} {ln:7d} {nd:8d} {c:4d} {d:5d} {e:5d} {fs:>24} '
              f'{"2>" if ph else "1>":>5}')
    print(f'== {m}: counter value at the <B1 events')
    for i, v, ln in bev[:ne]:
        vs = str(v) if v is None or v < 10 ** 12 else f'~2^{v.bit_length()}'
        print(f'{i:9d} |L|={ln:6d} cval={vs}'
              + (f'  mod (2,3,5,7)=({v % 2},{v % 3},{v % 5},{v % 7})' if v is not None else ''))
    print(stat)
