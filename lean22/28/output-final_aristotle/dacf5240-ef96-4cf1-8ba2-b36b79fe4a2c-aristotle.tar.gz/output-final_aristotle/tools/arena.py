"""Exploratory study of the "arena" that decides the fate of a 141 block.

When the `<B1` sweep creates an `F = 141` block, the head is immediately to its
left, and until the `F` is reached again the head can only move inside the
region bounded by the left end `^11` and the `F`.  What happens there depends
only on the part `rest` of the left stack that is *below* the `03` that created
the `F`.

This script runs that arena for every short `rest` over {W = 03, X = 11,
Z = 01} and classifies the outcome:

  SURVIVE  the head reaches the `F` (`A> 141 -> <A 241`) and the block is
           consumed -- the machine lives on;
  HALT     a pending `2>` comes to stand in front of the `141` and the machine
           dies;
  TIMEOUT  undecided within the step budget (the arena is a counter, so it can
           run for very long).

The rules used are exactly the block rules verified in the Lean development.
Findings (not machine-checked; the two smallest halting cases are verified in
Lean as `BB25.halts_Bt_of_no_Z_below_W` and `BB25.halts_Bt_WWZL`):

  * `rest = 11^a` always halts (no `01` to turn around at);
  * but `rest = 03 01` halts too, so the presence of a `01` block below the
    `03` is *not* enough to save the machine;
  * most `rest` survive.
"""
import itertools
SHIFT2 = {'X': ['V','P1'], 'V': ['Y','P1'], 'Y': ['Y','P2'], 'U': ['V','P2'],
          'P1': ['V'], 'P2': ['Y']}
SHIFT1 = {'X': ['X','P1'], 'V': ['U','P1'], 'Y': ['U','P2'], 'U': ['X','P2'],
          'P1': ['X'], 'P2': ['U']}
def arena(rest, maxsteps=30000):
    lt = list(rest) + ['L']; st='L'; rt=[]
    for i in range(maxsteps):
        if st=='R':
            if not rt: return 'SURVIVE', i
            b=rt[0]
            if b in ('P1','P2'):
                if len(rt)==1:
                    if b=='P2': return 'HALT', i
                    st, rt = 'L', ['P2']; continue
                tbl = SHIFT1 if b=='P1' else SHIFT2
                rt = tbl[rt[1]]+rt[2:]; continue
            if b=='X': st, rt = 'L', ['V']+rt[1:]; continue
            if b=='V': lt = ['W']+lt; rt = rt[1:]; continue
            if b=='Y': lt = ['Z']+lt; rt = rt[1:]; continue
            if b=='U': st, rt = 'L', ['Y']+rt[1:]; continue
            return 'STUCK'+b, i
        else:
            if lt==['L']: st, rt = 'R', ['P2']+rt; continue
            b=lt[0]
            if b=='W': lt, rt = lt[1:], ['X']+rt; continue
            if b=='X': lt, rt = lt[1:], ['Y']+rt; continue
            if b=='Z': lt, st = ['X']+lt[1:], 'R'; continue
            return 'STUCK'+b, i
    return 'TIMEOUT', maxsteps
counts={}; halting=[]
for n in range(0,7):
    for rest in itertools.product('WXZ', repeat=n):
        r,i=arena(rest); counts[r]=counts.get(r,0)+1
        if r=='HALT': halting.append((''.join(rest),i))
print(counts)
print('halting:', len(halting))
print(sorted(halting, key=lambda s:(len(s[0]),s[1]))[:30])
