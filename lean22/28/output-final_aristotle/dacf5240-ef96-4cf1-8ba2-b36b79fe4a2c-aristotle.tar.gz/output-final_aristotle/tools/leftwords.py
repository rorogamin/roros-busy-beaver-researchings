import sys
from blocksim import GRULE
import fastsim as F

def run(member, nsteps, maxevents=40):
    lt=['L']; rt=['R1']; st='R'; grule=GRULE[member]
    out=[]
    for i in range(nsteps):
        if st=='L' and lt==['L']:
            # word right of the head, nearest-head first
            out.append((i, ''.join(reversed(rt))))
            if len(out)>=maxevents: return out,'events'
        if st=='L':
            if F.stride(lt) is not None:
                st='R'; continue
        if st=='R':
            top=rt[-1]
            if top in ('P1','P2'):
                tbl=F.SHIFT1 if top=='P1' else F.SHIFT2
                if len(rt)==1:
                    rt[-1]='R1' if top=='P1' else 'R2'; continue
                nxt=rt[-2]
                if top=='P1' and nxt in ('F','G'):
                    rt[-1]='P2'; st='L'; continue
                if nxt not in tbl: return out, f'DANGER {top} {nxt}'
                rt.pop(); rt.pop(); rt.extend(tbl[nxt]); continue
            if top=='R': rt.pop(); rt.extend(['R','V']); st='L'; continue
            if top=='R1': rt[-1]='R2'; st='L'; continue
            if top=='R2': rt.pop(); rt.extend(['R1','Y']); st='B'; continue
            if top=='X': rt[-1]='V'; st='L'; continue
            if top=='V': rt.pop(); lt.append('W'); continue
            if top=='Y': rt.pop(); lt.append('Z'); continue
            if top=='U': rt[-1]='Y'; st='L'; continue
            if top=='F': rt[-1]='G'; st='L'; continue
            if top=='N1': rt[-1]='N2'; st='L'; continue
            if top=='N2': rt[-1]='Y'; st='B'; continue
            if top=='G':
                st2,push,emit,k=grule; rt.pop(); rt.extend(reversed(emit)); lt.extend(reversed(push)); st=st2; continue
            return out, f'STUCK A> {top}'
        if st=='L':
            b=lt[-1]
            if b=='L': rt.append('P2'); st='R'; continue
            lt.pop()
            if b=='W': rt.append('X'); continue
            if b=='Z': lt.append('X'); st='R'; continue
            if b=='X': rt.append('Y'); continue
            if b=='J': lt.append('X'); rt.append('P2'); st='R'; continue
            if b=='J1': rt.append('P2'); rt.append('X'); st='L'; continue
            if b=='J0': rt.append('Y'); st='B'; continue
            if b=='K0': lt.append('K1'); st='R'; continue
            if b=='K1': lt.append('X'); rt.append('P2'); st='R'; continue
            return out, f'STUCK {b} <A'
        if st=='B':
            b=lt[-1]
            if b=='L': return out,'SPINOUT'
            lt.pop()
            if b=='W': rt.append('F'); st='L'; continue
            if b=='Z': rt.append('P2'); rt.append('X'); st='L'; continue
            if b=='X': rt.append('Y'); continue
            return out, f'HALTS {b} <B1'
    return out,'ok'

if __name__=='__main__':
    m=sys.argv[1] if len(sys.argv)>1 else '2LB'
    ne=int(sys.argv[2]) if len(sys.argv)>2 else 12
    out,stat=run(m, 10**7, ne)
    for i,w in out: print(f'{i:9d} {w}')
    print(stat)
