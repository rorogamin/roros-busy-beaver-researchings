"""Auxiliary blocks introduced by particular family members."""
from sim import machine, show, A, B
from rules import rule

if __name__ == '__main__':
    m = machine(None)  # these should never read B4
    rule('023 <A', m, [3, 2, 0], A, 'L', [])
    rule('013 <A', m, [3, 1, 0], A, 'L', [])
    rule('003 <A', m, [3, 0, 0], A, 'L', [])
    rule('001 <A', m, [1, 0, 0], A, 'L', [])
    rule('011 <A', m, [1, 1, 0], A, 'L', [])
    rule('A> 101', m, [], A, 'R', [1, 0, 1])
    rule('A> 201', m, [], A, 'R', [2, 0, 1])
