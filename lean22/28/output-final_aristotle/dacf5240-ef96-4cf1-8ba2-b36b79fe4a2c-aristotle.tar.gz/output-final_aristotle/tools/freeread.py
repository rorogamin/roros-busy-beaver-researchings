"""The free (no pending digit) re-reading of a deposited word.

`Y` pushes a one bit, `V` pushes a pop, `X` decrements and then pushes a
pop, `U` decrements and then pushes a one bit.  This is what the head does
after the marker `K0` of `2RA` turns it around without creating a pending
digit.
"""
import itertools
from episode import cval, pdec, bval, adm, good, nbit, nsh


def cdec(s):
    """One decrement of a counter stack (nearest-first list)."""
    if not s:
        return s
    b, t = s[0], s[1:]
    if b == 'Z':
        return ['X'] + t
    if b == 'X':
        return ['Z'] + cdec(t)
    if b == 'W':
        return ['W'] + cdec(cdec(t))
    return s


def ufold(sigma, w):
    s = list(sigma)
    for d in w:
        if d == 'Y':
            s = ['Z'] + s
        elif d == 'V':
            s = ['W'] + s
        elif d == 'X':
            if cval(s) < 1:
                return None
            s = ['W'] + cdec(s)
        elif d == 'U':
            if cval(s) < 1:
                return None
            s = ['Z'] + cdec(s)
        else:
            raise ValueError(d)
    return s


def stacks(n):
    """All admissible counter stacks with n blocks over the bottom."""
    for t in itertools.product('WXZ', repeat=n):
        s = list(t) + ['L']
        if adm(s):
            yield s


if __name__ == '__main__':
    print('sigma with cval 0 : free re-read of P(sigma) ++ [V]')
    bad = 0
    for n in range(0, 8):
        for s in stacks(n):
            if cval(s) != 0:
                continue
            w = pdec(s) + ['V']
            r = ufold(['L'], w)
            if r is None:
                print('  STUCK', ' '.join(s), '->', ' '.join(w))
                bad += 1
                continue
            ok = cval(r) == 0
            if not ok:
                print('  cval != 0:', ' '.join(s), 'w=', ' '.join(w),
                      '-> ', ' '.join(r), 'cval', cval(r), 'bval', bval(r))
                bad += 1
    print('violations:', bad)
