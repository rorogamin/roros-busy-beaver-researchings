"""Event log of the block simulation: F creations, left-end visits, right-end visits."""
import sys
from blocksim import bstep, stride, Stuck, GRULE


def run_events(member, nsteps, use_stride=True):
    lt, st, rt = ['L'], 'R', ['R1']
    total = 5
    events = []
    for i in range(nsteps):
        if use_stride and st == 'L':
            s = stride(lt)
            if s is not None:
                lt, k = s
                st = 'R'
                total += k
                continue
        try:
            lt2, st2, rt2, k = bstep(member, lt, st, rt)
        except Stuck as e:
            events.append((i, total, 'STUCK', str(e), (lt, st, rt)))
            return events
        # detect events
        if st == 'B' and lt and lt[0] == 'W':
            events.append((i, total, 'Fcreate', len(lt2), (list(lt), st, list(rt))))
        if st == 'L' and lt == ['L']:
            events.append((i, total, 'leftend', len(rt), (list(lt), st, list(rt))))
        if st == 'R' and rt and rt[0] == 'G':
            events.append((i, total, 'Gconsume', len(lt), (list(lt), st, list(rt))))
        if st == 'R' and rt == ['R2']:
            events.append((i, total, 'rightend', len(lt), (list(lt), st, list(rt))))
        lt, st, rt = lt2, st2, rt2
        total += k
    events.append((nsteps, total, 'END', len(lt), (lt, st, rt)))
    return events


def compress(xs):
    out = []
    for x in xs:
        if out and out[-1][0] == x:
            out[-1][1] += 1
        else:
            out.append([x, 1])
    return ' '.join(a if b == 1 else f'{a}^{b}' for a, b in out)


if __name__ == '__main__':
    member = sys.argv[1] if len(sys.argv) > 1 else '2LB'
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 20000
    stride_on = len(sys.argv) <= 3 or sys.argv[3] != 'nostride'
    ev = run_events(member, n, stride_on)
    for (i, total, kind, extra, cfg) in ev:
        lt, st, rt = cfg
        if kind in ('STUCK', 'END', 'Fcreate', 'Gconsume'):
            print(f'{i:8d} {kind:9s} {extra}\n    L: {compress(lt)}\n    R: {st} {compress(rt)}')
        else:
            print(f'{i:8d} {kind:9s} {extra}')
