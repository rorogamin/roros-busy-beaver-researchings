"""Event log: interleaved overflow (reset word shift map) and <B1 events,
with the top structure of the left stack at each <B1.

Exploratory only.
    cd tools && PYTHONPATH=. python3 fdyn.py 2LB 400000 30
"""
import sys
from blocksim import GRULE
import fastsim as F
from phases import rmap, cval

DIGITS = ('X', 'V', 'Y', 'U')


def topstruct(lt):
    """(#leading X blocks from the top, next block or None)."""
    i = len(lt) - 1
    k = 0
    while i >= 0 and lt[i] == 'X':
        k += 1
        i -= 1
    return k, (lt[i] if i >= 0 else None)


def run(member, nsteps, maxevents=30):
    lt = ['L']; rt = ['R1']; st = 'R'
    grule = GRULE[member]
    ev = []
    def note(x):
        ev.append(x)
        return len(ev) >= maxevents
    for i in range(nsteps):
        if st == 'L' and lt == ['L']:
            word = list(reversed(rt))
            digits = []
            for b in word:
                if b in DIGITS: digits.append(b)
                else: break
            ph, p = rmap(True, digits)
            if note(('OF', i, p, ph, len(digits), len(word), word[len(digits)] if len(digits) < len(word) else '$')):
                return ev, 'events'
        if st == 'L':
            if F.stride(lt) is not None:
                st = 'R'; continue
        if st == 'R':
            top = rt[-1]
            if top in ('P1','P2'):
                tbl = F.SHIFT1 if top=='P1' else F.SHIFT2
                if len(rt)==1:
                    rt[-1] = 'R1' if top=='P1' else 'R2'; continue
                nxt = rt[-2]
                if top=='P1' and nxt in ('F','G'):
                    rt[-1]='P2'; st='L'; continue
                if nxt not in tbl:
                    return ev, f'DANGER {top} {nxt}'
                rt.pop(); rt.pop(); rt.extend(tbl[nxt]); continue
            if top=='R': rt.pop(); rt.extend(['R','V']); st='L'; continue
            if top=='R1': rt[-1]='R2'; st='L'; continue
            if top=='R2':
                rt.pop(); rt.extend(['R1','Y']); st='B'
                if note(('B1', i, cval(lt), topstruct(lt), len(lt))): return ev,'events'
                continue
            if top=='X': rt[-1]='V'; st='L'; continue
            if top=='V': rt.pop(); lt.append('W'); continue
            if top=='Y': rt.pop(); lt.append('Z'); continue
            if top=='U': rt[-1]='Y'; st='L'; continue
            if top=='F': rt[-1]='G'; st='L'; continue
            if top=='N1': rt[-1]='N2'; st='L'; continue
            if top=='N2':
                rt[-1]='Y'; st='B'
                if note(('B1', i, cval(lt), topstruct(lt), len(lt))): return ev,'events'
                continue
            if top=='G':
                st2,pushl,emit,k = grule
                rt.pop(); rt.extend(reversed(emit)); lt.extend(reversed(pushl)); st=st2
                if st=='B':
                    if note(('B1', i, cval(lt), topstruct(lt), len(lt))): return ev,'events'
                continue
            return ev, f'STUCK A> {top}'
        if st=='L':
            b = lt[-1]
            if b=='L': rt.append('P2'); st='R'; continue
            lt.pop()
            if b=='W': rt.append('X'); continue
            if b=='Z': lt.append('X'); st='R'; continue
            if b=='X': rt.append('Y'); continue
            if b=='J': lt.append('X'); rt.append('P2'); st='R'; continue
            if b=='J1': rt.append('P2'); rt.append('X'); st='L'; continue
            if b=='J0':
                rt.append('Y'); st='B'
                if note(('B1', i, cval(lt), topstruct(lt), len(lt))): return ev,'events'
                continue
            if b=='K0': lt.append('K1'); st='R'; continue
            if b=='K1': lt.append('X'); rt.append('P2'); st='R'; continue
            return ev, f'STUCK {b} <A'
        if st=='B':
            b = lt[-1]
            if b=='L': return ev, 'SPINOUT'
            lt.pop()
            if b=='W': rt.append('F'); st='L'; continue
            if b=='Z': rt.append('P2'); rt.append('X'); st='L'; continue
            if b=='X': rt.append('Y'); continue
            return ev, f'HALTS {b} <B1'
    return ev, 'ok'


def fmt(x):
    if x is None: return 'None'
    return str(x) if x < 10**15 else f'~2^{x.bit_length()}({x % 256})'


if __name__ == '__main__':
    m = sys.argv[1] if len(sys.argv)>1 else '2LB'
    n = int(sys.argv[2]) if len(sys.argv)>2 else 400000
    ne = int(sys.argv[3]) if len(sys.argv)>3 else 30
    ev, stat = run(m, n, ne)
    print(f'== {m} status={stat}')
    for e in ev:
        if e[0]=='OF':
            _, i, (c,d,en,f), ph, nd, nw, after = e
            print(f'{i:8d} OF  c={c} d={d} e={en:6d} f={fmt(f):>22} end={"2>" if ph else "1>"} ndig={nd} |w|={nw} after={after}')
        else:
            _, i, v, (k, nxt), ln = e
            print(f'{i:8d} B1  cval={fmt(v):>22} topX^{k} next={nxt} |L|={ln}')
