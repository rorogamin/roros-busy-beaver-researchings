"""Explore the `W` case episode of the `<B1` sweep for the members `2RA`
and `1RB`: start from the configuration `c <A 141 22^r 1$` created by a pop
of the sweep and run the block simulator until the next checkpoint
`s <B1 22 1$`.

Usage:  python3 episode.py
"""
from blocksim import bstep, Stuck

PURE = ('L', 'W', 'X', 'Z')


def cval(lt):
    v = 0
    for b in reversed(lt):
        if b == 'L':
            v = 0
        elif b == 'X':
            v = 2 * v
        elif b == 'Z':
            v = 2 * v + 1
        elif b == 'W':
            v = v // 2
        else:
            raise ValueError('cval: ' + b)
    return v


def pdec(lt):
    """The decoded word, in tape order (deepest block first)."""
    out = []
    for i in range(len(lt) - 1, -1, -1):
        b = lt[i]
        if b == 'L':
            out = []
        elif b in ('X', 'Z'):
            out.append('Y')
        elif b == 'W':
            out.append('V' if cval(lt[i + 1:]) % 2 == 1 else 'X')
        else:
            raise ValueError('pdec: ' + b)
    return out


def rstep(d, a):
    if d == 'Y':
        return 2 * a + 1
    if d == 'V':
        return 2 * a
    if d == 'X':
        return a // 2 - 1 if a >= 0 else -((-a + 1) // 2) - 1
    raise ValueError(d)


def rrun(w, a):
    for d in w:
        a = rstep(d, a)
    return a


def bval(lt):
    return rrun(pdec(lt), 0)


def nbit(lt):
    n = 0
    for b in lt:
        if b == 'L':
            return n
        if b in ('X', 'Z'):
            n += 1
    return n


def nsh(lt):
    n = 0
    for b in lt:
        if b == 'L':
            return n
        if b == 'W':
            n += 1
    return n


def suffixes(lt):
    return [lt[i:] for i in range(len(lt) + 1)]


def adm(lt):
    return all(nsh(t) <= nbit(t) for t in suffixes(lt))


def good(lt):
    return all(cval(t) <= bval(t) for t in suffixes(lt))


def run_to_cp(member, lt, st, rt, limit=2000000):
    """Run until a checkpoint `s <B1 22 1$` is reached."""
    k = 0
    for i in range(limit):
        if st == 'B' and rt == ['Y', 'R1'] and all(b in PURE for b in lt):
            return ('cp', lt, k, i)
        try:
            lt, st, rt, c = bstep(member, lt, st, rt)
        except Stuck as e:
            return ('stuck: %s' % e, (lt, st, rt), k, i)
        k += c
    return ('limit', (lt, st, rt), k, limit)


def wcase(member, c, r, limit=2000000):
    return run_to_cp(member, list(c), 'L', ['F'] + ['Y'] * r + ['R1'], limit)


def report(member, c, r):
    st, lt, k, n = wcase(member, c, r)
    if st != 'cp':
        print('%-4s c=%-28s r=%-3d -> %s' % (member, ''.join(x + ' ' for x in c), r, st))
        return
    pure = all(b in PURE for b in lt)
    info = 'pure=%s' % pure
    if pure:
        info += ' cval=%-6d bval=%-6d adm=%-5s good=%-5s' % (
            cval(lt), bval(lt), adm(lt), good(lt))
    print('%-4s c=%-26s r=%-3d -> %-34s %s  (%d blk, %d base)'
          % (member, ' '.join(c), r, ' '.join(lt), info, n, k))


if __name__ == '__main__':
    import itertools
    stacks = [
        ['X', 'X', 'X', 'Z', 'Z', 'Z', 'L'],
        ['Z', 'Z', 'L'],
        ['X', 'Z', 'Z', 'L'],
        ['Z', 'X', 'Z', 'L'],
        ['X', 'X', 'Z', 'Z', 'L'],
        ['W', 'Z', 'Z', 'Z', 'L'],
        ['Z', 'W', 'Z', 'Z', 'Z', 'L'],
        ['X', 'Z', 'W', 'Z', 'Z', 'Z', 'L'],
    ]
    for member in ('2RA', '1RB'):
        for c in stacks:
            if cval(c) < 2:
                continue
            for r in (2, 3, 4, 5, 6):
                report(member, c, r)
        print()
