"""Trace the local episode of `1RB` after the marker `J1` has dissolved.

Start at  <c2, Lt, X P2 rest_n>  and run the block simulator until a
checkpoint-looking configuration is reached.
"""
import itertools
from blocksim import bstep, Stuck
from episode import cval, pdec, bval, nbit, nsh, rrun

PURE = ('W', 'X', 'Z')


def kword(n):
    return ['Y'] * n + ['V', 'Y', 'Y', 'V', 'X'] + ['V'] * (n - 1 if n >= 1 else 0)


def restn(n):
    if n == 0:
        return ['X', 'P2', 'Y', 'Y', 'R1']
    if n == 1:
        return ['Y', 'V', 'P2', 'Y', 'Y', 'R1']
    return kword(n) + ['R']


def adm(lt):
    for i in range(len(lt) + 1):
        t = lt[i:]
        if nsh(t) > nbit(t):
            return False
    return True


def good(lt):
    for i in range(len(lt) + 1):
        t = lt[i:]
        if cval(t) > bval(t):
            return False
    return True


def stacks(maxlen):
    out = []
    for n in range(0, maxlen + 1):
        for tup in itertools.product(PURE, repeat=n):
            s = list(tup) + ['L']
            if adm(s) and good(s):
                out.append(s)
    return out


def trace(c2, n, limit=400, verbose=False):
    lt, st, rt = list(c2), 'L', ['X', 'P2'] + restn(n)
    hist = []
    for i in range(limit):
        if verbose:
            print(i, lt, st, rt)
        hist.append((list(lt), st, list(rt)))
        # stop at a checkpoint  s <B1 22 1$
        if st == 'B' and rt == ['Y', 'R1']:
            return 'CP', lt, i
        if st == 'R' and rt == ['R']:
            return 'END', lt, i
        try:
            lt, st, rt, k = bstep('1RB', lt, st, rt)
        except Stuck as e:
            return 'STUCK:' + str(e), (lt, st, rt), i
    return 'LIMIT', (lt, st, rt), limit


if __name__ == '__main__':
    import sys
    ss = stacks(5)
    print('stacks', len(ss))
    res = {}
    for c2 in ss:
        a = cval(c2)
        b = bval(c2)
        if a > 1:
            continue
        if b < a + 2:
            continue
        if a % 2 == 0 and b < a + 4:
            continue
        for n in range(0, 5):
            r = trace(c2, n)
            res.setdefault(r[0], []).append((c2, n, r[1]))
    for k, v in res.items():
        print(k, len(v), v[:3])
