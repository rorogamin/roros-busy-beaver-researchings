"""The left-stride ("longitudinal") computation on the left tape.

Left-tape blocks, nearest to the head first:  W = 03, X = 11, Z = 01.
`strideN(bs, n)` = effect of `n` visits of the `<A` head at the right end of
the segment `bs`: returns the new segment and the number of base steps, or
None if the head runs off the left end of `bs`.
"""
from sim import machine, step, A


def strideN(bs, n):
    if n == 0:
        return (list(bs), 0)
    if not bs:
        return None
    b, rest = bs[0], bs[1:]
    if b == 'W':
        r = strideN(rest, 2 * n)
        return None if r is None else (['W'] + r[0], r[1] + 5 * n)
    if b == 'X':
        r = strideN(rest, (n + 1) // 2)
        if r is None:
            return None
        nb = 'X' if n % 2 == 0 else 'Z'
        return ([nb] + r[0], r[1] + 7 * (n // 2) + (0 if n % 2 == 0 else 4))
    if b == 'Z':
        r = strideN(rest, n // 2)
        if r is None:
            return None
        nb = 'Z' if n % 2 == 0 else 'X'
        return ([nb] + r[0], r[1] + 7 * (n // 2) + (0 if n % 2 == 0 else 3))
    raise ValueError(b)


DEN = {'W': [3, 0], 'X': [1, 1], 'Z': [1, 0]}


def den(bs):
    out = []
    for b in bs:
        out += DEN[b]
    return out


def parse_left(tape):
    """tape given left-to-right; return blocks nearest-first."""
    assert len(tape) % 2 == 0
    pairs = [tape[i:i + 2] for i in range(0, len(tape), 2)]
    inv = {'03': 'W', '11': 'X', '01': 'Z'}
    return [inv[p] for p in reversed(pairs)]


def check(tape, tail=(), rt=()):
    """Compare the stride prediction with the real simulation."""
    bs = parse_left(tape)
    res = strideN(bs, 1)
    m = machine(None)
    c = (den(bs) + list(tail), A, 'L', list(rt))
    if res is None:
        return bs, None, None
    bs2, k = res
    for _ in range(k):
        c = step(m, c)
        assert c is not None
    ok = c == (den(bs2) + list(tail), A, 'R', list(rt))
    return bs2, k, ok


if __name__ == '__main__':
    # the worked example from the notes: step 268 -> step 355
    tape = '1111010301111101030303'
    bs2, k, ok = check(tape)
    print('blocks in :', parse_left(tape))
    print('blocks out:', bs2)
    print('steps     :', k, '(expected 355-268 =', 355 - 268, ')')
    print('matches simulation:', ok)
    print('tape out  :', ''.join(map(str, reversed(den(bs2)))))
