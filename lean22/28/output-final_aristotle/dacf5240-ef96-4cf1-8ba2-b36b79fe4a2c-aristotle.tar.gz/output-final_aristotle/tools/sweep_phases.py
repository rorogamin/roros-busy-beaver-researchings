"""Sweep of tools/phases.py over all 13 members (exploratory, not machine-checked).

    cd tools && PYTHONPATH=. python3 sweep_phases.py > phases_sweep.txt
"""
import sys, phases
from blocksim import GRULE
for m in GRULE:
    ov, bev, stat = phases.run(m, 400000, 14)
    print(f'=== {m}  status={stat}')
    print('  resets: ' + ', '.join(f'(c={c},d={d},e={e},f%8={f%8},odd={f%2},end={"2>" if ph else "1>"})' for _,_,_,(c,d,e,f),ph in ov))
    print('  B1 cvals: ' + ', '.join('None' if v is None else f'{v%2}|{v%3}|{v%5}' for _,v,_ in bev[:14]))
    print('  B1 raw: ' + ', '.join('None' if v is None else (str(v) if v<10**9 else f'~2^{v.bit_length()}') for _,v,_ in bev[:8]))
    sys.stdout.flush()
