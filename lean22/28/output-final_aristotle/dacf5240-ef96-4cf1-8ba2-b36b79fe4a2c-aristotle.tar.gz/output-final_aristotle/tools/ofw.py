"""Exploration of the overflow word `ofw` and the cost of the reset that reads it.

Head-first lists (the Lean convention of `Overflow.lean`): the first element of
the stack is the block nearest the machine head, the last is the left end `L`.
The word `ofw s` is in tape order (deepest block first), which is the order the
reset phase reads it in.

Exploratory only: nothing here is machine-checked.
"""
from fractions import Fraction
from itertools import product


def cval(s):
    if not s:
        return 0
    b, r = s[0], s[1:]
    if b == 'X':
        return 2 * cval(r)
    if b == 'Z':
        return 2 * cval(r) + 1
    if b == 'W':
        return cval(r) // 2
    return 0


def cdec(s):
    if not s:
        return s
    b, r = s[0], s[1:]
    if b == 'Z':
        return ['X'] + r
    if b == 'X':
        return ['Z'] + cdec(r)
    if b == 'W':
        return ['W'] + cdec(cdec(r))
    return s


def ofw(s):
    if not s:
        return []
    b, r = s[0], s[1:]
    if b == 'X':
        return ofw(r) + ['Y']
    if b == 'W':
        if cval(r) == 0:
            return ofw(r) + ['X']
        return ofw(cdec(r)) + ['V']
    return []


# --- the reset shift map ----------------------------------------------------

def push(p):
    c, d, e, f = p
    return (c, d, e + 1, 2 * f + 1)


def pop(p):
    c, d, e, f = p
    if e == 0:
        return (c, d + 1, 0, 0)
    return (c, d, e - 1, f // 2)


def dec(p):
    c, d, e, f = p
    if f == 0:
        return (c + 2 ** d, d, e, 2 ** e - 1)
    return (c, d, e, f - 1)


def rphase(b):
    return b in ('Y', 'U')


def rstep(ph, p, b):
    q = p if ph else dec(p)
    if b in ('V', 'Y'):
        return push(q)
    if b in ('X', 'U'):
        return pop(q)
    return q


def rmap(w, ph=True, p=(0, 0, 0, 0)):
    for b in w:
        p = rstep(ph, p, b)
        ph = rphase(b)
    return ph, p


def rcost(w, ph=True, p=(0, 0, 0, 0)):
    tot = Fraction(0)
    for b in w:
        if not ph:
            tot += Fraction(1, 2 ** p[2])
        p = rstep(ph, p, b)
        ph = rphase(b)
    return tot


def stacks(n):
    """All block stacks of `n` blocks over the left end, head-first."""
    for t in product('WXZ', repeat=n):
        yield list(t) + ['L']


if __name__ == '__main__':
    import sys
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    worst = {}
    for n in range(0, N + 1):
        for s in stacks(n):
            if cval(s) != 0:
                continue
            w = ofw(s)
            _, p = rmap(w)
            c = rcost(w)
            key = n
            if key not in worst or c > worst[key][0]:
                worst[key] = (c, s, w, p)
    for n in sorted(worst):
        c, s, w, p = worst[n]
        print(n, float(c), ''.join(s), ''.join(w), p)
