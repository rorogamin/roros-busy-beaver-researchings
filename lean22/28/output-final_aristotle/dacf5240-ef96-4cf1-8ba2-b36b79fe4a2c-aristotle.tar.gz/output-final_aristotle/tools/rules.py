"""Discover exact step counts for the longitudinal rules.

For each rule we give the left-hand side as a directed configuration whose
tails are *generic*: we instantiate the tails with two different random
fillings and only accept a step count n at which both runs agree on the
part of the tape the head has actually visited, and the head sits at the
same place relative to the pattern.
"""
import random
from sim import machine, step, show, A, B

random.seed(0)


def pad(xs, tail):
    return list(xs) + list(tail)


def trace(m, l, q, d, r, tail_l, tail_r, n):
    c = (pad(l, tail_l), q, d, pad(r, tail_r))
    out = []
    for i in range(n + 1):
        out.append(c)
        if c is None:
            break
        c = step(m, c)
    return out


def find(m, l, q, d, r, maxn=60, nl=8, nr=8):
    """Return list of (n, generic config) for n = 1..maxn where the config is
    independent of the tails (i.e. equals prefix + same tails)."""
    res = []
    tls = [[random.randrange(5) for _ in range(nl)] for _ in range(2)]
    trs = [[random.randrange(5) for _ in range(nr)] for _ in range(2)]
    tr = [trace(m, l, q, d, r, tls[k], trs[k], maxn) for k in range(2)]
    for n in range(1, maxn + 1):
        cs = [t[n] if n < len(t) else None for t in tr]
        if any(c is None for c in cs):
            res.append((n, 'HALT/short'))
            break
        ok = True
        pl = pr = None
        for k, c in enumerate(cs):
            L, q2, d2, R = c
            if len(L) < len(tls[k]) or L[len(L) - len(tls[k]):] != tls[k]:
                ok = False
                break
            if len(R) < len(trs[k]) or R[len(R) - len(trs[k]):] != trs[k]:
                ok = False
                break
            a = (L[:len(L) - len(tls[k])], q2, d2, R[:len(R) - len(trs[k])])
            if k == 0:
                pl = a
            else:
                pr = a
        if ok and pl == pr:
            res.append((n, pl))
    return res


def rule(name, m, l, q, d, r, maxn=40):
    print(f'--- {name}:  {show((l, q, d, r))}')
    for n, c in find(m, l, q, d, r, maxn):
        print('   ', n, show(c) if c != 'HALT/short' else c)


if __name__ == '__main__':
    m = machine(None)
    # shared rules
    rule('W <A  (03 <A)', m, [3, 0], A, 'L', [])
    rule('Z <A  (01 <A)', m, [1, 0], A, 'L', [])
    rule('X <A  (11 <A)', m, [1, 1], A, 'L', [])
    rule('W <B1 (03 <B1)', m, [3, 0], B, 'L', [1])
    rule('Z <B1 (01 <B1)', m, [1, 0], B, 'L', [1])
    rule('X <B1 (11 <B1)', m, [1, 1], B, 'L', [1])
    rule('A> 11', m, [], A, 'R', [1, 1])
    rule('A> 21', m, [], A, 'R', [2, 1])
    rule('A> 22', m, [], A, 'R', [2, 2])
    rule('A> 12', m, [], A, 'R', [1, 2])
    rule('A> 141', m, [], A, 'R', [1, 4, 1])
