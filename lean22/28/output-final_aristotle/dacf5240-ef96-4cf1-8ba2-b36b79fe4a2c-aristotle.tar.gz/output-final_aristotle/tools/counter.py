"""The left stack is a shift-overflow counter.

Reading the left stack from the BOTTOM (the left end) to the TOP (nearest the head),
with value v starting at 0:

    X = 11  ->  v := 2v          (append the bit 0)
    Z = 01  ->  v := 2v + 1      (append the bit 1)
    W = 03  ->  v := v // 2      (shift: delete the last bit)

Then:
  * one excursion of the head into the left stack decrements v by one;
  * the head reaches the left end exactly when v = 0;
  * a block popped off the right stack pushes a digit:  V=21 -> W, Y=22 -> Z,
    and the head turns at X=11 (-> V) and U=12 (-> Y).
"""
import sys
from blocksim import GRULE, Stuck
import blocksim as bs


def value(lt):
    """lt is nearest-the-head first, ending with 'L'."""
    v = 0
    for b in reversed(lt):
        if b == 'L':
            continue
        elif b == 'X':
            v = 2 * v
        elif b == 'Z':
            v = 2 * v + 1
        elif b == 'W':
            v = v // 2
        else:
            return None
    return v


def check_stride_decrements(n=200000):
    """Empirical check: a full left excursion decrements the counter by one."""
    import random
    random.seed(1)
    bad = 0
    for _ in range(n):
        k = random.randrange(1, 12)
        S = [random.choice('WXZ') for _ in range(k)] + ['L']
        v = value(S)
        out = bs.stride(S)
        if v == 0:
            if out is not None:
                bad += 1
        else:
            if out is None or value(out[0]) != v - 1:
                bad += 1
                if bad < 5:
                    print('BAD', S, v, out)
    return bad


if __name__ == '__main__':
    print('stride decrement check, bad =', check_stride_decrements(20000))
