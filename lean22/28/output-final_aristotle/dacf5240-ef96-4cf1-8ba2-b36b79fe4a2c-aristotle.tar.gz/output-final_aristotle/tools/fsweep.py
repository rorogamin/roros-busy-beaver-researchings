import sys
from blocksim import GRULE
import finv

for m in GRULE:
    res, stat = finv.collect(m, 400000, 14)
    print(f'=== {m} {stat}')
    rows=[]
    for i,w,(c,d,e,f),ph,after in res:
        st = finv.steps(w)
        okbl = (f.bit_length()==e)
        # step-wise: is bit_length(f) == e at every step?
        allbl = all(p[3].bit_length()==p[2] or p[2]==0 for _,p,_ in st)
        rows.append(f'(e={e},bl={f.bit_length()},f%8={f%8},allbl={int(allbl)},after={after})')
    print('  ' + ', '.join(rows))
    sys.stdout.flush()
