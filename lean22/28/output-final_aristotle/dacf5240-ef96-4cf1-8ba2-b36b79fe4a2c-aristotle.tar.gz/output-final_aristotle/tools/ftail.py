import sys
from blocksim import GRULE
import finv, fdyn
from fractions import Fraction

# 1. tails of words and f mod 32
for m in GRULE:
    res,stat = finv.collect(m,400000,14)
    print(f'=== {m}')
    for i,w,(c,d,e,f),ph,after in res:
        print(f'   |w|={len(w):5d} tail={"".join(w[-8:]):>8} head={"".join(w[:6]):>6} f%32={f%32:3d} after={after}')
    sys.stdout.flush()
print()
# 2. does cval at the <B1 equal f-1 from the preceding overflow?
for m in GRULE:
    ev,stat = fdyn.run(m,400000,40)
    last=None; ok=[]; 
    for e in ev:
        if e[0]=='OF': last=e[2][3]
        else:
            v=e[2]
            ok.append('None' if v is None else ('f-1' if last is not None and v==last-1 else f'OTHER({v})'))
    print(f'{m:4s} {stat:12s} ' + ' '.join(ok))
