"""Trace the local drain of the `2RA` marker episode.

Start at `Z^j K0 c2 <A 11 2> 22 22 1$` (the configuration (14) of the notes)
and watch the marker: it should stay `K0` until one decrement excursion
reaches it, become `K1`, and then the next overflow should turn the head
around at `K1`, creating the pending `2>`.
"""
from blocksim import bstep, Stuck
from episode import cval, pdec, bval, adm, good, nbit, nsh


def local(lt):
    """The part of the stack above the marker, plus the marker."""
    for i, b in enumerate(lt):
        if b in ('K0', 'K1'):
            return lt[:i], b
    return lt, None


def trace(j, c2, limit=100000, show=False):
    lt = ['Z'] * j + ['K0'] + list(c2)
    st, rt = 'L', ['X', 'P2', 'Y', 'Y', 'R1']
    mark = 'K0'
    events = []
    for i in range(limit):
        above, m = local(lt)
        if m != mark:
            events.append(('flip', i, list(lt), st, list(rt)))
            mark = m
        if m is None:
            events.append(('gone', i, list(lt), st, list(rt)))
            return events
        if show:
            print(i, ' '.join(lt), st, ' '.join(rt))
        try:
            lt, st, rt, k = bstep('2RA', lt, st, rt)
        except Stuck as e:
            events.append(('stuck', i, str(e)))
            return events
    events.append(('limit',))
    return events


def shape(j):
    """The shape predicted by the notes at each drain round (nearest first)."""
    n = j + 1
    out = []
    for r in range(1, n):
        s = (['W'] * (r + 1) + ['Z', 'X', 'W'] + ['Z'] * r + ['X']
             + ['Z'] * (n - r - 1))
        out.append(s)
    return out


if __name__ == '__main__':
    for j in range(0, 6):
        c2 = ['X', 'Z', 'Z', 'L']
        ev = trace(j, c2)
        print('j =', j)
        for e in ev:
            if e[0] in ('flip', 'gone'):
                print('  %-5s step %-4d  %s  %s  %s'
                      % (e[0], e[1], ' '.join(e[2]), e[3], ' '.join(e[4])))
            else:
                print('  ', e)
        print('  predicted round shapes:', [' '.join(s) for s in shape(j)])
